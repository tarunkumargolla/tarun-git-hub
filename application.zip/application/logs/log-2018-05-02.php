<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-02 06:29:22 --> Config Class Initialized
INFO - 2018-05-02 06:29:22 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:29:22 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:29:22 --> Utf8 Class Initialized
INFO - 2018-05-02 06:29:22 --> URI Class Initialized
INFO - 2018-05-02 06:29:22 --> Router Class Initialized
INFO - 2018-05-02 06:29:22 --> Output Class Initialized
INFO - 2018-05-02 06:29:22 --> Security Class Initialized
DEBUG - 2018-05-02 06:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:29:22 --> Input Class Initialized
INFO - 2018-05-02 06:29:22 --> Language Class Initialized
INFO - 2018-05-02 06:29:22 --> Loader Class Initialized
INFO - 2018-05-02 06:29:22 --> Helper loaded: common_helper
INFO - 2018-05-02 06:29:22 --> Database Driver Class Initialized
ERROR - 2018-05-02 06:29:22 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-02 06:29:22 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-02 06:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:29:23 --> Email Class Initialized
INFO - 2018-05-02 06:29:23 --> Controller Class Initialized
INFO - 2018-05-02 06:29:23 --> Helper loaded: form_helper
INFO - 2018-05-02 06:29:23 --> Form Validation Class Initialized
INFO - 2018-05-02 06:29:23 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:29:23 --> Helper loaded: url_helper
INFO - 2018-05-02 06:29:23 --> Model Class Initialized
INFO - 2018-05-02 06:29:23 --> Model Class Initialized
INFO - 2018-05-02 06:29:23 --> Model Class Initialized
INFO - 2018-05-02 06:29:23 --> Config Class Initialized
INFO - 2018-05-02 06:29:23 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:29:23 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:29:23 --> Utf8 Class Initialized
INFO - 2018-05-02 06:29:23 --> URI Class Initialized
INFO - 2018-05-02 06:29:23 --> Router Class Initialized
INFO - 2018-05-02 06:29:23 --> Output Class Initialized
INFO - 2018-05-02 06:29:23 --> Security Class Initialized
DEBUG - 2018-05-02 06:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:29:23 --> Input Class Initialized
INFO - 2018-05-02 06:29:23 --> Language Class Initialized
INFO - 2018-05-02 06:29:23 --> Loader Class Initialized
INFO - 2018-05-02 06:29:23 --> Helper loaded: common_helper
INFO - 2018-05-02 06:29:23 --> Database Driver Class Initialized
INFO - 2018-05-02 06:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:29:23 --> Email Class Initialized
INFO - 2018-05-02 06:29:23 --> Controller Class Initialized
INFO - 2018-05-02 06:29:23 --> Helper loaded: form_helper
INFO - 2018-05-02 06:29:23 --> Form Validation Class Initialized
INFO - 2018-05-02 06:29:23 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:29:23 --> Helper loaded: url_helper
INFO - 2018-05-02 06:29:23 --> Model Class Initialized
INFO - 2018-05-02 06:29:23 --> Model Class Initialized
INFO - 2018-05-02 06:29:23 --> Config Class Initialized
INFO - 2018-05-02 06:29:23 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:29:23 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:29:23 --> Utf8 Class Initialized
INFO - 2018-05-02 06:29:23 --> URI Class Initialized
DEBUG - 2018-05-02 06:29:23 --> No URI present. Default controller set.
INFO - 2018-05-02 06:29:23 --> Router Class Initialized
INFO - 2018-05-02 06:29:23 --> Output Class Initialized
INFO - 2018-05-02 06:29:23 --> Security Class Initialized
DEBUG - 2018-05-02 06:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:29:23 --> Input Class Initialized
INFO - 2018-05-02 06:29:23 --> Language Class Initialized
INFO - 2018-05-02 06:29:23 --> Loader Class Initialized
INFO - 2018-05-02 06:29:23 --> Helper loaded: common_helper
INFO - 2018-05-02 06:29:23 --> Database Driver Class Initialized
INFO - 2018-05-02 06:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:29:23 --> Email Class Initialized
INFO - 2018-05-02 06:29:23 --> Controller Class Initialized
INFO - 2018-05-02 06:29:23 --> Helper loaded: form_helper
INFO - 2018-05-02 06:29:23 --> Form Validation Class Initialized
INFO - 2018-05-02 06:29:23 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:29:23 --> Helper loaded: url_helper
INFO - 2018-05-02 06:29:23 --> Model Class Initialized
INFO - 2018-05-02 06:29:23 --> Model Class Initialized
INFO - 2018-05-02 06:29:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\index.php
INFO - 2018-05-02 06:29:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:29:23 --> Final output sent to browser
DEBUG - 2018-05-02 06:29:23 --> Total execution time: 0.1570
INFO - 2018-05-02 06:29:29 --> Config Class Initialized
INFO - 2018-05-02 06:29:29 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:29:29 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:29:29 --> Utf8 Class Initialized
INFO - 2018-05-02 06:29:29 --> URI Class Initialized
DEBUG - 2018-05-02 06:29:29 --> No URI present. Default controller set.
INFO - 2018-05-02 06:29:29 --> Router Class Initialized
INFO - 2018-05-02 06:29:29 --> Output Class Initialized
INFO - 2018-05-02 06:29:29 --> Security Class Initialized
DEBUG - 2018-05-02 06:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:29:29 --> Input Class Initialized
INFO - 2018-05-02 06:29:30 --> Language Class Initialized
INFO - 2018-05-02 06:29:30 --> Loader Class Initialized
INFO - 2018-05-02 06:29:30 --> Helper loaded: common_helper
INFO - 2018-05-02 06:29:30 --> Database Driver Class Initialized
INFO - 2018-05-02 06:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:29:30 --> Email Class Initialized
INFO - 2018-05-02 06:29:30 --> Controller Class Initialized
INFO - 2018-05-02 06:29:30 --> Helper loaded: form_helper
INFO - 2018-05-02 06:29:30 --> Form Validation Class Initialized
INFO - 2018-05-02 06:29:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:29:30 --> Helper loaded: url_helper
INFO - 2018-05-02 06:29:30 --> Model Class Initialized
INFO - 2018-05-02 06:29:30 --> Model Class Initialized
DEBUG - 2018-05-02 06:29:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:29:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 06:29:30 --> Config Class Initialized
INFO - 2018-05-02 06:29:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:29:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:29:30 --> Utf8 Class Initialized
INFO - 2018-05-02 06:29:30 --> URI Class Initialized
INFO - 2018-05-02 06:29:30 --> Router Class Initialized
INFO - 2018-05-02 06:29:30 --> Output Class Initialized
INFO - 2018-05-02 06:29:30 --> Security Class Initialized
DEBUG - 2018-05-02 06:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:29:30 --> Input Class Initialized
INFO - 2018-05-02 06:29:30 --> Language Class Initialized
INFO - 2018-05-02 06:29:30 --> Loader Class Initialized
INFO - 2018-05-02 06:29:30 --> Helper loaded: common_helper
INFO - 2018-05-02 06:29:30 --> Database Driver Class Initialized
INFO - 2018-05-02 06:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:29:30 --> Email Class Initialized
INFO - 2018-05-02 06:29:30 --> Controller Class Initialized
INFO - 2018-05-02 06:29:30 --> Helper loaded: form_helper
INFO - 2018-05-02 06:29:30 --> Form Validation Class Initialized
INFO - 2018-05-02 06:29:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:29:30 --> Helper loaded: url_helper
INFO - 2018-05-02 06:29:30 --> Model Class Initialized
INFO - 2018-05-02 06:29:30 --> Model Class Initialized
INFO - 2018-05-02 06:29:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:29:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
ERROR - 2018-05-02 06:29:30 --> Undefined variable: categories
ERROR - 2018-05-02 06:29:30 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-02 06:29:30 --> Trying to get property of non-object
ERROR - 2018-05-02 06:29:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-02 06:29:30 --> Undefined variable: articles
ERROR - 2018-05-02 06:29:30 --> Severity: Notice --> Undefined variable: articles C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-02 06:29:30 --> Trying to get property of non-object
ERROR - 2018-05-02 06:29:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-02 06:29:30 --> Undefined variable: subscriptions
ERROR - 2018-05-02 06:29:30 --> Severity: Notice --> Undefined variable: subscriptions C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
ERROR - 2018-05-02 06:29:30 --> Trying to get property of non-object
ERROR - 2018-05-02 06:29:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
INFO - 2018-05-02 06:29:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php
INFO - 2018-05-02 06:29:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:29:30 --> Final output sent to browser
DEBUG - 2018-05-02 06:29:30 --> Total execution time: 0.1680
INFO - 2018-05-02 06:41:53 --> Config Class Initialized
INFO - 2018-05-02 06:41:53 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:41:53 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:41:53 --> Utf8 Class Initialized
INFO - 2018-05-02 06:41:53 --> URI Class Initialized
INFO - 2018-05-02 06:41:53 --> Router Class Initialized
INFO - 2018-05-02 06:41:53 --> Output Class Initialized
INFO - 2018-05-02 06:41:53 --> Security Class Initialized
DEBUG - 2018-05-02 06:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:41:53 --> Input Class Initialized
INFO - 2018-05-02 06:41:53 --> Language Class Initialized
INFO - 2018-05-02 06:41:53 --> Loader Class Initialized
INFO - 2018-05-02 06:41:53 --> Helper loaded: common_helper
INFO - 2018-05-02 06:41:53 --> Database Driver Class Initialized
INFO - 2018-05-02 06:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:41:53 --> Email Class Initialized
INFO - 2018-05-02 06:41:53 --> Controller Class Initialized
INFO - 2018-05-02 06:41:53 --> Helper loaded: form_helper
INFO - 2018-05-02 06:41:53 --> Form Validation Class Initialized
INFO - 2018-05-02 06:41:53 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:41:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:41:53 --> Helper loaded: url_helper
INFO - 2018-05-02 06:41:53 --> Model Class Initialized
INFO - 2018-05-02 06:41:53 --> Model Class Initialized
INFO - 2018-05-02 06:41:53 --> Model Class Initialized
INFO - 2018-05-02 10:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-02 10:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:11:53 --> Final output sent to browser
DEBUG - 2018-05-02 10:11:53 --> Total execution time: 0.1330
INFO - 2018-05-02 06:42:02 --> Config Class Initialized
INFO - 2018-05-02 06:42:02 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:42:02 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:42:02 --> Utf8 Class Initialized
INFO - 2018-05-02 06:42:02 --> URI Class Initialized
INFO - 2018-05-02 06:42:02 --> Router Class Initialized
INFO - 2018-05-02 06:42:02 --> Output Class Initialized
INFO - 2018-05-02 06:42:02 --> Security Class Initialized
DEBUG - 2018-05-02 06:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:42:02 --> Input Class Initialized
INFO - 2018-05-02 06:42:02 --> Language Class Initialized
INFO - 2018-05-02 06:42:02 --> Loader Class Initialized
INFO - 2018-05-02 06:42:02 --> Helper loaded: common_helper
INFO - 2018-05-02 06:42:02 --> Database Driver Class Initialized
INFO - 2018-05-02 06:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:42:02 --> Email Class Initialized
INFO - 2018-05-02 06:42:02 --> Controller Class Initialized
INFO - 2018-05-02 06:42:02 --> Helper loaded: form_helper
INFO - 2018-05-02 06:42:02 --> Form Validation Class Initialized
INFO - 2018-05-02 06:42:02 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:42:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:42:02 --> Helper loaded: url_helper
INFO - 2018-05-02 06:42:02 --> Model Class Initialized
INFO - 2018-05-02 06:42:02 --> Model Class Initialized
INFO - 2018-05-02 06:42:02 --> Model Class Initialized
INFO - 2018-05-02 10:12:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:12:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:12:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 10:12:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:12:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:12:02 --> Final output sent to browser
DEBUG - 2018-05-02 10:12:02 --> Total execution time: 0.1430
INFO - 2018-05-02 06:46:08 --> Config Class Initialized
INFO - 2018-05-02 06:46:08 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:46:08 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:46:08 --> Utf8 Class Initialized
INFO - 2018-05-02 06:46:08 --> URI Class Initialized
INFO - 2018-05-02 06:46:08 --> Router Class Initialized
INFO - 2018-05-02 06:46:08 --> Output Class Initialized
INFO - 2018-05-02 06:46:08 --> Security Class Initialized
DEBUG - 2018-05-02 06:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:46:08 --> Input Class Initialized
INFO - 2018-05-02 06:46:08 --> Language Class Initialized
INFO - 2018-05-02 06:46:08 --> Loader Class Initialized
INFO - 2018-05-02 06:46:08 --> Helper loaded: common_helper
INFO - 2018-05-02 06:46:08 --> Database Driver Class Initialized
INFO - 2018-05-02 06:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:46:08 --> Email Class Initialized
INFO - 2018-05-02 06:46:08 --> Controller Class Initialized
INFO - 2018-05-02 06:46:08 --> Helper loaded: form_helper
INFO - 2018-05-02 06:46:08 --> Form Validation Class Initialized
INFO - 2018-05-02 06:46:08 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:46:08 --> Helper loaded: url_helper
INFO - 2018-05-02 06:46:08 --> Model Class Initialized
INFO - 2018-05-02 06:46:08 --> Model Class Initialized
INFO - 2018-05-02 06:46:08 --> Model Class Initialized
INFO - 2018-05-02 10:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 10:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:16:08 --> Final output sent to browser
DEBUG - 2018-05-02 10:16:08 --> Total execution time: 0.1550
INFO - 2018-05-02 06:46:10 --> Config Class Initialized
INFO - 2018-05-02 06:46:10 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:46:10 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:46:10 --> Utf8 Class Initialized
INFO - 2018-05-02 06:46:10 --> URI Class Initialized
INFO - 2018-05-02 06:46:10 --> Router Class Initialized
INFO - 2018-05-02 06:46:10 --> Output Class Initialized
INFO - 2018-05-02 06:46:10 --> Security Class Initialized
DEBUG - 2018-05-02 06:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:46:10 --> Input Class Initialized
INFO - 2018-05-02 06:46:10 --> Language Class Initialized
INFO - 2018-05-02 06:46:10 --> Loader Class Initialized
INFO - 2018-05-02 06:46:10 --> Helper loaded: common_helper
INFO - 2018-05-02 06:46:10 --> Database Driver Class Initialized
INFO - 2018-05-02 06:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:46:10 --> Email Class Initialized
INFO - 2018-05-02 06:46:10 --> Controller Class Initialized
INFO - 2018-05-02 06:46:10 --> Helper loaded: form_helper
INFO - 2018-05-02 06:46:10 --> Form Validation Class Initialized
INFO - 2018-05-02 06:46:10 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:46:10 --> Helper loaded: url_helper
INFO - 2018-05-02 06:46:10 --> Model Class Initialized
INFO - 2018-05-02 06:46:10 --> Model Class Initialized
INFO - 2018-05-02 06:46:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:46:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:46:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:46:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:46:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:46:10 --> Final output sent to browser
DEBUG - 2018-05-02 06:46:10 --> Total execution time: 0.2510
INFO - 2018-05-02 06:46:15 --> Config Class Initialized
INFO - 2018-05-02 06:46:15 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:46:15 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:46:15 --> Utf8 Class Initialized
INFO - 2018-05-02 06:46:15 --> URI Class Initialized
INFO - 2018-05-02 06:46:15 --> Router Class Initialized
INFO - 2018-05-02 06:46:15 --> Output Class Initialized
INFO - 2018-05-02 06:46:15 --> Security Class Initialized
DEBUG - 2018-05-02 06:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:46:15 --> Input Class Initialized
INFO - 2018-05-02 06:46:15 --> Language Class Initialized
INFO - 2018-05-02 06:46:15 --> Loader Class Initialized
INFO - 2018-05-02 06:46:15 --> Helper loaded: common_helper
INFO - 2018-05-02 06:46:15 --> Database Driver Class Initialized
INFO - 2018-05-02 06:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:46:15 --> Email Class Initialized
INFO - 2018-05-02 06:46:15 --> Controller Class Initialized
INFO - 2018-05-02 06:46:15 --> Helper loaded: form_helper
INFO - 2018-05-02 06:46:15 --> Form Validation Class Initialized
INFO - 2018-05-02 06:46:15 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:46:15 --> Helper loaded: url_helper
INFO - 2018-05-02 06:46:15 --> Model Class Initialized
INFO - 2018-05-02 06:46:15 --> Model Class Initialized
INFO - 2018-05-02 06:46:15 --> Model Class Initialized
INFO - 2018-05-02 10:16:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:16:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:16:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 10:16:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:16:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:16:15 --> Final output sent to browser
DEBUG - 2018-05-02 10:16:15 --> Total execution time: 0.1400
INFO - 2018-05-02 06:46:17 --> Config Class Initialized
INFO - 2018-05-02 06:46:17 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:46:17 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:46:17 --> Utf8 Class Initialized
INFO - 2018-05-02 06:46:17 --> URI Class Initialized
INFO - 2018-05-02 06:46:17 --> Router Class Initialized
INFO - 2018-05-02 06:46:17 --> Output Class Initialized
INFO - 2018-05-02 06:46:17 --> Security Class Initialized
DEBUG - 2018-05-02 06:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:46:17 --> Input Class Initialized
INFO - 2018-05-02 06:46:17 --> Language Class Initialized
INFO - 2018-05-02 06:46:17 --> Loader Class Initialized
INFO - 2018-05-02 06:46:17 --> Helper loaded: common_helper
INFO - 2018-05-02 06:46:17 --> Database Driver Class Initialized
INFO - 2018-05-02 06:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:46:17 --> Email Class Initialized
INFO - 2018-05-02 06:46:17 --> Controller Class Initialized
INFO - 2018-05-02 06:46:17 --> Helper loaded: form_helper
INFO - 2018-05-02 06:46:17 --> Form Validation Class Initialized
INFO - 2018-05-02 06:46:17 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:46:17 --> Helper loaded: url_helper
INFO - 2018-05-02 06:46:17 --> Model Class Initialized
INFO - 2018-05-02 06:46:17 --> Model Class Initialized
INFO - 2018-05-02 06:46:17 --> Model Class Initialized
INFO - 2018-05-02 10:16:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:16:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:16:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:16:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-02 10:16:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:16:17 --> Final output sent to browser
DEBUG - 2018-05-02 10:16:17 --> Total execution time: 0.1780
INFO - 2018-05-02 06:46:21 --> Config Class Initialized
INFO - 2018-05-02 06:46:21 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:46:21 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:46:21 --> Utf8 Class Initialized
INFO - 2018-05-02 06:46:21 --> URI Class Initialized
INFO - 2018-05-02 06:46:21 --> Router Class Initialized
INFO - 2018-05-02 06:46:21 --> Output Class Initialized
INFO - 2018-05-02 06:46:21 --> Security Class Initialized
DEBUG - 2018-05-02 06:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:46:21 --> Input Class Initialized
INFO - 2018-05-02 06:46:21 --> Language Class Initialized
INFO - 2018-05-02 06:46:21 --> Loader Class Initialized
INFO - 2018-05-02 06:46:21 --> Helper loaded: common_helper
INFO - 2018-05-02 06:46:21 --> Database Driver Class Initialized
INFO - 2018-05-02 06:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:46:21 --> Email Class Initialized
INFO - 2018-05-02 06:46:21 --> Controller Class Initialized
INFO - 2018-05-02 06:46:21 --> Helper loaded: form_helper
INFO - 2018-05-02 06:46:21 --> Form Validation Class Initialized
INFO - 2018-05-02 06:46:21 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:46:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:46:21 --> Helper loaded: url_helper
INFO - 2018-05-02 06:46:21 --> Model Class Initialized
INFO - 2018-05-02 06:46:21 --> Model Class Initialized
INFO - 2018-05-02 06:46:21 --> Model Class Initialized
INFO - 2018-05-02 10:16:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:16:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:16:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 10:16:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:16:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:16:21 --> Final output sent to browser
DEBUG - 2018-05-02 10:16:21 --> Total execution time: 0.1480
INFO - 2018-05-02 06:46:27 --> Config Class Initialized
INFO - 2018-05-02 06:46:27 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:46:27 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:46:27 --> Utf8 Class Initialized
INFO - 2018-05-02 06:46:27 --> URI Class Initialized
INFO - 2018-05-02 06:46:27 --> Router Class Initialized
INFO - 2018-05-02 06:46:27 --> Output Class Initialized
INFO - 2018-05-02 06:46:27 --> Security Class Initialized
DEBUG - 2018-05-02 06:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:46:27 --> Input Class Initialized
INFO - 2018-05-02 06:46:27 --> Language Class Initialized
INFO - 2018-05-02 06:46:27 --> Loader Class Initialized
INFO - 2018-05-02 06:46:27 --> Helper loaded: common_helper
INFO - 2018-05-02 06:46:27 --> Database Driver Class Initialized
INFO - 2018-05-02 06:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:46:27 --> Email Class Initialized
INFO - 2018-05-02 06:46:27 --> Controller Class Initialized
INFO - 2018-05-02 06:46:27 --> Helper loaded: form_helper
INFO - 2018-05-02 06:46:27 --> Form Validation Class Initialized
INFO - 2018-05-02 06:46:27 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:46:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:46:27 --> Helper loaded: url_helper
INFO - 2018-05-02 06:46:27 --> Model Class Initialized
INFO - 2018-05-02 06:46:27 --> Model Class Initialized
INFO - 2018-05-02 06:46:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:46:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:46:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:46:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:46:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:46:27 --> Final output sent to browser
DEBUG - 2018-05-02 06:46:27 --> Total execution time: 0.1330
INFO - 2018-05-02 06:46:38 --> Config Class Initialized
INFO - 2018-05-02 06:46:38 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:46:38 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:46:38 --> Utf8 Class Initialized
INFO - 2018-05-02 06:46:38 --> URI Class Initialized
INFO - 2018-05-02 06:46:38 --> Router Class Initialized
INFO - 2018-05-02 06:46:38 --> Output Class Initialized
INFO - 2018-05-02 06:46:38 --> Security Class Initialized
DEBUG - 2018-05-02 06:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:46:38 --> Input Class Initialized
INFO - 2018-05-02 06:46:38 --> Language Class Initialized
INFO - 2018-05-02 06:46:38 --> Loader Class Initialized
INFO - 2018-05-02 06:46:38 --> Helper loaded: common_helper
INFO - 2018-05-02 06:46:38 --> Database Driver Class Initialized
INFO - 2018-05-02 06:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:46:38 --> Email Class Initialized
INFO - 2018-05-02 06:46:38 --> Controller Class Initialized
INFO - 2018-05-02 06:46:38 --> Helper loaded: form_helper
INFO - 2018-05-02 06:46:38 --> Form Validation Class Initialized
INFO - 2018-05-02 06:46:38 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:46:38 --> Helper loaded: url_helper
INFO - 2018-05-02 06:46:38 --> Model Class Initialized
INFO - 2018-05-02 06:46:38 --> Model Class Initialized
INFO - 2018-05-02 06:46:38 --> Model Class Initialized
INFO - 2018-05-02 10:16:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:16:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:16:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 10:16:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:16:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:16:38 --> Final output sent to browser
DEBUG - 2018-05-02 10:16:38 --> Total execution time: 0.1540
INFO - 2018-05-02 06:46:40 --> Config Class Initialized
INFO - 2018-05-02 06:46:40 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:46:40 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:46:40 --> Utf8 Class Initialized
INFO - 2018-05-02 06:46:40 --> URI Class Initialized
INFO - 2018-05-02 06:46:40 --> Router Class Initialized
INFO - 2018-05-02 06:46:40 --> Output Class Initialized
INFO - 2018-05-02 06:46:40 --> Security Class Initialized
DEBUG - 2018-05-02 06:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:46:40 --> Input Class Initialized
INFO - 2018-05-02 06:46:40 --> Language Class Initialized
INFO - 2018-05-02 06:46:40 --> Loader Class Initialized
INFO - 2018-05-02 06:46:40 --> Helper loaded: common_helper
INFO - 2018-05-02 06:46:40 --> Database Driver Class Initialized
INFO - 2018-05-02 06:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:46:40 --> Email Class Initialized
INFO - 2018-05-02 06:46:40 --> Controller Class Initialized
INFO - 2018-05-02 06:46:40 --> Helper loaded: form_helper
INFO - 2018-05-02 06:46:40 --> Form Validation Class Initialized
INFO - 2018-05-02 06:46:40 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:46:40 --> Helper loaded: url_helper
INFO - 2018-05-02 06:46:40 --> Model Class Initialized
INFO - 2018-05-02 06:46:40 --> Model Class Initialized
INFO - 2018-05-02 06:46:40 --> Model Class Initialized
INFO - 2018-05-02 10:16:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:16:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:16:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:16:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-02 10:16:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:16:40 --> Final output sent to browser
DEBUG - 2018-05-02 10:16:40 --> Total execution time: 0.1510
INFO - 2018-05-02 06:46:41 --> Config Class Initialized
INFO - 2018-05-02 06:46:41 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:46:41 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:46:41 --> Utf8 Class Initialized
INFO - 2018-05-02 06:46:41 --> URI Class Initialized
INFO - 2018-05-02 06:46:41 --> Router Class Initialized
INFO - 2018-05-02 06:46:41 --> Output Class Initialized
INFO - 2018-05-02 06:46:41 --> Security Class Initialized
DEBUG - 2018-05-02 06:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:46:41 --> Input Class Initialized
INFO - 2018-05-02 06:46:41 --> Language Class Initialized
INFO - 2018-05-02 06:46:41 --> Loader Class Initialized
INFO - 2018-05-02 06:46:41 --> Helper loaded: common_helper
INFO - 2018-05-02 06:46:42 --> Database Driver Class Initialized
INFO - 2018-05-02 06:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:46:42 --> Email Class Initialized
INFO - 2018-05-02 06:46:42 --> Controller Class Initialized
INFO - 2018-05-02 06:46:42 --> Helper loaded: form_helper
INFO - 2018-05-02 06:46:42 --> Form Validation Class Initialized
INFO - 2018-05-02 06:46:42 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:46:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:46:42 --> Helper loaded: url_helper
INFO - 2018-05-02 06:46:42 --> Model Class Initialized
INFO - 2018-05-02 06:46:42 --> Model Class Initialized
INFO - 2018-05-02 06:46:42 --> Model Class Initialized
INFO - 2018-05-02 10:16:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:16:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:16:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 10:16:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:16:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:16:42 --> Final output sent to browser
DEBUG - 2018-05-02 10:16:42 --> Total execution time: 0.1510
INFO - 2018-05-02 06:46:45 --> Config Class Initialized
INFO - 2018-05-02 06:46:45 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:46:45 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:46:45 --> Utf8 Class Initialized
INFO - 2018-05-02 06:46:45 --> URI Class Initialized
INFO - 2018-05-02 06:46:45 --> Router Class Initialized
INFO - 2018-05-02 06:46:45 --> Output Class Initialized
INFO - 2018-05-02 06:46:45 --> Security Class Initialized
DEBUG - 2018-05-02 06:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:46:45 --> Input Class Initialized
INFO - 2018-05-02 06:46:45 --> Language Class Initialized
INFO - 2018-05-02 06:46:45 --> Loader Class Initialized
INFO - 2018-05-02 06:46:45 --> Helper loaded: common_helper
INFO - 2018-05-02 06:46:45 --> Database Driver Class Initialized
INFO - 2018-05-02 06:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:46:45 --> Email Class Initialized
INFO - 2018-05-02 06:46:45 --> Controller Class Initialized
INFO - 2018-05-02 06:46:45 --> Helper loaded: form_helper
INFO - 2018-05-02 06:46:45 --> Form Validation Class Initialized
INFO - 2018-05-02 06:46:45 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:46:45 --> Helper loaded: url_helper
INFO - 2018-05-02 06:46:45 --> Model Class Initialized
INFO - 2018-05-02 06:46:45 --> Model Class Initialized
INFO - 2018-05-02 06:46:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:46:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:46:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:46:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:46:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:46:45 --> Final output sent to browser
DEBUG - 2018-05-02 06:46:45 --> Total execution time: 0.1370
INFO - 2018-05-02 06:46:58 --> Config Class Initialized
INFO - 2018-05-02 06:46:58 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:46:58 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:46:58 --> Utf8 Class Initialized
INFO - 2018-05-02 06:46:58 --> URI Class Initialized
INFO - 2018-05-02 06:46:58 --> Router Class Initialized
INFO - 2018-05-02 06:46:58 --> Output Class Initialized
INFO - 2018-05-02 06:46:58 --> Security Class Initialized
DEBUG - 2018-05-02 06:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:46:58 --> Input Class Initialized
INFO - 2018-05-02 06:46:58 --> Language Class Initialized
INFO - 2018-05-02 06:46:58 --> Loader Class Initialized
INFO - 2018-05-02 06:46:58 --> Helper loaded: common_helper
INFO - 2018-05-02 06:46:58 --> Database Driver Class Initialized
INFO - 2018-05-02 06:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:46:58 --> Email Class Initialized
INFO - 2018-05-02 06:46:58 --> Controller Class Initialized
INFO - 2018-05-02 06:46:58 --> Helper loaded: form_helper
INFO - 2018-05-02 06:46:58 --> Form Validation Class Initialized
INFO - 2018-05-02 06:46:58 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:46:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:46:58 --> Helper loaded: url_helper
INFO - 2018-05-02 06:46:58 --> Model Class Initialized
INFO - 2018-05-02 06:46:58 --> Model Class Initialized
INFO - 2018-05-02 06:46:59 --> Config Class Initialized
INFO - 2018-05-02 06:46:59 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:46:59 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:46:59 --> Utf8 Class Initialized
INFO - 2018-05-02 06:46:59 --> URI Class Initialized
INFO - 2018-05-02 06:46:59 --> Router Class Initialized
INFO - 2018-05-02 06:46:59 --> Output Class Initialized
INFO - 2018-05-02 06:46:59 --> Security Class Initialized
DEBUG - 2018-05-02 06:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:46:59 --> Input Class Initialized
INFO - 2018-05-02 06:46:59 --> Language Class Initialized
INFO - 2018-05-02 06:46:59 --> Loader Class Initialized
INFO - 2018-05-02 06:46:59 --> Helper loaded: common_helper
INFO - 2018-05-02 06:46:59 --> Database Driver Class Initialized
INFO - 2018-05-02 06:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:46:59 --> Email Class Initialized
INFO - 2018-05-02 06:46:59 --> Controller Class Initialized
INFO - 2018-05-02 06:46:59 --> Helper loaded: form_helper
INFO - 2018-05-02 06:46:59 --> Form Validation Class Initialized
INFO - 2018-05-02 06:46:59 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:46:59 --> Helper loaded: url_helper
INFO - 2018-05-02 06:46:59 --> Model Class Initialized
INFO - 2018-05-02 06:46:59 --> Model Class Initialized
INFO - 2018-05-02 06:46:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:46:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:46:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:46:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:46:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:46:59 --> Final output sent to browser
DEBUG - 2018-05-02 06:46:59 --> Total execution time: 0.1440
INFO - 2018-05-02 06:47:19 --> Config Class Initialized
INFO - 2018-05-02 06:47:19 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:47:19 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:47:19 --> Utf8 Class Initialized
INFO - 2018-05-02 06:47:19 --> URI Class Initialized
INFO - 2018-05-02 06:47:19 --> Router Class Initialized
INFO - 2018-05-02 06:47:19 --> Output Class Initialized
INFO - 2018-05-02 06:47:19 --> Security Class Initialized
DEBUG - 2018-05-02 06:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:47:19 --> Input Class Initialized
INFO - 2018-05-02 06:47:19 --> Language Class Initialized
INFO - 2018-05-02 06:47:19 --> Loader Class Initialized
INFO - 2018-05-02 06:47:19 --> Helper loaded: common_helper
INFO - 2018-05-02 06:47:19 --> Database Driver Class Initialized
INFO - 2018-05-02 06:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:47:19 --> Email Class Initialized
INFO - 2018-05-02 06:47:19 --> Controller Class Initialized
INFO - 2018-05-02 06:47:19 --> Helper loaded: form_helper
INFO - 2018-05-02 06:47:19 --> Form Validation Class Initialized
INFO - 2018-05-02 06:47:19 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:47:19 --> Helper loaded: url_helper
INFO - 2018-05-02 06:47:19 --> Model Class Initialized
INFO - 2018-05-02 06:47:19 --> Model Class Initialized
INFO - 2018-05-02 06:47:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:47:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:47:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:47:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:47:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:47:19 --> Final output sent to browser
DEBUG - 2018-05-02 06:47:19 --> Total execution time: 0.1360
INFO - 2018-05-02 06:47:24 --> Config Class Initialized
INFO - 2018-05-02 06:47:24 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:47:24 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:47:24 --> Utf8 Class Initialized
INFO - 2018-05-02 06:47:24 --> URI Class Initialized
INFO - 2018-05-02 06:47:24 --> Router Class Initialized
INFO - 2018-05-02 06:47:24 --> Output Class Initialized
INFO - 2018-05-02 06:47:24 --> Security Class Initialized
DEBUG - 2018-05-02 06:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:47:24 --> Input Class Initialized
INFO - 2018-05-02 06:47:24 --> Language Class Initialized
INFO - 2018-05-02 06:47:24 --> Loader Class Initialized
INFO - 2018-05-02 06:47:24 --> Helper loaded: common_helper
INFO - 2018-05-02 06:47:24 --> Database Driver Class Initialized
INFO - 2018-05-02 06:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:47:24 --> Email Class Initialized
INFO - 2018-05-02 06:47:24 --> Controller Class Initialized
INFO - 2018-05-02 06:47:24 --> Helper loaded: form_helper
INFO - 2018-05-02 06:47:24 --> Form Validation Class Initialized
INFO - 2018-05-02 06:47:24 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:47:24 --> Helper loaded: url_helper
INFO - 2018-05-02 06:47:24 --> Model Class Initialized
INFO - 2018-05-02 06:47:24 --> Model Class Initialized
INFO - 2018-05-02 06:47:24 --> Config Class Initialized
INFO - 2018-05-02 06:47:24 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:47:24 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:47:24 --> Utf8 Class Initialized
INFO - 2018-05-02 06:47:24 --> URI Class Initialized
INFO - 2018-05-02 06:47:24 --> Router Class Initialized
INFO - 2018-05-02 06:47:24 --> Output Class Initialized
INFO - 2018-05-02 06:47:24 --> Security Class Initialized
DEBUG - 2018-05-02 06:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:47:24 --> Input Class Initialized
INFO - 2018-05-02 06:47:24 --> Language Class Initialized
INFO - 2018-05-02 06:47:24 --> Loader Class Initialized
INFO - 2018-05-02 06:47:24 --> Helper loaded: common_helper
INFO - 2018-05-02 06:47:24 --> Database Driver Class Initialized
INFO - 2018-05-02 06:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:47:24 --> Email Class Initialized
INFO - 2018-05-02 06:47:24 --> Controller Class Initialized
INFO - 2018-05-02 06:47:24 --> Helper loaded: form_helper
INFO - 2018-05-02 06:47:24 --> Form Validation Class Initialized
INFO - 2018-05-02 06:47:24 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:47:24 --> Helper loaded: url_helper
INFO - 2018-05-02 06:47:24 --> Model Class Initialized
INFO - 2018-05-02 06:47:24 --> Model Class Initialized
INFO - 2018-05-02 06:47:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:47:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:47:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:47:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:47:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:47:25 --> Final output sent to browser
DEBUG - 2018-05-02 06:47:25 --> Total execution time: 0.1380
INFO - 2018-05-02 06:51:58 --> Config Class Initialized
INFO - 2018-05-02 06:51:58 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:51:58 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:51:58 --> Utf8 Class Initialized
INFO - 2018-05-02 06:51:58 --> URI Class Initialized
INFO - 2018-05-02 06:51:58 --> Router Class Initialized
INFO - 2018-05-02 06:51:58 --> Output Class Initialized
INFO - 2018-05-02 06:51:58 --> Security Class Initialized
DEBUG - 2018-05-02 06:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:51:58 --> Input Class Initialized
INFO - 2018-05-02 06:51:58 --> Language Class Initialized
INFO - 2018-05-02 06:51:58 --> Loader Class Initialized
INFO - 2018-05-02 06:51:58 --> Helper loaded: common_helper
INFO - 2018-05-02 06:51:58 --> Database Driver Class Initialized
INFO - 2018-05-02 06:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:51:58 --> Email Class Initialized
INFO - 2018-05-02 06:51:58 --> Controller Class Initialized
INFO - 2018-05-02 06:51:58 --> Helper loaded: form_helper
INFO - 2018-05-02 06:51:58 --> Form Validation Class Initialized
INFO - 2018-05-02 06:51:58 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:51:58 --> Helper loaded: url_helper
INFO - 2018-05-02 06:51:58 --> Model Class Initialized
INFO - 2018-05-02 06:51:58 --> Model Class Initialized
INFO - 2018-05-02 06:51:58 --> Model Class Initialized
INFO - 2018-05-02 10:21:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:21:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:21:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 10:21:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:21:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:21:58 --> Final output sent to browser
DEBUG - 2018-05-02 10:21:58 --> Total execution time: 0.1570
INFO - 2018-05-02 06:55:11 --> Config Class Initialized
INFO - 2018-05-02 06:55:11 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:55:11 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:55:11 --> Utf8 Class Initialized
INFO - 2018-05-02 06:55:11 --> URI Class Initialized
INFO - 2018-05-02 06:55:11 --> Router Class Initialized
INFO - 2018-05-02 06:55:11 --> Output Class Initialized
INFO - 2018-05-02 06:55:11 --> Security Class Initialized
DEBUG - 2018-05-02 06:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:55:11 --> Input Class Initialized
INFO - 2018-05-02 06:55:11 --> Language Class Initialized
INFO - 2018-05-02 06:55:11 --> Loader Class Initialized
INFO - 2018-05-02 06:55:11 --> Helper loaded: common_helper
INFO - 2018-05-02 06:55:11 --> Database Driver Class Initialized
INFO - 2018-05-02 06:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:55:11 --> Email Class Initialized
INFO - 2018-05-02 06:55:11 --> Controller Class Initialized
INFO - 2018-05-02 06:55:11 --> Helper loaded: form_helper
INFO - 2018-05-02 06:55:11 --> Form Validation Class Initialized
INFO - 2018-05-02 06:55:11 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:55:11 --> Helper loaded: url_helper
INFO - 2018-05-02 06:55:11 --> Model Class Initialized
INFO - 2018-05-02 06:55:11 --> Model Class Initialized
INFO - 2018-05-02 06:55:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:55:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:55:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:55:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:55:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:55:11 --> Final output sent to browser
DEBUG - 2018-05-02 06:55:11 --> Total execution time: 0.1460
INFO - 2018-05-02 06:55:16 --> Config Class Initialized
INFO - 2018-05-02 06:55:16 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:55:16 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:55:16 --> Utf8 Class Initialized
INFO - 2018-05-02 06:55:16 --> URI Class Initialized
INFO - 2018-05-02 06:55:16 --> Router Class Initialized
INFO - 2018-05-02 06:55:16 --> Output Class Initialized
INFO - 2018-05-02 06:55:16 --> Security Class Initialized
DEBUG - 2018-05-02 06:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:55:16 --> Input Class Initialized
INFO - 2018-05-02 06:55:16 --> Language Class Initialized
INFO - 2018-05-02 06:55:16 --> Loader Class Initialized
INFO - 2018-05-02 06:55:16 --> Helper loaded: common_helper
INFO - 2018-05-02 06:55:16 --> Database Driver Class Initialized
INFO - 2018-05-02 06:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:55:16 --> Email Class Initialized
INFO - 2018-05-02 06:55:16 --> Controller Class Initialized
INFO - 2018-05-02 06:55:16 --> Helper loaded: form_helper
INFO - 2018-05-02 06:55:16 --> Form Validation Class Initialized
INFO - 2018-05-02 06:55:16 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:55:16 --> Helper loaded: url_helper
INFO - 2018-05-02 06:55:16 --> Model Class Initialized
INFO - 2018-05-02 06:55:16 --> Model Class Initialized
INFO - 2018-05-02 06:55:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:55:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:55:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:55:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:55:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:55:16 --> Final output sent to browser
DEBUG - 2018-05-02 06:55:16 --> Total execution time: 0.1300
INFO - 2018-05-02 06:55:28 --> Config Class Initialized
INFO - 2018-05-02 06:55:28 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:55:28 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:55:28 --> Utf8 Class Initialized
INFO - 2018-05-02 06:55:28 --> URI Class Initialized
INFO - 2018-05-02 06:55:28 --> Router Class Initialized
INFO - 2018-05-02 06:55:28 --> Output Class Initialized
INFO - 2018-05-02 06:55:28 --> Security Class Initialized
DEBUG - 2018-05-02 06:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:55:28 --> Input Class Initialized
INFO - 2018-05-02 06:55:28 --> Language Class Initialized
INFO - 2018-05-02 06:55:28 --> Loader Class Initialized
INFO - 2018-05-02 06:55:28 --> Helper loaded: common_helper
INFO - 2018-05-02 06:55:28 --> Database Driver Class Initialized
INFO - 2018-05-02 06:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:55:28 --> Email Class Initialized
INFO - 2018-05-02 06:55:28 --> Controller Class Initialized
INFO - 2018-05-02 06:55:28 --> Helper loaded: form_helper
INFO - 2018-05-02 06:55:28 --> Form Validation Class Initialized
INFO - 2018-05-02 06:55:28 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:55:28 --> Helper loaded: url_helper
INFO - 2018-05-02 06:55:28 --> Model Class Initialized
INFO - 2018-05-02 06:55:28 --> Model Class Initialized
INFO - 2018-05-02 06:55:28 --> Config Class Initialized
INFO - 2018-05-02 06:55:28 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:55:28 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:55:28 --> Utf8 Class Initialized
INFO - 2018-05-02 06:55:28 --> URI Class Initialized
INFO - 2018-05-02 06:55:28 --> Router Class Initialized
INFO - 2018-05-02 06:55:28 --> Output Class Initialized
INFO - 2018-05-02 06:55:28 --> Security Class Initialized
DEBUG - 2018-05-02 06:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:55:28 --> Input Class Initialized
INFO - 2018-05-02 06:55:28 --> Language Class Initialized
INFO - 2018-05-02 06:55:28 --> Loader Class Initialized
INFO - 2018-05-02 06:55:28 --> Helper loaded: common_helper
INFO - 2018-05-02 06:55:28 --> Database Driver Class Initialized
INFO - 2018-05-02 06:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:55:28 --> Email Class Initialized
INFO - 2018-05-02 06:55:28 --> Controller Class Initialized
INFO - 2018-05-02 06:55:28 --> Helper loaded: form_helper
INFO - 2018-05-02 06:55:28 --> Form Validation Class Initialized
INFO - 2018-05-02 06:55:28 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:55:28 --> Helper loaded: url_helper
INFO - 2018-05-02 06:55:28 --> Model Class Initialized
INFO - 2018-05-02 06:55:28 --> Model Class Initialized
INFO - 2018-05-02 06:55:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:55:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:55:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:55:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:55:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:55:28 --> Final output sent to browser
DEBUG - 2018-05-02 06:55:28 --> Total execution time: 0.1280
INFO - 2018-05-02 06:56:31 --> Config Class Initialized
INFO - 2018-05-02 06:56:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:56:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:56:31 --> Utf8 Class Initialized
INFO - 2018-05-02 06:56:31 --> URI Class Initialized
INFO - 2018-05-02 06:56:31 --> Router Class Initialized
INFO - 2018-05-02 06:56:31 --> Output Class Initialized
INFO - 2018-05-02 06:56:31 --> Security Class Initialized
DEBUG - 2018-05-02 06:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:56:31 --> Input Class Initialized
INFO - 2018-05-02 06:56:31 --> Language Class Initialized
INFO - 2018-05-02 06:56:32 --> Loader Class Initialized
INFO - 2018-05-02 06:56:32 --> Helper loaded: common_helper
INFO - 2018-05-02 06:56:32 --> Database Driver Class Initialized
INFO - 2018-05-02 06:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:56:32 --> Email Class Initialized
INFO - 2018-05-02 06:56:32 --> Controller Class Initialized
INFO - 2018-05-02 06:56:32 --> Helper loaded: form_helper
INFO - 2018-05-02 06:56:32 --> Form Validation Class Initialized
INFO - 2018-05-02 06:56:32 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:56:32 --> Helper loaded: url_helper
INFO - 2018-05-02 06:56:32 --> Model Class Initialized
INFO - 2018-05-02 06:56:32 --> Model Class Initialized
INFO - 2018-05-02 06:56:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:56:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:56:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:56:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:56:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:56:32 --> Final output sent to browser
DEBUG - 2018-05-02 06:56:32 --> Total execution time: 0.2660
INFO - 2018-05-02 06:56:51 --> Config Class Initialized
INFO - 2018-05-02 06:56:51 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:56:51 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:56:51 --> Utf8 Class Initialized
INFO - 2018-05-02 06:56:51 --> URI Class Initialized
INFO - 2018-05-02 06:56:51 --> Router Class Initialized
INFO - 2018-05-02 06:56:51 --> Output Class Initialized
INFO - 2018-05-02 06:56:51 --> Security Class Initialized
DEBUG - 2018-05-02 06:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:56:51 --> Input Class Initialized
INFO - 2018-05-02 06:56:51 --> Language Class Initialized
INFO - 2018-05-02 06:56:51 --> Loader Class Initialized
INFO - 2018-05-02 06:56:51 --> Helper loaded: common_helper
INFO - 2018-05-02 06:56:51 --> Database Driver Class Initialized
INFO - 2018-05-02 06:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:56:51 --> Email Class Initialized
INFO - 2018-05-02 06:56:51 --> Controller Class Initialized
INFO - 2018-05-02 06:56:51 --> Helper loaded: form_helper
INFO - 2018-05-02 06:56:51 --> Form Validation Class Initialized
INFO - 2018-05-02 06:56:51 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:56:51 --> Helper loaded: url_helper
INFO - 2018-05-02 06:56:51 --> Model Class Initialized
INFO - 2018-05-02 06:56:51 --> Model Class Initialized
INFO - 2018-05-02 06:56:51 --> Config Class Initialized
INFO - 2018-05-02 06:56:51 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:56:51 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:56:51 --> Utf8 Class Initialized
INFO - 2018-05-02 06:56:51 --> URI Class Initialized
INFO - 2018-05-02 06:56:51 --> Router Class Initialized
INFO - 2018-05-02 06:56:52 --> Output Class Initialized
INFO - 2018-05-02 06:56:52 --> Security Class Initialized
DEBUG - 2018-05-02 06:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:56:52 --> Input Class Initialized
INFO - 2018-05-02 06:56:52 --> Language Class Initialized
INFO - 2018-05-02 06:56:52 --> Loader Class Initialized
INFO - 2018-05-02 06:56:52 --> Helper loaded: common_helper
INFO - 2018-05-02 06:56:52 --> Database Driver Class Initialized
INFO - 2018-05-02 06:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:56:52 --> Email Class Initialized
INFO - 2018-05-02 06:56:52 --> Controller Class Initialized
INFO - 2018-05-02 06:56:52 --> Helper loaded: form_helper
INFO - 2018-05-02 06:56:52 --> Form Validation Class Initialized
INFO - 2018-05-02 06:56:52 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:56:52 --> Helper loaded: url_helper
INFO - 2018-05-02 06:56:52 --> Model Class Initialized
INFO - 2018-05-02 06:56:52 --> Model Class Initialized
INFO - 2018-05-02 06:56:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:56:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:56:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:56:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:56:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:56:52 --> Final output sent to browser
DEBUG - 2018-05-02 06:56:52 --> Total execution time: 0.1350
INFO - 2018-05-02 06:58:01 --> Config Class Initialized
INFO - 2018-05-02 06:58:01 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:58:01 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:58:01 --> Utf8 Class Initialized
INFO - 2018-05-02 06:58:01 --> URI Class Initialized
INFO - 2018-05-02 06:58:01 --> Router Class Initialized
INFO - 2018-05-02 06:58:01 --> Output Class Initialized
INFO - 2018-05-02 06:58:01 --> Security Class Initialized
DEBUG - 2018-05-02 06:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:58:01 --> Input Class Initialized
INFO - 2018-05-02 06:58:01 --> Language Class Initialized
INFO - 2018-05-02 06:58:01 --> Loader Class Initialized
INFO - 2018-05-02 06:58:01 --> Helper loaded: common_helper
INFO - 2018-05-02 06:58:01 --> Database Driver Class Initialized
INFO - 2018-05-02 06:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:58:01 --> Email Class Initialized
INFO - 2018-05-02 06:58:01 --> Controller Class Initialized
INFO - 2018-05-02 06:58:01 --> Helper loaded: form_helper
INFO - 2018-05-02 06:58:01 --> Form Validation Class Initialized
INFO - 2018-05-02 06:58:01 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:58:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:58:01 --> Helper loaded: url_helper
INFO - 2018-05-02 06:58:01 --> Model Class Initialized
INFO - 2018-05-02 06:58:01 --> Model Class Initialized
INFO - 2018-05-02 06:58:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:58:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:58:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:58:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:58:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:58:01 --> Final output sent to browser
DEBUG - 2018-05-02 06:58:01 --> Total execution time: 0.1330
INFO - 2018-05-02 06:58:22 --> Config Class Initialized
INFO - 2018-05-02 06:58:22 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:58:22 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:58:22 --> Utf8 Class Initialized
INFO - 2018-05-02 06:58:22 --> URI Class Initialized
INFO - 2018-05-02 06:58:22 --> Router Class Initialized
INFO - 2018-05-02 06:58:22 --> Output Class Initialized
INFO - 2018-05-02 06:58:22 --> Security Class Initialized
DEBUG - 2018-05-02 06:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:58:22 --> Input Class Initialized
INFO - 2018-05-02 06:58:22 --> Language Class Initialized
INFO - 2018-05-02 06:58:22 --> Loader Class Initialized
INFO - 2018-05-02 06:58:22 --> Helper loaded: common_helper
INFO - 2018-05-02 06:58:22 --> Database Driver Class Initialized
INFO - 2018-05-02 06:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:58:22 --> Email Class Initialized
INFO - 2018-05-02 06:58:22 --> Controller Class Initialized
INFO - 2018-05-02 06:58:22 --> Helper loaded: form_helper
INFO - 2018-05-02 06:58:22 --> Form Validation Class Initialized
INFO - 2018-05-02 06:58:22 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:58:22 --> Helper loaded: url_helper
INFO - 2018-05-02 06:58:22 --> Model Class Initialized
INFO - 2018-05-02 06:58:22 --> Model Class Initialized
INFO - 2018-05-02 06:58:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:58:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:58:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:58:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:58:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:58:22 --> Final output sent to browser
DEBUG - 2018-05-02 06:58:22 --> Total execution time: 0.1410
INFO - 2018-05-02 06:58:44 --> Config Class Initialized
INFO - 2018-05-02 06:58:44 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:58:44 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:58:44 --> Utf8 Class Initialized
INFO - 2018-05-02 06:58:44 --> URI Class Initialized
INFO - 2018-05-02 06:58:44 --> Router Class Initialized
INFO - 2018-05-02 06:58:44 --> Output Class Initialized
INFO - 2018-05-02 06:58:44 --> Security Class Initialized
DEBUG - 2018-05-02 06:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:58:44 --> Input Class Initialized
INFO - 2018-05-02 06:58:44 --> Language Class Initialized
INFO - 2018-05-02 06:58:44 --> Loader Class Initialized
INFO - 2018-05-02 06:58:44 --> Helper loaded: common_helper
INFO - 2018-05-02 06:58:44 --> Database Driver Class Initialized
INFO - 2018-05-02 06:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:58:44 --> Email Class Initialized
INFO - 2018-05-02 06:58:44 --> Controller Class Initialized
INFO - 2018-05-02 06:58:44 --> Helper loaded: form_helper
INFO - 2018-05-02 06:58:44 --> Form Validation Class Initialized
INFO - 2018-05-02 06:58:44 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:58:44 --> Helper loaded: url_helper
INFO - 2018-05-02 06:58:44 --> Model Class Initialized
INFO - 2018-05-02 06:58:44 --> Model Class Initialized
INFO - 2018-05-02 06:58:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:58:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:58:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:58:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/editPromotionBanner.php
INFO - 2018-05-02 06:58:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:58:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:58:44 --> Final output sent to browser
DEBUG - 2018-05-02 06:58:44 --> Total execution time: 0.1700
INFO - 2018-05-02 06:58:57 --> Config Class Initialized
INFO - 2018-05-02 06:58:57 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:58:57 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:58:57 --> Utf8 Class Initialized
INFO - 2018-05-02 06:58:57 --> URI Class Initialized
INFO - 2018-05-02 06:58:57 --> Router Class Initialized
INFO - 2018-05-02 06:58:57 --> Output Class Initialized
INFO - 2018-05-02 06:58:57 --> Security Class Initialized
DEBUG - 2018-05-02 06:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:58:57 --> Input Class Initialized
INFO - 2018-05-02 06:58:57 --> Language Class Initialized
INFO - 2018-05-02 06:58:57 --> Loader Class Initialized
INFO - 2018-05-02 06:58:57 --> Helper loaded: common_helper
INFO - 2018-05-02 06:58:57 --> Database Driver Class Initialized
INFO - 2018-05-02 06:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:58:57 --> Email Class Initialized
INFO - 2018-05-02 06:58:57 --> Controller Class Initialized
INFO - 2018-05-02 06:58:57 --> Helper loaded: form_helper
INFO - 2018-05-02 06:58:57 --> Form Validation Class Initialized
INFO - 2018-05-02 06:58:57 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:58:57 --> Helper loaded: url_helper
INFO - 2018-05-02 06:58:57 --> Model Class Initialized
INFO - 2018-05-02 06:58:57 --> Model Class Initialized
INFO - 2018-05-02 06:58:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:58:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:58:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:58:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:58:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:58:57 --> Final output sent to browser
DEBUG - 2018-05-02 06:58:57 --> Total execution time: 0.1390
INFO - 2018-05-02 06:59:01 --> Config Class Initialized
INFO - 2018-05-02 06:59:01 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:59:01 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:59:01 --> Utf8 Class Initialized
INFO - 2018-05-02 06:59:01 --> URI Class Initialized
INFO - 2018-05-02 06:59:01 --> Router Class Initialized
INFO - 2018-05-02 06:59:01 --> Output Class Initialized
INFO - 2018-05-02 06:59:01 --> Security Class Initialized
DEBUG - 2018-05-02 06:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:59:01 --> Input Class Initialized
INFO - 2018-05-02 06:59:01 --> Language Class Initialized
INFO - 2018-05-02 06:59:01 --> Loader Class Initialized
INFO - 2018-05-02 06:59:01 --> Helper loaded: common_helper
INFO - 2018-05-02 06:59:01 --> Database Driver Class Initialized
INFO - 2018-05-02 06:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:59:01 --> Email Class Initialized
INFO - 2018-05-02 06:59:01 --> Controller Class Initialized
INFO - 2018-05-02 06:59:01 --> Helper loaded: form_helper
INFO - 2018-05-02 06:59:01 --> Form Validation Class Initialized
INFO - 2018-05-02 06:59:01 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:59:01 --> Helper loaded: url_helper
INFO - 2018-05-02 06:59:01 --> Model Class Initialized
INFO - 2018-05-02 06:59:01 --> Model Class Initialized
INFO - 2018-05-02 06:59:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:59:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:59:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:59:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/editPromotionBanner.php
INFO - 2018-05-02 06:59:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:59:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:59:01 --> Final output sent to browser
DEBUG - 2018-05-02 06:59:01 --> Total execution time: 0.1420
INFO - 2018-05-02 06:59:04 --> Config Class Initialized
INFO - 2018-05-02 06:59:04 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:59:04 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:59:04 --> Utf8 Class Initialized
INFO - 2018-05-02 06:59:04 --> URI Class Initialized
INFO - 2018-05-02 06:59:04 --> Router Class Initialized
INFO - 2018-05-02 06:59:04 --> Output Class Initialized
INFO - 2018-05-02 06:59:04 --> Security Class Initialized
DEBUG - 2018-05-02 06:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:59:04 --> Input Class Initialized
INFO - 2018-05-02 06:59:04 --> Language Class Initialized
INFO - 2018-05-02 06:59:04 --> Loader Class Initialized
INFO - 2018-05-02 06:59:04 --> Helper loaded: common_helper
INFO - 2018-05-02 06:59:04 --> Database Driver Class Initialized
INFO - 2018-05-02 06:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:59:04 --> Email Class Initialized
INFO - 2018-05-02 06:59:04 --> Controller Class Initialized
INFO - 2018-05-02 06:59:04 --> Helper loaded: form_helper
INFO - 2018-05-02 06:59:04 --> Form Validation Class Initialized
INFO - 2018-05-02 06:59:04 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:59:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:59:04 --> Helper loaded: url_helper
INFO - 2018-05-02 06:59:04 --> Model Class Initialized
INFO - 2018-05-02 06:59:04 --> Model Class Initialized
INFO - 2018-05-02 06:59:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:59:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:59:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:59:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:59:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:59:04 --> Final output sent to browser
DEBUG - 2018-05-02 06:59:04 --> Total execution time: 0.1410
INFO - 2018-05-02 06:59:06 --> Config Class Initialized
INFO - 2018-05-02 06:59:06 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:59:06 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:59:06 --> Utf8 Class Initialized
INFO - 2018-05-02 06:59:06 --> URI Class Initialized
INFO - 2018-05-02 06:59:06 --> Router Class Initialized
INFO - 2018-05-02 06:59:06 --> Output Class Initialized
INFO - 2018-05-02 06:59:06 --> Security Class Initialized
DEBUG - 2018-05-02 06:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:59:06 --> Input Class Initialized
INFO - 2018-05-02 06:59:06 --> Language Class Initialized
INFO - 2018-05-02 06:59:06 --> Loader Class Initialized
INFO - 2018-05-02 06:59:06 --> Helper loaded: common_helper
INFO - 2018-05-02 06:59:06 --> Database Driver Class Initialized
INFO - 2018-05-02 06:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:59:06 --> Email Class Initialized
INFO - 2018-05-02 06:59:06 --> Controller Class Initialized
INFO - 2018-05-02 06:59:06 --> Helper loaded: form_helper
INFO - 2018-05-02 06:59:06 --> Form Validation Class Initialized
INFO - 2018-05-02 06:59:06 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:59:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:59:06 --> Helper loaded: url_helper
INFO - 2018-05-02 06:59:06 --> Model Class Initialized
INFO - 2018-05-02 06:59:06 --> Model Class Initialized
INFO - 2018-05-02 06:59:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:59:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:59:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:59:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/editPromotionBanner.php
INFO - 2018-05-02 06:59:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:59:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:59:06 --> Final output sent to browser
DEBUG - 2018-05-02 06:59:06 --> Total execution time: 0.1530
INFO - 2018-05-02 06:59:50 --> Config Class Initialized
INFO - 2018-05-02 06:59:50 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:59:50 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:59:50 --> Utf8 Class Initialized
INFO - 2018-05-02 06:59:50 --> URI Class Initialized
INFO - 2018-05-02 06:59:50 --> Router Class Initialized
INFO - 2018-05-02 06:59:50 --> Output Class Initialized
INFO - 2018-05-02 06:59:50 --> Security Class Initialized
DEBUG - 2018-05-02 06:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:59:50 --> Input Class Initialized
INFO - 2018-05-02 06:59:50 --> Language Class Initialized
INFO - 2018-05-02 06:59:50 --> Loader Class Initialized
INFO - 2018-05-02 06:59:50 --> Helper loaded: common_helper
INFO - 2018-05-02 06:59:50 --> Database Driver Class Initialized
INFO - 2018-05-02 06:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:59:50 --> Email Class Initialized
INFO - 2018-05-02 06:59:50 --> Controller Class Initialized
INFO - 2018-05-02 06:59:50 --> Helper loaded: form_helper
INFO - 2018-05-02 06:59:50 --> Form Validation Class Initialized
INFO - 2018-05-02 06:59:50 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:59:50 --> Helper loaded: url_helper
INFO - 2018-05-02 06:59:50 --> Model Class Initialized
INFO - 2018-05-02 06:59:50 --> Model Class Initialized
DEBUG - 2018-05-02 06:59:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:59:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 06:59:50 --> Config Class Initialized
INFO - 2018-05-02 06:59:50 --> Hooks Class Initialized
DEBUG - 2018-05-02 06:59:50 --> UTF-8 Support Enabled
INFO - 2018-05-02 06:59:50 --> Utf8 Class Initialized
INFO - 2018-05-02 06:59:50 --> URI Class Initialized
INFO - 2018-05-02 06:59:50 --> Router Class Initialized
INFO - 2018-05-02 06:59:50 --> Output Class Initialized
INFO - 2018-05-02 06:59:50 --> Security Class Initialized
DEBUG - 2018-05-02 06:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 06:59:50 --> Input Class Initialized
INFO - 2018-05-02 06:59:50 --> Language Class Initialized
INFO - 2018-05-02 06:59:50 --> Loader Class Initialized
INFO - 2018-05-02 06:59:50 --> Helper loaded: common_helper
INFO - 2018-05-02 06:59:50 --> Database Driver Class Initialized
INFO - 2018-05-02 06:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 06:59:50 --> Email Class Initialized
INFO - 2018-05-02 06:59:50 --> Controller Class Initialized
INFO - 2018-05-02 06:59:50 --> Helper loaded: form_helper
INFO - 2018-05-02 06:59:50 --> Form Validation Class Initialized
INFO - 2018-05-02 06:59:50 --> Helper loaded: email_helper
DEBUG - 2018-05-02 06:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 06:59:50 --> Helper loaded: url_helper
INFO - 2018-05-02 06:59:50 --> Model Class Initialized
INFO - 2018-05-02 06:59:50 --> Model Class Initialized
INFO - 2018-05-02 06:59:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 06:59:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 06:59:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 06:59:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 06:59:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 06:59:50 --> Final output sent to browser
DEBUG - 2018-05-02 06:59:50 --> Total execution time: 0.1310
INFO - 2018-05-02 07:01:51 --> Config Class Initialized
INFO - 2018-05-02 07:01:51 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:01:51 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:01:51 --> Utf8 Class Initialized
INFO - 2018-05-02 07:01:51 --> URI Class Initialized
INFO - 2018-05-02 07:01:51 --> Router Class Initialized
INFO - 2018-05-02 07:01:51 --> Output Class Initialized
INFO - 2018-05-02 07:01:51 --> Security Class Initialized
DEBUG - 2018-05-02 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:01:51 --> Input Class Initialized
INFO - 2018-05-02 07:01:51 --> Language Class Initialized
INFO - 2018-05-02 07:01:51 --> Loader Class Initialized
INFO - 2018-05-02 07:01:51 --> Helper loaded: common_helper
INFO - 2018-05-02 07:01:51 --> Database Driver Class Initialized
INFO - 2018-05-02 07:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:01:51 --> Email Class Initialized
INFO - 2018-05-02 07:01:51 --> Controller Class Initialized
INFO - 2018-05-02 07:01:51 --> Helper loaded: form_helper
INFO - 2018-05-02 07:01:51 --> Form Validation Class Initialized
INFO - 2018-05-02 07:01:51 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:01:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:01:51 --> Helper loaded: url_helper
INFO - 2018-05-02 07:01:51 --> Model Class Initialized
INFO - 2018-05-02 07:01:51 --> Model Class Initialized
INFO - 2018-05-02 07:01:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:01:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:01:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:01:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/editPromotionBanner.php
INFO - 2018-05-02 07:01:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:01:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:01:51 --> Final output sent to browser
DEBUG - 2018-05-02 07:01:51 --> Total execution time: 0.1430
INFO - 2018-05-02 07:01:57 --> Config Class Initialized
INFO - 2018-05-02 07:01:57 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:01:57 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:01:57 --> Utf8 Class Initialized
INFO - 2018-05-02 07:01:57 --> URI Class Initialized
INFO - 2018-05-02 07:01:57 --> Router Class Initialized
INFO - 2018-05-02 07:01:57 --> Output Class Initialized
INFO - 2018-05-02 07:01:57 --> Security Class Initialized
DEBUG - 2018-05-02 07:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:01:57 --> Input Class Initialized
INFO - 2018-05-02 07:01:57 --> Language Class Initialized
INFO - 2018-05-02 07:01:57 --> Loader Class Initialized
INFO - 2018-05-02 07:01:57 --> Helper loaded: common_helper
INFO - 2018-05-02 07:01:57 --> Database Driver Class Initialized
INFO - 2018-05-02 07:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:01:57 --> Email Class Initialized
INFO - 2018-05-02 07:01:57 --> Controller Class Initialized
INFO - 2018-05-02 07:01:57 --> Helper loaded: form_helper
INFO - 2018-05-02 07:01:57 --> Form Validation Class Initialized
INFO - 2018-05-02 07:01:57 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:01:57 --> Helper loaded: url_helper
INFO - 2018-05-02 07:01:57 --> Model Class Initialized
INFO - 2018-05-02 07:01:57 --> Model Class Initialized
DEBUG - 2018-05-02 07:01:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:01:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-02 07:01:57 --> Query error: Duplicate entry '1' for key 'promotion_display_order' - Invalid query: UPDATE `promotion_banners` SET `promotion_title` = 'promotion banners with video code', `promotion_celebrity_id` = '1', `promotion_type` = '25', `promotion_content` = 'promotion banners with video code', `promotion_display_order` = '1', `promotion_updatedTime` = '18-05-02 07:01:57', `promotion_image` = '', `promotion_video_code` = 'DFshJWs2shs'
WHERE `promotion_id` = '4'
INFO - 2018-05-02 07:01:57 --> Config Class Initialized
INFO - 2018-05-02 07:01:57 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:01:57 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:01:57 --> Utf8 Class Initialized
INFO - 2018-05-02 07:01:57 --> URI Class Initialized
INFO - 2018-05-02 07:01:57 --> Router Class Initialized
INFO - 2018-05-02 07:01:57 --> Output Class Initialized
INFO - 2018-05-02 07:01:57 --> Security Class Initialized
DEBUG - 2018-05-02 07:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:01:57 --> Input Class Initialized
INFO - 2018-05-02 07:01:57 --> Language Class Initialized
INFO - 2018-05-02 07:01:57 --> Loader Class Initialized
INFO - 2018-05-02 07:01:57 --> Helper loaded: common_helper
INFO - 2018-05-02 07:01:57 --> Database Driver Class Initialized
INFO - 2018-05-02 07:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:01:57 --> Email Class Initialized
INFO - 2018-05-02 07:01:57 --> Controller Class Initialized
INFO - 2018-05-02 07:01:57 --> Helper loaded: form_helper
INFO - 2018-05-02 07:01:57 --> Form Validation Class Initialized
INFO - 2018-05-02 07:01:57 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:01:57 --> Helper loaded: url_helper
INFO - 2018-05-02 07:01:57 --> Model Class Initialized
INFO - 2018-05-02 07:01:57 --> Model Class Initialized
INFO - 2018-05-02 07:01:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:01:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:01:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:01:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/editPromotionBanner.php
INFO - 2018-05-02 07:01:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:01:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:01:57 --> Final output sent to browser
DEBUG - 2018-05-02 07:01:57 --> Total execution time: 0.1330
INFO - 2018-05-02 07:02:50 --> Config Class Initialized
INFO - 2018-05-02 07:02:50 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:02:50 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:02:50 --> Utf8 Class Initialized
INFO - 2018-05-02 07:02:50 --> URI Class Initialized
INFO - 2018-05-02 07:02:51 --> Router Class Initialized
INFO - 2018-05-02 07:02:51 --> Output Class Initialized
INFO - 2018-05-02 07:02:51 --> Security Class Initialized
DEBUG - 2018-05-02 07:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:02:51 --> Input Class Initialized
INFO - 2018-05-02 07:02:51 --> Language Class Initialized
INFO - 2018-05-02 07:02:51 --> Loader Class Initialized
INFO - 2018-05-02 07:02:51 --> Helper loaded: common_helper
INFO - 2018-05-02 07:02:51 --> Database Driver Class Initialized
INFO - 2018-05-02 07:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:02:51 --> Email Class Initialized
INFO - 2018-05-02 07:02:51 --> Controller Class Initialized
INFO - 2018-05-02 07:02:51 --> Helper loaded: form_helper
INFO - 2018-05-02 07:02:51 --> Form Validation Class Initialized
INFO - 2018-05-02 07:02:51 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:02:51 --> Helper loaded: url_helper
INFO - 2018-05-02 07:02:51 --> Model Class Initialized
INFO - 2018-05-02 07:02:51 --> Model Class Initialized
INFO - 2018-05-02 07:02:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:02:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:02:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:02:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/editPromotionBanner.php
INFO - 2018-05-02 07:02:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:02:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:02:51 --> Final output sent to browser
DEBUG - 2018-05-02 07:02:51 --> Total execution time: 0.1370
INFO - 2018-05-02 07:02:53 --> Config Class Initialized
INFO - 2018-05-02 07:02:53 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:02:53 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:02:53 --> Utf8 Class Initialized
INFO - 2018-05-02 07:02:53 --> URI Class Initialized
INFO - 2018-05-02 07:02:53 --> Router Class Initialized
INFO - 2018-05-02 07:02:53 --> Output Class Initialized
INFO - 2018-05-02 07:02:53 --> Security Class Initialized
DEBUG - 2018-05-02 07:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:02:53 --> Input Class Initialized
INFO - 2018-05-02 07:02:53 --> Language Class Initialized
INFO - 2018-05-02 07:02:53 --> Loader Class Initialized
INFO - 2018-05-02 07:02:53 --> Helper loaded: common_helper
INFO - 2018-05-02 07:02:53 --> Database Driver Class Initialized
INFO - 2018-05-02 07:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:02:53 --> Email Class Initialized
INFO - 2018-05-02 07:02:53 --> Controller Class Initialized
INFO - 2018-05-02 07:02:53 --> Helper loaded: form_helper
INFO - 2018-05-02 07:02:53 --> Form Validation Class Initialized
INFO - 2018-05-02 07:02:53 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:02:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:02:53 --> Helper loaded: url_helper
INFO - 2018-05-02 07:02:53 --> Model Class Initialized
INFO - 2018-05-02 07:02:53 --> Model Class Initialized
DEBUG - 2018-05-02 07:02:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:02:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 07:02:53 --> Config Class Initialized
INFO - 2018-05-02 07:02:53 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:02:53 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:02:53 --> Utf8 Class Initialized
INFO - 2018-05-02 07:02:53 --> URI Class Initialized
INFO - 2018-05-02 07:02:53 --> Router Class Initialized
INFO - 2018-05-02 07:02:53 --> Output Class Initialized
INFO - 2018-05-02 07:02:53 --> Security Class Initialized
DEBUG - 2018-05-02 07:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:02:53 --> Input Class Initialized
INFO - 2018-05-02 07:02:53 --> Language Class Initialized
INFO - 2018-05-02 07:02:53 --> Loader Class Initialized
INFO - 2018-05-02 07:02:53 --> Helper loaded: common_helper
INFO - 2018-05-02 07:02:53 --> Database Driver Class Initialized
INFO - 2018-05-02 07:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:02:53 --> Email Class Initialized
INFO - 2018-05-02 07:02:53 --> Controller Class Initialized
INFO - 2018-05-02 07:02:53 --> Helper loaded: form_helper
INFO - 2018-05-02 07:02:53 --> Form Validation Class Initialized
INFO - 2018-05-02 07:02:53 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:02:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:02:53 --> Helper loaded: url_helper
INFO - 2018-05-02 07:02:53 --> Model Class Initialized
INFO - 2018-05-02 07:02:53 --> Model Class Initialized
INFO - 2018-05-02 07:02:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:02:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:02:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:02:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 07:02:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:02:53 --> Final output sent to browser
DEBUG - 2018-05-02 07:02:53 --> Total execution time: 0.1770
INFO - 2018-05-02 07:03:05 --> Config Class Initialized
INFO - 2018-05-02 07:03:05 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:05 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:05 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:05 --> URI Class Initialized
INFO - 2018-05-02 07:03:05 --> Router Class Initialized
INFO - 2018-05-02 07:03:05 --> Output Class Initialized
INFO - 2018-05-02 07:03:05 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:05 --> Input Class Initialized
INFO - 2018-05-02 07:03:05 --> Language Class Initialized
INFO - 2018-05-02 07:03:05 --> Loader Class Initialized
INFO - 2018-05-02 07:03:05 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:05 --> Database Driver Class Initialized
INFO - 2018-05-02 07:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:05 --> Email Class Initialized
INFO - 2018-05-02 07:03:05 --> Controller Class Initialized
INFO - 2018-05-02 07:03:05 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:05 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:05 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:05 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:05 --> Model Class Initialized
INFO - 2018-05-02 07:03:05 --> Model Class Initialized
INFO - 2018-05-02 07:03:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:03:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:03:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/editPromotionBanner.php
INFO - 2018-05-02 07:03:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:03:05 --> Final output sent to browser
DEBUG - 2018-05-02 07:03:05 --> Total execution time: 0.1470
INFO - 2018-05-02 07:03:06 --> Config Class Initialized
INFO - 2018-05-02 07:03:06 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:06 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:06 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:06 --> URI Class Initialized
INFO - 2018-05-02 07:03:06 --> Router Class Initialized
INFO - 2018-05-02 07:03:06 --> Output Class Initialized
INFO - 2018-05-02 07:03:06 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:06 --> Input Class Initialized
INFO - 2018-05-02 07:03:06 --> Language Class Initialized
INFO - 2018-05-02 07:03:06 --> Loader Class Initialized
INFO - 2018-05-02 07:03:06 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:06 --> Database Driver Class Initialized
INFO - 2018-05-02 07:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:06 --> Email Class Initialized
INFO - 2018-05-02 07:03:06 --> Controller Class Initialized
INFO - 2018-05-02 07:03:06 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:06 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:06 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:06 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:06 --> Model Class Initialized
INFO - 2018-05-02 07:03:06 --> Model Class Initialized
INFO - 2018-05-02 07:03:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:03:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:03:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 07:03:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:03:06 --> Final output sent to browser
DEBUG - 2018-05-02 07:03:06 --> Total execution time: 0.1390
INFO - 2018-05-02 07:03:08 --> Config Class Initialized
INFO - 2018-05-02 07:03:08 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:08 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:08 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:08 --> URI Class Initialized
INFO - 2018-05-02 07:03:08 --> Router Class Initialized
INFO - 2018-05-02 07:03:08 --> Output Class Initialized
INFO - 2018-05-02 07:03:08 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:08 --> Input Class Initialized
INFO - 2018-05-02 07:03:08 --> Language Class Initialized
INFO - 2018-05-02 07:03:08 --> Loader Class Initialized
INFO - 2018-05-02 07:03:08 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:08 --> Database Driver Class Initialized
INFO - 2018-05-02 07:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:08 --> Email Class Initialized
INFO - 2018-05-02 07:03:08 --> Controller Class Initialized
INFO - 2018-05-02 07:03:08 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:08 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:08 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:08 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:08 --> Model Class Initialized
INFO - 2018-05-02 07:03:08 --> Model Class Initialized
INFO - 2018-05-02 07:03:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:03:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:03:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/addPromotionBanner.php
INFO - 2018-05-02 07:03:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:03:08 --> Final output sent to browser
DEBUG - 2018-05-02 07:03:08 --> Total execution time: 0.1620
INFO - 2018-05-02 07:03:22 --> Config Class Initialized
INFO - 2018-05-02 07:03:22 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:22 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:22 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:22 --> URI Class Initialized
INFO - 2018-05-02 07:03:22 --> Router Class Initialized
INFO - 2018-05-02 07:03:22 --> Output Class Initialized
INFO - 2018-05-02 07:03:22 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:22 --> Input Class Initialized
INFO - 2018-05-02 07:03:22 --> Language Class Initialized
INFO - 2018-05-02 07:03:22 --> Loader Class Initialized
INFO - 2018-05-02 07:03:22 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:22 --> Database Driver Class Initialized
INFO - 2018-05-02 07:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:22 --> Email Class Initialized
INFO - 2018-05-02 07:03:22 --> Controller Class Initialized
INFO - 2018-05-02 07:03:22 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:22 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:22 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:22 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:22 --> Model Class Initialized
INFO - 2018-05-02 07:03:22 --> Model Class Initialized
DEBUG - 2018-05-02 07:03:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 07:03:42 --> Config Class Initialized
INFO - 2018-05-02 07:03:42 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:42 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:42 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:42 --> URI Class Initialized
INFO - 2018-05-02 07:03:42 --> Router Class Initialized
INFO - 2018-05-02 07:03:42 --> Output Class Initialized
INFO - 2018-05-02 07:03:42 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:42 --> Input Class Initialized
INFO - 2018-05-02 07:03:42 --> Language Class Initialized
INFO - 2018-05-02 07:03:42 --> Loader Class Initialized
INFO - 2018-05-02 07:03:42 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:42 --> Database Driver Class Initialized
INFO - 2018-05-02 07:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:42 --> Email Class Initialized
INFO - 2018-05-02 07:03:42 --> Controller Class Initialized
INFO - 2018-05-02 07:03:42 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:42 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:42 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:42 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:42 --> Model Class Initialized
INFO - 2018-05-02 07:03:42 --> Model Class Initialized
DEBUG - 2018-05-02 07:03:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-02 07:03:43 --> Query error: Duplicate entry '1' for key 'promotion_display_order' - Invalid query: INSERT INTO `promotion_banners` (`promotion_title`, `promotion_celebrity_id`, `promotion_type`, `promotion_content`, `promotion_display_order`, `promotion_createdTime`, `promotion_video_file`, `promotion_thumb_image`, `promotion_video_code`, `promotion_image`) VALUES ('Zxcvb', '1', '24', 'zxcvbn', '1', '18-05-02 07:03:42', '', '', '', '223561525237422.jpg')
INFO - 2018-05-02 07:03:43 --> Config Class Initialized
INFO - 2018-05-02 07:03:43 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:43 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:43 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:43 --> URI Class Initialized
INFO - 2018-05-02 07:03:43 --> Router Class Initialized
INFO - 2018-05-02 07:03:43 --> Output Class Initialized
INFO - 2018-05-02 07:03:43 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:43 --> Input Class Initialized
INFO - 2018-05-02 07:03:43 --> Language Class Initialized
INFO - 2018-05-02 07:03:43 --> Loader Class Initialized
INFO - 2018-05-02 07:03:43 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:43 --> Database Driver Class Initialized
INFO - 2018-05-02 07:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:43 --> Email Class Initialized
INFO - 2018-05-02 07:03:43 --> Controller Class Initialized
INFO - 2018-05-02 07:03:43 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:43 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:43 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:43 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:43 --> Model Class Initialized
INFO - 2018-05-02 07:03:43 --> Model Class Initialized
INFO - 2018-05-02 07:03:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:03:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:03:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/addPromotionBanner.php
INFO - 2018-05-02 07:03:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:03:43 --> Final output sent to browser
DEBUG - 2018-05-02 07:03:43 --> Total execution time: 0.1300
INFO - 2018-05-02 07:03:48 --> Config Class Initialized
INFO - 2018-05-02 07:03:48 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:48 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:48 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:48 --> URI Class Initialized
INFO - 2018-05-02 07:03:48 --> Router Class Initialized
INFO - 2018-05-02 07:03:48 --> Output Class Initialized
INFO - 2018-05-02 07:03:48 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:48 --> Input Class Initialized
INFO - 2018-05-02 07:03:48 --> Language Class Initialized
INFO - 2018-05-02 07:03:48 --> Loader Class Initialized
INFO - 2018-05-02 07:03:48 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:48 --> Database Driver Class Initialized
INFO - 2018-05-02 07:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:48 --> Email Class Initialized
INFO - 2018-05-02 07:03:48 --> Controller Class Initialized
INFO - 2018-05-02 07:03:48 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:48 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:48 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:48 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:48 --> Model Class Initialized
INFO - 2018-05-02 07:03:48 --> Model Class Initialized
INFO - 2018-05-02 07:03:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:03:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:03:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/addPromotionBanner.php
INFO - 2018-05-02 07:03:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:03:48 --> Final output sent to browser
DEBUG - 2018-05-02 07:03:48 --> Total execution time: 0.1620
INFO - 2018-05-02 07:03:49 --> Config Class Initialized
INFO - 2018-05-02 07:03:49 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:49 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:49 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:49 --> URI Class Initialized
INFO - 2018-05-02 07:03:49 --> Router Class Initialized
INFO - 2018-05-02 07:03:49 --> Output Class Initialized
INFO - 2018-05-02 07:03:49 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:49 --> Input Class Initialized
INFO - 2018-05-02 07:03:49 --> Language Class Initialized
INFO - 2018-05-02 07:03:49 --> Loader Class Initialized
INFO - 2018-05-02 07:03:49 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:49 --> Database Driver Class Initialized
INFO - 2018-05-02 07:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:49 --> Email Class Initialized
INFO - 2018-05-02 07:03:49 --> Controller Class Initialized
INFO - 2018-05-02 07:03:49 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:49 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:49 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:49 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:49 --> Model Class Initialized
INFO - 2018-05-02 07:03:49 --> Model Class Initialized
INFO - 2018-05-02 07:03:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:03:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:03:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 07:03:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:03:49 --> Final output sent to browser
DEBUG - 2018-05-02 07:03:49 --> Total execution time: 0.1390
INFO - 2018-05-02 07:03:50 --> Config Class Initialized
INFO - 2018-05-02 07:03:50 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:50 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:50 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:50 --> URI Class Initialized
INFO - 2018-05-02 07:03:50 --> Router Class Initialized
INFO - 2018-05-02 07:03:50 --> Output Class Initialized
INFO - 2018-05-02 07:03:50 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:50 --> Input Class Initialized
INFO - 2018-05-02 07:03:50 --> Language Class Initialized
INFO - 2018-05-02 07:03:50 --> Loader Class Initialized
INFO - 2018-05-02 07:03:50 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:50 --> Database Driver Class Initialized
INFO - 2018-05-02 07:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:50 --> Email Class Initialized
INFO - 2018-05-02 07:03:50 --> Controller Class Initialized
INFO - 2018-05-02 07:03:50 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:50 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:50 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:50 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:50 --> Model Class Initialized
INFO - 2018-05-02 07:03:50 --> Model Class Initialized
INFO - 2018-05-02 07:03:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:03:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:03:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/editPromotionBanner.php
INFO - 2018-05-02 07:03:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:03:50 --> Final output sent to browser
DEBUG - 2018-05-02 07:03:50 --> Total execution time: 0.1970
INFO - 2018-05-02 07:03:50 --> Config Class Initialized
INFO - 2018-05-02 07:03:50 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:50 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:50 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:50 --> URI Class Initialized
INFO - 2018-05-02 07:03:50 --> Router Class Initialized
INFO - 2018-05-02 07:03:50 --> Output Class Initialized
INFO - 2018-05-02 07:03:50 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:50 --> Input Class Initialized
INFO - 2018-05-02 07:03:50 --> Language Class Initialized
INFO - 2018-05-02 07:03:50 --> Loader Class Initialized
INFO - 2018-05-02 07:03:50 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:50 --> Database Driver Class Initialized
ERROR - 2018-05-02 07:03:50 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-02 07:03:50 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-02 07:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:50 --> Email Class Initialized
INFO - 2018-05-02 07:03:50 --> Controller Class Initialized
INFO - 2018-05-02 07:03:50 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:50 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:50 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:50 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:50 --> Model Class Initialized
INFO - 2018-05-02 07:03:50 --> Model Class Initialized
INFO - 2018-05-02 07:03:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:03:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:03:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 07:03:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:03:50 --> Final output sent to browser
DEBUG - 2018-05-02 07:03:50 --> Total execution time: 0.1800
INFO - 2018-05-02 07:03:51 --> Config Class Initialized
INFO - 2018-05-02 07:03:51 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:51 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:51 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:51 --> URI Class Initialized
INFO - 2018-05-02 07:03:51 --> Router Class Initialized
INFO - 2018-05-02 07:03:51 --> Output Class Initialized
INFO - 2018-05-02 07:03:51 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:51 --> Input Class Initialized
INFO - 2018-05-02 07:03:51 --> Language Class Initialized
INFO - 2018-05-02 07:03:51 --> Loader Class Initialized
INFO - 2018-05-02 07:03:51 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:51 --> Database Driver Class Initialized
INFO - 2018-05-02 07:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:51 --> Email Class Initialized
INFO - 2018-05-02 07:03:51 --> Controller Class Initialized
INFO - 2018-05-02 07:03:51 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:51 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:51 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:51 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:51 --> Model Class Initialized
INFO - 2018-05-02 07:03:51 --> Model Class Initialized
INFO - 2018-05-02 07:03:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:03:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:03:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/editPromotionBanner.php
INFO - 2018-05-02 07:03:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:03:51 --> Final output sent to browser
DEBUG - 2018-05-02 07:03:51 --> Total execution time: 0.1290
INFO - 2018-05-02 07:03:52 --> Config Class Initialized
INFO - 2018-05-02 07:03:52 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:52 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:52 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:52 --> URI Class Initialized
INFO - 2018-05-02 07:03:52 --> Router Class Initialized
INFO - 2018-05-02 07:03:52 --> Output Class Initialized
INFO - 2018-05-02 07:03:52 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:52 --> Input Class Initialized
INFO - 2018-05-02 07:03:52 --> Language Class Initialized
INFO - 2018-05-02 07:03:52 --> Loader Class Initialized
INFO - 2018-05-02 07:03:52 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:52 --> Database Driver Class Initialized
INFO - 2018-05-02 07:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:52 --> Email Class Initialized
INFO - 2018-05-02 07:03:52 --> Controller Class Initialized
INFO - 2018-05-02 07:03:52 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:52 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:52 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:52 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:52 --> Model Class Initialized
INFO - 2018-05-02 07:03:52 --> Model Class Initialized
INFO - 2018-05-02 07:03:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 07:03:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 07:03:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:03:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-02 07:03:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 07:03:52 --> Final output sent to browser
DEBUG - 2018-05-02 07:03:52 --> Total execution time: 0.1420
INFO - 2018-05-02 07:03:52 --> Config Class Initialized
INFO - 2018-05-02 07:03:52 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:03:52 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:03:52 --> Utf8 Class Initialized
INFO - 2018-05-02 07:03:52 --> URI Class Initialized
INFO - 2018-05-02 07:03:52 --> Router Class Initialized
INFO - 2018-05-02 07:03:52 --> Output Class Initialized
INFO - 2018-05-02 07:03:52 --> Security Class Initialized
DEBUG - 2018-05-02 07:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:03:52 --> Input Class Initialized
INFO - 2018-05-02 07:03:52 --> Language Class Initialized
INFO - 2018-05-02 07:03:52 --> Loader Class Initialized
INFO - 2018-05-02 07:03:52 --> Helper loaded: common_helper
INFO - 2018-05-02 07:03:52 --> Database Driver Class Initialized
INFO - 2018-05-02 07:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:03:52 --> Email Class Initialized
INFO - 2018-05-02 07:03:52 --> Controller Class Initialized
INFO - 2018-05-02 07:03:52 --> Helper loaded: form_helper
INFO - 2018-05-02 07:03:52 --> Form Validation Class Initialized
INFO - 2018-05-02 07:03:52 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:03:52 --> Helper loaded: url_helper
INFO - 2018-05-02 07:03:52 --> Model Class Initialized
INFO - 2018-05-02 07:03:52 --> Model Class Initialized
INFO - 2018-05-02 07:03:52 --> Model Class Initialized
INFO - 2018-05-02 10:33:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:33:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:33:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 10:33:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:33:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:33:52 --> Final output sent to browser
DEBUG - 2018-05-02 10:33:52 --> Total execution time: 0.1910
INFO - 2018-05-02 07:16:30 --> Config Class Initialized
INFO - 2018-05-02 07:16:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:16:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:16:30 --> Utf8 Class Initialized
INFO - 2018-05-02 07:16:30 --> URI Class Initialized
INFO - 2018-05-02 07:16:30 --> Router Class Initialized
INFO - 2018-05-02 07:16:30 --> Output Class Initialized
INFO - 2018-05-02 07:16:30 --> Security Class Initialized
DEBUG - 2018-05-02 07:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:16:30 --> Input Class Initialized
INFO - 2018-05-02 07:16:30 --> Language Class Initialized
INFO - 2018-05-02 07:16:30 --> Loader Class Initialized
INFO - 2018-05-02 07:16:30 --> Helper loaded: common_helper
INFO - 2018-05-02 07:16:30 --> Database Driver Class Initialized
INFO - 2018-05-02 07:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:16:30 --> Email Class Initialized
INFO - 2018-05-02 07:16:30 --> Controller Class Initialized
INFO - 2018-05-02 07:16:30 --> Helper loaded: form_helper
INFO - 2018-05-02 07:16:30 --> Form Validation Class Initialized
INFO - 2018-05-02 07:16:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:16:30 --> Helper loaded: url_helper
INFO - 2018-05-02 07:16:30 --> Model Class Initialized
INFO - 2018-05-02 07:16:30 --> Model Class Initialized
INFO - 2018-05-02 07:16:30 --> Model Class Initialized
INFO - 2018-05-02 10:46:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:46:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:46:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:46:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-02 10:46:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:46:30 --> Final output sent to browser
DEBUG - 2018-05-02 10:46:30 --> Total execution time: 0.1470
INFO - 2018-05-02 07:16:34 --> Config Class Initialized
INFO - 2018-05-02 07:16:34 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:16:34 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:16:34 --> Utf8 Class Initialized
INFO - 2018-05-02 07:16:34 --> URI Class Initialized
INFO - 2018-05-02 07:16:34 --> Router Class Initialized
INFO - 2018-05-02 07:16:34 --> Output Class Initialized
INFO - 2018-05-02 07:16:34 --> Security Class Initialized
DEBUG - 2018-05-02 07:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:16:34 --> Input Class Initialized
INFO - 2018-05-02 07:16:34 --> Language Class Initialized
INFO - 2018-05-02 07:16:34 --> Loader Class Initialized
INFO - 2018-05-02 07:16:34 --> Helper loaded: common_helper
INFO - 2018-05-02 07:16:34 --> Database Driver Class Initialized
INFO - 2018-05-02 07:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:16:34 --> Email Class Initialized
INFO - 2018-05-02 07:16:34 --> Controller Class Initialized
INFO - 2018-05-02 07:16:34 --> Helper loaded: form_helper
INFO - 2018-05-02 07:16:34 --> Form Validation Class Initialized
INFO - 2018-05-02 07:16:34 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:16:34 --> Helper loaded: url_helper
INFO - 2018-05-02 07:16:34 --> Model Class Initialized
INFO - 2018-05-02 07:16:34 --> Model Class Initialized
INFO - 2018-05-02 07:16:34 --> Model Class Initialized
INFO - 2018-05-02 07:16:34 --> Config Class Initialized
INFO - 2018-05-02 07:16:34 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:16:34 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:16:34 --> Utf8 Class Initialized
INFO - 2018-05-02 07:16:34 --> URI Class Initialized
INFO - 2018-05-02 07:16:34 --> Router Class Initialized
INFO - 2018-05-02 07:16:34 --> Output Class Initialized
INFO - 2018-05-02 07:16:34 --> Security Class Initialized
DEBUG - 2018-05-02 07:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:16:34 --> Input Class Initialized
INFO - 2018-05-02 07:16:34 --> Language Class Initialized
INFO - 2018-05-02 07:16:34 --> Loader Class Initialized
INFO - 2018-05-02 07:16:34 --> Helper loaded: common_helper
INFO - 2018-05-02 07:16:34 --> Database Driver Class Initialized
INFO - 2018-05-02 07:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:16:34 --> Email Class Initialized
INFO - 2018-05-02 07:16:34 --> Controller Class Initialized
INFO - 2018-05-02 07:16:34 --> Helper loaded: form_helper
INFO - 2018-05-02 07:16:34 --> Form Validation Class Initialized
INFO - 2018-05-02 07:16:34 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:16:34 --> Helper loaded: url_helper
INFO - 2018-05-02 07:16:34 --> Model Class Initialized
INFO - 2018-05-02 07:16:34 --> Model Class Initialized
INFO - 2018-05-02 07:16:34 --> Model Class Initialized
INFO - 2018-05-02 10:46:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:46:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:46:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:46:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-02 10:46:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:46:34 --> Final output sent to browser
DEBUG - 2018-05-02 10:46:34 --> Total execution time: 0.1320
INFO - 2018-05-02 07:17:32 --> Config Class Initialized
INFO - 2018-05-02 07:17:32 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:17:32 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:17:32 --> Utf8 Class Initialized
INFO - 2018-05-02 07:17:32 --> URI Class Initialized
INFO - 2018-05-02 07:17:32 --> Router Class Initialized
INFO - 2018-05-02 07:17:32 --> Output Class Initialized
INFO - 2018-05-02 07:17:32 --> Security Class Initialized
DEBUG - 2018-05-02 07:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:17:32 --> Input Class Initialized
INFO - 2018-05-02 07:17:32 --> Language Class Initialized
INFO - 2018-05-02 07:17:32 --> Loader Class Initialized
INFO - 2018-05-02 07:17:32 --> Helper loaded: common_helper
INFO - 2018-05-02 07:17:32 --> Database Driver Class Initialized
INFO - 2018-05-02 07:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:17:32 --> Email Class Initialized
INFO - 2018-05-02 07:17:32 --> Controller Class Initialized
INFO - 2018-05-02 07:17:32 --> Helper loaded: form_helper
INFO - 2018-05-02 07:17:32 --> Form Validation Class Initialized
INFO - 2018-05-02 07:17:32 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:17:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:17:32 --> Helper loaded: url_helper
INFO - 2018-05-02 07:17:32 --> Model Class Initialized
INFO - 2018-05-02 07:17:32 --> Model Class Initialized
INFO - 2018-05-02 07:17:32 --> Model Class Initialized
INFO - 2018-05-02 10:47:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:47:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:47:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:47:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-02 10:47:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:47:32 --> Final output sent to browser
DEBUG - 2018-05-02 10:47:32 --> Total execution time: 0.1380
INFO - 2018-05-02 07:18:10 --> Config Class Initialized
INFO - 2018-05-02 07:18:10 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:18:10 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:18:10 --> Utf8 Class Initialized
INFO - 2018-05-02 07:18:10 --> URI Class Initialized
INFO - 2018-05-02 07:18:10 --> Router Class Initialized
INFO - 2018-05-02 07:18:10 --> Output Class Initialized
INFO - 2018-05-02 07:18:10 --> Security Class Initialized
DEBUG - 2018-05-02 07:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:18:10 --> Input Class Initialized
INFO - 2018-05-02 07:18:10 --> Language Class Initialized
INFO - 2018-05-02 07:18:10 --> Loader Class Initialized
INFO - 2018-05-02 07:18:10 --> Helper loaded: common_helper
INFO - 2018-05-02 07:18:10 --> Database Driver Class Initialized
INFO - 2018-05-02 07:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:18:10 --> Email Class Initialized
INFO - 2018-05-02 07:18:10 --> Controller Class Initialized
INFO - 2018-05-02 07:18:10 --> Helper loaded: form_helper
INFO - 2018-05-02 07:18:10 --> Form Validation Class Initialized
INFO - 2018-05-02 07:18:10 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:18:10 --> Helper loaded: url_helper
INFO - 2018-05-02 07:18:10 --> Model Class Initialized
INFO - 2018-05-02 07:18:10 --> Model Class Initialized
INFO - 2018-05-02 07:18:10 --> Model Class Initialized
INFO - 2018-05-02 10:48:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:48:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:48:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:48:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-02 10:48:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:48:10 --> Final output sent to browser
DEBUG - 2018-05-02 10:48:10 --> Total execution time: 0.1290
INFO - 2018-05-02 07:18:15 --> Config Class Initialized
INFO - 2018-05-02 07:18:15 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:18:15 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:18:15 --> Utf8 Class Initialized
INFO - 2018-05-02 07:18:15 --> URI Class Initialized
INFO - 2018-05-02 07:18:15 --> Router Class Initialized
INFO - 2018-05-02 07:18:15 --> Output Class Initialized
INFO - 2018-05-02 07:18:15 --> Security Class Initialized
DEBUG - 2018-05-02 07:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:18:15 --> Input Class Initialized
INFO - 2018-05-02 07:18:15 --> Language Class Initialized
INFO - 2018-05-02 07:18:15 --> Loader Class Initialized
INFO - 2018-05-02 07:18:15 --> Helper loaded: common_helper
INFO - 2018-05-02 07:18:15 --> Database Driver Class Initialized
INFO - 2018-05-02 07:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:18:15 --> Email Class Initialized
INFO - 2018-05-02 07:18:15 --> Controller Class Initialized
INFO - 2018-05-02 07:18:15 --> Helper loaded: form_helper
INFO - 2018-05-02 07:18:15 --> Form Validation Class Initialized
INFO - 2018-05-02 07:18:15 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:18:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:18:15 --> Helper loaded: url_helper
INFO - 2018-05-02 07:18:15 --> Model Class Initialized
INFO - 2018-05-02 07:18:15 --> Model Class Initialized
INFO - 2018-05-02 07:18:15 --> Model Class Initialized
ERROR - 2018-05-02 10:48:15 --> rmdir(../uploads/gallery/moviePicks): No such file or directory
ERROR - 2018-05-02 10:48:15 --> Severity: Warning --> rmdir(../uploads/gallery/moviePicks): No such file or directory C:\xampp\htdocs\Celebrity\admin\application\controllers\Galery.php 251
INFO - 2018-05-02 07:18:19 --> Config Class Initialized
INFO - 2018-05-02 07:18:19 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:18:19 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:18:19 --> Utf8 Class Initialized
INFO - 2018-05-02 07:18:19 --> URI Class Initialized
INFO - 2018-05-02 07:18:19 --> Router Class Initialized
INFO - 2018-05-02 07:18:19 --> Output Class Initialized
INFO - 2018-05-02 07:18:19 --> Security Class Initialized
DEBUG - 2018-05-02 07:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:18:19 --> Input Class Initialized
INFO - 2018-05-02 07:18:19 --> Language Class Initialized
INFO - 2018-05-02 07:18:19 --> Loader Class Initialized
INFO - 2018-05-02 07:18:19 --> Helper loaded: common_helper
INFO - 2018-05-02 07:18:19 --> Database Driver Class Initialized
INFO - 2018-05-02 07:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:18:19 --> Email Class Initialized
INFO - 2018-05-02 07:18:19 --> Controller Class Initialized
INFO - 2018-05-02 07:18:19 --> Helper loaded: form_helper
INFO - 2018-05-02 07:18:19 --> Form Validation Class Initialized
INFO - 2018-05-02 07:18:19 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:18:19 --> Helper loaded: url_helper
INFO - 2018-05-02 07:18:19 --> Model Class Initialized
INFO - 2018-05-02 07:18:19 --> Model Class Initialized
INFO - 2018-05-02 07:18:19 --> Model Class Initialized
INFO - 2018-05-02 10:48:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:48:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:48:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:48:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-02 10:48:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:48:19 --> Final output sent to browser
DEBUG - 2018-05-02 10:48:19 --> Total execution time: 0.1420
INFO - 2018-05-02 07:19:59 --> Config Class Initialized
INFO - 2018-05-02 07:19:59 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:19:59 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:19:59 --> Utf8 Class Initialized
INFO - 2018-05-02 07:19:59 --> URI Class Initialized
INFO - 2018-05-02 07:19:59 --> Router Class Initialized
INFO - 2018-05-02 07:19:59 --> Output Class Initialized
INFO - 2018-05-02 07:19:59 --> Security Class Initialized
DEBUG - 2018-05-02 07:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:19:59 --> Input Class Initialized
INFO - 2018-05-02 07:19:59 --> Language Class Initialized
INFO - 2018-05-02 07:19:59 --> Loader Class Initialized
INFO - 2018-05-02 07:19:59 --> Helper loaded: common_helper
INFO - 2018-05-02 07:19:59 --> Database Driver Class Initialized
INFO - 2018-05-02 07:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:19:59 --> Email Class Initialized
INFO - 2018-05-02 07:19:59 --> Controller Class Initialized
INFO - 2018-05-02 07:19:59 --> Helper loaded: form_helper
INFO - 2018-05-02 07:19:59 --> Form Validation Class Initialized
INFO - 2018-05-02 07:19:59 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:19:59 --> Helper loaded: url_helper
INFO - 2018-05-02 07:19:59 --> Model Class Initialized
INFO - 2018-05-02 07:19:59 --> Model Class Initialized
INFO - 2018-05-02 07:19:59 --> Model Class Initialized
INFO - 2018-05-02 10:49:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:49:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:49:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:49:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-02 10:49:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:49:59 --> Final output sent to browser
DEBUG - 2018-05-02 10:49:59 --> Total execution time: 0.1400
INFO - 2018-05-02 07:20:03 --> Config Class Initialized
INFO - 2018-05-02 07:20:03 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:20:03 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:20:03 --> Utf8 Class Initialized
INFO - 2018-05-02 07:20:03 --> URI Class Initialized
INFO - 2018-05-02 07:20:03 --> Router Class Initialized
INFO - 2018-05-02 07:20:03 --> Output Class Initialized
INFO - 2018-05-02 07:20:03 --> Security Class Initialized
DEBUG - 2018-05-02 07:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:20:03 --> Input Class Initialized
INFO - 2018-05-02 07:20:03 --> Language Class Initialized
INFO - 2018-05-02 07:20:03 --> Loader Class Initialized
INFO - 2018-05-02 07:20:03 --> Helper loaded: common_helper
INFO - 2018-05-02 07:20:03 --> Database Driver Class Initialized
INFO - 2018-05-02 07:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:20:03 --> Email Class Initialized
INFO - 2018-05-02 07:20:03 --> Controller Class Initialized
INFO - 2018-05-02 07:20:03 --> Helper loaded: form_helper
INFO - 2018-05-02 07:20:03 --> Form Validation Class Initialized
INFO - 2018-05-02 07:20:03 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:20:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:20:03 --> Helper loaded: url_helper
INFO - 2018-05-02 07:20:03 --> Model Class Initialized
INFO - 2018-05-02 07:20:03 --> Model Class Initialized
INFO - 2018-05-02 07:20:03 --> Model Class Initialized
ERROR - 2018-05-02 10:50:03 --> rmdir(../uploads/gallery/shooting_Picks): No such file or directory
ERROR - 2018-05-02 10:50:03 --> Severity: Warning --> rmdir(../uploads/gallery/shooting_Picks): No such file or directory C:\xampp\htdocs\Celebrity\admin\application\controllers\Galery.php 251
INFO - 2018-05-02 07:20:08 --> Config Class Initialized
INFO - 2018-05-02 07:20:08 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:20:08 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:20:08 --> Utf8 Class Initialized
INFO - 2018-05-02 07:20:08 --> URI Class Initialized
INFO - 2018-05-02 07:20:08 --> Router Class Initialized
INFO - 2018-05-02 07:20:08 --> Output Class Initialized
INFO - 2018-05-02 07:20:08 --> Security Class Initialized
DEBUG - 2018-05-02 07:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:20:08 --> Input Class Initialized
INFO - 2018-05-02 07:20:08 --> Language Class Initialized
INFO - 2018-05-02 07:20:08 --> Loader Class Initialized
INFO - 2018-05-02 07:20:08 --> Helper loaded: common_helper
INFO - 2018-05-02 07:20:08 --> Database Driver Class Initialized
INFO - 2018-05-02 07:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:20:08 --> Email Class Initialized
INFO - 2018-05-02 07:20:08 --> Controller Class Initialized
INFO - 2018-05-02 07:20:08 --> Helper loaded: form_helper
INFO - 2018-05-02 07:20:08 --> Form Validation Class Initialized
INFO - 2018-05-02 07:20:08 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:20:08 --> Helper loaded: url_helper
INFO - 2018-05-02 07:20:08 --> Model Class Initialized
INFO - 2018-05-02 07:20:08 --> Model Class Initialized
INFO - 2018-05-02 07:20:08 --> Model Class Initialized
ERROR - 2018-05-02 10:50:08 --> rmdir(../uploads/gallery/shooting_Picks): No such file or directory
ERROR - 2018-05-02 10:50:08 --> Severity: Warning --> rmdir(../uploads/gallery/shooting_Picks): No such file or directory C:\xampp\htdocs\Celebrity\admin\application\controllers\Galery.php 251
INFO - 2018-05-02 07:20:22 --> Config Class Initialized
INFO - 2018-05-02 07:20:22 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:20:22 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:20:22 --> Utf8 Class Initialized
INFO - 2018-05-02 07:20:22 --> URI Class Initialized
INFO - 2018-05-02 07:20:22 --> Router Class Initialized
INFO - 2018-05-02 07:20:22 --> Output Class Initialized
INFO - 2018-05-02 07:20:22 --> Security Class Initialized
DEBUG - 2018-05-02 07:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:20:22 --> Input Class Initialized
INFO - 2018-05-02 07:20:22 --> Language Class Initialized
INFO - 2018-05-02 07:20:22 --> Loader Class Initialized
INFO - 2018-05-02 07:20:22 --> Helper loaded: common_helper
INFO - 2018-05-02 07:20:22 --> Database Driver Class Initialized
INFO - 2018-05-02 07:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:20:22 --> Email Class Initialized
INFO - 2018-05-02 07:20:22 --> Controller Class Initialized
INFO - 2018-05-02 07:20:22 --> Helper loaded: form_helper
INFO - 2018-05-02 07:20:22 --> Form Validation Class Initialized
INFO - 2018-05-02 07:20:22 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:20:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:20:22 --> Helper loaded: url_helper
INFO - 2018-05-02 07:20:22 --> Model Class Initialized
INFO - 2018-05-02 07:20:22 --> Model Class Initialized
INFO - 2018-05-02 07:20:22 --> Model Class Initialized
INFO - 2018-05-02 10:50:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:50:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:50:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:50:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-02 10:50:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:50:22 --> Final output sent to browser
DEBUG - 2018-05-02 10:50:22 --> Total execution time: 0.1280
INFO - 2018-05-02 07:20:57 --> Config Class Initialized
INFO - 2018-05-02 07:20:57 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:20:57 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:20:57 --> Utf8 Class Initialized
INFO - 2018-05-02 07:20:57 --> URI Class Initialized
INFO - 2018-05-02 07:20:57 --> Router Class Initialized
INFO - 2018-05-02 07:20:57 --> Output Class Initialized
INFO - 2018-05-02 07:20:57 --> Security Class Initialized
DEBUG - 2018-05-02 07:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:20:57 --> Input Class Initialized
INFO - 2018-05-02 07:20:57 --> Language Class Initialized
INFO - 2018-05-02 07:20:57 --> Loader Class Initialized
INFO - 2018-05-02 07:20:57 --> Helper loaded: common_helper
INFO - 2018-05-02 07:20:57 --> Database Driver Class Initialized
INFO - 2018-05-02 07:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:20:57 --> Email Class Initialized
INFO - 2018-05-02 07:20:57 --> Controller Class Initialized
INFO - 2018-05-02 07:20:57 --> Helper loaded: form_helper
INFO - 2018-05-02 07:20:57 --> Form Validation Class Initialized
INFO - 2018-05-02 07:20:57 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:20:57 --> Helper loaded: url_helper
INFO - 2018-05-02 07:20:57 --> Model Class Initialized
INFO - 2018-05-02 07:20:57 --> Model Class Initialized
INFO - 2018-05-02 07:20:57 --> Model Class Initialized
INFO - 2018-05-02 10:50:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:50:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:50:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 10:50:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:50:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:50:57 --> Final output sent to browser
DEBUG - 2018-05-02 10:50:57 --> Total execution time: 0.1370
INFO - 2018-05-02 07:29:03 --> Config Class Initialized
INFO - 2018-05-02 07:29:03 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:29:03 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:29:03 --> Utf8 Class Initialized
INFO - 2018-05-02 07:29:04 --> URI Class Initialized
INFO - 2018-05-02 07:29:04 --> Router Class Initialized
INFO - 2018-05-02 07:29:04 --> Output Class Initialized
INFO - 2018-05-02 07:29:04 --> Security Class Initialized
DEBUG - 2018-05-02 07:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:29:04 --> Input Class Initialized
INFO - 2018-05-02 07:29:04 --> Language Class Initialized
INFO - 2018-05-02 07:29:04 --> Loader Class Initialized
INFO - 2018-05-02 07:29:04 --> Helper loaded: common_helper
INFO - 2018-05-02 07:29:04 --> Database Driver Class Initialized
INFO - 2018-05-02 07:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:29:04 --> Email Class Initialized
INFO - 2018-05-02 07:29:04 --> Controller Class Initialized
INFO - 2018-05-02 07:29:04 --> Helper loaded: form_helper
INFO - 2018-05-02 07:29:04 --> Form Validation Class Initialized
INFO - 2018-05-02 07:29:04 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:29:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:29:04 --> Helper loaded: url_helper
INFO - 2018-05-02 07:29:04 --> Model Class Initialized
INFO - 2018-05-02 07:29:04 --> Model Class Initialized
INFO - 2018-05-02 07:29:04 --> Model Class Initialized
INFO - 2018-05-02 10:59:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:59:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:59:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:59:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-02 10:59:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:59:04 --> Final output sent to browser
DEBUG - 2018-05-02 10:59:04 --> Total execution time: 0.1310
INFO - 2018-05-02 07:29:06 --> Config Class Initialized
INFO - 2018-05-02 07:29:06 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:29:06 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:29:06 --> Utf8 Class Initialized
INFO - 2018-05-02 07:29:06 --> URI Class Initialized
INFO - 2018-05-02 07:29:06 --> Router Class Initialized
INFO - 2018-05-02 07:29:06 --> Output Class Initialized
INFO - 2018-05-02 07:29:06 --> Security Class Initialized
DEBUG - 2018-05-02 07:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:29:06 --> Input Class Initialized
INFO - 2018-05-02 07:29:06 --> Language Class Initialized
INFO - 2018-05-02 07:29:06 --> Loader Class Initialized
INFO - 2018-05-02 07:29:06 --> Helper loaded: common_helper
INFO - 2018-05-02 07:29:06 --> Database Driver Class Initialized
INFO - 2018-05-02 07:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:29:07 --> Email Class Initialized
INFO - 2018-05-02 07:29:07 --> Controller Class Initialized
INFO - 2018-05-02 07:29:07 --> Helper loaded: form_helper
INFO - 2018-05-02 07:29:07 --> Form Validation Class Initialized
INFO - 2018-05-02 07:29:07 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:29:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:29:07 --> Helper loaded: url_helper
INFO - 2018-05-02 07:29:07 --> Model Class Initialized
INFO - 2018-05-02 07:29:07 --> Model Class Initialized
INFO - 2018-05-02 07:29:07 --> Model Class Initialized
INFO - 2018-05-02 10:59:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:59:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 10:59:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 10:59:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:59:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:59:07 --> Final output sent to browser
DEBUG - 2018-05-02 10:59:07 --> Total execution time: 0.1710
INFO - 2018-05-02 07:34:31 --> Config Class Initialized
INFO - 2018-05-02 07:34:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:34:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:34:31 --> Utf8 Class Initialized
INFO - 2018-05-02 07:34:31 --> URI Class Initialized
INFO - 2018-05-02 07:34:31 --> Router Class Initialized
INFO - 2018-05-02 07:34:31 --> Output Class Initialized
INFO - 2018-05-02 07:34:31 --> Security Class Initialized
DEBUG - 2018-05-02 07:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:34:31 --> Input Class Initialized
INFO - 2018-05-02 07:34:31 --> Language Class Initialized
INFO - 2018-05-02 07:34:31 --> Loader Class Initialized
INFO - 2018-05-02 07:34:31 --> Helper loaded: common_helper
INFO - 2018-05-02 07:34:31 --> Database Driver Class Initialized
INFO - 2018-05-02 07:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:34:31 --> Email Class Initialized
INFO - 2018-05-02 07:34:31 --> Controller Class Initialized
INFO - 2018-05-02 07:34:31 --> Helper loaded: form_helper
INFO - 2018-05-02 07:34:31 --> Form Validation Class Initialized
INFO - 2018-05-02 07:34:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:34:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:34:31 --> Helper loaded: url_helper
INFO - 2018-05-02 07:34:31 --> Model Class Initialized
INFO - 2018-05-02 07:34:31 --> Model Class Initialized
INFO - 2018-05-02 07:34:31 --> Model Class Initialized
INFO - 2018-05-02 11:04:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:04:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:04:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:04:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-02 11:04:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:04:31 --> Final output sent to browser
DEBUG - 2018-05-02 11:04:31 --> Total execution time: 0.1360
INFO - 2018-05-02 07:34:35 --> Config Class Initialized
INFO - 2018-05-02 07:34:35 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:34:35 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:34:35 --> Utf8 Class Initialized
INFO - 2018-05-02 07:34:35 --> URI Class Initialized
INFO - 2018-05-02 07:34:35 --> Router Class Initialized
INFO - 2018-05-02 07:34:35 --> Output Class Initialized
INFO - 2018-05-02 07:34:35 --> Security Class Initialized
DEBUG - 2018-05-02 07:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:34:35 --> Input Class Initialized
INFO - 2018-05-02 07:34:35 --> Language Class Initialized
INFO - 2018-05-02 07:34:35 --> Loader Class Initialized
INFO - 2018-05-02 07:34:35 --> Helper loaded: common_helper
INFO - 2018-05-02 07:34:35 --> Database Driver Class Initialized
INFO - 2018-05-02 07:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:34:36 --> Email Class Initialized
INFO - 2018-05-02 07:34:36 --> Controller Class Initialized
INFO - 2018-05-02 07:34:36 --> Helper loaded: form_helper
INFO - 2018-05-02 07:34:36 --> Form Validation Class Initialized
INFO - 2018-05-02 07:34:36 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:34:36 --> Helper loaded: url_helper
INFO - 2018-05-02 07:34:36 --> Model Class Initialized
INFO - 2018-05-02 07:34:36 --> Model Class Initialized
INFO - 2018-05-02 07:34:36 --> Model Class Initialized
INFO - 2018-05-02 11:04:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:04:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:04:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:04:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:04:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:04:36 --> Final output sent to browser
DEBUG - 2018-05-02 11:04:36 --> Total execution time: 0.1730
INFO - 2018-05-02 07:34:43 --> Config Class Initialized
INFO - 2018-05-02 07:34:43 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:34:43 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:34:43 --> Utf8 Class Initialized
INFO - 2018-05-02 07:34:43 --> URI Class Initialized
INFO - 2018-05-02 07:34:43 --> Router Class Initialized
INFO - 2018-05-02 07:34:43 --> Output Class Initialized
INFO - 2018-05-02 07:34:43 --> Security Class Initialized
DEBUG - 2018-05-02 07:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:34:43 --> Input Class Initialized
INFO - 2018-05-02 07:34:43 --> Language Class Initialized
INFO - 2018-05-02 07:34:43 --> Loader Class Initialized
INFO - 2018-05-02 07:34:43 --> Helper loaded: common_helper
INFO - 2018-05-02 07:34:43 --> Database Driver Class Initialized
INFO - 2018-05-02 07:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:34:43 --> Email Class Initialized
INFO - 2018-05-02 07:34:43 --> Controller Class Initialized
INFO - 2018-05-02 07:34:43 --> Helper loaded: form_helper
INFO - 2018-05-02 07:34:43 --> Form Validation Class Initialized
INFO - 2018-05-02 07:34:43 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:34:43 --> Helper loaded: url_helper
INFO - 2018-05-02 07:34:43 --> Model Class Initialized
INFO - 2018-05-02 07:34:43 --> Model Class Initialized
INFO - 2018-05-02 07:34:43 --> Model Class Initialized
INFO - 2018-05-02 11:04:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:04:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:04:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:04:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:04:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:04:43 --> Final output sent to browser
DEBUG - 2018-05-02 11:04:43 --> Total execution time: 0.1390
INFO - 2018-05-02 07:34:46 --> Config Class Initialized
INFO - 2018-05-02 07:34:46 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:34:46 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:34:46 --> Utf8 Class Initialized
INFO - 2018-05-02 07:34:46 --> URI Class Initialized
INFO - 2018-05-02 07:34:46 --> Router Class Initialized
INFO - 2018-05-02 07:34:46 --> Output Class Initialized
INFO - 2018-05-02 07:34:46 --> Security Class Initialized
DEBUG - 2018-05-02 07:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:34:46 --> Input Class Initialized
INFO - 2018-05-02 07:34:46 --> Language Class Initialized
INFO - 2018-05-02 07:34:46 --> Loader Class Initialized
INFO - 2018-05-02 07:34:46 --> Helper loaded: common_helper
INFO - 2018-05-02 07:34:46 --> Database Driver Class Initialized
INFO - 2018-05-02 07:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:34:46 --> Email Class Initialized
INFO - 2018-05-02 07:34:46 --> Controller Class Initialized
INFO - 2018-05-02 07:34:46 --> Helper loaded: form_helper
INFO - 2018-05-02 07:34:46 --> Form Validation Class Initialized
INFO - 2018-05-02 07:34:46 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:34:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:34:46 --> Helper loaded: url_helper
INFO - 2018-05-02 07:34:46 --> Model Class Initialized
INFO - 2018-05-02 07:34:46 --> Model Class Initialized
INFO - 2018-05-02 07:34:46 --> Model Class Initialized
INFO - 2018-05-02 11:04:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:04:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:04:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:04:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/aboutMovie.php
INFO - 2018-05-02 11:04:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:04:46 --> Final output sent to browser
DEBUG - 2018-05-02 11:04:46 --> Total execution time: 0.1710
INFO - 2018-05-02 07:34:48 --> Config Class Initialized
INFO - 2018-05-02 07:34:48 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:34:48 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:34:48 --> Utf8 Class Initialized
INFO - 2018-05-02 07:34:48 --> URI Class Initialized
INFO - 2018-05-02 07:34:48 --> Router Class Initialized
INFO - 2018-05-02 07:34:48 --> Output Class Initialized
INFO - 2018-05-02 07:34:48 --> Security Class Initialized
DEBUG - 2018-05-02 07:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:34:48 --> Input Class Initialized
INFO - 2018-05-02 07:34:48 --> Language Class Initialized
INFO - 2018-05-02 07:34:48 --> Loader Class Initialized
INFO - 2018-05-02 07:34:48 --> Helper loaded: common_helper
INFO - 2018-05-02 07:34:48 --> Database Driver Class Initialized
INFO - 2018-05-02 07:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:34:48 --> Email Class Initialized
INFO - 2018-05-02 07:34:48 --> Controller Class Initialized
INFO - 2018-05-02 07:34:48 --> Helper loaded: form_helper
INFO - 2018-05-02 07:34:48 --> Form Validation Class Initialized
INFO - 2018-05-02 07:34:48 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:34:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:34:48 --> Helper loaded: url_helper
INFO - 2018-05-02 07:34:48 --> Model Class Initialized
INFO - 2018-05-02 07:34:48 --> Model Class Initialized
INFO - 2018-05-02 07:34:48 --> Model Class Initialized
INFO - 2018-05-02 11:04:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:04:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:04:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:04:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:04:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:04:48 --> Final output sent to browser
DEBUG - 2018-05-02 11:04:48 --> Total execution time: 0.1930
INFO - 2018-05-02 07:34:50 --> Config Class Initialized
INFO - 2018-05-02 07:34:50 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:34:50 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:34:50 --> Utf8 Class Initialized
INFO - 2018-05-02 07:34:50 --> URI Class Initialized
INFO - 2018-05-02 07:34:50 --> Router Class Initialized
INFO - 2018-05-02 07:34:50 --> Output Class Initialized
INFO - 2018-05-02 07:34:50 --> Security Class Initialized
DEBUG - 2018-05-02 07:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:34:50 --> Input Class Initialized
INFO - 2018-05-02 07:34:50 --> Language Class Initialized
INFO - 2018-05-02 07:34:50 --> Loader Class Initialized
INFO - 2018-05-02 07:34:50 --> Helper loaded: common_helper
INFO - 2018-05-02 07:34:50 --> Database Driver Class Initialized
INFO - 2018-05-02 07:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:34:50 --> Email Class Initialized
INFO - 2018-05-02 07:34:50 --> Controller Class Initialized
INFO - 2018-05-02 07:34:50 --> Helper loaded: form_helper
INFO - 2018-05-02 07:34:50 --> Form Validation Class Initialized
INFO - 2018-05-02 07:34:50 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:34:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:34:50 --> Helper loaded: url_helper
INFO - 2018-05-02 07:34:50 --> Model Class Initialized
INFO - 2018-05-02 07:34:50 --> Model Class Initialized
INFO - 2018-05-02 07:34:50 --> Model Class Initialized
INFO - 2018-05-02 11:04:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:04:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:04:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:04:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-02 11:04:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:04:50 --> Final output sent to browser
DEBUG - 2018-05-02 11:04:50 --> Total execution time: 0.2030
INFO - 2018-05-02 07:34:53 --> Config Class Initialized
INFO - 2018-05-02 07:34:53 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:34:53 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:34:53 --> Utf8 Class Initialized
INFO - 2018-05-02 07:34:53 --> URI Class Initialized
INFO - 2018-05-02 07:34:53 --> Router Class Initialized
INFO - 2018-05-02 07:34:53 --> Output Class Initialized
INFO - 2018-05-02 07:34:53 --> Security Class Initialized
DEBUG - 2018-05-02 07:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:34:53 --> Input Class Initialized
INFO - 2018-05-02 07:34:53 --> Language Class Initialized
INFO - 2018-05-02 07:34:53 --> Loader Class Initialized
INFO - 2018-05-02 07:34:53 --> Helper loaded: common_helper
INFO - 2018-05-02 07:34:53 --> Database Driver Class Initialized
INFO - 2018-05-02 07:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:34:53 --> Email Class Initialized
INFO - 2018-05-02 07:34:53 --> Controller Class Initialized
INFO - 2018-05-02 07:34:53 --> Helper loaded: form_helper
INFO - 2018-05-02 07:34:53 --> Form Validation Class Initialized
INFO - 2018-05-02 07:34:53 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:34:53 --> Helper loaded: url_helper
INFO - 2018-05-02 07:34:53 --> Model Class Initialized
INFO - 2018-05-02 07:34:53 --> Model Class Initialized
INFO - 2018-05-02 07:34:53 --> Model Class Initialized
INFO - 2018-05-02 11:04:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:04:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:04:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:04:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:04:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:04:53 --> Final output sent to browser
DEBUG - 2018-05-02 11:04:53 --> Total execution time: 0.1610
INFO - 2018-05-02 07:34:56 --> Config Class Initialized
INFO - 2018-05-02 07:34:56 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:34:56 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:34:56 --> Utf8 Class Initialized
INFO - 2018-05-02 07:34:56 --> URI Class Initialized
INFO - 2018-05-02 07:34:56 --> Router Class Initialized
INFO - 2018-05-02 07:34:56 --> Output Class Initialized
INFO - 2018-05-02 07:34:56 --> Security Class Initialized
DEBUG - 2018-05-02 07:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:34:56 --> Input Class Initialized
INFO - 2018-05-02 07:34:56 --> Language Class Initialized
INFO - 2018-05-02 07:34:56 --> Loader Class Initialized
INFO - 2018-05-02 07:34:56 --> Helper loaded: common_helper
INFO - 2018-05-02 07:34:56 --> Database Driver Class Initialized
INFO - 2018-05-02 07:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:34:56 --> Email Class Initialized
INFO - 2018-05-02 07:34:56 --> Controller Class Initialized
INFO - 2018-05-02 07:34:56 --> Helper loaded: form_helper
INFO - 2018-05-02 07:34:56 --> Form Validation Class Initialized
INFO - 2018-05-02 07:34:56 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:34:56 --> Helper loaded: url_helper
INFO - 2018-05-02 07:34:56 --> Model Class Initialized
INFO - 2018-05-02 07:34:56 --> Model Class Initialized
INFO - 2018-05-02 07:34:56 --> Model Class Initialized
INFO - 2018-05-02 11:04:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:04:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:04:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:04:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editGeleryImages.php
INFO - 2018-05-02 11:04:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:04:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:04:56 --> Final output sent to browser
DEBUG - 2018-05-02 11:04:56 --> Total execution time: 0.1770
INFO - 2018-05-02 07:34:59 --> Config Class Initialized
INFO - 2018-05-02 07:34:59 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:34:59 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:34:59 --> Utf8 Class Initialized
INFO - 2018-05-02 07:34:59 --> URI Class Initialized
INFO - 2018-05-02 07:34:59 --> Router Class Initialized
INFO - 2018-05-02 07:34:59 --> Output Class Initialized
INFO - 2018-05-02 07:34:59 --> Security Class Initialized
DEBUG - 2018-05-02 07:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:34:59 --> Input Class Initialized
INFO - 2018-05-02 07:34:59 --> Language Class Initialized
INFO - 2018-05-02 07:34:59 --> Loader Class Initialized
INFO - 2018-05-02 07:34:59 --> Helper loaded: common_helper
INFO - 2018-05-02 07:34:59 --> Database Driver Class Initialized
INFO - 2018-05-02 07:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:34:59 --> Email Class Initialized
INFO - 2018-05-02 07:34:59 --> Controller Class Initialized
INFO - 2018-05-02 07:34:59 --> Helper loaded: form_helper
INFO - 2018-05-02 07:34:59 --> Form Validation Class Initialized
INFO - 2018-05-02 07:34:59 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:34:59 --> Helper loaded: url_helper
INFO - 2018-05-02 07:34:59 --> Model Class Initialized
INFO - 2018-05-02 07:34:59 --> Model Class Initialized
INFO - 2018-05-02 07:34:59 --> Model Class Initialized
INFO - 2018-05-02 11:04:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:04:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:04:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:04:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:04:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:04:59 --> Final output sent to browser
DEBUG - 2018-05-02 11:04:59 --> Total execution time: 0.1350
INFO - 2018-05-02 07:35:03 --> Config Class Initialized
INFO - 2018-05-02 07:35:03 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:35:03 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:35:03 --> Utf8 Class Initialized
INFO - 2018-05-02 07:35:03 --> URI Class Initialized
INFO - 2018-05-02 07:35:03 --> Router Class Initialized
INFO - 2018-05-02 07:35:03 --> Output Class Initialized
INFO - 2018-05-02 07:35:03 --> Security Class Initialized
DEBUG - 2018-05-02 07:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:35:03 --> Input Class Initialized
INFO - 2018-05-02 07:35:03 --> Language Class Initialized
INFO - 2018-05-02 07:35:03 --> Loader Class Initialized
INFO - 2018-05-02 07:35:03 --> Helper loaded: common_helper
INFO - 2018-05-02 07:35:03 --> Database Driver Class Initialized
INFO - 2018-05-02 07:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:35:03 --> Email Class Initialized
INFO - 2018-05-02 07:35:03 --> Controller Class Initialized
INFO - 2018-05-02 07:35:03 --> Helper loaded: form_helper
INFO - 2018-05-02 07:35:03 --> Form Validation Class Initialized
INFO - 2018-05-02 07:35:03 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:35:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:35:03 --> Helper loaded: url_helper
INFO - 2018-05-02 07:35:03 --> Model Class Initialized
INFO - 2018-05-02 07:35:03 --> Model Class Initialized
INFO - 2018-05-02 07:35:03 --> Model Class Initialized
INFO - 2018-05-02 11:05:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:05:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:05:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:05:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/aboutMovie.php
INFO - 2018-05-02 11:05:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:05:03 --> Final output sent to browser
DEBUG - 2018-05-02 11:05:03 --> Total execution time: 0.1450
INFO - 2018-05-02 07:35:04 --> Config Class Initialized
INFO - 2018-05-02 07:35:04 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:35:04 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:35:04 --> Utf8 Class Initialized
INFO - 2018-05-02 07:35:04 --> URI Class Initialized
INFO - 2018-05-02 07:35:04 --> Router Class Initialized
INFO - 2018-05-02 07:35:04 --> Output Class Initialized
INFO - 2018-05-02 07:35:04 --> Security Class Initialized
DEBUG - 2018-05-02 07:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:35:04 --> Input Class Initialized
INFO - 2018-05-02 07:35:04 --> Language Class Initialized
INFO - 2018-05-02 07:35:04 --> Loader Class Initialized
INFO - 2018-05-02 07:35:04 --> Helper loaded: common_helper
INFO - 2018-05-02 07:35:04 --> Database Driver Class Initialized
INFO - 2018-05-02 07:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:35:04 --> Email Class Initialized
INFO - 2018-05-02 07:35:04 --> Controller Class Initialized
INFO - 2018-05-02 07:35:04 --> Helper loaded: form_helper
INFO - 2018-05-02 07:35:04 --> Form Validation Class Initialized
INFO - 2018-05-02 07:35:04 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:35:04 --> Helper loaded: url_helper
INFO - 2018-05-02 07:35:04 --> Model Class Initialized
INFO - 2018-05-02 07:35:04 --> Model Class Initialized
INFO - 2018-05-02 07:35:04 --> Model Class Initialized
INFO - 2018-05-02 11:05:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:05:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:05:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:05:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:05:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:05:04 --> Final output sent to browser
DEBUG - 2018-05-02 11:05:04 --> Total execution time: 0.1390
INFO - 2018-05-02 07:37:44 --> Config Class Initialized
INFO - 2018-05-02 07:37:44 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:37:44 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:37:44 --> Utf8 Class Initialized
INFO - 2018-05-02 07:37:44 --> URI Class Initialized
INFO - 2018-05-02 07:37:44 --> Router Class Initialized
INFO - 2018-05-02 07:37:44 --> Output Class Initialized
INFO - 2018-05-02 07:37:44 --> Security Class Initialized
DEBUG - 2018-05-02 07:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:37:44 --> Input Class Initialized
INFO - 2018-05-02 07:37:44 --> Language Class Initialized
INFO - 2018-05-02 07:37:44 --> Loader Class Initialized
INFO - 2018-05-02 07:37:44 --> Helper loaded: common_helper
INFO - 2018-05-02 07:37:44 --> Database Driver Class Initialized
INFO - 2018-05-02 07:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:37:44 --> Email Class Initialized
INFO - 2018-05-02 07:37:44 --> Controller Class Initialized
INFO - 2018-05-02 07:37:44 --> Helper loaded: form_helper
INFO - 2018-05-02 07:37:44 --> Form Validation Class Initialized
INFO - 2018-05-02 07:37:44 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:37:44 --> Helper loaded: url_helper
INFO - 2018-05-02 07:37:44 --> Model Class Initialized
INFO - 2018-05-02 07:37:44 --> Model Class Initialized
INFO - 2018-05-02 07:37:44 --> Model Class Initialized
INFO - 2018-05-02 11:07:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:07:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:07:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:07:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:07:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:07:44 --> Final output sent to browser
DEBUG - 2018-05-02 11:07:44 --> Total execution time: 0.1410
INFO - 2018-05-02 07:37:47 --> Config Class Initialized
INFO - 2018-05-02 07:37:47 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:37:47 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:37:47 --> Utf8 Class Initialized
INFO - 2018-05-02 07:37:47 --> URI Class Initialized
INFO - 2018-05-02 07:37:47 --> Router Class Initialized
INFO - 2018-05-02 07:37:47 --> Output Class Initialized
INFO - 2018-05-02 07:37:47 --> Security Class Initialized
DEBUG - 2018-05-02 07:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:37:47 --> Input Class Initialized
INFO - 2018-05-02 07:37:47 --> Language Class Initialized
INFO - 2018-05-02 07:37:47 --> Loader Class Initialized
INFO - 2018-05-02 07:37:47 --> Helper loaded: common_helper
INFO - 2018-05-02 07:37:47 --> Database Driver Class Initialized
INFO - 2018-05-02 07:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:37:47 --> Email Class Initialized
INFO - 2018-05-02 07:37:47 --> Controller Class Initialized
INFO - 2018-05-02 07:37:47 --> Helper loaded: form_helper
INFO - 2018-05-02 07:37:47 --> Form Validation Class Initialized
INFO - 2018-05-02 07:37:47 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:37:47 --> Helper loaded: url_helper
INFO - 2018-05-02 07:37:47 --> Model Class Initialized
INFO - 2018-05-02 07:37:47 --> Model Class Initialized
INFO - 2018-05-02 07:37:47 --> Model Class Initialized
INFO - 2018-05-02 11:07:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:07:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:07:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:07:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:07:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:07:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:07:47 --> Final output sent to browser
DEBUG - 2018-05-02 11:07:47 --> Total execution time: 0.1770
INFO - 2018-05-02 07:37:52 --> Config Class Initialized
INFO - 2018-05-02 07:37:52 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:37:52 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:37:52 --> Utf8 Class Initialized
INFO - 2018-05-02 07:37:52 --> URI Class Initialized
INFO - 2018-05-02 07:37:52 --> Router Class Initialized
INFO - 2018-05-02 07:37:52 --> Output Class Initialized
INFO - 2018-05-02 07:37:52 --> Security Class Initialized
DEBUG - 2018-05-02 07:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:37:52 --> Input Class Initialized
INFO - 2018-05-02 07:37:53 --> Language Class Initialized
INFO - 2018-05-02 07:37:53 --> Loader Class Initialized
INFO - 2018-05-02 07:37:53 --> Helper loaded: common_helper
INFO - 2018-05-02 07:37:53 --> Database Driver Class Initialized
INFO - 2018-05-02 07:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:37:53 --> Email Class Initialized
INFO - 2018-05-02 07:37:53 --> Controller Class Initialized
INFO - 2018-05-02 07:37:53 --> Helper loaded: form_helper
INFO - 2018-05-02 07:37:53 --> Form Validation Class Initialized
INFO - 2018-05-02 07:37:53 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:37:53 --> Helper loaded: url_helper
INFO - 2018-05-02 07:37:53 --> Model Class Initialized
INFO - 2018-05-02 07:37:53 --> Model Class Initialized
INFO - 2018-05-02 07:37:53 --> Model Class Initialized
INFO - 2018-05-02 11:07:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:07:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:07:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:07:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:07:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:07:53 --> Final output sent to browser
DEBUG - 2018-05-02 11:07:53 --> Total execution time: 0.1460
INFO - 2018-05-02 07:38:57 --> Config Class Initialized
INFO - 2018-05-02 07:38:57 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:38:57 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:38:57 --> Utf8 Class Initialized
INFO - 2018-05-02 07:38:57 --> URI Class Initialized
INFO - 2018-05-02 07:38:57 --> Router Class Initialized
INFO - 2018-05-02 07:38:57 --> Output Class Initialized
INFO - 2018-05-02 07:38:57 --> Security Class Initialized
DEBUG - 2018-05-02 07:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:38:57 --> Input Class Initialized
INFO - 2018-05-02 07:38:57 --> Language Class Initialized
INFO - 2018-05-02 07:38:57 --> Loader Class Initialized
INFO - 2018-05-02 07:38:57 --> Helper loaded: common_helper
INFO - 2018-05-02 07:38:57 --> Database Driver Class Initialized
INFO - 2018-05-02 07:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:38:57 --> Email Class Initialized
INFO - 2018-05-02 07:38:57 --> Controller Class Initialized
INFO - 2018-05-02 07:38:57 --> Helper loaded: form_helper
INFO - 2018-05-02 07:38:57 --> Form Validation Class Initialized
INFO - 2018-05-02 07:38:57 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:38:57 --> Helper loaded: url_helper
INFO - 2018-05-02 07:38:57 --> Model Class Initialized
INFO - 2018-05-02 07:38:57 --> Model Class Initialized
INFO - 2018-05-02 07:38:57 --> Model Class Initialized
INFO - 2018-05-02 11:08:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:08:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:08:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:08:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:08:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:08:57 --> Final output sent to browser
DEBUG - 2018-05-02 11:08:57 --> Total execution time: 0.1560
INFO - 2018-05-02 07:38:58 --> Config Class Initialized
INFO - 2018-05-02 07:38:58 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:38:58 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:38:58 --> Utf8 Class Initialized
INFO - 2018-05-02 07:38:58 --> URI Class Initialized
INFO - 2018-05-02 07:38:58 --> Router Class Initialized
INFO - 2018-05-02 07:38:58 --> Output Class Initialized
INFO - 2018-05-02 07:38:58 --> Security Class Initialized
DEBUG - 2018-05-02 07:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:38:58 --> Input Class Initialized
INFO - 2018-05-02 07:38:58 --> Language Class Initialized
INFO - 2018-05-02 07:38:58 --> Loader Class Initialized
INFO - 2018-05-02 07:38:58 --> Helper loaded: common_helper
INFO - 2018-05-02 07:38:58 --> Database Driver Class Initialized
INFO - 2018-05-02 07:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:38:58 --> Email Class Initialized
INFO - 2018-05-02 07:38:58 --> Controller Class Initialized
INFO - 2018-05-02 07:38:58 --> Helper loaded: form_helper
INFO - 2018-05-02 07:38:58 --> Form Validation Class Initialized
INFO - 2018-05-02 07:38:58 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:38:58 --> Helper loaded: url_helper
INFO - 2018-05-02 07:38:58 --> Model Class Initialized
INFO - 2018-05-02 07:38:58 --> Model Class Initialized
INFO - 2018-05-02 07:38:58 --> Model Class Initialized
INFO - 2018-05-02 11:08:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:08:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:08:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:08:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:08:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:08:58 --> Final output sent to browser
DEBUG - 2018-05-02 11:08:58 --> Total execution time: 0.1500
INFO - 2018-05-02 07:39:00 --> Config Class Initialized
INFO - 2018-05-02 07:39:00 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:39:00 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:39:00 --> Utf8 Class Initialized
INFO - 2018-05-02 07:39:00 --> URI Class Initialized
INFO - 2018-05-02 07:39:00 --> Router Class Initialized
INFO - 2018-05-02 07:39:00 --> Output Class Initialized
INFO - 2018-05-02 07:39:00 --> Security Class Initialized
DEBUG - 2018-05-02 07:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:39:00 --> Input Class Initialized
INFO - 2018-05-02 07:39:00 --> Language Class Initialized
INFO - 2018-05-02 07:39:00 --> Loader Class Initialized
INFO - 2018-05-02 07:39:00 --> Helper loaded: common_helper
INFO - 2018-05-02 07:39:00 --> Database Driver Class Initialized
INFO - 2018-05-02 07:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:39:00 --> Email Class Initialized
INFO - 2018-05-02 07:39:00 --> Controller Class Initialized
INFO - 2018-05-02 07:39:00 --> Helper loaded: form_helper
INFO - 2018-05-02 07:39:00 --> Form Validation Class Initialized
INFO - 2018-05-02 07:39:00 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:39:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:39:00 --> Helper loaded: url_helper
INFO - 2018-05-02 07:39:00 --> Model Class Initialized
INFO - 2018-05-02 07:39:00 --> Model Class Initialized
INFO - 2018-05-02 07:39:00 --> Model Class Initialized
INFO - 2018-05-02 11:09:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:09:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:09:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:09:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:09:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:09:00 --> Final output sent to browser
DEBUG - 2018-05-02 11:09:00 --> Total execution time: 0.1280
INFO - 2018-05-02 07:42:57 --> Config Class Initialized
INFO - 2018-05-02 07:42:57 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:42:57 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:42:57 --> Utf8 Class Initialized
INFO - 2018-05-02 07:42:57 --> URI Class Initialized
INFO - 2018-05-02 07:42:57 --> Router Class Initialized
INFO - 2018-05-02 07:42:57 --> Output Class Initialized
INFO - 2018-05-02 07:42:57 --> Security Class Initialized
DEBUG - 2018-05-02 07:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:42:57 --> Input Class Initialized
INFO - 2018-05-02 07:42:57 --> Language Class Initialized
INFO - 2018-05-02 07:42:57 --> Loader Class Initialized
INFO - 2018-05-02 07:42:57 --> Helper loaded: common_helper
INFO - 2018-05-02 07:42:57 --> Database Driver Class Initialized
INFO - 2018-05-02 07:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:42:57 --> Email Class Initialized
INFO - 2018-05-02 07:42:57 --> Controller Class Initialized
INFO - 2018-05-02 07:42:57 --> Helper loaded: form_helper
INFO - 2018-05-02 07:42:57 --> Form Validation Class Initialized
INFO - 2018-05-02 07:42:57 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:42:57 --> Helper loaded: url_helper
INFO - 2018-05-02 07:42:57 --> Model Class Initialized
INFO - 2018-05-02 07:42:57 --> Model Class Initialized
INFO - 2018-05-02 07:42:57 --> Model Class Initialized
INFO - 2018-05-02 11:12:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:12:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:12:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:12:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:12:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:12:57 --> Final output sent to browser
DEBUG - 2018-05-02 11:12:57 --> Total execution time: 0.1430
INFO - 2018-05-02 07:45:29 --> Config Class Initialized
INFO - 2018-05-02 07:45:29 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:45:29 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:45:29 --> Utf8 Class Initialized
INFO - 2018-05-02 07:45:29 --> URI Class Initialized
INFO - 2018-05-02 07:45:29 --> Router Class Initialized
INFO - 2018-05-02 07:45:29 --> Output Class Initialized
INFO - 2018-05-02 07:45:29 --> Security Class Initialized
DEBUG - 2018-05-02 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:45:29 --> Input Class Initialized
INFO - 2018-05-02 07:45:29 --> Language Class Initialized
INFO - 2018-05-02 07:45:29 --> Loader Class Initialized
INFO - 2018-05-02 07:45:29 --> Helper loaded: common_helper
INFO - 2018-05-02 07:45:29 --> Database Driver Class Initialized
INFO - 2018-05-02 07:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:45:30 --> Email Class Initialized
INFO - 2018-05-02 07:45:30 --> Controller Class Initialized
INFO - 2018-05-02 07:45:30 --> Helper loaded: form_helper
INFO - 2018-05-02 07:45:30 --> Form Validation Class Initialized
INFO - 2018-05-02 07:45:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:45:30 --> Helper loaded: url_helper
INFO - 2018-05-02 07:45:30 --> Model Class Initialized
INFO - 2018-05-02 07:45:30 --> Model Class Initialized
INFO - 2018-05-02 07:45:30 --> Model Class Initialized
INFO - 2018-05-02 11:15:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:15:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:15:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-02 11:15:30 --> Undefined variable: celebritys
ERROR - 2018-05-02 11:15:30 --> Severity: Notice --> Undefined variable: celebritys C:\xampp\htdocs\Celebrity\admin\application\views\movies\movieImageDetails.php 53
ERROR - 2018-05-02 11:15:30 --> Trying to get property of non-object
ERROR - 2018-05-02 11:15:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movieImageDetails.php 53
INFO - 2018-05-02 11:15:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:15:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:15:30 --> Final output sent to browser
DEBUG - 2018-05-02 11:15:30 --> Total execution time: 0.1380
INFO - 2018-05-02 07:45:48 --> Config Class Initialized
INFO - 2018-05-02 07:45:48 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:45:48 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:45:48 --> Utf8 Class Initialized
INFO - 2018-05-02 07:45:48 --> URI Class Initialized
INFO - 2018-05-02 07:45:48 --> Router Class Initialized
INFO - 2018-05-02 07:45:48 --> Output Class Initialized
INFO - 2018-05-02 07:45:48 --> Security Class Initialized
DEBUG - 2018-05-02 07:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:45:48 --> Input Class Initialized
INFO - 2018-05-02 07:45:48 --> Language Class Initialized
INFO - 2018-05-02 07:45:48 --> Loader Class Initialized
INFO - 2018-05-02 07:45:48 --> Helper loaded: common_helper
INFO - 2018-05-02 07:45:48 --> Database Driver Class Initialized
INFO - 2018-05-02 07:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:45:48 --> Email Class Initialized
INFO - 2018-05-02 07:45:48 --> Controller Class Initialized
INFO - 2018-05-02 07:45:48 --> Helper loaded: form_helper
INFO - 2018-05-02 07:45:48 --> Form Validation Class Initialized
INFO - 2018-05-02 07:45:48 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:45:48 --> Helper loaded: url_helper
INFO - 2018-05-02 07:45:48 --> Model Class Initialized
INFO - 2018-05-02 07:45:48 --> Model Class Initialized
INFO - 2018-05-02 07:45:48 --> Model Class Initialized
INFO - 2018-05-02 11:15:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:15:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:15:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:15:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:15:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:15:48 --> Final output sent to browser
DEBUG - 2018-05-02 11:15:48 --> Total execution time: 0.1470
INFO - 2018-05-02 07:45:52 --> Config Class Initialized
INFO - 2018-05-02 07:45:52 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:45:52 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:45:52 --> Utf8 Class Initialized
INFO - 2018-05-02 07:45:52 --> URI Class Initialized
INFO - 2018-05-02 07:45:52 --> Router Class Initialized
INFO - 2018-05-02 07:45:52 --> Output Class Initialized
INFO - 2018-05-02 07:45:52 --> Security Class Initialized
DEBUG - 2018-05-02 07:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:45:52 --> Input Class Initialized
INFO - 2018-05-02 07:45:52 --> Language Class Initialized
INFO - 2018-05-02 07:45:52 --> Loader Class Initialized
INFO - 2018-05-02 07:45:52 --> Helper loaded: common_helper
INFO - 2018-05-02 07:45:52 --> Database Driver Class Initialized
INFO - 2018-05-02 07:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:45:52 --> Email Class Initialized
INFO - 2018-05-02 07:45:52 --> Controller Class Initialized
INFO - 2018-05-02 07:45:52 --> Helper loaded: form_helper
INFO - 2018-05-02 07:45:52 --> Form Validation Class Initialized
INFO - 2018-05-02 07:45:52 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:45:52 --> Helper loaded: url_helper
INFO - 2018-05-02 07:45:52 --> Model Class Initialized
INFO - 2018-05-02 07:45:52 --> Model Class Initialized
INFO - 2018-05-02 07:45:52 --> Model Class Initialized
INFO - 2018-05-02 11:15:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:15:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:15:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-02 11:15:52 --> Trying to get property of non-object
ERROR - 2018-05-02 11:15:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-02 11:15:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:15:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:15:52 --> Final output sent to browser
DEBUG - 2018-05-02 11:15:52 --> Total execution time: 0.1370
INFO - 2018-05-02 07:45:59 --> Config Class Initialized
INFO - 2018-05-02 07:45:59 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:45:59 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:45:59 --> Utf8 Class Initialized
INFO - 2018-05-02 07:45:59 --> URI Class Initialized
INFO - 2018-05-02 07:45:59 --> Router Class Initialized
INFO - 2018-05-02 07:45:59 --> Output Class Initialized
INFO - 2018-05-02 07:45:59 --> Security Class Initialized
DEBUG - 2018-05-02 07:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:45:59 --> Input Class Initialized
INFO - 2018-05-02 07:45:59 --> Language Class Initialized
INFO - 2018-05-02 07:45:59 --> Loader Class Initialized
INFO - 2018-05-02 07:45:59 --> Helper loaded: common_helper
INFO - 2018-05-02 07:45:59 --> Database Driver Class Initialized
INFO - 2018-05-02 07:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:45:59 --> Email Class Initialized
INFO - 2018-05-02 07:45:59 --> Controller Class Initialized
INFO - 2018-05-02 07:45:59 --> Helper loaded: form_helper
INFO - 2018-05-02 07:45:59 --> Form Validation Class Initialized
INFO - 2018-05-02 07:45:59 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:45:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:45:59 --> Helper loaded: url_helper
INFO - 2018-05-02 07:45:59 --> Model Class Initialized
INFO - 2018-05-02 07:45:59 --> Model Class Initialized
INFO - 2018-05-02 07:45:59 --> Model Class Initialized
INFO - 2018-05-02 11:15:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:15:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:15:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:15:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:15:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:15:59 --> Final output sent to browser
DEBUG - 2018-05-02 11:15:59 --> Total execution time: 0.1390
INFO - 2018-05-02 07:46:02 --> Config Class Initialized
INFO - 2018-05-02 07:46:02 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:46:02 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:46:02 --> Utf8 Class Initialized
INFO - 2018-05-02 07:46:02 --> URI Class Initialized
INFO - 2018-05-02 07:46:02 --> Router Class Initialized
INFO - 2018-05-02 07:46:02 --> Output Class Initialized
INFO - 2018-05-02 07:46:02 --> Security Class Initialized
DEBUG - 2018-05-02 07:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:46:02 --> Input Class Initialized
INFO - 2018-05-02 07:46:02 --> Language Class Initialized
INFO - 2018-05-02 07:46:02 --> Loader Class Initialized
INFO - 2018-05-02 07:46:02 --> Helper loaded: common_helper
INFO - 2018-05-02 07:46:02 --> Database Driver Class Initialized
INFO - 2018-05-02 07:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:46:02 --> Email Class Initialized
INFO - 2018-05-02 07:46:02 --> Controller Class Initialized
INFO - 2018-05-02 07:46:02 --> Helper loaded: form_helper
INFO - 2018-05-02 07:46:02 --> Form Validation Class Initialized
INFO - 2018-05-02 07:46:02 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:46:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:46:02 --> Helper loaded: url_helper
INFO - 2018-05-02 07:46:02 --> Model Class Initialized
INFO - 2018-05-02 07:46:02 --> Model Class Initialized
INFO - 2018-05-02 07:46:02 --> Model Class Initialized
INFO - 2018-05-02 11:16:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:16:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:16:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-02 11:16:02 --> Trying to get property of non-object
ERROR - 2018-05-02 11:16:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-02 11:16:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:16:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:16:02 --> Final output sent to browser
DEBUG - 2018-05-02 11:16:02 --> Total execution time: 0.1520
INFO - 2018-05-02 07:46:08 --> Config Class Initialized
INFO - 2018-05-02 07:46:08 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:46:08 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:46:08 --> Utf8 Class Initialized
INFO - 2018-05-02 07:46:08 --> URI Class Initialized
INFO - 2018-05-02 07:46:08 --> Router Class Initialized
INFO - 2018-05-02 07:46:08 --> Output Class Initialized
INFO - 2018-05-02 07:46:08 --> Security Class Initialized
DEBUG - 2018-05-02 07:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:46:08 --> Input Class Initialized
INFO - 2018-05-02 07:46:08 --> Language Class Initialized
INFO - 2018-05-02 07:46:08 --> Loader Class Initialized
INFO - 2018-05-02 07:46:08 --> Helper loaded: common_helper
INFO - 2018-05-02 07:46:08 --> Database Driver Class Initialized
INFO - 2018-05-02 07:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:46:08 --> Email Class Initialized
INFO - 2018-05-02 07:46:08 --> Controller Class Initialized
INFO - 2018-05-02 07:46:08 --> Helper loaded: form_helper
INFO - 2018-05-02 07:46:08 --> Form Validation Class Initialized
INFO - 2018-05-02 07:46:08 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:46:08 --> Helper loaded: url_helper
INFO - 2018-05-02 07:46:08 --> Model Class Initialized
INFO - 2018-05-02 07:46:08 --> Model Class Initialized
INFO - 2018-05-02 07:46:08 --> Model Class Initialized
INFO - 2018-05-02 11:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:16:08 --> Final output sent to browser
DEBUG - 2018-05-02 11:16:08 --> Total execution time: 0.1510
INFO - 2018-05-02 07:46:16 --> Config Class Initialized
INFO - 2018-05-02 07:46:16 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:46:16 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:46:16 --> Utf8 Class Initialized
INFO - 2018-05-02 07:46:16 --> URI Class Initialized
INFO - 2018-05-02 07:46:16 --> Router Class Initialized
INFO - 2018-05-02 07:46:16 --> Output Class Initialized
INFO - 2018-05-02 07:46:16 --> Security Class Initialized
DEBUG - 2018-05-02 07:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:46:16 --> Input Class Initialized
INFO - 2018-05-02 07:46:16 --> Language Class Initialized
INFO - 2018-05-02 07:46:16 --> Loader Class Initialized
INFO - 2018-05-02 07:46:16 --> Helper loaded: common_helper
INFO - 2018-05-02 07:46:16 --> Database Driver Class Initialized
INFO - 2018-05-02 07:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:46:16 --> Email Class Initialized
INFO - 2018-05-02 07:46:16 --> Controller Class Initialized
INFO - 2018-05-02 07:46:16 --> Helper loaded: form_helper
INFO - 2018-05-02 07:46:16 --> Form Validation Class Initialized
INFO - 2018-05-02 07:46:16 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:46:16 --> Helper loaded: url_helper
INFO - 2018-05-02 07:46:16 --> Model Class Initialized
INFO - 2018-05-02 07:46:16 --> Model Class Initialized
INFO - 2018-05-02 07:46:16 --> Model Class Initialized
INFO - 2018-05-02 11:16:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:16:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:16:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-02 11:16:16 --> Trying to get property of non-object
ERROR - 2018-05-02 11:16:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-02 11:16:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:16:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:16:16 --> Final output sent to browser
DEBUG - 2018-05-02 11:16:16 --> Total execution time: 0.1390
INFO - 2018-05-02 07:46:18 --> Config Class Initialized
INFO - 2018-05-02 07:46:18 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:46:18 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:46:18 --> Utf8 Class Initialized
INFO - 2018-05-02 07:46:18 --> URI Class Initialized
INFO - 2018-05-02 07:46:18 --> Router Class Initialized
INFO - 2018-05-02 07:46:18 --> Output Class Initialized
INFO - 2018-05-02 07:46:18 --> Security Class Initialized
DEBUG - 2018-05-02 07:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:46:18 --> Input Class Initialized
INFO - 2018-05-02 07:46:18 --> Language Class Initialized
INFO - 2018-05-02 07:46:18 --> Loader Class Initialized
INFO - 2018-05-02 07:46:18 --> Helper loaded: common_helper
INFO - 2018-05-02 07:46:18 --> Database Driver Class Initialized
INFO - 2018-05-02 07:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:46:18 --> Email Class Initialized
INFO - 2018-05-02 07:46:18 --> Controller Class Initialized
INFO - 2018-05-02 07:46:18 --> Helper loaded: form_helper
INFO - 2018-05-02 07:46:18 --> Form Validation Class Initialized
INFO - 2018-05-02 07:46:18 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:46:18 --> Helper loaded: url_helper
INFO - 2018-05-02 07:46:18 --> Model Class Initialized
INFO - 2018-05-02 07:46:18 --> Model Class Initialized
INFO - 2018-05-02 07:46:18 --> Model Class Initialized
INFO - 2018-05-02 11:16:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:16:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:16:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:16:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:16:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:16:18 --> Final output sent to browser
DEBUG - 2018-05-02 11:16:18 --> Total execution time: 0.1350
INFO - 2018-05-02 07:50:44 --> Config Class Initialized
INFO - 2018-05-02 07:50:44 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:50:44 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:50:44 --> Utf8 Class Initialized
INFO - 2018-05-02 07:50:44 --> URI Class Initialized
INFO - 2018-05-02 07:50:44 --> Router Class Initialized
INFO - 2018-05-02 07:50:44 --> Output Class Initialized
INFO - 2018-05-02 07:50:44 --> Security Class Initialized
DEBUG - 2018-05-02 07:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:50:44 --> Input Class Initialized
INFO - 2018-05-02 07:50:44 --> Language Class Initialized
INFO - 2018-05-02 07:50:44 --> Loader Class Initialized
INFO - 2018-05-02 07:50:44 --> Helper loaded: common_helper
INFO - 2018-05-02 07:50:44 --> Database Driver Class Initialized
INFO - 2018-05-02 07:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:50:44 --> Email Class Initialized
INFO - 2018-05-02 07:50:44 --> Controller Class Initialized
INFO - 2018-05-02 07:50:44 --> Helper loaded: form_helper
INFO - 2018-05-02 07:50:44 --> Form Validation Class Initialized
INFO - 2018-05-02 07:50:44 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:50:44 --> Helper loaded: url_helper
INFO - 2018-05-02 07:50:44 --> Model Class Initialized
INFO - 2018-05-02 07:50:44 --> Model Class Initialized
INFO - 2018-05-02 07:50:44 --> Model Class Initialized
INFO - 2018-05-02 11:20:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:20:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:20:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 07:51:42 --> Config Class Initialized
INFO - 2018-05-02 07:51:42 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:51:42 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:51:42 --> Utf8 Class Initialized
INFO - 2018-05-02 07:51:42 --> URI Class Initialized
INFO - 2018-05-02 07:51:42 --> Router Class Initialized
INFO - 2018-05-02 07:51:42 --> Output Class Initialized
INFO - 2018-05-02 07:51:42 --> Security Class Initialized
DEBUG - 2018-05-02 07:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:51:42 --> Input Class Initialized
INFO - 2018-05-02 07:51:42 --> Language Class Initialized
INFO - 2018-05-02 07:51:42 --> Loader Class Initialized
INFO - 2018-05-02 07:51:42 --> Helper loaded: common_helper
INFO - 2018-05-02 07:51:42 --> Database Driver Class Initialized
INFO - 2018-05-02 07:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:51:42 --> Email Class Initialized
INFO - 2018-05-02 07:51:42 --> Controller Class Initialized
INFO - 2018-05-02 07:51:42 --> Helper loaded: form_helper
INFO - 2018-05-02 07:51:42 --> Form Validation Class Initialized
INFO - 2018-05-02 07:51:42 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:51:42 --> Helper loaded: url_helper
INFO - 2018-05-02 07:51:42 --> Model Class Initialized
INFO - 2018-05-02 07:51:42 --> Model Class Initialized
INFO - 2018-05-02 07:51:42 --> Model Class Initialized
INFO - 2018-05-02 11:21:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:21:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:21:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:21:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:21:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:21:42 --> Final output sent to browser
DEBUG - 2018-05-02 11:21:42 --> Total execution time: 0.1340
INFO - 2018-05-02 07:51:44 --> Config Class Initialized
INFO - 2018-05-02 07:51:44 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:51:44 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:51:44 --> Utf8 Class Initialized
INFO - 2018-05-02 07:51:44 --> URI Class Initialized
INFO - 2018-05-02 07:51:44 --> Router Class Initialized
INFO - 2018-05-02 07:51:44 --> Output Class Initialized
INFO - 2018-05-02 07:51:44 --> Security Class Initialized
DEBUG - 2018-05-02 07:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:51:44 --> Input Class Initialized
INFO - 2018-05-02 07:51:44 --> Language Class Initialized
INFO - 2018-05-02 07:51:44 --> Loader Class Initialized
INFO - 2018-05-02 07:51:44 --> Helper loaded: common_helper
INFO - 2018-05-02 07:51:44 --> Database Driver Class Initialized
INFO - 2018-05-02 07:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:51:44 --> Email Class Initialized
INFO - 2018-05-02 07:51:44 --> Controller Class Initialized
INFO - 2018-05-02 07:51:44 --> Helper loaded: form_helper
INFO - 2018-05-02 07:51:44 --> Form Validation Class Initialized
INFO - 2018-05-02 07:51:44 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:51:44 --> Helper loaded: url_helper
INFO - 2018-05-02 07:51:44 --> Model Class Initialized
INFO - 2018-05-02 07:51:44 --> Model Class Initialized
INFO - 2018-05-02 07:51:44 --> Model Class Initialized
ERROR - 2018-05-02 11:21:44 --> Trying to get property of non-object
ERROR - 2018-05-02 11:21:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 705
INFO - 2018-05-02 11:21:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:21:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:21:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:21:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:21:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:21:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:21:44 --> Final output sent to browser
DEBUG - 2018-05-02 11:21:44 --> Total execution time: 0.1720
INFO - 2018-05-02 07:51:45 --> Config Class Initialized
INFO - 2018-05-02 07:51:45 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:51:45 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:51:45 --> Utf8 Class Initialized
INFO - 2018-05-02 07:51:45 --> URI Class Initialized
INFO - 2018-05-02 07:51:45 --> Router Class Initialized
INFO - 2018-05-02 07:51:45 --> Output Class Initialized
INFO - 2018-05-02 07:51:45 --> Security Class Initialized
DEBUG - 2018-05-02 07:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:51:45 --> Input Class Initialized
INFO - 2018-05-02 07:51:45 --> Language Class Initialized
INFO - 2018-05-02 07:51:45 --> Loader Class Initialized
INFO - 2018-05-02 07:51:45 --> Helper loaded: common_helper
INFO - 2018-05-02 07:51:45 --> Database Driver Class Initialized
INFO - 2018-05-02 07:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:51:45 --> Email Class Initialized
INFO - 2018-05-02 07:51:45 --> Controller Class Initialized
INFO - 2018-05-02 07:51:45 --> Helper loaded: form_helper
INFO - 2018-05-02 07:51:45 --> Form Validation Class Initialized
INFO - 2018-05-02 07:51:45 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:51:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:51:45 --> Helper loaded: url_helper
INFO - 2018-05-02 07:51:45 --> Model Class Initialized
INFO - 2018-05-02 07:51:45 --> Model Class Initialized
INFO - 2018-05-02 07:51:45 --> Model Class Initialized
ERROR - 2018-05-02 11:21:45 --> Trying to get property of non-object
ERROR - 2018-05-02 11:21:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 705
INFO - 2018-05-02 11:21:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:21:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:21:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:21:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:21:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:21:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:21:45 --> Final output sent to browser
DEBUG - 2018-05-02 11:21:45 --> Total execution time: 0.1560
INFO - 2018-05-02 07:53:09 --> Config Class Initialized
INFO - 2018-05-02 07:53:09 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:53:09 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:53:09 --> Utf8 Class Initialized
INFO - 2018-05-02 07:53:09 --> URI Class Initialized
INFO - 2018-05-02 07:53:09 --> Router Class Initialized
INFO - 2018-05-02 07:53:09 --> Output Class Initialized
INFO - 2018-05-02 07:53:09 --> Security Class Initialized
DEBUG - 2018-05-02 07:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:53:09 --> Input Class Initialized
INFO - 2018-05-02 07:53:09 --> Language Class Initialized
INFO - 2018-05-02 07:53:09 --> Loader Class Initialized
INFO - 2018-05-02 07:53:09 --> Helper loaded: common_helper
INFO - 2018-05-02 07:53:09 --> Database Driver Class Initialized
INFO - 2018-05-02 07:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:53:09 --> Email Class Initialized
INFO - 2018-05-02 07:53:09 --> Controller Class Initialized
INFO - 2018-05-02 07:53:09 --> Helper loaded: form_helper
INFO - 2018-05-02 07:53:09 --> Form Validation Class Initialized
INFO - 2018-05-02 07:53:09 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:53:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:53:09 --> Helper loaded: url_helper
INFO - 2018-05-02 07:53:09 --> Model Class Initialized
INFO - 2018-05-02 07:53:09 --> Model Class Initialized
INFO - 2018-05-02 07:53:09 --> Model Class Initialized
ERROR - 2018-05-02 11:23:09 --> Trying to get property of non-object
ERROR - 2018-05-02 11:23:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 705
INFO - 2018-05-02 11:23:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:23:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:23:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:23:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:23:09 --> Final output sent to browser
DEBUG - 2018-05-02 11:23:09 --> Total execution time: 0.1460
INFO - 2018-05-02 07:53:11 --> Config Class Initialized
INFO - 2018-05-02 07:53:11 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:53:11 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:53:11 --> Utf8 Class Initialized
INFO - 2018-05-02 07:53:11 --> URI Class Initialized
INFO - 2018-05-02 07:53:11 --> Router Class Initialized
INFO - 2018-05-02 07:53:11 --> Output Class Initialized
INFO - 2018-05-02 07:53:11 --> Security Class Initialized
DEBUG - 2018-05-02 07:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:53:11 --> Input Class Initialized
INFO - 2018-05-02 07:53:11 --> Language Class Initialized
INFO - 2018-05-02 07:53:11 --> Loader Class Initialized
INFO - 2018-05-02 07:53:11 --> Helper loaded: common_helper
INFO - 2018-05-02 07:53:11 --> Database Driver Class Initialized
INFO - 2018-05-02 07:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:53:11 --> Email Class Initialized
INFO - 2018-05-02 07:53:11 --> Controller Class Initialized
INFO - 2018-05-02 07:53:11 --> Helper loaded: form_helper
INFO - 2018-05-02 07:53:11 --> Form Validation Class Initialized
INFO - 2018-05-02 07:53:11 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:53:11 --> Helper loaded: url_helper
INFO - 2018-05-02 07:53:11 --> Model Class Initialized
INFO - 2018-05-02 07:53:11 --> Model Class Initialized
INFO - 2018-05-02 07:53:11 --> Model Class Initialized
INFO - 2018-05-02 11:23:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:23:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:23:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:23:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:23:11 --> Final output sent to browser
DEBUG - 2018-05-02 11:23:11 --> Total execution time: 0.1440
INFO - 2018-05-02 07:53:13 --> Config Class Initialized
INFO - 2018-05-02 07:53:13 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:53:13 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:53:13 --> Utf8 Class Initialized
INFO - 2018-05-02 07:53:13 --> URI Class Initialized
INFO - 2018-05-02 07:53:13 --> Router Class Initialized
INFO - 2018-05-02 07:53:13 --> Output Class Initialized
INFO - 2018-05-02 07:53:13 --> Security Class Initialized
DEBUG - 2018-05-02 07:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:53:13 --> Input Class Initialized
INFO - 2018-05-02 07:53:13 --> Language Class Initialized
INFO - 2018-05-02 07:53:13 --> Loader Class Initialized
INFO - 2018-05-02 07:53:13 --> Helper loaded: common_helper
INFO - 2018-05-02 07:53:13 --> Database Driver Class Initialized
INFO - 2018-05-02 07:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:53:13 --> Email Class Initialized
INFO - 2018-05-02 07:53:13 --> Controller Class Initialized
INFO - 2018-05-02 07:53:13 --> Helper loaded: form_helper
INFO - 2018-05-02 07:53:13 --> Form Validation Class Initialized
INFO - 2018-05-02 07:53:13 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:53:13 --> Helper loaded: url_helper
INFO - 2018-05-02 07:53:13 --> Model Class Initialized
INFO - 2018-05-02 07:53:13 --> Model Class Initialized
INFO - 2018-05-02 07:53:13 --> Model Class Initialized
ERROR - 2018-05-02 11:23:13 --> Trying to get property of non-object
ERROR - 2018-05-02 11:23:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 705
INFO - 2018-05-02 11:23:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:23:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:23:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:23:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:23:13 --> Final output sent to browser
DEBUG - 2018-05-02 11:23:13 --> Total execution time: 0.1680
INFO - 2018-05-02 07:53:13 --> Config Class Initialized
INFO - 2018-05-02 07:53:13 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:53:13 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:53:13 --> Utf8 Class Initialized
INFO - 2018-05-02 07:53:13 --> URI Class Initialized
INFO - 2018-05-02 07:53:13 --> Router Class Initialized
INFO - 2018-05-02 07:53:13 --> Output Class Initialized
INFO - 2018-05-02 07:53:13 --> Security Class Initialized
DEBUG - 2018-05-02 07:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:53:13 --> Input Class Initialized
INFO - 2018-05-02 07:53:13 --> Language Class Initialized
INFO - 2018-05-02 07:53:13 --> Loader Class Initialized
INFO - 2018-05-02 07:53:13 --> Helper loaded: common_helper
INFO - 2018-05-02 07:53:13 --> Database Driver Class Initialized
INFO - 2018-05-02 07:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:53:13 --> Email Class Initialized
INFO - 2018-05-02 07:53:13 --> Controller Class Initialized
INFO - 2018-05-02 07:53:13 --> Helper loaded: form_helper
INFO - 2018-05-02 07:53:13 --> Form Validation Class Initialized
INFO - 2018-05-02 07:53:13 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:53:13 --> Helper loaded: url_helper
INFO - 2018-05-02 07:53:13 --> Model Class Initialized
INFO - 2018-05-02 07:53:13 --> Model Class Initialized
INFO - 2018-05-02 07:53:13 --> Model Class Initialized
ERROR - 2018-05-02 11:23:13 --> Trying to get property of non-object
ERROR - 2018-05-02 11:23:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 705
INFO - 2018-05-02 11:23:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:23:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:23:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:23:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:23:13 --> Final output sent to browser
DEBUG - 2018-05-02 11:23:13 --> Total execution time: 0.1480
INFO - 2018-05-02 07:53:16 --> Config Class Initialized
INFO - 2018-05-02 07:53:16 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:53:16 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:53:16 --> Utf8 Class Initialized
INFO - 2018-05-02 07:53:16 --> URI Class Initialized
INFO - 2018-05-02 07:53:16 --> Router Class Initialized
INFO - 2018-05-02 07:53:16 --> Output Class Initialized
INFO - 2018-05-02 07:53:16 --> Security Class Initialized
DEBUG - 2018-05-02 07:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:53:16 --> Input Class Initialized
INFO - 2018-05-02 07:53:16 --> Language Class Initialized
INFO - 2018-05-02 07:53:16 --> Loader Class Initialized
INFO - 2018-05-02 07:53:16 --> Helper loaded: common_helper
INFO - 2018-05-02 07:53:16 --> Database Driver Class Initialized
INFO - 2018-05-02 07:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:53:16 --> Email Class Initialized
INFO - 2018-05-02 07:53:16 --> Controller Class Initialized
INFO - 2018-05-02 07:53:16 --> Helper loaded: form_helper
INFO - 2018-05-02 07:53:16 --> Form Validation Class Initialized
INFO - 2018-05-02 07:53:16 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:53:16 --> Helper loaded: url_helper
INFO - 2018-05-02 07:53:16 --> Model Class Initialized
INFO - 2018-05-02 07:53:16 --> Model Class Initialized
INFO - 2018-05-02 07:53:16 --> Model Class Initialized
INFO - 2018-05-02 11:23:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:23:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:23:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:23:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:23:16 --> Final output sent to browser
DEBUG - 2018-05-02 11:23:16 --> Total execution time: 0.1530
INFO - 2018-05-02 07:53:18 --> Config Class Initialized
INFO - 2018-05-02 07:53:18 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:53:18 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:53:18 --> Utf8 Class Initialized
INFO - 2018-05-02 07:53:18 --> URI Class Initialized
INFO - 2018-05-02 07:53:18 --> Router Class Initialized
INFO - 2018-05-02 07:53:18 --> Output Class Initialized
INFO - 2018-05-02 07:53:18 --> Security Class Initialized
DEBUG - 2018-05-02 07:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:53:18 --> Input Class Initialized
INFO - 2018-05-02 07:53:18 --> Language Class Initialized
INFO - 2018-05-02 07:53:18 --> Loader Class Initialized
INFO - 2018-05-02 07:53:18 --> Helper loaded: common_helper
INFO - 2018-05-02 07:53:18 --> Database Driver Class Initialized
INFO - 2018-05-02 07:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:53:18 --> Email Class Initialized
INFO - 2018-05-02 07:53:18 --> Controller Class Initialized
INFO - 2018-05-02 07:53:18 --> Helper loaded: form_helper
INFO - 2018-05-02 07:53:18 --> Form Validation Class Initialized
INFO - 2018-05-02 07:53:18 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:53:18 --> Helper loaded: url_helper
INFO - 2018-05-02 07:53:18 --> Model Class Initialized
INFO - 2018-05-02 07:53:18 --> Model Class Initialized
INFO - 2018-05-02 07:53:18 --> Model Class Initialized
ERROR - 2018-05-02 11:23:18 --> Trying to get property of non-object
ERROR - 2018-05-02 11:23:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 705
INFO - 2018-05-02 11:23:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:23:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:23:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:23:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:23:18 --> Final output sent to browser
DEBUG - 2018-05-02 11:23:18 --> Total execution time: 0.1430
INFO - 2018-05-02 07:53:20 --> Config Class Initialized
INFO - 2018-05-02 07:53:20 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:53:20 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:53:20 --> Utf8 Class Initialized
INFO - 2018-05-02 07:53:20 --> URI Class Initialized
INFO - 2018-05-02 07:53:20 --> Router Class Initialized
INFO - 2018-05-02 07:53:20 --> Output Class Initialized
INFO - 2018-05-02 07:53:20 --> Security Class Initialized
DEBUG - 2018-05-02 07:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:53:20 --> Input Class Initialized
INFO - 2018-05-02 07:53:20 --> Language Class Initialized
INFO - 2018-05-02 07:53:20 --> Loader Class Initialized
INFO - 2018-05-02 07:53:20 --> Helper loaded: common_helper
INFO - 2018-05-02 07:53:20 --> Database Driver Class Initialized
INFO - 2018-05-02 07:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:53:20 --> Email Class Initialized
INFO - 2018-05-02 07:53:20 --> Controller Class Initialized
INFO - 2018-05-02 07:53:20 --> Helper loaded: form_helper
INFO - 2018-05-02 07:53:20 --> Form Validation Class Initialized
INFO - 2018-05-02 07:53:20 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:53:20 --> Helper loaded: url_helper
INFO - 2018-05-02 07:53:20 --> Model Class Initialized
INFO - 2018-05-02 07:53:20 --> Model Class Initialized
INFO - 2018-05-02 07:53:20 --> Model Class Initialized
INFO - 2018-05-02 11:23:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:23:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:23:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:23:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:23:20 --> Final output sent to browser
DEBUG - 2018-05-02 11:23:20 --> Total execution time: 0.1440
INFO - 2018-05-02 07:53:21 --> Config Class Initialized
INFO - 2018-05-02 07:53:21 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:53:21 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:53:21 --> Utf8 Class Initialized
INFO - 2018-05-02 07:53:21 --> URI Class Initialized
INFO - 2018-05-02 07:53:21 --> Router Class Initialized
INFO - 2018-05-02 07:53:21 --> Output Class Initialized
INFO - 2018-05-02 07:53:21 --> Security Class Initialized
DEBUG - 2018-05-02 07:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:53:21 --> Input Class Initialized
INFO - 2018-05-02 07:53:21 --> Language Class Initialized
INFO - 2018-05-02 07:53:21 --> Loader Class Initialized
INFO - 2018-05-02 07:53:21 --> Helper loaded: common_helper
INFO - 2018-05-02 07:53:21 --> Database Driver Class Initialized
INFO - 2018-05-02 07:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:53:21 --> Email Class Initialized
INFO - 2018-05-02 07:53:21 --> Controller Class Initialized
INFO - 2018-05-02 07:53:21 --> Helper loaded: form_helper
INFO - 2018-05-02 07:53:21 --> Form Validation Class Initialized
INFO - 2018-05-02 07:53:21 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:53:21 --> Helper loaded: url_helper
INFO - 2018-05-02 07:53:21 --> Model Class Initialized
INFO - 2018-05-02 07:53:21 --> Model Class Initialized
INFO - 2018-05-02 07:53:21 --> Model Class Initialized
ERROR - 2018-05-02 11:23:21 --> Trying to get property of non-object
ERROR - 2018-05-02 11:23:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 705
INFO - 2018-05-02 11:23:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:23:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:23:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:23:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:23:21 --> Final output sent to browser
DEBUG - 2018-05-02 11:23:21 --> Total execution time: 0.1480
INFO - 2018-05-02 07:53:21 --> Config Class Initialized
INFO - 2018-05-02 07:53:21 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:53:21 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:53:21 --> Utf8 Class Initialized
INFO - 2018-05-02 07:53:21 --> URI Class Initialized
INFO - 2018-05-02 07:53:21 --> Router Class Initialized
INFO - 2018-05-02 07:53:21 --> Output Class Initialized
INFO - 2018-05-02 07:53:21 --> Security Class Initialized
DEBUG - 2018-05-02 07:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:53:21 --> Input Class Initialized
INFO - 2018-05-02 07:53:21 --> Language Class Initialized
INFO - 2018-05-02 07:53:21 --> Loader Class Initialized
INFO - 2018-05-02 07:53:21 --> Helper loaded: common_helper
INFO - 2018-05-02 07:53:21 --> Database Driver Class Initialized
INFO - 2018-05-02 07:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:53:21 --> Email Class Initialized
INFO - 2018-05-02 07:53:21 --> Controller Class Initialized
INFO - 2018-05-02 07:53:21 --> Helper loaded: form_helper
INFO - 2018-05-02 07:53:21 --> Form Validation Class Initialized
INFO - 2018-05-02 07:53:21 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:53:21 --> Helper loaded: url_helper
INFO - 2018-05-02 07:53:21 --> Model Class Initialized
INFO - 2018-05-02 07:53:21 --> Model Class Initialized
INFO - 2018-05-02 07:53:21 --> Model Class Initialized
ERROR - 2018-05-02 11:23:21 --> Trying to get property of non-object
ERROR - 2018-05-02 11:23:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 705
INFO - 2018-05-02 11:23:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:23:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:23:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:23:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:23:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:23:21 --> Final output sent to browser
DEBUG - 2018-05-02 11:23:21 --> Total execution time: 0.1450
INFO - 2018-05-02 07:54:18 --> Config Class Initialized
INFO - 2018-05-02 07:54:18 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:54:18 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:54:18 --> Utf8 Class Initialized
INFO - 2018-05-02 07:54:18 --> URI Class Initialized
INFO - 2018-05-02 07:54:18 --> Router Class Initialized
INFO - 2018-05-02 07:54:18 --> Output Class Initialized
INFO - 2018-05-02 07:54:18 --> Security Class Initialized
DEBUG - 2018-05-02 07:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:54:18 --> Input Class Initialized
INFO - 2018-05-02 07:54:18 --> Language Class Initialized
INFO - 2018-05-02 07:54:18 --> Loader Class Initialized
INFO - 2018-05-02 07:54:18 --> Helper loaded: common_helper
INFO - 2018-05-02 07:54:18 --> Database Driver Class Initialized
INFO - 2018-05-02 07:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:54:18 --> Email Class Initialized
INFO - 2018-05-02 07:54:18 --> Controller Class Initialized
INFO - 2018-05-02 07:54:18 --> Helper loaded: form_helper
INFO - 2018-05-02 07:54:18 --> Form Validation Class Initialized
INFO - 2018-05-02 07:54:18 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:54:18 --> Helper loaded: url_helper
INFO - 2018-05-02 07:54:18 --> Model Class Initialized
INFO - 2018-05-02 07:54:18 --> Model Class Initialized
INFO - 2018-05-02 07:54:18 --> Model Class Initialized
INFO - 2018-05-02 11:24:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:24:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:24:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:24:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:24:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:24:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:24:18 --> Final output sent to browser
DEBUG - 2018-05-02 11:24:18 --> Total execution time: 0.1310
INFO - 2018-05-02 07:54:25 --> Config Class Initialized
INFO - 2018-05-02 07:54:25 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:54:25 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:54:25 --> Utf8 Class Initialized
INFO - 2018-05-02 07:54:25 --> URI Class Initialized
INFO - 2018-05-02 07:54:25 --> Router Class Initialized
INFO - 2018-05-02 07:54:25 --> Output Class Initialized
INFO - 2018-05-02 07:54:25 --> Security Class Initialized
DEBUG - 2018-05-02 07:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:54:25 --> Input Class Initialized
INFO - 2018-05-02 07:54:25 --> Language Class Initialized
INFO - 2018-05-02 07:54:25 --> Loader Class Initialized
INFO - 2018-05-02 07:54:25 --> Helper loaded: common_helper
INFO - 2018-05-02 07:54:25 --> Database Driver Class Initialized
INFO - 2018-05-02 07:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:54:25 --> Email Class Initialized
INFO - 2018-05-02 07:54:25 --> Controller Class Initialized
INFO - 2018-05-02 07:54:25 --> Helper loaded: form_helper
INFO - 2018-05-02 07:54:25 --> Form Validation Class Initialized
INFO - 2018-05-02 07:54:25 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:54:25 --> Helper loaded: url_helper
INFO - 2018-05-02 07:54:25 --> Model Class Initialized
INFO - 2018-05-02 07:54:25 --> Model Class Initialized
INFO - 2018-05-02 07:54:25 --> Model Class Initialized
INFO - 2018-05-02 11:24:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:24:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:24:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:24:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:24:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:24:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:24:25 --> Final output sent to browser
DEBUG - 2018-05-02 11:24:25 --> Total execution time: 0.1340
INFO - 2018-05-02 07:56:17 --> Config Class Initialized
INFO - 2018-05-02 07:56:17 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:56:17 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:56:17 --> Utf8 Class Initialized
INFO - 2018-05-02 07:56:17 --> URI Class Initialized
INFO - 2018-05-02 07:56:17 --> Router Class Initialized
INFO - 2018-05-02 07:56:17 --> Output Class Initialized
INFO - 2018-05-02 07:56:17 --> Security Class Initialized
DEBUG - 2018-05-02 07:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:56:17 --> Input Class Initialized
INFO - 2018-05-02 07:56:17 --> Language Class Initialized
INFO - 2018-05-02 07:56:17 --> Loader Class Initialized
INFO - 2018-05-02 07:56:17 --> Helper loaded: common_helper
INFO - 2018-05-02 07:56:17 --> Database Driver Class Initialized
INFO - 2018-05-02 07:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:56:17 --> Email Class Initialized
INFO - 2018-05-02 07:56:17 --> Controller Class Initialized
INFO - 2018-05-02 07:56:17 --> Helper loaded: form_helper
INFO - 2018-05-02 07:56:17 --> Form Validation Class Initialized
INFO - 2018-05-02 07:56:17 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:56:17 --> Helper loaded: url_helper
INFO - 2018-05-02 07:56:17 --> Model Class Initialized
INFO - 2018-05-02 07:56:17 --> Model Class Initialized
INFO - 2018-05-02 07:56:17 --> Model Class Initialized
INFO - 2018-05-02 11:26:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:26:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:26:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:26:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:26:17 --> Final output sent to browser
DEBUG - 2018-05-02 11:26:17 --> Total execution time: 0.1820
INFO - 2018-05-02 07:56:18 --> Config Class Initialized
INFO - 2018-05-02 07:56:18 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:56:18 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:56:18 --> Utf8 Class Initialized
INFO - 2018-05-02 07:56:18 --> URI Class Initialized
INFO - 2018-05-02 07:56:18 --> Router Class Initialized
INFO - 2018-05-02 07:56:19 --> Output Class Initialized
INFO - 2018-05-02 07:56:19 --> Security Class Initialized
DEBUG - 2018-05-02 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:56:19 --> Input Class Initialized
INFO - 2018-05-02 07:56:19 --> Language Class Initialized
INFO - 2018-05-02 07:56:19 --> Loader Class Initialized
INFO - 2018-05-02 07:56:19 --> Helper loaded: common_helper
INFO - 2018-05-02 07:56:19 --> Database Driver Class Initialized
INFO - 2018-05-02 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:56:19 --> Email Class Initialized
INFO - 2018-05-02 07:56:19 --> Controller Class Initialized
INFO - 2018-05-02 07:56:19 --> Helper loaded: form_helper
INFO - 2018-05-02 07:56:19 --> Form Validation Class Initialized
INFO - 2018-05-02 07:56:19 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:56:19 --> Helper loaded: url_helper
INFO - 2018-05-02 07:56:19 --> Model Class Initialized
INFO - 2018-05-02 07:56:19 --> Model Class Initialized
INFO - 2018-05-02 07:56:19 --> Model Class Initialized
ERROR - 2018-05-02 11:26:19 --> Trying to get property of non-object
ERROR - 2018-05-02 11:26:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 705
INFO - 2018-05-02 11:26:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:26:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:26:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:26:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:26:19 --> Final output sent to browser
DEBUG - 2018-05-02 11:26:19 --> Total execution time: 0.2020
INFO - 2018-05-02 07:56:19 --> Config Class Initialized
INFO - 2018-05-02 07:56:19 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:56:19 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:56:19 --> Utf8 Class Initialized
INFO - 2018-05-02 07:56:19 --> URI Class Initialized
INFO - 2018-05-02 07:56:19 --> Router Class Initialized
INFO - 2018-05-02 07:56:19 --> Output Class Initialized
INFO - 2018-05-02 07:56:19 --> Security Class Initialized
DEBUG - 2018-05-02 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:56:19 --> Input Class Initialized
INFO - 2018-05-02 07:56:19 --> Language Class Initialized
INFO - 2018-05-02 07:56:19 --> Loader Class Initialized
INFO - 2018-05-02 07:56:19 --> Helper loaded: common_helper
INFO - 2018-05-02 07:56:19 --> Database Driver Class Initialized
INFO - 2018-05-02 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:56:19 --> Email Class Initialized
INFO - 2018-05-02 07:56:19 --> Controller Class Initialized
INFO - 2018-05-02 07:56:19 --> Helper loaded: form_helper
INFO - 2018-05-02 07:56:19 --> Form Validation Class Initialized
INFO - 2018-05-02 07:56:19 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:56:19 --> Helper loaded: url_helper
INFO - 2018-05-02 07:56:19 --> Model Class Initialized
INFO - 2018-05-02 07:56:19 --> Model Class Initialized
INFO - 2018-05-02 07:56:19 --> Model Class Initialized
ERROR - 2018-05-02 11:26:19 --> Trying to get property of non-object
ERROR - 2018-05-02 11:26:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 705
INFO - 2018-05-02 11:26:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:26:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:26:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:26:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:26:19 --> Final output sent to browser
DEBUG - 2018-05-02 11:26:19 --> Total execution time: 0.1340
INFO - 2018-05-02 07:56:31 --> Config Class Initialized
INFO - 2018-05-02 07:56:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:56:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:56:31 --> Utf8 Class Initialized
INFO - 2018-05-02 07:56:31 --> URI Class Initialized
INFO - 2018-05-02 07:56:31 --> Router Class Initialized
INFO - 2018-05-02 07:56:31 --> Output Class Initialized
INFO - 2018-05-02 07:56:31 --> Security Class Initialized
DEBUG - 2018-05-02 07:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:56:31 --> Input Class Initialized
INFO - 2018-05-02 07:56:31 --> Language Class Initialized
INFO - 2018-05-02 07:56:31 --> Loader Class Initialized
INFO - 2018-05-02 07:56:31 --> Helper loaded: common_helper
INFO - 2018-05-02 07:56:31 --> Database Driver Class Initialized
INFO - 2018-05-02 07:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:56:31 --> Email Class Initialized
INFO - 2018-05-02 07:56:31 --> Controller Class Initialized
INFO - 2018-05-02 07:56:31 --> Helper loaded: form_helper
INFO - 2018-05-02 07:56:31 --> Form Validation Class Initialized
INFO - 2018-05-02 07:56:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:56:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:56:31 --> Helper loaded: url_helper
INFO - 2018-05-02 07:56:32 --> Model Class Initialized
INFO - 2018-05-02 07:56:32 --> Model Class Initialized
INFO - 2018-05-02 07:56:32 --> Model Class Initialized
ERROR - 2018-05-02 11:26:32 --> Trying to get property of non-object
ERROR - 2018-05-02 11:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 705
INFO - 2018-05-02 11:26:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:26:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:26:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:26:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:26:32 --> Final output sent to browser
DEBUG - 2018-05-02 11:26:32 --> Total execution time: 0.1470
INFO - 2018-05-02 07:56:33 --> Config Class Initialized
INFO - 2018-05-02 07:56:33 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:56:33 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:56:33 --> Utf8 Class Initialized
INFO - 2018-05-02 07:56:33 --> URI Class Initialized
INFO - 2018-05-02 07:56:33 --> Router Class Initialized
INFO - 2018-05-02 07:56:33 --> Output Class Initialized
INFO - 2018-05-02 07:56:33 --> Security Class Initialized
DEBUG - 2018-05-02 07:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:56:33 --> Input Class Initialized
INFO - 2018-05-02 07:56:33 --> Language Class Initialized
INFO - 2018-05-02 07:56:33 --> Loader Class Initialized
INFO - 2018-05-02 07:56:33 --> Helper loaded: common_helper
INFO - 2018-05-02 07:56:33 --> Database Driver Class Initialized
INFO - 2018-05-02 07:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:56:33 --> Email Class Initialized
INFO - 2018-05-02 07:56:33 --> Controller Class Initialized
INFO - 2018-05-02 07:56:33 --> Helper loaded: form_helper
INFO - 2018-05-02 07:56:33 --> Form Validation Class Initialized
INFO - 2018-05-02 07:56:33 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:56:34 --> Helper loaded: url_helper
INFO - 2018-05-02 07:56:34 --> Model Class Initialized
INFO - 2018-05-02 07:56:34 --> Model Class Initialized
INFO - 2018-05-02 07:56:34 --> Model Class Initialized
INFO - 2018-05-02 11:26:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:26:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:26:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:26:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:26:34 --> Final output sent to browser
DEBUG - 2018-05-02 11:26:34 --> Total execution time: 0.1470
INFO - 2018-05-02 07:56:35 --> Config Class Initialized
INFO - 2018-05-02 07:56:35 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:56:35 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:56:35 --> Utf8 Class Initialized
INFO - 2018-05-02 07:56:35 --> URI Class Initialized
INFO - 2018-05-02 07:56:35 --> Router Class Initialized
INFO - 2018-05-02 07:56:35 --> Output Class Initialized
INFO - 2018-05-02 07:56:35 --> Security Class Initialized
DEBUG - 2018-05-02 07:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:56:35 --> Input Class Initialized
INFO - 2018-05-02 07:56:35 --> Language Class Initialized
INFO - 2018-05-02 07:56:35 --> Loader Class Initialized
INFO - 2018-05-02 07:56:35 --> Helper loaded: common_helper
INFO - 2018-05-02 07:56:35 --> Database Driver Class Initialized
INFO - 2018-05-02 07:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:56:35 --> Email Class Initialized
INFO - 2018-05-02 07:56:35 --> Controller Class Initialized
INFO - 2018-05-02 07:56:35 --> Helper loaded: form_helper
INFO - 2018-05-02 07:56:35 --> Form Validation Class Initialized
INFO - 2018-05-02 07:56:35 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:56:35 --> Helper loaded: url_helper
INFO - 2018-05-02 07:56:35 --> Model Class Initialized
INFO - 2018-05-02 07:56:35 --> Model Class Initialized
INFO - 2018-05-02 07:56:35 --> Model Class Initialized
INFO - 2018-05-02 11:26:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:26:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:26:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:26:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:26:35 --> Final output sent to browser
DEBUG - 2018-05-02 11:26:35 --> Total execution time: 0.1690
INFO - 2018-05-02 07:56:37 --> Config Class Initialized
INFO - 2018-05-02 07:56:37 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:56:37 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:56:37 --> Utf8 Class Initialized
INFO - 2018-05-02 07:56:37 --> URI Class Initialized
INFO - 2018-05-02 07:56:37 --> Router Class Initialized
INFO - 2018-05-02 07:56:37 --> Output Class Initialized
INFO - 2018-05-02 07:56:38 --> Security Class Initialized
DEBUG - 2018-05-02 07:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:56:38 --> Input Class Initialized
INFO - 2018-05-02 07:56:38 --> Language Class Initialized
INFO - 2018-05-02 07:56:38 --> Loader Class Initialized
INFO - 2018-05-02 07:56:38 --> Helper loaded: common_helper
INFO - 2018-05-02 07:56:38 --> Database Driver Class Initialized
INFO - 2018-05-02 07:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:56:38 --> Email Class Initialized
INFO - 2018-05-02 07:56:38 --> Controller Class Initialized
INFO - 2018-05-02 07:56:38 --> Helper loaded: form_helper
INFO - 2018-05-02 07:56:38 --> Form Validation Class Initialized
INFO - 2018-05-02 07:56:38 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:56:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:56:38 --> Helper loaded: url_helper
INFO - 2018-05-02 07:56:38 --> Model Class Initialized
INFO - 2018-05-02 07:56:38 --> Model Class Initialized
INFO - 2018-05-02 07:56:38 --> Model Class Initialized
INFO - 2018-05-02 11:26:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:26:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:26:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:26:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:26:38 --> Final output sent to browser
DEBUG - 2018-05-02 11:26:38 --> Total execution time: 0.1310
INFO - 2018-05-02 07:56:41 --> Config Class Initialized
INFO - 2018-05-02 07:56:41 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:56:41 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:56:41 --> Utf8 Class Initialized
INFO - 2018-05-02 07:56:41 --> URI Class Initialized
INFO - 2018-05-02 07:56:41 --> Router Class Initialized
INFO - 2018-05-02 07:56:41 --> Output Class Initialized
INFO - 2018-05-02 07:56:41 --> Security Class Initialized
DEBUG - 2018-05-02 07:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:56:41 --> Input Class Initialized
INFO - 2018-05-02 07:56:41 --> Language Class Initialized
INFO - 2018-05-02 07:56:41 --> Loader Class Initialized
INFO - 2018-05-02 07:56:41 --> Helper loaded: common_helper
INFO - 2018-05-02 07:56:41 --> Database Driver Class Initialized
INFO - 2018-05-02 07:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:56:41 --> Email Class Initialized
INFO - 2018-05-02 07:56:41 --> Controller Class Initialized
INFO - 2018-05-02 07:56:41 --> Helper loaded: form_helper
INFO - 2018-05-02 07:56:41 --> Form Validation Class Initialized
INFO - 2018-05-02 07:56:41 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:56:41 --> Helper loaded: url_helper
INFO - 2018-05-02 07:56:41 --> Model Class Initialized
INFO - 2018-05-02 07:56:41 --> Model Class Initialized
INFO - 2018-05-02 07:56:41 --> Model Class Initialized
INFO - 2018-05-02 11:26:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:26:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:26:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:26:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:26:41 --> Final output sent to browser
DEBUG - 2018-05-02 11:26:41 --> Total execution time: 0.1750
INFO - 2018-05-02 07:56:55 --> Config Class Initialized
INFO - 2018-05-02 07:56:55 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:56:55 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:56:55 --> Utf8 Class Initialized
INFO - 2018-05-02 07:56:55 --> URI Class Initialized
INFO - 2018-05-02 07:56:55 --> Router Class Initialized
INFO - 2018-05-02 07:56:55 --> Output Class Initialized
INFO - 2018-05-02 07:56:55 --> Security Class Initialized
DEBUG - 2018-05-02 07:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:56:55 --> Input Class Initialized
INFO - 2018-05-02 07:56:55 --> Language Class Initialized
INFO - 2018-05-02 07:56:55 --> Loader Class Initialized
INFO - 2018-05-02 07:56:55 --> Helper loaded: common_helper
INFO - 2018-05-02 07:56:55 --> Database Driver Class Initialized
INFO - 2018-05-02 07:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:56:55 --> Email Class Initialized
INFO - 2018-05-02 07:56:55 --> Controller Class Initialized
INFO - 2018-05-02 07:56:55 --> Helper loaded: form_helper
INFO - 2018-05-02 07:56:55 --> Form Validation Class Initialized
INFO - 2018-05-02 07:56:55 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:56:55 --> Helper loaded: url_helper
INFO - 2018-05-02 07:56:55 --> Model Class Initialized
INFO - 2018-05-02 07:56:55 --> Model Class Initialized
INFO - 2018-05-02 07:56:55 --> Model Class Initialized
INFO - 2018-05-02 11:26:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:26:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:26:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:26:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:26:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:26:55 --> Final output sent to browser
DEBUG - 2018-05-02 11:26:55 --> Total execution time: 0.1480
INFO - 2018-05-02 07:57:15 --> Config Class Initialized
INFO - 2018-05-02 07:57:15 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:57:15 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:57:15 --> Utf8 Class Initialized
INFO - 2018-05-02 07:57:15 --> URI Class Initialized
INFO - 2018-05-02 07:57:15 --> Router Class Initialized
INFO - 2018-05-02 07:57:15 --> Output Class Initialized
INFO - 2018-05-02 07:57:15 --> Security Class Initialized
DEBUG - 2018-05-02 07:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:57:15 --> Input Class Initialized
INFO - 2018-05-02 07:57:15 --> Language Class Initialized
INFO - 2018-05-02 07:57:15 --> Loader Class Initialized
INFO - 2018-05-02 07:57:15 --> Helper loaded: common_helper
INFO - 2018-05-02 07:57:15 --> Database Driver Class Initialized
INFO - 2018-05-02 07:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:57:15 --> Email Class Initialized
INFO - 2018-05-02 07:57:15 --> Controller Class Initialized
INFO - 2018-05-02 07:57:15 --> Helper loaded: form_helper
INFO - 2018-05-02 07:57:15 --> Form Validation Class Initialized
INFO - 2018-05-02 07:57:15 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:57:15 --> Helper loaded: url_helper
INFO - 2018-05-02 07:57:15 --> Model Class Initialized
INFO - 2018-05-02 07:57:15 --> Model Class Initialized
INFO - 2018-05-02 07:57:15 --> Model Class Initialized
INFO - 2018-05-02 11:27:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:27:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:27:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:27:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-02 11:27:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:27:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:27:15 --> Final output sent to browser
DEBUG - 2018-05-02 11:27:15 --> Total execution time: 0.1470
INFO - 2018-05-02 07:57:18 --> Config Class Initialized
INFO - 2018-05-02 07:57:18 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:57:18 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:57:18 --> Utf8 Class Initialized
INFO - 2018-05-02 07:57:18 --> URI Class Initialized
INFO - 2018-05-02 07:57:18 --> Router Class Initialized
INFO - 2018-05-02 07:57:18 --> Output Class Initialized
INFO - 2018-05-02 07:57:18 --> Security Class Initialized
DEBUG - 2018-05-02 07:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:57:18 --> Input Class Initialized
INFO - 2018-05-02 07:57:18 --> Language Class Initialized
INFO - 2018-05-02 07:57:18 --> Loader Class Initialized
INFO - 2018-05-02 07:57:18 --> Helper loaded: common_helper
INFO - 2018-05-02 07:57:18 --> Database Driver Class Initialized
INFO - 2018-05-02 07:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:57:18 --> Email Class Initialized
INFO - 2018-05-02 07:57:18 --> Controller Class Initialized
INFO - 2018-05-02 07:57:18 --> Helper loaded: form_helper
INFO - 2018-05-02 07:57:18 --> Form Validation Class Initialized
INFO - 2018-05-02 07:57:18 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:57:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:57:18 --> Helper loaded: url_helper
INFO - 2018-05-02 07:57:18 --> Model Class Initialized
INFO - 2018-05-02 07:57:18 --> Model Class Initialized
INFO - 2018-05-02 07:57:18 --> Model Class Initialized
INFO - 2018-05-02 11:27:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:27:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:27:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:27:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:27:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:27:18 --> Final output sent to browser
DEBUG - 2018-05-02 11:27:18 --> Total execution time: 0.1610
INFO - 2018-05-02 07:57:38 --> Config Class Initialized
INFO - 2018-05-02 07:57:38 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:57:38 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:57:38 --> Utf8 Class Initialized
INFO - 2018-05-02 07:57:38 --> URI Class Initialized
INFO - 2018-05-02 07:57:38 --> Router Class Initialized
INFO - 2018-05-02 07:57:38 --> Output Class Initialized
INFO - 2018-05-02 07:57:38 --> Security Class Initialized
DEBUG - 2018-05-02 07:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:57:38 --> Input Class Initialized
INFO - 2018-05-02 07:57:38 --> Language Class Initialized
INFO - 2018-05-02 07:57:38 --> Loader Class Initialized
INFO - 2018-05-02 07:57:38 --> Helper loaded: common_helper
INFO - 2018-05-02 07:57:38 --> Database Driver Class Initialized
INFO - 2018-05-02 07:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:57:38 --> Email Class Initialized
INFO - 2018-05-02 07:57:38 --> Controller Class Initialized
INFO - 2018-05-02 07:57:38 --> Helper loaded: form_helper
INFO - 2018-05-02 07:57:38 --> Form Validation Class Initialized
INFO - 2018-05-02 07:57:38 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:57:38 --> Helper loaded: url_helper
INFO - 2018-05-02 07:57:38 --> Model Class Initialized
INFO - 2018-05-02 07:57:38 --> Model Class Initialized
INFO - 2018-05-02 07:57:38 --> Model Class Initialized
INFO - 2018-05-02 11:27:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:27:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:27:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:27:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:27:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:27:38 --> Final output sent to browser
DEBUG - 2018-05-02 11:27:38 --> Total execution time: 0.1460
INFO - 2018-05-02 07:57:41 --> Config Class Initialized
INFO - 2018-05-02 07:57:41 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:57:41 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:57:41 --> Utf8 Class Initialized
INFO - 2018-05-02 07:57:41 --> URI Class Initialized
INFO - 2018-05-02 07:57:41 --> Router Class Initialized
INFO - 2018-05-02 07:57:41 --> Output Class Initialized
INFO - 2018-05-02 07:57:41 --> Security Class Initialized
DEBUG - 2018-05-02 07:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:57:41 --> Input Class Initialized
INFO - 2018-05-02 07:57:41 --> Language Class Initialized
INFO - 2018-05-02 07:57:41 --> Loader Class Initialized
INFO - 2018-05-02 07:57:41 --> Helper loaded: common_helper
INFO - 2018-05-02 07:57:41 --> Database Driver Class Initialized
INFO - 2018-05-02 07:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:57:41 --> Email Class Initialized
INFO - 2018-05-02 07:57:41 --> Controller Class Initialized
INFO - 2018-05-02 07:57:41 --> Helper loaded: form_helper
INFO - 2018-05-02 07:57:41 --> Form Validation Class Initialized
INFO - 2018-05-02 07:57:41 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:57:41 --> Helper loaded: url_helper
INFO - 2018-05-02 07:57:41 --> Model Class Initialized
INFO - 2018-05-02 07:57:41 --> Model Class Initialized
INFO - 2018-05-02 07:57:41 --> Model Class Initialized
INFO - 2018-05-02 11:27:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:27:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:27:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:27:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:27:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:27:41 --> Final output sent to browser
DEBUG - 2018-05-02 11:27:41 --> Total execution time: 0.2170
INFO - 2018-05-02 07:57:48 --> Config Class Initialized
INFO - 2018-05-02 07:57:48 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:57:48 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:57:48 --> Utf8 Class Initialized
INFO - 2018-05-02 07:57:48 --> URI Class Initialized
INFO - 2018-05-02 07:57:48 --> Router Class Initialized
INFO - 2018-05-02 07:57:49 --> Output Class Initialized
INFO - 2018-05-02 07:57:49 --> Security Class Initialized
DEBUG - 2018-05-02 07:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:57:49 --> Input Class Initialized
INFO - 2018-05-02 07:57:49 --> Language Class Initialized
INFO - 2018-05-02 07:57:49 --> Loader Class Initialized
INFO - 2018-05-02 07:57:49 --> Helper loaded: common_helper
INFO - 2018-05-02 07:57:49 --> Database Driver Class Initialized
INFO - 2018-05-02 07:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:57:49 --> Email Class Initialized
INFO - 2018-05-02 07:57:49 --> Controller Class Initialized
INFO - 2018-05-02 07:57:49 --> Helper loaded: form_helper
INFO - 2018-05-02 07:57:49 --> Form Validation Class Initialized
INFO - 2018-05-02 07:57:49 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:57:49 --> Helper loaded: url_helper
INFO - 2018-05-02 07:57:49 --> Model Class Initialized
INFO - 2018-05-02 07:57:49 --> Model Class Initialized
INFO - 2018-05-02 07:57:49 --> Model Class Initialized
INFO - 2018-05-02 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:27:49 --> Final output sent to browser
DEBUG - 2018-05-02 11:27:49 --> Total execution time: 0.2100
INFO - 2018-05-02 07:57:50 --> Config Class Initialized
INFO - 2018-05-02 07:57:50 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:57:50 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:57:50 --> Utf8 Class Initialized
INFO - 2018-05-02 07:57:50 --> URI Class Initialized
INFO - 2018-05-02 07:57:50 --> Router Class Initialized
INFO - 2018-05-02 07:57:50 --> Output Class Initialized
INFO - 2018-05-02 07:57:50 --> Security Class Initialized
DEBUG - 2018-05-02 07:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:57:50 --> Input Class Initialized
INFO - 2018-05-02 07:57:50 --> Language Class Initialized
INFO - 2018-05-02 07:57:50 --> Loader Class Initialized
INFO - 2018-05-02 07:57:50 --> Helper loaded: common_helper
INFO - 2018-05-02 07:57:50 --> Database Driver Class Initialized
INFO - 2018-05-02 07:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:57:50 --> Email Class Initialized
INFO - 2018-05-02 07:57:50 --> Controller Class Initialized
INFO - 2018-05-02 07:57:50 --> Helper loaded: form_helper
INFO - 2018-05-02 07:57:50 --> Form Validation Class Initialized
INFO - 2018-05-02 07:57:50 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:57:50 --> Helper loaded: url_helper
INFO - 2018-05-02 07:57:50 --> Model Class Initialized
INFO - 2018-05-02 07:57:50 --> Model Class Initialized
INFO - 2018-05-02 07:57:50 --> Model Class Initialized
INFO - 2018-05-02 11:27:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:27:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:27:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:27:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:27:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:27:50 --> Final output sent to browser
DEBUG - 2018-05-02 11:27:50 --> Total execution time: 0.1470
INFO - 2018-05-02 07:57:51 --> Config Class Initialized
INFO - 2018-05-02 07:57:51 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:57:51 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:57:51 --> Utf8 Class Initialized
INFO - 2018-05-02 07:57:51 --> URI Class Initialized
INFO - 2018-05-02 07:57:51 --> Router Class Initialized
INFO - 2018-05-02 07:57:51 --> Output Class Initialized
INFO - 2018-05-02 07:57:51 --> Security Class Initialized
DEBUG - 2018-05-02 07:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:57:51 --> Input Class Initialized
INFO - 2018-05-02 07:57:51 --> Language Class Initialized
INFO - 2018-05-02 07:57:51 --> Loader Class Initialized
INFO - 2018-05-02 07:57:51 --> Helper loaded: common_helper
INFO - 2018-05-02 07:57:52 --> Database Driver Class Initialized
INFO - 2018-05-02 07:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:57:52 --> Email Class Initialized
INFO - 2018-05-02 07:57:52 --> Controller Class Initialized
INFO - 2018-05-02 07:57:52 --> Helper loaded: form_helper
INFO - 2018-05-02 07:57:52 --> Form Validation Class Initialized
INFO - 2018-05-02 07:57:52 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:57:52 --> Helper loaded: url_helper
INFO - 2018-05-02 07:57:52 --> Model Class Initialized
INFO - 2018-05-02 07:57:52 --> Model Class Initialized
INFO - 2018-05-02 07:57:52 --> Model Class Initialized
INFO - 2018-05-02 11:27:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:27:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:27:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:27:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:27:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:27:52 --> Final output sent to browser
DEBUG - 2018-05-02 11:27:52 --> Total execution time: 0.1870
INFO - 2018-05-02 07:57:53 --> Config Class Initialized
INFO - 2018-05-02 07:57:53 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:57:53 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:57:53 --> Utf8 Class Initialized
INFO - 2018-05-02 07:57:53 --> URI Class Initialized
INFO - 2018-05-02 07:57:53 --> Router Class Initialized
INFO - 2018-05-02 07:57:53 --> Output Class Initialized
INFO - 2018-05-02 07:57:53 --> Security Class Initialized
DEBUG - 2018-05-02 07:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:57:53 --> Input Class Initialized
INFO - 2018-05-02 07:57:53 --> Language Class Initialized
INFO - 2018-05-02 07:57:53 --> Loader Class Initialized
INFO - 2018-05-02 07:57:53 --> Helper loaded: common_helper
INFO - 2018-05-02 07:57:53 --> Database Driver Class Initialized
INFO - 2018-05-02 07:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:57:53 --> Email Class Initialized
INFO - 2018-05-02 07:57:53 --> Controller Class Initialized
INFO - 2018-05-02 07:57:53 --> Helper loaded: form_helper
INFO - 2018-05-02 07:57:53 --> Form Validation Class Initialized
INFO - 2018-05-02 07:57:53 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:57:53 --> Helper loaded: url_helper
INFO - 2018-05-02 07:57:53 --> Model Class Initialized
INFO - 2018-05-02 07:57:53 --> Model Class Initialized
INFO - 2018-05-02 07:57:53 --> Model Class Initialized
INFO - 2018-05-02 11:27:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:27:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:27:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:27:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/aboutMovie.php
INFO - 2018-05-02 11:27:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:27:53 --> Final output sent to browser
DEBUG - 2018-05-02 11:27:53 --> Total execution time: 0.1410
INFO - 2018-05-02 07:58:02 --> Config Class Initialized
INFO - 2018-05-02 07:58:02 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:58:02 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:58:02 --> Utf8 Class Initialized
INFO - 2018-05-02 07:58:02 --> URI Class Initialized
INFO - 2018-05-02 07:58:02 --> Router Class Initialized
INFO - 2018-05-02 07:58:02 --> Output Class Initialized
INFO - 2018-05-02 07:58:02 --> Security Class Initialized
DEBUG - 2018-05-02 07:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:58:02 --> Input Class Initialized
INFO - 2018-05-02 07:58:02 --> Language Class Initialized
INFO - 2018-05-02 07:58:02 --> Loader Class Initialized
INFO - 2018-05-02 07:58:02 --> Helper loaded: common_helper
INFO - 2018-05-02 07:58:02 --> Database Driver Class Initialized
INFO - 2018-05-02 07:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:58:02 --> Email Class Initialized
INFO - 2018-05-02 07:58:02 --> Controller Class Initialized
INFO - 2018-05-02 07:58:02 --> Helper loaded: form_helper
INFO - 2018-05-02 07:58:02 --> Form Validation Class Initialized
INFO - 2018-05-02 07:58:02 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:58:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:58:02 --> Helper loaded: url_helper
INFO - 2018-05-02 07:58:02 --> Model Class Initialized
INFO - 2018-05-02 07:58:02 --> Model Class Initialized
INFO - 2018-05-02 07:58:02 --> Model Class Initialized
INFO - 2018-05-02 11:28:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:28:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:28:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:28:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-02 11:28:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:28:02 --> Final output sent to browser
DEBUG - 2018-05-02 11:28:02 --> Total execution time: 0.1550
INFO - 2018-05-02 07:58:10 --> Config Class Initialized
INFO - 2018-05-02 07:58:10 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:58:10 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:58:10 --> Utf8 Class Initialized
INFO - 2018-05-02 07:58:10 --> URI Class Initialized
INFO - 2018-05-02 07:58:10 --> Router Class Initialized
INFO - 2018-05-02 07:58:10 --> Output Class Initialized
INFO - 2018-05-02 07:58:10 --> Security Class Initialized
DEBUG - 2018-05-02 07:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:58:10 --> Input Class Initialized
INFO - 2018-05-02 07:58:10 --> Language Class Initialized
INFO - 2018-05-02 07:58:10 --> Loader Class Initialized
INFO - 2018-05-02 07:58:10 --> Helper loaded: common_helper
INFO - 2018-05-02 07:58:10 --> Database Driver Class Initialized
INFO - 2018-05-02 07:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:58:10 --> Email Class Initialized
INFO - 2018-05-02 07:58:10 --> Controller Class Initialized
INFO - 2018-05-02 07:58:10 --> Helper loaded: form_helper
INFO - 2018-05-02 07:58:10 --> Form Validation Class Initialized
INFO - 2018-05-02 07:58:10 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:58:10 --> Helper loaded: url_helper
INFO - 2018-05-02 07:58:10 --> Model Class Initialized
INFO - 2018-05-02 07:58:10 --> Model Class Initialized
INFO - 2018-05-02 07:58:10 --> Model Class Initialized
INFO - 2018-05-02 11:28:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:28:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:28:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:28:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/aboutMovie.php
INFO - 2018-05-02 11:28:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:28:10 --> Final output sent to browser
DEBUG - 2018-05-02 11:28:10 --> Total execution time: 0.3840
INFO - 2018-05-02 07:58:18 --> Config Class Initialized
INFO - 2018-05-02 07:58:18 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:58:18 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:58:18 --> Utf8 Class Initialized
INFO - 2018-05-02 07:58:18 --> URI Class Initialized
INFO - 2018-05-02 07:58:18 --> Router Class Initialized
INFO - 2018-05-02 07:58:18 --> Output Class Initialized
INFO - 2018-05-02 07:58:18 --> Security Class Initialized
DEBUG - 2018-05-02 07:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:58:18 --> Input Class Initialized
INFO - 2018-05-02 07:58:18 --> Language Class Initialized
INFO - 2018-05-02 07:58:18 --> Loader Class Initialized
INFO - 2018-05-02 07:58:18 --> Helper loaded: common_helper
INFO - 2018-05-02 07:58:18 --> Database Driver Class Initialized
INFO - 2018-05-02 07:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:58:18 --> Email Class Initialized
INFO - 2018-05-02 07:58:18 --> Controller Class Initialized
INFO - 2018-05-02 07:58:18 --> Helper loaded: form_helper
INFO - 2018-05-02 07:58:18 --> Form Validation Class Initialized
INFO - 2018-05-02 07:58:18 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:58:18 --> Helper loaded: url_helper
INFO - 2018-05-02 07:58:18 --> Model Class Initialized
INFO - 2018-05-02 07:58:18 --> Model Class Initialized
INFO - 2018-05-02 07:58:18 --> Model Class Initialized
INFO - 2018-05-02 11:28:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:28:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:28:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:28:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/songsLink.php
INFO - 2018-05-02 11:28:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:28:18 --> Final output sent to browser
DEBUG - 2018-05-02 11:28:18 --> Total execution time: 0.3220
INFO - 2018-05-02 07:58:55 --> Config Class Initialized
INFO - 2018-05-02 07:58:55 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:58:55 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:58:55 --> Utf8 Class Initialized
INFO - 2018-05-02 07:58:55 --> URI Class Initialized
INFO - 2018-05-02 07:58:55 --> Router Class Initialized
INFO - 2018-05-02 07:58:55 --> Output Class Initialized
INFO - 2018-05-02 07:58:55 --> Security Class Initialized
DEBUG - 2018-05-02 07:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:58:55 --> Input Class Initialized
INFO - 2018-05-02 07:58:55 --> Language Class Initialized
INFO - 2018-05-02 07:58:55 --> Loader Class Initialized
INFO - 2018-05-02 07:58:55 --> Helper loaded: common_helper
INFO - 2018-05-02 07:58:55 --> Database Driver Class Initialized
INFO - 2018-05-02 07:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:58:55 --> Email Class Initialized
INFO - 2018-05-02 07:58:55 --> Controller Class Initialized
INFO - 2018-05-02 07:58:55 --> Helper loaded: form_helper
INFO - 2018-05-02 07:58:55 --> Form Validation Class Initialized
INFO - 2018-05-02 07:58:55 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:58:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:58:55 --> Helper loaded: url_helper
INFO - 2018-05-02 07:58:55 --> Model Class Initialized
INFO - 2018-05-02 07:58:55 --> Model Class Initialized
INFO - 2018-05-02 07:58:55 --> Model Class Initialized
INFO - 2018-05-02 11:28:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:28:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:28:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:28:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/songsLink.php
INFO - 2018-05-02 11:28:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:28:55 --> Final output sent to browser
DEBUG - 2018-05-02 11:28:55 --> Total execution time: 0.1450
INFO - 2018-05-02 07:59:29 --> Config Class Initialized
INFO - 2018-05-02 07:59:29 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:59:29 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:59:29 --> Utf8 Class Initialized
INFO - 2018-05-02 07:59:29 --> URI Class Initialized
INFO - 2018-05-02 07:59:29 --> Router Class Initialized
INFO - 2018-05-02 07:59:29 --> Output Class Initialized
INFO - 2018-05-02 07:59:29 --> Security Class Initialized
DEBUG - 2018-05-02 07:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:59:29 --> Input Class Initialized
INFO - 2018-05-02 07:59:29 --> Language Class Initialized
INFO - 2018-05-02 07:59:29 --> Loader Class Initialized
INFO - 2018-05-02 07:59:29 --> Helper loaded: common_helper
INFO - 2018-05-02 07:59:29 --> Database Driver Class Initialized
INFO - 2018-05-02 07:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:59:29 --> Email Class Initialized
INFO - 2018-05-02 07:59:29 --> Controller Class Initialized
INFO - 2018-05-02 07:59:29 --> Helper loaded: form_helper
INFO - 2018-05-02 07:59:29 --> Form Validation Class Initialized
INFO - 2018-05-02 07:59:29 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:59:29 --> Helper loaded: url_helper
INFO - 2018-05-02 07:59:29 --> Model Class Initialized
INFO - 2018-05-02 07:59:29 --> Model Class Initialized
INFO - 2018-05-02 07:59:29 --> Model Class Initialized
INFO - 2018-05-02 11:29:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:29:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:29:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:29:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/aboutMovie.php
INFO - 2018-05-02 11:29:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:29:29 --> Final output sent to browser
DEBUG - 2018-05-02 11:29:29 --> Total execution time: 0.1510
INFO - 2018-05-02 07:59:30 --> Config Class Initialized
INFO - 2018-05-02 07:59:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:59:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:59:30 --> Utf8 Class Initialized
INFO - 2018-05-02 07:59:30 --> URI Class Initialized
INFO - 2018-05-02 07:59:30 --> Router Class Initialized
INFO - 2018-05-02 07:59:30 --> Output Class Initialized
INFO - 2018-05-02 07:59:30 --> Security Class Initialized
DEBUG - 2018-05-02 07:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:59:30 --> Input Class Initialized
INFO - 2018-05-02 07:59:30 --> Language Class Initialized
INFO - 2018-05-02 07:59:30 --> Loader Class Initialized
INFO - 2018-05-02 07:59:30 --> Helper loaded: common_helper
INFO - 2018-05-02 07:59:30 --> Database Driver Class Initialized
INFO - 2018-05-02 07:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:59:30 --> Email Class Initialized
INFO - 2018-05-02 07:59:30 --> Controller Class Initialized
INFO - 2018-05-02 07:59:30 --> Helper loaded: form_helper
INFO - 2018-05-02 07:59:30 --> Form Validation Class Initialized
INFO - 2018-05-02 07:59:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:59:30 --> Helper loaded: url_helper
INFO - 2018-05-02 07:59:30 --> Model Class Initialized
INFO - 2018-05-02 07:59:30 --> Model Class Initialized
INFO - 2018-05-02 07:59:30 --> Model Class Initialized
INFO - 2018-05-02 11:29:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:29:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:29:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:29:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:29:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:29:30 --> Final output sent to browser
DEBUG - 2018-05-02 11:29:30 --> Total execution time: 0.1470
INFO - 2018-05-02 07:59:31 --> Config Class Initialized
INFO - 2018-05-02 07:59:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:59:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:59:31 --> Utf8 Class Initialized
INFO - 2018-05-02 07:59:31 --> URI Class Initialized
INFO - 2018-05-02 07:59:31 --> Router Class Initialized
INFO - 2018-05-02 07:59:31 --> Output Class Initialized
INFO - 2018-05-02 07:59:31 --> Security Class Initialized
DEBUG - 2018-05-02 07:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:59:31 --> Input Class Initialized
INFO - 2018-05-02 07:59:31 --> Language Class Initialized
INFO - 2018-05-02 07:59:31 --> Loader Class Initialized
INFO - 2018-05-02 07:59:31 --> Helper loaded: common_helper
INFO - 2018-05-02 07:59:31 --> Database Driver Class Initialized
INFO - 2018-05-02 07:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:59:31 --> Email Class Initialized
INFO - 2018-05-02 07:59:31 --> Controller Class Initialized
INFO - 2018-05-02 07:59:31 --> Helper loaded: form_helper
INFO - 2018-05-02 07:59:31 --> Form Validation Class Initialized
INFO - 2018-05-02 07:59:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:59:31 --> Helper loaded: url_helper
INFO - 2018-05-02 07:59:31 --> Model Class Initialized
INFO - 2018-05-02 07:59:31 --> Model Class Initialized
INFO - 2018-05-02 07:59:31 --> Model Class Initialized
INFO - 2018-05-02 11:29:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:29:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:29:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:29:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:29:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:29:31 --> Final output sent to browser
DEBUG - 2018-05-02 11:29:31 --> Total execution time: 0.1450
INFO - 2018-05-02 07:59:33 --> Config Class Initialized
INFO - 2018-05-02 07:59:33 --> Hooks Class Initialized
DEBUG - 2018-05-02 07:59:33 --> UTF-8 Support Enabled
INFO - 2018-05-02 07:59:33 --> Utf8 Class Initialized
INFO - 2018-05-02 07:59:33 --> URI Class Initialized
INFO - 2018-05-02 07:59:33 --> Router Class Initialized
INFO - 2018-05-02 07:59:33 --> Output Class Initialized
INFO - 2018-05-02 07:59:33 --> Security Class Initialized
DEBUG - 2018-05-02 07:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 07:59:33 --> Input Class Initialized
INFO - 2018-05-02 07:59:33 --> Language Class Initialized
INFO - 2018-05-02 07:59:33 --> Loader Class Initialized
INFO - 2018-05-02 07:59:33 --> Helper loaded: common_helper
INFO - 2018-05-02 07:59:33 --> Database Driver Class Initialized
INFO - 2018-05-02 07:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 07:59:33 --> Email Class Initialized
INFO - 2018-05-02 07:59:33 --> Controller Class Initialized
INFO - 2018-05-02 07:59:33 --> Helper loaded: form_helper
INFO - 2018-05-02 07:59:33 --> Form Validation Class Initialized
INFO - 2018-05-02 07:59:33 --> Helper loaded: email_helper
DEBUG - 2018-05-02 07:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 07:59:33 --> Helper loaded: url_helper
INFO - 2018-05-02 07:59:33 --> Model Class Initialized
INFO - 2018-05-02 07:59:33 --> Model Class Initialized
INFO - 2018-05-02 07:59:33 --> Model Class Initialized
INFO - 2018-05-02 11:29:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:29:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:29:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:29:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-02 11:29:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:29:33 --> Final output sent to browser
DEBUG - 2018-05-02 11:29:33 --> Total execution time: 0.1490
INFO - 2018-05-02 08:02:18 --> Config Class Initialized
INFO - 2018-05-02 08:02:18 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:18 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:18 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:18 --> URI Class Initialized
INFO - 2018-05-02 08:02:18 --> Router Class Initialized
INFO - 2018-05-02 08:02:18 --> Output Class Initialized
INFO - 2018-05-02 08:02:18 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:18 --> Input Class Initialized
INFO - 2018-05-02 08:02:18 --> Language Class Initialized
INFO - 2018-05-02 08:02:18 --> Loader Class Initialized
INFO - 2018-05-02 08:02:18 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:18 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:18 --> Email Class Initialized
INFO - 2018-05-02 08:02:18 --> Controller Class Initialized
INFO - 2018-05-02 08:02:18 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:18 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:18 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:18 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:18 --> Model Class Initialized
INFO - 2018-05-02 08:02:18 --> Model Class Initialized
INFO - 2018-05-02 08:02:18 --> Model Class Initialized
INFO - 2018-05-02 11:32:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:18 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:18 --> Total execution time: 0.1500
INFO - 2018-05-02 08:02:29 --> Config Class Initialized
INFO - 2018-05-02 08:02:29 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:29 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:29 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:29 --> URI Class Initialized
INFO - 2018-05-02 08:02:29 --> Router Class Initialized
INFO - 2018-05-02 08:02:29 --> Output Class Initialized
INFO - 2018-05-02 08:02:29 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:29 --> Input Class Initialized
INFO - 2018-05-02 08:02:29 --> Language Class Initialized
INFO - 2018-05-02 08:02:29 --> Loader Class Initialized
INFO - 2018-05-02 08:02:29 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:29 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:29 --> Email Class Initialized
INFO - 2018-05-02 08:02:29 --> Controller Class Initialized
INFO - 2018-05-02 08:02:29 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:29 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:29 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:29 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:29 --> Model Class Initialized
INFO - 2018-05-02 08:02:29 --> Model Class Initialized
INFO - 2018-05-02 08:02:29 --> Model Class Initialized
INFO - 2018-05-02 11:32:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:29 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:29 --> Total execution time: 0.1270
INFO - 2018-05-02 08:02:30 --> Config Class Initialized
INFO - 2018-05-02 08:02:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:30 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:30 --> URI Class Initialized
INFO - 2018-05-02 08:02:30 --> Router Class Initialized
INFO - 2018-05-02 08:02:30 --> Output Class Initialized
INFO - 2018-05-02 08:02:30 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:30 --> Input Class Initialized
INFO - 2018-05-02 08:02:30 --> Language Class Initialized
INFO - 2018-05-02 08:02:30 --> Loader Class Initialized
INFO - 2018-05-02 08:02:30 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:30 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:30 --> Email Class Initialized
INFO - 2018-05-02 08:02:30 --> Controller Class Initialized
INFO - 2018-05-02 08:02:30 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:30 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:30 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:30 --> Model Class Initialized
INFO - 2018-05-02 08:02:30 --> Model Class Initialized
INFO - 2018-05-02 08:02:30 --> Model Class Initialized
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:30 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:30 --> Total execution time: 0.1290
INFO - 2018-05-02 08:02:30 --> Config Class Initialized
INFO - 2018-05-02 08:02:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:30 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:30 --> URI Class Initialized
INFO - 2018-05-02 08:02:30 --> Router Class Initialized
INFO - 2018-05-02 08:02:30 --> Output Class Initialized
INFO - 2018-05-02 08:02:30 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:30 --> Input Class Initialized
INFO - 2018-05-02 08:02:30 --> Language Class Initialized
INFO - 2018-05-02 08:02:30 --> Loader Class Initialized
INFO - 2018-05-02 08:02:30 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:30 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:30 --> Email Class Initialized
INFO - 2018-05-02 08:02:30 --> Controller Class Initialized
INFO - 2018-05-02 08:02:30 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:30 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:30 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:30 --> Model Class Initialized
INFO - 2018-05-02 08:02:30 --> Model Class Initialized
INFO - 2018-05-02 08:02:30 --> Model Class Initialized
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:30 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:30 --> Total execution time: 0.1350
INFO - 2018-05-02 08:02:30 --> Config Class Initialized
INFO - 2018-05-02 08:02:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:30 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:30 --> URI Class Initialized
INFO - 2018-05-02 08:02:30 --> Router Class Initialized
INFO - 2018-05-02 08:02:30 --> Output Class Initialized
INFO - 2018-05-02 08:02:30 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:30 --> Input Class Initialized
INFO - 2018-05-02 08:02:30 --> Language Class Initialized
INFO - 2018-05-02 08:02:30 --> Loader Class Initialized
INFO - 2018-05-02 08:02:30 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:30 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:30 --> Email Class Initialized
INFO - 2018-05-02 08:02:30 --> Controller Class Initialized
INFO - 2018-05-02 08:02:30 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:30 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:30 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:30 --> Model Class Initialized
INFO - 2018-05-02 08:02:30 --> Model Class Initialized
INFO - 2018-05-02 08:02:30 --> Model Class Initialized
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:30 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:30 --> Total execution time: 0.1290
INFO - 2018-05-02 08:02:30 --> Config Class Initialized
INFO - 2018-05-02 08:02:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:30 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:30 --> URI Class Initialized
INFO - 2018-05-02 08:02:30 --> Router Class Initialized
INFO - 2018-05-02 08:02:30 --> Output Class Initialized
INFO - 2018-05-02 08:02:30 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:30 --> Input Class Initialized
INFO - 2018-05-02 08:02:30 --> Language Class Initialized
INFO - 2018-05-02 08:02:30 --> Loader Class Initialized
INFO - 2018-05-02 08:02:30 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:30 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:30 --> Email Class Initialized
INFO - 2018-05-02 08:02:30 --> Controller Class Initialized
INFO - 2018-05-02 08:02:30 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:30 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:30 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:30 --> Model Class Initialized
INFO - 2018-05-02 08:02:30 --> Model Class Initialized
INFO - 2018-05-02 08:02:30 --> Model Class Initialized
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:30 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:30 --> Total execution time: 0.1440
INFO - 2018-05-02 08:02:31 --> Config Class Initialized
INFO - 2018-05-02 08:02:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:31 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:31 --> URI Class Initialized
INFO - 2018-05-02 08:02:31 --> Router Class Initialized
INFO - 2018-05-02 08:02:31 --> Output Class Initialized
INFO - 2018-05-02 08:02:31 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:31 --> Input Class Initialized
INFO - 2018-05-02 08:02:31 --> Language Class Initialized
INFO - 2018-05-02 08:02:31 --> Loader Class Initialized
INFO - 2018-05-02 08:02:31 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:31 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:31 --> Email Class Initialized
INFO - 2018-05-02 08:02:31 --> Controller Class Initialized
INFO - 2018-05-02 08:02:31 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:31 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:31 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:31 --> Model Class Initialized
INFO - 2018-05-02 08:02:31 --> Model Class Initialized
INFO - 2018-05-02 08:02:31 --> Model Class Initialized
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:31 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:31 --> Total execution time: 0.1360
INFO - 2018-05-02 08:02:31 --> Config Class Initialized
INFO - 2018-05-02 08:02:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:31 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:31 --> URI Class Initialized
INFO - 2018-05-02 08:02:31 --> Router Class Initialized
INFO - 2018-05-02 08:02:31 --> Output Class Initialized
INFO - 2018-05-02 08:02:31 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:31 --> Input Class Initialized
INFO - 2018-05-02 08:02:31 --> Language Class Initialized
INFO - 2018-05-02 08:02:31 --> Loader Class Initialized
INFO - 2018-05-02 08:02:31 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:31 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:31 --> Email Class Initialized
INFO - 2018-05-02 08:02:31 --> Controller Class Initialized
INFO - 2018-05-02 08:02:31 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:31 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:31 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:31 --> Model Class Initialized
INFO - 2018-05-02 08:02:31 --> Model Class Initialized
INFO - 2018-05-02 08:02:31 --> Model Class Initialized
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:31 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:31 --> Total execution time: 0.1310
INFO - 2018-05-02 08:02:31 --> Config Class Initialized
INFO - 2018-05-02 08:02:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:31 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:31 --> URI Class Initialized
INFO - 2018-05-02 08:02:31 --> Router Class Initialized
INFO - 2018-05-02 08:02:31 --> Output Class Initialized
INFO - 2018-05-02 08:02:31 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:31 --> Input Class Initialized
INFO - 2018-05-02 08:02:31 --> Language Class Initialized
INFO - 2018-05-02 08:02:31 --> Loader Class Initialized
INFO - 2018-05-02 08:02:31 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:31 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:31 --> Email Class Initialized
INFO - 2018-05-02 08:02:31 --> Controller Class Initialized
INFO - 2018-05-02 08:02:31 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:31 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:31 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:31 --> Model Class Initialized
INFO - 2018-05-02 08:02:31 --> Model Class Initialized
INFO - 2018-05-02 08:02:31 --> Model Class Initialized
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:31 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:31 --> Total execution time: 0.1340
INFO - 2018-05-02 08:02:31 --> Config Class Initialized
INFO - 2018-05-02 08:02:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:31 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:31 --> URI Class Initialized
INFO - 2018-05-02 08:02:31 --> Router Class Initialized
INFO - 2018-05-02 08:02:31 --> Output Class Initialized
INFO - 2018-05-02 08:02:31 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:31 --> Input Class Initialized
INFO - 2018-05-02 08:02:31 --> Language Class Initialized
INFO - 2018-05-02 08:02:31 --> Loader Class Initialized
INFO - 2018-05-02 08:02:31 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:31 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:31 --> Email Class Initialized
INFO - 2018-05-02 08:02:31 --> Controller Class Initialized
INFO - 2018-05-02 08:02:31 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:31 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:31 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:31 --> Model Class Initialized
INFO - 2018-05-02 08:02:31 --> Model Class Initialized
INFO - 2018-05-02 08:02:31 --> Model Class Initialized
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:31 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:31 --> Total execution time: 0.1410
INFO - 2018-05-02 08:02:32 --> Config Class Initialized
INFO - 2018-05-02 08:02:32 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:32 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:32 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:32 --> URI Class Initialized
INFO - 2018-05-02 08:02:32 --> Router Class Initialized
INFO - 2018-05-02 08:02:32 --> Output Class Initialized
INFO - 2018-05-02 08:02:32 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:32 --> Input Class Initialized
INFO - 2018-05-02 08:02:32 --> Language Class Initialized
INFO - 2018-05-02 08:02:32 --> Loader Class Initialized
INFO - 2018-05-02 08:02:32 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:32 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:32 --> Email Class Initialized
INFO - 2018-05-02 08:02:32 --> Controller Class Initialized
INFO - 2018-05-02 08:02:32 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:32 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:32 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:32 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:32 --> Model Class Initialized
INFO - 2018-05-02 08:02:32 --> Model Class Initialized
INFO - 2018-05-02 08:02:32 --> Model Class Initialized
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:32 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:32 --> Total execution time: 0.1300
INFO - 2018-05-02 08:02:32 --> Config Class Initialized
INFO - 2018-05-02 08:02:32 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:32 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:32 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:32 --> URI Class Initialized
INFO - 2018-05-02 08:02:32 --> Router Class Initialized
INFO - 2018-05-02 08:02:32 --> Output Class Initialized
INFO - 2018-05-02 08:02:32 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:32 --> Input Class Initialized
INFO - 2018-05-02 08:02:32 --> Language Class Initialized
INFO - 2018-05-02 08:02:32 --> Loader Class Initialized
INFO - 2018-05-02 08:02:32 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:32 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:32 --> Email Class Initialized
INFO - 2018-05-02 08:02:32 --> Controller Class Initialized
INFO - 2018-05-02 08:02:32 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:32 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:32 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:32 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:32 --> Model Class Initialized
INFO - 2018-05-02 08:02:32 --> Model Class Initialized
INFO - 2018-05-02 08:02:32 --> Model Class Initialized
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:32 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:32 --> Total execution time: 0.1310
INFO - 2018-05-02 08:02:32 --> Config Class Initialized
INFO - 2018-05-02 08:02:32 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:32 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:32 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:32 --> URI Class Initialized
INFO - 2018-05-02 08:02:32 --> Router Class Initialized
INFO - 2018-05-02 08:02:32 --> Output Class Initialized
INFO - 2018-05-02 08:02:32 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:32 --> Input Class Initialized
INFO - 2018-05-02 08:02:32 --> Language Class Initialized
INFO - 2018-05-02 08:02:32 --> Loader Class Initialized
INFO - 2018-05-02 08:02:32 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:32 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:32 --> Email Class Initialized
INFO - 2018-05-02 08:02:32 --> Controller Class Initialized
INFO - 2018-05-02 08:02:32 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:32 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:32 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:32 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:32 --> Model Class Initialized
INFO - 2018-05-02 08:02:32 --> Model Class Initialized
INFO - 2018-05-02 08:02:32 --> Model Class Initialized
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:32 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:32 --> Total execution time: 0.1350
INFO - 2018-05-02 08:02:32 --> Config Class Initialized
INFO - 2018-05-02 08:02:32 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:32 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:32 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:32 --> URI Class Initialized
INFO - 2018-05-02 08:02:32 --> Router Class Initialized
INFO - 2018-05-02 08:02:32 --> Output Class Initialized
INFO - 2018-05-02 08:02:32 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:32 --> Input Class Initialized
INFO - 2018-05-02 08:02:32 --> Language Class Initialized
INFO - 2018-05-02 08:02:32 --> Loader Class Initialized
INFO - 2018-05-02 08:02:32 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:32 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:32 --> Email Class Initialized
INFO - 2018-05-02 08:02:32 --> Controller Class Initialized
INFO - 2018-05-02 08:02:32 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:32 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:32 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:32 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:32 --> Model Class Initialized
INFO - 2018-05-02 08:02:32 --> Model Class Initialized
INFO - 2018-05-02 08:02:32 --> Model Class Initialized
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:32 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:32 --> Total execution time: 0.1320
INFO - 2018-05-02 08:02:32 --> Config Class Initialized
INFO - 2018-05-02 08:02:32 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:32 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:33 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:33 --> URI Class Initialized
INFO - 2018-05-02 08:02:33 --> Router Class Initialized
INFO - 2018-05-02 08:02:33 --> Output Class Initialized
INFO - 2018-05-02 08:02:33 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:33 --> Input Class Initialized
INFO - 2018-05-02 08:02:33 --> Language Class Initialized
INFO - 2018-05-02 08:02:33 --> Loader Class Initialized
INFO - 2018-05-02 08:02:33 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:33 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:33 --> Email Class Initialized
INFO - 2018-05-02 08:02:33 --> Controller Class Initialized
INFO - 2018-05-02 08:02:33 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:33 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:33 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:33 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:33 --> Model Class Initialized
INFO - 2018-05-02 08:02:33 --> Model Class Initialized
INFO - 2018-05-02 08:02:33 --> Model Class Initialized
INFO - 2018-05-02 11:32:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:33 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:33 --> Total execution time: 0.1350
INFO - 2018-05-02 08:02:33 --> Config Class Initialized
INFO - 2018-05-02 08:02:33 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:02:33 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:02:33 --> Utf8 Class Initialized
INFO - 2018-05-02 08:02:33 --> URI Class Initialized
INFO - 2018-05-02 08:02:33 --> Router Class Initialized
INFO - 2018-05-02 08:02:33 --> Output Class Initialized
INFO - 2018-05-02 08:02:33 --> Security Class Initialized
DEBUG - 2018-05-02 08:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:02:33 --> Input Class Initialized
INFO - 2018-05-02 08:02:33 --> Language Class Initialized
INFO - 2018-05-02 08:02:33 --> Loader Class Initialized
INFO - 2018-05-02 08:02:33 --> Helper loaded: common_helper
INFO - 2018-05-02 08:02:33 --> Database Driver Class Initialized
INFO - 2018-05-02 08:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:02:33 --> Email Class Initialized
INFO - 2018-05-02 08:02:33 --> Controller Class Initialized
INFO - 2018-05-02 08:02:33 --> Helper loaded: form_helper
INFO - 2018-05-02 08:02:33 --> Form Validation Class Initialized
INFO - 2018-05-02 08:02:33 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:02:33 --> Helper loaded: url_helper
INFO - 2018-05-02 08:02:33 --> Model Class Initialized
INFO - 2018-05-02 08:02:33 --> Model Class Initialized
INFO - 2018-05-02 08:02:33 --> Model Class Initialized
INFO - 2018-05-02 11:32:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:32:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:32:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 11:32:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:32:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:32:33 --> Final output sent to browser
DEBUG - 2018-05-02 11:32:33 --> Total execution time: 0.1300
INFO - 2018-05-02 08:10:08 --> Config Class Initialized
INFO - 2018-05-02 08:10:08 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:10:08 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:10:08 --> Utf8 Class Initialized
INFO - 2018-05-02 08:10:08 --> URI Class Initialized
INFO - 2018-05-02 08:10:08 --> Router Class Initialized
INFO - 2018-05-02 08:10:08 --> Output Class Initialized
INFO - 2018-05-02 08:10:08 --> Security Class Initialized
DEBUG - 2018-05-02 08:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:10:08 --> Input Class Initialized
INFO - 2018-05-02 08:10:08 --> Language Class Initialized
INFO - 2018-05-02 08:10:08 --> Loader Class Initialized
INFO - 2018-05-02 08:10:08 --> Helper loaded: common_helper
INFO - 2018-05-02 08:10:09 --> Database Driver Class Initialized
INFO - 2018-05-02 08:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:10:09 --> Email Class Initialized
INFO - 2018-05-02 08:10:09 --> Controller Class Initialized
INFO - 2018-05-02 08:10:09 --> Helper loaded: form_helper
INFO - 2018-05-02 08:10:09 --> Form Validation Class Initialized
INFO - 2018-05-02 08:10:09 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:10:09 --> Helper loaded: url_helper
INFO - 2018-05-02 08:10:09 --> Model Class Initialized
INFO - 2018-05-02 08:10:09 --> Model Class Initialized
INFO - 2018-05-02 08:10:09 --> Model Class Initialized
INFO - 2018-05-02 11:40:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:40:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:40:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:40:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/wishes.php
INFO - 2018-05-02 11:40:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:40:09 --> Final output sent to browser
DEBUG - 2018-05-02 11:40:09 --> Total execution time: 0.2300
INFO - 2018-05-02 08:10:54 --> Config Class Initialized
INFO - 2018-05-02 08:10:54 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:10:54 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:10:54 --> Utf8 Class Initialized
INFO - 2018-05-02 08:10:54 --> URI Class Initialized
INFO - 2018-05-02 08:10:54 --> Router Class Initialized
INFO - 2018-05-02 08:10:54 --> Output Class Initialized
INFO - 2018-05-02 08:10:54 --> Security Class Initialized
DEBUG - 2018-05-02 08:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:10:54 --> Input Class Initialized
INFO - 2018-05-02 08:10:54 --> Language Class Initialized
INFO - 2018-05-02 08:10:54 --> Loader Class Initialized
INFO - 2018-05-02 08:10:54 --> Helper loaded: common_helper
INFO - 2018-05-02 08:10:54 --> Database Driver Class Initialized
INFO - 2018-05-02 08:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:10:54 --> Email Class Initialized
INFO - 2018-05-02 08:10:54 --> Controller Class Initialized
INFO - 2018-05-02 08:10:54 --> Helper loaded: form_helper
INFO - 2018-05-02 08:10:54 --> Form Validation Class Initialized
INFO - 2018-05-02 08:10:54 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:10:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:10:54 --> Helper loaded: url_helper
INFO - 2018-05-02 08:10:54 --> Model Class Initialized
INFO - 2018-05-02 08:10:54 --> Model Class Initialized
INFO - 2018-05-02 08:10:54 --> Model Class Initialized
INFO - 2018-05-02 11:40:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:40:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:40:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:40:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/addWishes.php
INFO - 2018-05-02 11:40:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:40:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:40:54 --> Final output sent to browser
DEBUG - 2018-05-02 11:40:54 --> Total execution time: 0.1550
INFO - 2018-05-02 08:11:31 --> Config Class Initialized
INFO - 2018-05-02 08:11:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:11:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:11:31 --> Utf8 Class Initialized
INFO - 2018-05-02 08:11:31 --> URI Class Initialized
INFO - 2018-05-02 08:11:31 --> Router Class Initialized
INFO - 2018-05-02 08:11:31 --> Output Class Initialized
INFO - 2018-05-02 08:11:31 --> Security Class Initialized
DEBUG - 2018-05-02 08:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:11:31 --> Input Class Initialized
INFO - 2018-05-02 08:11:31 --> Language Class Initialized
INFO - 2018-05-02 08:11:31 --> Loader Class Initialized
INFO - 2018-05-02 08:11:31 --> Helper loaded: common_helper
INFO - 2018-05-02 08:11:31 --> Database Driver Class Initialized
INFO - 2018-05-02 08:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:11:31 --> Email Class Initialized
INFO - 2018-05-02 08:11:31 --> Controller Class Initialized
INFO - 2018-05-02 08:11:31 --> Helper loaded: form_helper
INFO - 2018-05-02 08:11:31 --> Form Validation Class Initialized
INFO - 2018-05-02 08:11:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:11:31 --> Helper loaded: url_helper
INFO - 2018-05-02 08:11:31 --> Model Class Initialized
INFO - 2018-05-02 08:11:31 --> Model Class Initialized
INFO - 2018-05-02 08:11:31 --> Model Class Initialized
INFO - 2018-05-02 11:41:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:41:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:41:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:41:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/addWishes.php
INFO - 2018-05-02 11:41:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:41:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:41:31 --> Final output sent to browser
DEBUG - 2018-05-02 11:41:31 --> Total execution time: 0.1500
INFO - 2018-05-02 08:12:23 --> Config Class Initialized
INFO - 2018-05-02 08:12:23 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:12:23 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:12:23 --> Utf8 Class Initialized
INFO - 2018-05-02 08:12:23 --> URI Class Initialized
INFO - 2018-05-02 08:12:23 --> Router Class Initialized
INFO - 2018-05-02 08:12:23 --> Output Class Initialized
INFO - 2018-05-02 08:12:23 --> Security Class Initialized
DEBUG - 2018-05-02 08:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:12:23 --> Input Class Initialized
INFO - 2018-05-02 08:12:23 --> Language Class Initialized
INFO - 2018-05-02 08:12:23 --> Loader Class Initialized
INFO - 2018-05-02 08:12:23 --> Helper loaded: common_helper
INFO - 2018-05-02 08:12:23 --> Database Driver Class Initialized
INFO - 2018-05-02 08:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:12:23 --> Email Class Initialized
INFO - 2018-05-02 08:12:23 --> Controller Class Initialized
INFO - 2018-05-02 08:12:23 --> Helper loaded: form_helper
INFO - 2018-05-02 08:12:23 --> Form Validation Class Initialized
INFO - 2018-05-02 08:12:23 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:12:23 --> Helper loaded: url_helper
INFO - 2018-05-02 08:12:23 --> Model Class Initialized
INFO - 2018-05-02 08:12:23 --> Model Class Initialized
INFO - 2018-05-02 08:12:23 --> Model Class Initialized
INFO - 2018-05-02 11:42:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 11:42:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 11:42:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 11:42:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/wishes.php
INFO - 2018-05-02 11:42:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 11:42:23 --> Final output sent to browser
DEBUG - 2018-05-02 11:42:23 --> Total execution time: 0.1430
INFO - 2018-05-02 08:52:08 --> Config Class Initialized
INFO - 2018-05-02 08:52:08 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:52:08 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:52:08 --> Utf8 Class Initialized
INFO - 2018-05-02 08:52:08 --> URI Class Initialized
INFO - 2018-05-02 08:52:08 --> Router Class Initialized
INFO - 2018-05-02 08:52:08 --> Output Class Initialized
INFO - 2018-05-02 08:52:08 --> Security Class Initialized
DEBUG - 2018-05-02 08:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:52:08 --> Input Class Initialized
INFO - 2018-05-02 08:52:08 --> Language Class Initialized
INFO - 2018-05-02 08:52:08 --> Loader Class Initialized
INFO - 2018-05-02 08:52:08 --> Helper loaded: common_helper
INFO - 2018-05-02 08:52:08 --> Database Driver Class Initialized
INFO - 2018-05-02 08:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:52:08 --> Email Class Initialized
INFO - 2018-05-02 08:52:08 --> Controller Class Initialized
INFO - 2018-05-02 08:52:08 --> Helper loaded: form_helper
INFO - 2018-05-02 08:52:08 --> Form Validation Class Initialized
INFO - 2018-05-02 08:52:08 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:52:08 --> Helper loaded: url_helper
INFO - 2018-05-02 08:52:08 --> Model Class Initialized
INFO - 2018-05-02 08:52:08 --> Model Class Initialized
INFO - 2018-05-02 08:52:08 --> Model Class Initialized
INFO - 2018-05-02 12:22:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:22:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:22:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 12:22:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:22:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:22:08 --> Final output sent to browser
DEBUG - 2018-05-02 12:22:08 --> Total execution time: 0.1590
INFO - 2018-05-02 08:52:12 --> Config Class Initialized
INFO - 2018-05-02 08:52:12 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:52:12 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:52:12 --> Utf8 Class Initialized
INFO - 2018-05-02 08:52:12 --> URI Class Initialized
INFO - 2018-05-02 08:52:12 --> Router Class Initialized
INFO - 2018-05-02 08:52:12 --> Output Class Initialized
INFO - 2018-05-02 08:52:12 --> Security Class Initialized
DEBUG - 2018-05-02 08:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:52:12 --> Input Class Initialized
INFO - 2018-05-02 08:52:12 --> Language Class Initialized
INFO - 2018-05-02 08:52:12 --> Loader Class Initialized
INFO - 2018-05-02 08:52:12 --> Helper loaded: common_helper
INFO - 2018-05-02 08:52:12 --> Database Driver Class Initialized
INFO - 2018-05-02 08:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:52:12 --> Email Class Initialized
INFO - 2018-05-02 08:52:12 --> Controller Class Initialized
INFO - 2018-05-02 08:52:12 --> Helper loaded: form_helper
INFO - 2018-05-02 08:52:12 --> Form Validation Class Initialized
INFO - 2018-05-02 08:52:12 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:52:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:52:12 --> Helper loaded: url_helper
INFO - 2018-05-02 08:52:12 --> Model Class Initialized
INFO - 2018-05-02 08:52:12 --> Model Class Initialized
INFO - 2018-05-02 08:52:12 --> Model Class Initialized
INFO - 2018-05-02 12:22:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:22:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:22:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:22:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-02 12:22:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:22:12 --> Final output sent to browser
DEBUG - 2018-05-02 12:22:12 --> Total execution time: 0.1570
INFO - 2018-05-02 08:52:53 --> Config Class Initialized
INFO - 2018-05-02 08:52:53 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:52:53 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:52:53 --> Utf8 Class Initialized
INFO - 2018-05-02 08:52:53 --> URI Class Initialized
INFO - 2018-05-02 08:52:53 --> Router Class Initialized
INFO - 2018-05-02 08:52:53 --> Output Class Initialized
INFO - 2018-05-02 08:52:53 --> Security Class Initialized
DEBUG - 2018-05-02 08:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:52:53 --> Input Class Initialized
INFO - 2018-05-02 08:52:53 --> Language Class Initialized
INFO - 2018-05-02 08:52:53 --> Loader Class Initialized
INFO - 2018-05-02 08:52:53 --> Helper loaded: common_helper
INFO - 2018-05-02 08:52:53 --> Database Driver Class Initialized
INFO - 2018-05-02 08:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:52:53 --> Email Class Initialized
INFO - 2018-05-02 08:52:53 --> Controller Class Initialized
INFO - 2018-05-02 08:52:53 --> Helper loaded: form_helper
INFO - 2018-05-02 08:52:53 --> Form Validation Class Initialized
INFO - 2018-05-02 08:52:53 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:52:53 --> Helper loaded: url_helper
INFO - 2018-05-02 08:52:53 --> Model Class Initialized
INFO - 2018-05-02 08:52:53 --> Model Class Initialized
INFO - 2018-05-02 08:52:53 --> Model Class Initialized
INFO - 2018-05-02 12:22:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:22:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:22:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 12:22:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:22:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:22:53 --> Final output sent to browser
DEBUG - 2018-05-02 12:22:53 --> Total execution time: 0.1400
INFO - 2018-05-02 08:53:30 --> Config Class Initialized
INFO - 2018-05-02 08:53:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:53:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:53:30 --> Utf8 Class Initialized
INFO - 2018-05-02 08:53:30 --> URI Class Initialized
INFO - 2018-05-02 08:53:30 --> Router Class Initialized
INFO - 2018-05-02 08:53:30 --> Output Class Initialized
INFO - 2018-05-02 08:53:30 --> Security Class Initialized
DEBUG - 2018-05-02 08:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:53:30 --> Input Class Initialized
INFO - 2018-05-02 08:53:30 --> Language Class Initialized
INFO - 2018-05-02 08:53:30 --> Loader Class Initialized
INFO - 2018-05-02 08:53:30 --> Helper loaded: common_helper
INFO - 2018-05-02 08:53:30 --> Database Driver Class Initialized
INFO - 2018-05-02 08:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:53:30 --> Email Class Initialized
INFO - 2018-05-02 08:53:30 --> Controller Class Initialized
INFO - 2018-05-02 08:53:30 --> Helper loaded: form_helper
INFO - 2018-05-02 08:53:30 --> Form Validation Class Initialized
INFO - 2018-05-02 08:53:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:53:30 --> Helper loaded: url_helper
INFO - 2018-05-02 08:53:30 --> Model Class Initialized
INFO - 2018-05-02 08:53:30 --> Model Class Initialized
INFO - 2018-05-02 08:53:30 --> Model Class Initialized
ERROR - 2018-05-02 12:23:30 --> Query error: Table 'celebstar.tutorial' doesn't exist - Invalid query: SELECT *
FROM `tutorial`
WHERE `isDeleted` =0
AND `appId` = '3'
ERROR - 2018-05-02 12:23:30 --> Call to a member function result() on boolean
ERROR - 2018-05-02 12:23:30 --> Severity: Error --> Call to a member function result() on boolean C:\xampp\htdocs\Celebrity\admin\application\core\Healthcontroller.php 75
INFO - 2018-05-02 08:54:55 --> Config Class Initialized
INFO - 2018-05-02 08:54:55 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:54:55 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:54:55 --> Utf8 Class Initialized
INFO - 2018-05-02 08:54:55 --> URI Class Initialized
INFO - 2018-05-02 08:54:55 --> Router Class Initialized
INFO - 2018-05-02 08:54:55 --> Output Class Initialized
INFO - 2018-05-02 08:54:55 --> Security Class Initialized
DEBUG - 2018-05-02 08:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:54:55 --> Input Class Initialized
INFO - 2018-05-02 08:54:55 --> Language Class Initialized
INFO - 2018-05-02 08:54:55 --> Loader Class Initialized
INFO - 2018-05-02 08:54:55 --> Helper loaded: common_helper
INFO - 2018-05-02 08:54:55 --> Database Driver Class Initialized
INFO - 2018-05-02 08:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:54:55 --> Email Class Initialized
INFO - 2018-05-02 08:54:55 --> Controller Class Initialized
INFO - 2018-05-02 08:54:55 --> Helper loaded: form_helper
INFO - 2018-05-02 08:54:55 --> Form Validation Class Initialized
INFO - 2018-05-02 08:54:55 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:54:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:54:55 --> Helper loaded: url_helper
INFO - 2018-05-02 08:54:55 --> Model Class Initialized
INFO - 2018-05-02 08:54:55 --> Model Class Initialized
INFO - 2018-05-02 08:54:55 --> Model Class Initialized
INFO - 2018-05-02 08:55:55 --> Config Class Initialized
INFO - 2018-05-02 08:55:55 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:55:55 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:55:55 --> Utf8 Class Initialized
INFO - 2018-05-02 08:55:55 --> URI Class Initialized
INFO - 2018-05-02 08:55:55 --> Router Class Initialized
INFO - 2018-05-02 08:55:55 --> Output Class Initialized
INFO - 2018-05-02 08:55:55 --> Security Class Initialized
DEBUG - 2018-05-02 08:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:55:55 --> Input Class Initialized
INFO - 2018-05-02 08:55:55 --> Language Class Initialized
INFO - 2018-05-02 08:55:55 --> Loader Class Initialized
INFO - 2018-05-02 08:55:55 --> Helper loaded: common_helper
INFO - 2018-05-02 08:55:55 --> Database Driver Class Initialized
INFO - 2018-05-02 08:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:55:55 --> Email Class Initialized
INFO - 2018-05-02 08:55:55 --> Controller Class Initialized
INFO - 2018-05-02 08:55:55 --> Helper loaded: form_helper
INFO - 2018-05-02 08:55:55 --> Form Validation Class Initialized
INFO - 2018-05-02 08:55:55 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:55:55 --> Helper loaded: url_helper
INFO - 2018-05-02 08:55:55 --> Model Class Initialized
INFO - 2018-05-02 08:55:55 --> Model Class Initialized
INFO - 2018-05-02 08:55:55 --> Model Class Initialized
INFO - 2018-05-02 08:56:05 --> Config Class Initialized
INFO - 2018-05-02 08:56:05 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:56:05 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:56:05 --> Utf8 Class Initialized
INFO - 2018-05-02 08:56:05 --> URI Class Initialized
INFO - 2018-05-02 08:56:05 --> Router Class Initialized
INFO - 2018-05-02 08:56:05 --> Output Class Initialized
INFO - 2018-05-02 08:56:05 --> Security Class Initialized
DEBUG - 2018-05-02 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:56:05 --> Input Class Initialized
INFO - 2018-05-02 08:56:05 --> Language Class Initialized
INFO - 2018-05-02 08:56:05 --> Loader Class Initialized
INFO - 2018-05-02 08:56:05 --> Helper loaded: common_helper
INFO - 2018-05-02 08:56:05 --> Database Driver Class Initialized
INFO - 2018-05-02 08:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:56:05 --> Email Class Initialized
INFO - 2018-05-02 08:56:05 --> Controller Class Initialized
INFO - 2018-05-02 08:56:05 --> Helper loaded: form_helper
INFO - 2018-05-02 08:56:05 --> Form Validation Class Initialized
INFO - 2018-05-02 08:56:05 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:56:05 --> Helper loaded: url_helper
INFO - 2018-05-02 08:56:05 --> Model Class Initialized
INFO - 2018-05-02 08:56:05 --> Model Class Initialized
INFO - 2018-05-02 08:56:05 --> Model Class Initialized
ERROR - 2018-05-02 12:26:05 --> Query error: Table 'celebstar.tutorial' doesn't exist - Invalid query: SELECT *
FROM `tutorial`
WHERE `isDeleted` =0
AND `appId` = '3'
ERROR - 2018-05-02 12:26:05 --> Call to a member function result() on boolean
ERROR - 2018-05-02 12:26:05 --> Severity: Error --> Call to a member function result() on boolean C:\xampp\htdocs\Celebrity\admin\application\core\Healthcontroller.php 75
INFO - 2018-05-02 08:56:51 --> Config Class Initialized
INFO - 2018-05-02 08:56:51 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:56:51 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:56:51 --> Utf8 Class Initialized
INFO - 2018-05-02 08:56:51 --> URI Class Initialized
INFO - 2018-05-02 08:56:51 --> Router Class Initialized
INFO - 2018-05-02 08:56:51 --> Output Class Initialized
INFO - 2018-05-02 08:56:51 --> Security Class Initialized
DEBUG - 2018-05-02 08:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:56:51 --> Input Class Initialized
INFO - 2018-05-02 08:56:51 --> Language Class Initialized
INFO - 2018-05-02 08:56:51 --> Loader Class Initialized
INFO - 2018-05-02 08:56:51 --> Helper loaded: common_helper
INFO - 2018-05-02 08:56:51 --> Database Driver Class Initialized
INFO - 2018-05-02 08:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:56:51 --> Email Class Initialized
INFO - 2018-05-02 08:56:51 --> Controller Class Initialized
INFO - 2018-05-02 08:56:51 --> Helper loaded: form_helper
INFO - 2018-05-02 08:56:51 --> Form Validation Class Initialized
INFO - 2018-05-02 08:56:51 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:56:51 --> Helper loaded: url_helper
INFO - 2018-05-02 08:56:51 --> Model Class Initialized
INFO - 2018-05-02 08:56:51 --> Model Class Initialized
INFO - 2018-05-02 08:56:51 --> Model Class Initialized
INFO - 2018-05-02 08:57:06 --> Config Class Initialized
INFO - 2018-05-02 08:57:06 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:57:06 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:57:06 --> Utf8 Class Initialized
INFO - 2018-05-02 08:57:06 --> URI Class Initialized
INFO - 2018-05-02 08:57:06 --> Router Class Initialized
INFO - 2018-05-02 08:57:06 --> Output Class Initialized
INFO - 2018-05-02 08:57:06 --> Security Class Initialized
DEBUG - 2018-05-02 08:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:57:06 --> Input Class Initialized
INFO - 2018-05-02 08:57:06 --> Language Class Initialized
INFO - 2018-05-02 08:57:06 --> Loader Class Initialized
INFO - 2018-05-02 08:57:06 --> Helper loaded: common_helper
INFO - 2018-05-02 08:57:06 --> Database Driver Class Initialized
INFO - 2018-05-02 08:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:57:06 --> Email Class Initialized
INFO - 2018-05-02 08:57:06 --> Controller Class Initialized
INFO - 2018-05-02 08:57:06 --> Helper loaded: form_helper
INFO - 2018-05-02 08:57:06 --> Form Validation Class Initialized
INFO - 2018-05-02 08:57:06 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:57:06 --> Helper loaded: url_helper
INFO - 2018-05-02 08:57:06 --> Model Class Initialized
INFO - 2018-05-02 08:57:06 --> Model Class Initialized
INFO - 2018-05-02 08:57:06 --> Model Class Initialized
INFO - 2018-05-02 12:27:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:27:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:27:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:27:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 12:27:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:27:06 --> Final output sent to browser
DEBUG - 2018-05-02 12:27:06 --> Total execution time: 0.1410
INFO - 2018-05-02 08:57:45 --> Config Class Initialized
INFO - 2018-05-02 08:57:45 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:57:45 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:57:45 --> Utf8 Class Initialized
INFO - 2018-05-02 08:57:45 --> URI Class Initialized
INFO - 2018-05-02 08:57:45 --> Router Class Initialized
INFO - 2018-05-02 08:57:45 --> Output Class Initialized
INFO - 2018-05-02 08:57:45 --> Security Class Initialized
DEBUG - 2018-05-02 08:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:57:45 --> Input Class Initialized
INFO - 2018-05-02 08:57:45 --> Language Class Initialized
INFO - 2018-05-02 08:57:45 --> Loader Class Initialized
INFO - 2018-05-02 08:57:45 --> Helper loaded: common_helper
INFO - 2018-05-02 08:57:45 --> Database Driver Class Initialized
INFO - 2018-05-02 08:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:57:45 --> Email Class Initialized
INFO - 2018-05-02 08:57:45 --> Controller Class Initialized
INFO - 2018-05-02 08:57:45 --> Helper loaded: form_helper
INFO - 2018-05-02 08:57:46 --> Form Validation Class Initialized
INFO - 2018-05-02 08:57:46 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:57:46 --> Helper loaded: url_helper
INFO - 2018-05-02 08:57:46 --> Model Class Initialized
INFO - 2018-05-02 08:57:46 --> Model Class Initialized
INFO - 2018-05-02 08:57:46 --> Model Class Initialized
INFO - 2018-05-02 12:27:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:27:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:27:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-02 12:27:46 --> Undefined variable: tutorial
ERROR - 2018-05-02 12:27:46 --> Severity: Notice --> Undefined variable: tutorial C:\xampp\htdocs\Celebrity\admin\application\views\tutorial\addTutorial.php 62
ERROR - 2018-05-02 12:27:46 --> Undefined variable: tutorial
ERROR - 2018-05-02 12:27:46 --> Severity: Notice --> Undefined variable: tutorial C:\xampp\htdocs\Celebrity\admin\application\views\tutorial\addTutorial.php 68
ERROR - 2018-05-02 12:27:46 --> Undefined variable: tutorial
ERROR - 2018-05-02 12:27:46 --> Severity: Notice --> Undefined variable: tutorial C:\xampp\htdocs\Celebrity\admin\application\views\tutorial\addTutorial.php 74
INFO - 2018-05-02 12:27:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:27:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:27:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:27:46 --> Final output sent to browser
DEBUG - 2018-05-02 12:27:46 --> Total execution time: 0.1600
INFO - 2018-05-02 08:58:50 --> Config Class Initialized
INFO - 2018-05-02 08:58:50 --> Hooks Class Initialized
DEBUG - 2018-05-02 08:58:50 --> UTF-8 Support Enabled
INFO - 2018-05-02 08:58:50 --> Utf8 Class Initialized
INFO - 2018-05-02 08:58:50 --> URI Class Initialized
INFO - 2018-05-02 08:58:50 --> Router Class Initialized
INFO - 2018-05-02 08:58:50 --> Output Class Initialized
INFO - 2018-05-02 08:58:50 --> Security Class Initialized
DEBUG - 2018-05-02 08:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 08:58:50 --> Input Class Initialized
INFO - 2018-05-02 08:58:50 --> Language Class Initialized
INFO - 2018-05-02 08:58:50 --> Loader Class Initialized
INFO - 2018-05-02 08:58:50 --> Helper loaded: common_helper
INFO - 2018-05-02 08:58:50 --> Database Driver Class Initialized
INFO - 2018-05-02 08:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 08:58:50 --> Email Class Initialized
INFO - 2018-05-02 08:58:50 --> Controller Class Initialized
INFO - 2018-05-02 08:58:50 --> Helper loaded: form_helper
INFO - 2018-05-02 08:58:50 --> Form Validation Class Initialized
INFO - 2018-05-02 08:58:50 --> Helper loaded: email_helper
DEBUG - 2018-05-02 08:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 08:58:50 --> Helper loaded: url_helper
INFO - 2018-05-02 08:58:50 --> Model Class Initialized
INFO - 2018-05-02 08:58:50 --> Model Class Initialized
INFO - 2018-05-02 08:58:50 --> Model Class Initialized
INFO - 2018-05-02 12:28:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:28:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:28:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-02 12:28:50 --> Undefined variable: tutorial
ERROR - 2018-05-02 12:28:50 --> Severity: Notice --> Undefined variable: tutorial C:\xampp\htdocs\Celebrity\admin\application\views\tutorial\addTutorial.php 62
ERROR - 2018-05-02 12:28:50 --> Undefined variable: tutorial
ERROR - 2018-05-02 12:28:50 --> Severity: Notice --> Undefined variable: tutorial C:\xampp\htdocs\Celebrity\admin\application\views\tutorial\addTutorial.php 68
ERROR - 2018-05-02 12:28:50 --> Undefined variable: tutorial
ERROR - 2018-05-02 12:28:50 --> Severity: Notice --> Undefined variable: tutorial C:\xampp\htdocs\Celebrity\admin\application\views\tutorial\addTutorial.php 74
INFO - 2018-05-02 12:28:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:28:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:28:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:28:50 --> Final output sent to browser
DEBUG - 2018-05-02 12:28:50 --> Total execution time: 0.1450
INFO - 2018-05-02 09:00:18 --> Config Class Initialized
INFO - 2018-05-02 09:00:18 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:00:18 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:00:18 --> Utf8 Class Initialized
INFO - 2018-05-02 09:00:18 --> URI Class Initialized
INFO - 2018-05-02 09:00:18 --> Router Class Initialized
INFO - 2018-05-02 09:00:18 --> Output Class Initialized
INFO - 2018-05-02 09:00:18 --> Security Class Initialized
DEBUG - 2018-05-02 09:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:00:18 --> Input Class Initialized
INFO - 2018-05-02 09:00:18 --> Language Class Initialized
INFO - 2018-05-02 09:00:18 --> Loader Class Initialized
INFO - 2018-05-02 09:00:18 --> Helper loaded: common_helper
INFO - 2018-05-02 09:00:18 --> Database Driver Class Initialized
INFO - 2018-05-02 09:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:00:18 --> Email Class Initialized
INFO - 2018-05-02 09:00:18 --> Controller Class Initialized
INFO - 2018-05-02 09:00:18 --> Helper loaded: form_helper
INFO - 2018-05-02 09:00:18 --> Form Validation Class Initialized
INFO - 2018-05-02 09:00:18 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:00:18 --> Helper loaded: url_helper
INFO - 2018-05-02 09:00:18 --> Model Class Initialized
INFO - 2018-05-02 09:00:18 --> Model Class Initialized
INFO - 2018-05-02 09:00:18 --> Model Class Initialized
INFO - 2018-05-02 12:30:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:30:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:30:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-02 12:30:18 --> Undefined variable: tutorial
ERROR - 2018-05-02 12:30:18 --> Severity: Notice --> Undefined variable: tutorial C:\xampp\htdocs\Celebrity\admin\application\views\tutorial\addTutorial.php 62
ERROR - 2018-05-02 12:30:18 --> Undefined variable: tutorial
ERROR - 2018-05-02 12:30:18 --> Severity: Notice --> Undefined variable: tutorial C:\xampp\htdocs\Celebrity\admin\application\views\tutorial\addTutorial.php 68
ERROR - 2018-05-02 12:30:18 --> Undefined variable: tutorial
ERROR - 2018-05-02 12:30:18 --> Severity: Notice --> Undefined variable: tutorial C:\xampp\htdocs\Celebrity\admin\application\views\tutorial\addTutorial.php 74
INFO - 2018-05-02 12:30:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:30:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:30:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:30:18 --> Final output sent to browser
DEBUG - 2018-05-02 12:30:18 --> Total execution time: 0.1520
INFO - 2018-05-02 09:01:12 --> Config Class Initialized
INFO - 2018-05-02 09:01:12 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:01:12 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:01:12 --> Utf8 Class Initialized
INFO - 2018-05-02 09:01:12 --> URI Class Initialized
INFO - 2018-05-02 09:01:12 --> Router Class Initialized
INFO - 2018-05-02 09:01:12 --> Output Class Initialized
INFO - 2018-05-02 09:01:12 --> Security Class Initialized
DEBUG - 2018-05-02 09:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:01:12 --> Input Class Initialized
INFO - 2018-05-02 09:01:12 --> Language Class Initialized
INFO - 2018-05-02 09:01:12 --> Loader Class Initialized
INFO - 2018-05-02 09:01:12 --> Helper loaded: common_helper
INFO - 2018-05-02 09:01:12 --> Database Driver Class Initialized
INFO - 2018-05-02 09:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:01:12 --> Email Class Initialized
INFO - 2018-05-02 09:01:12 --> Controller Class Initialized
INFO - 2018-05-02 09:01:12 --> Helper loaded: form_helper
INFO - 2018-05-02 09:01:12 --> Form Validation Class Initialized
INFO - 2018-05-02 09:01:12 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:01:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:01:12 --> Helper loaded: url_helper
INFO - 2018-05-02 09:01:12 --> Model Class Initialized
INFO - 2018-05-02 09:01:12 --> Model Class Initialized
INFO - 2018-05-02 09:01:12 --> Model Class Initialized
INFO - 2018-05-02 12:31:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:31:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:31:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:31:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:31:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:31:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:31:12 --> Final output sent to browser
DEBUG - 2018-05-02 12:31:12 --> Total execution time: 0.1370
INFO - 2018-05-02 09:02:02 --> Config Class Initialized
INFO - 2018-05-02 09:02:02 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:02:02 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:02:02 --> Utf8 Class Initialized
INFO - 2018-05-02 09:02:02 --> URI Class Initialized
INFO - 2018-05-02 09:02:02 --> Router Class Initialized
INFO - 2018-05-02 09:02:02 --> Output Class Initialized
INFO - 2018-05-02 09:02:02 --> Security Class Initialized
DEBUG - 2018-05-02 09:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:02:02 --> Input Class Initialized
INFO - 2018-05-02 09:02:02 --> Language Class Initialized
INFO - 2018-05-02 09:02:02 --> Loader Class Initialized
INFO - 2018-05-02 09:02:02 --> Helper loaded: common_helper
INFO - 2018-05-02 09:02:02 --> Database Driver Class Initialized
INFO - 2018-05-02 09:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:02:02 --> Email Class Initialized
INFO - 2018-05-02 09:02:02 --> Controller Class Initialized
INFO - 2018-05-02 09:02:02 --> Helper loaded: form_helper
INFO - 2018-05-02 09:02:02 --> Form Validation Class Initialized
INFO - 2018-05-02 09:02:02 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:02:02 --> Helper loaded: url_helper
INFO - 2018-05-02 09:02:02 --> Model Class Initialized
INFO - 2018-05-02 09:02:02 --> Model Class Initialized
INFO - 2018-05-02 09:02:02 --> Model Class Initialized
DEBUG - 2018-05-02 12:32:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 12:32:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 09:02:02 --> Config Class Initialized
INFO - 2018-05-02 09:02:02 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:02:02 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:02:02 --> Utf8 Class Initialized
INFO - 2018-05-02 09:02:02 --> URI Class Initialized
INFO - 2018-05-02 09:02:02 --> Router Class Initialized
INFO - 2018-05-02 09:02:02 --> Output Class Initialized
INFO - 2018-05-02 09:02:02 --> Security Class Initialized
DEBUG - 2018-05-02 09:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:02:02 --> Input Class Initialized
INFO - 2018-05-02 09:02:02 --> Language Class Initialized
INFO - 2018-05-02 09:02:02 --> Loader Class Initialized
INFO - 2018-05-02 09:02:02 --> Helper loaded: common_helper
INFO - 2018-05-02 09:02:02 --> Database Driver Class Initialized
INFO - 2018-05-02 09:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:02:02 --> Email Class Initialized
INFO - 2018-05-02 09:02:02 --> Controller Class Initialized
INFO - 2018-05-02 09:02:02 --> Helper loaded: form_helper
INFO - 2018-05-02 09:02:02 --> Form Validation Class Initialized
INFO - 2018-05-02 09:02:02 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:02:02 --> Helper loaded: url_helper
INFO - 2018-05-02 09:02:02 --> Model Class Initialized
INFO - 2018-05-02 09:02:02 --> Model Class Initialized
INFO - 2018-05-02 09:02:02 --> Model Class Initialized
INFO - 2018-05-02 12:32:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:32:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:32:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-02 12:32:02 --> Trying to get property of non-object
ERROR - 2018-05-02 12:32:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\Wishes\addWishes.php 50
INFO - 2018-05-02 12:32:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/addWishes.php
INFO - 2018-05-02 12:32:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:32:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:32:02 --> Final output sent to browser
DEBUG - 2018-05-02 12:32:02 --> Total execution time: 0.1520
INFO - 2018-05-02 09:03:29 --> Config Class Initialized
INFO - 2018-05-02 09:03:29 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:03:29 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:03:29 --> Utf8 Class Initialized
INFO - 2018-05-02 09:03:29 --> URI Class Initialized
INFO - 2018-05-02 09:03:29 --> Router Class Initialized
INFO - 2018-05-02 09:03:29 --> Output Class Initialized
INFO - 2018-05-02 09:03:29 --> Security Class Initialized
DEBUG - 2018-05-02 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:03:29 --> Input Class Initialized
INFO - 2018-05-02 09:03:29 --> Language Class Initialized
INFO - 2018-05-02 09:03:29 --> Loader Class Initialized
INFO - 2018-05-02 09:03:29 --> Helper loaded: common_helper
INFO - 2018-05-02 09:03:29 --> Database Driver Class Initialized
INFO - 2018-05-02 09:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:03:29 --> Email Class Initialized
INFO - 2018-05-02 09:03:29 --> Controller Class Initialized
INFO - 2018-05-02 09:03:29 --> Helper loaded: form_helper
INFO - 2018-05-02 09:03:29 --> Form Validation Class Initialized
INFO - 2018-05-02 09:03:29 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:03:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:03:29 --> Helper loaded: url_helper
INFO - 2018-05-02 09:03:29 --> Model Class Initialized
INFO - 2018-05-02 09:03:29 --> Model Class Initialized
INFO - 2018-05-02 09:03:29 --> Model Class Initialized
INFO - 2018-05-02 12:33:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:33:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:33:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-02 12:33:29 --> Trying to get property of non-object
ERROR - 2018-05-02 12:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\Wishes\addWishes.php 50
INFO - 2018-05-02 12:33:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/addWishes.php
INFO - 2018-05-02 12:33:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:33:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:33:29 --> Final output sent to browser
DEBUG - 2018-05-02 12:33:29 --> Total execution time: 0.1470
INFO - 2018-05-02 09:04:50 --> Config Class Initialized
INFO - 2018-05-02 09:04:50 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:04:50 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:04:50 --> Utf8 Class Initialized
INFO - 2018-05-02 09:04:50 --> URI Class Initialized
INFO - 2018-05-02 09:04:50 --> Router Class Initialized
INFO - 2018-05-02 09:04:50 --> Output Class Initialized
INFO - 2018-05-02 09:04:50 --> Security Class Initialized
DEBUG - 2018-05-02 09:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:04:50 --> Input Class Initialized
INFO - 2018-05-02 09:04:50 --> Language Class Initialized
INFO - 2018-05-02 09:04:50 --> Loader Class Initialized
INFO - 2018-05-02 09:04:50 --> Helper loaded: common_helper
INFO - 2018-05-02 09:04:50 --> Database Driver Class Initialized
INFO - 2018-05-02 09:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:04:50 --> Email Class Initialized
INFO - 2018-05-02 09:04:50 --> Controller Class Initialized
INFO - 2018-05-02 09:04:50 --> Helper loaded: form_helper
INFO - 2018-05-02 09:04:50 --> Form Validation Class Initialized
INFO - 2018-05-02 09:04:50 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:04:50 --> Helper loaded: url_helper
INFO - 2018-05-02 09:04:50 --> Model Class Initialized
INFO - 2018-05-02 09:04:50 --> Model Class Initialized
INFO - 2018-05-02 09:04:50 --> Model Class Initialized
INFO - 2018-05-02 12:34:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:34:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:34:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:34:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:34:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:34:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:34:50 --> Final output sent to browser
DEBUG - 2018-05-02 12:34:50 --> Total execution time: 0.1540
INFO - 2018-05-02 09:05:31 --> Config Class Initialized
INFO - 2018-05-02 09:05:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:05:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:05:31 --> Utf8 Class Initialized
INFO - 2018-05-02 09:05:31 --> URI Class Initialized
INFO - 2018-05-02 09:05:31 --> Router Class Initialized
INFO - 2018-05-02 09:05:31 --> Output Class Initialized
INFO - 2018-05-02 09:05:31 --> Security Class Initialized
DEBUG - 2018-05-02 09:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:05:31 --> Input Class Initialized
INFO - 2018-05-02 09:05:31 --> Language Class Initialized
INFO - 2018-05-02 09:05:31 --> Loader Class Initialized
INFO - 2018-05-02 09:05:31 --> Helper loaded: common_helper
INFO - 2018-05-02 09:05:31 --> Database Driver Class Initialized
INFO - 2018-05-02 09:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:05:31 --> Email Class Initialized
INFO - 2018-05-02 09:05:31 --> Controller Class Initialized
INFO - 2018-05-02 09:05:31 --> Helper loaded: form_helper
INFO - 2018-05-02 09:05:31 --> Form Validation Class Initialized
INFO - 2018-05-02 09:05:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:05:31 --> Helper loaded: url_helper
INFO - 2018-05-02 09:05:31 --> Model Class Initialized
INFO - 2018-05-02 09:05:31 --> Model Class Initialized
INFO - 2018-05-02 09:05:31 --> Model Class Initialized
INFO - 2018-05-02 12:35:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:35:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:35:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:35:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:35:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:35:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:35:31 --> Final output sent to browser
DEBUG - 2018-05-02 12:35:31 --> Total execution time: 0.1400
INFO - 2018-05-02 09:06:11 --> Config Class Initialized
INFO - 2018-05-02 09:06:11 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:06:11 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:06:11 --> Utf8 Class Initialized
INFO - 2018-05-02 09:06:11 --> URI Class Initialized
INFO - 2018-05-02 09:06:11 --> Router Class Initialized
INFO - 2018-05-02 09:06:11 --> Output Class Initialized
INFO - 2018-05-02 09:06:11 --> Security Class Initialized
DEBUG - 2018-05-02 09:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:06:11 --> Input Class Initialized
INFO - 2018-05-02 09:06:11 --> Language Class Initialized
INFO - 2018-05-02 09:06:11 --> Loader Class Initialized
INFO - 2018-05-02 09:06:11 --> Helper loaded: common_helper
INFO - 2018-05-02 09:06:11 --> Database Driver Class Initialized
INFO - 2018-05-02 09:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:06:11 --> Email Class Initialized
INFO - 2018-05-02 09:06:11 --> Controller Class Initialized
INFO - 2018-05-02 09:06:11 --> Helper loaded: form_helper
INFO - 2018-05-02 09:06:11 --> Form Validation Class Initialized
INFO - 2018-05-02 09:06:11 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:06:11 --> Helper loaded: url_helper
INFO - 2018-05-02 09:06:11 --> Model Class Initialized
INFO - 2018-05-02 09:06:11 --> Model Class Initialized
INFO - 2018-05-02 09:06:11 --> Model Class Initialized
INFO - 2018-05-02 12:36:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:36:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:36:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:36:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:36:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:36:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:36:11 --> Final output sent to browser
DEBUG - 2018-05-02 12:36:11 --> Total execution time: 0.1470
INFO - 2018-05-02 09:06:15 --> Config Class Initialized
INFO - 2018-05-02 09:06:15 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:06:15 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:06:15 --> Utf8 Class Initialized
INFO - 2018-05-02 09:06:15 --> URI Class Initialized
INFO - 2018-05-02 09:06:15 --> Router Class Initialized
INFO - 2018-05-02 09:06:15 --> Output Class Initialized
INFO - 2018-05-02 09:06:15 --> Security Class Initialized
DEBUG - 2018-05-02 09:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:06:15 --> Input Class Initialized
INFO - 2018-05-02 09:06:15 --> Language Class Initialized
INFO - 2018-05-02 09:06:15 --> Loader Class Initialized
INFO - 2018-05-02 09:06:15 --> Helper loaded: common_helper
INFO - 2018-05-02 09:06:15 --> Database Driver Class Initialized
INFO - 2018-05-02 09:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:06:15 --> Email Class Initialized
INFO - 2018-05-02 09:06:15 --> Controller Class Initialized
INFO - 2018-05-02 09:06:15 --> Helper loaded: form_helper
INFO - 2018-05-02 09:06:15 --> Form Validation Class Initialized
INFO - 2018-05-02 09:06:15 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:06:15 --> Helper loaded: url_helper
INFO - 2018-05-02 09:06:15 --> Model Class Initialized
INFO - 2018-05-02 09:06:15 --> Model Class Initialized
INFO - 2018-05-02 09:06:15 --> Model Class Initialized
INFO - 2018-05-02 12:36:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:36:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:36:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:36:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 12:36:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:36:15 --> Final output sent to browser
DEBUG - 2018-05-02 12:36:15 --> Total execution time: 0.1390
INFO - 2018-05-02 09:06:49 --> Config Class Initialized
INFO - 2018-05-02 09:06:49 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:06:49 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:06:49 --> Utf8 Class Initialized
INFO - 2018-05-02 09:06:49 --> URI Class Initialized
INFO - 2018-05-02 09:06:49 --> Router Class Initialized
INFO - 2018-05-02 09:06:49 --> Output Class Initialized
INFO - 2018-05-02 09:06:49 --> Security Class Initialized
DEBUG - 2018-05-02 09:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:06:49 --> Input Class Initialized
INFO - 2018-05-02 09:06:49 --> Language Class Initialized
INFO - 2018-05-02 09:06:49 --> Loader Class Initialized
INFO - 2018-05-02 09:06:49 --> Helper loaded: common_helper
INFO - 2018-05-02 09:06:49 --> Database Driver Class Initialized
INFO - 2018-05-02 09:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:06:49 --> Email Class Initialized
INFO - 2018-05-02 09:06:49 --> Controller Class Initialized
INFO - 2018-05-02 09:06:49 --> Helper loaded: form_helper
INFO - 2018-05-02 09:06:49 --> Form Validation Class Initialized
INFO - 2018-05-02 09:06:49 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:06:49 --> Helper loaded: url_helper
INFO - 2018-05-02 09:06:49 --> Model Class Initialized
INFO - 2018-05-02 09:06:49 --> Model Class Initialized
INFO - 2018-05-02 09:06:49 --> Model Class Initialized
INFO - 2018-05-02 12:36:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:36:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:36:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:36:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:36:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:36:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:36:49 --> Final output sent to browser
DEBUG - 2018-05-02 12:36:49 --> Total execution time: 0.1380
INFO - 2018-05-02 09:07:44 --> Config Class Initialized
INFO - 2018-05-02 09:07:44 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:07:44 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:07:44 --> Utf8 Class Initialized
INFO - 2018-05-02 09:07:44 --> URI Class Initialized
INFO - 2018-05-02 09:07:44 --> Router Class Initialized
INFO - 2018-05-02 09:07:44 --> Output Class Initialized
INFO - 2018-05-02 09:07:44 --> Security Class Initialized
DEBUG - 2018-05-02 09:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:07:44 --> Input Class Initialized
INFO - 2018-05-02 09:07:44 --> Language Class Initialized
INFO - 2018-05-02 09:07:44 --> Loader Class Initialized
INFO - 2018-05-02 09:07:44 --> Helper loaded: common_helper
INFO - 2018-05-02 09:07:44 --> Database Driver Class Initialized
INFO - 2018-05-02 09:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:07:45 --> Email Class Initialized
INFO - 2018-05-02 09:07:45 --> Controller Class Initialized
INFO - 2018-05-02 09:07:45 --> Helper loaded: form_helper
INFO - 2018-05-02 09:07:45 --> Form Validation Class Initialized
INFO - 2018-05-02 09:07:45 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:07:45 --> Helper loaded: url_helper
INFO - 2018-05-02 09:07:45 --> Model Class Initialized
INFO - 2018-05-02 09:07:45 --> Model Class Initialized
INFO - 2018-05-02 09:07:45 --> Model Class Initialized
INFO - 2018-05-02 12:37:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:37:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:37:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:37:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:37:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:37:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:37:45 --> Final output sent to browser
DEBUG - 2018-05-02 12:37:45 --> Total execution time: 0.1540
INFO - 2018-05-02 09:08:10 --> Config Class Initialized
INFO - 2018-05-02 09:08:10 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:08:10 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:08:10 --> Utf8 Class Initialized
INFO - 2018-05-02 09:08:10 --> URI Class Initialized
INFO - 2018-05-02 09:08:10 --> Router Class Initialized
INFO - 2018-05-02 09:08:10 --> Output Class Initialized
INFO - 2018-05-02 09:08:10 --> Security Class Initialized
DEBUG - 2018-05-02 09:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:08:10 --> Input Class Initialized
INFO - 2018-05-02 09:08:10 --> Language Class Initialized
INFO - 2018-05-02 09:08:10 --> Loader Class Initialized
INFO - 2018-05-02 09:08:10 --> Helper loaded: common_helper
INFO - 2018-05-02 09:08:10 --> Database Driver Class Initialized
INFO - 2018-05-02 09:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:08:10 --> Email Class Initialized
INFO - 2018-05-02 09:08:10 --> Controller Class Initialized
INFO - 2018-05-02 09:08:10 --> Helper loaded: form_helper
INFO - 2018-05-02 09:08:10 --> Form Validation Class Initialized
INFO - 2018-05-02 09:08:10 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:08:10 --> Helper loaded: url_helper
INFO - 2018-05-02 09:08:10 --> Model Class Initialized
INFO - 2018-05-02 09:08:10 --> Model Class Initialized
INFO - 2018-05-02 09:08:10 --> Model Class Initialized
INFO - 2018-05-02 12:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:38:10 --> Final output sent to browser
DEBUG - 2018-05-02 12:38:10 --> Total execution time: 0.1310
INFO - 2018-05-02 09:08:56 --> Config Class Initialized
INFO - 2018-05-02 09:08:56 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:08:56 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:08:56 --> Utf8 Class Initialized
INFO - 2018-05-02 09:08:56 --> URI Class Initialized
INFO - 2018-05-02 09:08:56 --> Router Class Initialized
INFO - 2018-05-02 09:08:56 --> Output Class Initialized
INFO - 2018-05-02 09:08:56 --> Security Class Initialized
DEBUG - 2018-05-02 09:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:08:56 --> Input Class Initialized
INFO - 2018-05-02 09:08:56 --> Language Class Initialized
INFO - 2018-05-02 09:08:56 --> Loader Class Initialized
INFO - 2018-05-02 09:08:56 --> Helper loaded: common_helper
INFO - 2018-05-02 09:08:56 --> Database Driver Class Initialized
INFO - 2018-05-02 09:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:08:56 --> Email Class Initialized
INFO - 2018-05-02 09:08:56 --> Controller Class Initialized
INFO - 2018-05-02 09:08:56 --> Helper loaded: form_helper
INFO - 2018-05-02 09:08:56 --> Form Validation Class Initialized
INFO - 2018-05-02 09:08:56 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:08:56 --> Helper loaded: url_helper
INFO - 2018-05-02 09:08:56 --> Model Class Initialized
INFO - 2018-05-02 09:08:56 --> Model Class Initialized
INFO - 2018-05-02 09:08:56 --> Model Class Initialized
DEBUG - 2018-05-02 12:38:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 12:38:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-02 12:38:56 --> move_uploaded_file(../uploads/tutorial/313551525244936.jpg): failed to open stream: No such file or directory
ERROR - 2018-05-02 12:38:56 --> Severity: Warning --> move_uploaded_file(../uploads/tutorial/313551525244936.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\Celebrity\admin\application\controllers\Tutorial.php 86
ERROR - 2018-05-02 12:38:56 --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php8600.tmp' to '../uploads/tutorial/313551525244936.jpg'
ERROR - 2018-05-02 12:38:56 --> Severity: Warning --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php8600.tmp' to '../uploads/tutorial/313551525244936.jpg' C:\xampp\htdocs\Celebrity\admin\application\controllers\Tutorial.php 86
INFO - 2018-05-02 09:08:56 --> Config Class Initialized
INFO - 2018-05-02 09:08:56 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:08:56 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:08:56 --> Utf8 Class Initialized
INFO - 2018-05-02 09:08:56 --> URI Class Initialized
INFO - 2018-05-02 09:08:56 --> Router Class Initialized
INFO - 2018-05-02 09:08:56 --> Output Class Initialized
INFO - 2018-05-02 09:08:56 --> Security Class Initialized
DEBUG - 2018-05-02 09:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:08:56 --> Input Class Initialized
INFO - 2018-05-02 09:08:56 --> Language Class Initialized
INFO - 2018-05-02 09:08:56 --> Loader Class Initialized
INFO - 2018-05-02 09:08:56 --> Helper loaded: common_helper
INFO - 2018-05-02 09:08:56 --> Database Driver Class Initialized
INFO - 2018-05-02 09:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:08:56 --> Email Class Initialized
INFO - 2018-05-02 09:08:56 --> Controller Class Initialized
INFO - 2018-05-02 09:08:56 --> Helper loaded: form_helper
INFO - 2018-05-02 09:08:56 --> Form Validation Class Initialized
INFO - 2018-05-02 09:08:56 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:08:56 --> Helper loaded: url_helper
INFO - 2018-05-02 09:08:56 --> Model Class Initialized
INFO - 2018-05-02 09:08:56 --> Model Class Initialized
INFO - 2018-05-02 09:08:56 --> Model Class Initialized
INFO - 2018-05-02 12:38:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:38:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:38:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:38:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:38:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:38:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:38:56 --> Final output sent to browser
DEBUG - 2018-05-02 12:38:56 --> Total execution time: 0.1260
INFO - 2018-05-02 09:11:02 --> Config Class Initialized
INFO - 2018-05-02 09:11:02 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:11:02 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:11:02 --> Utf8 Class Initialized
INFO - 2018-05-02 09:11:02 --> URI Class Initialized
INFO - 2018-05-02 09:11:02 --> Router Class Initialized
INFO - 2018-05-02 09:11:02 --> Output Class Initialized
INFO - 2018-05-02 09:11:02 --> Security Class Initialized
DEBUG - 2018-05-02 09:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:11:02 --> Input Class Initialized
INFO - 2018-05-02 09:11:02 --> Language Class Initialized
INFO - 2018-05-02 09:11:02 --> Loader Class Initialized
INFO - 2018-05-02 09:11:02 --> Helper loaded: common_helper
INFO - 2018-05-02 09:11:02 --> Database Driver Class Initialized
INFO - 2018-05-02 09:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:11:02 --> Email Class Initialized
INFO - 2018-05-02 09:11:02 --> Controller Class Initialized
INFO - 2018-05-02 09:11:02 --> Helper loaded: form_helper
INFO - 2018-05-02 09:11:02 --> Form Validation Class Initialized
INFO - 2018-05-02 09:11:02 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:11:02 --> Helper loaded: url_helper
INFO - 2018-05-02 09:11:02 --> Model Class Initialized
INFO - 2018-05-02 09:11:02 --> Model Class Initialized
INFO - 2018-05-02 09:11:02 --> Model Class Initialized
INFO - 2018-05-02 12:41:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:41:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:41:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:41:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:41:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:41:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:41:02 --> Final output sent to browser
DEBUG - 2018-05-02 12:41:02 --> Total execution time: 0.1330
INFO - 2018-05-02 09:11:50 --> Config Class Initialized
INFO - 2018-05-02 09:11:50 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:11:50 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:11:50 --> Utf8 Class Initialized
INFO - 2018-05-02 09:11:50 --> URI Class Initialized
INFO - 2018-05-02 09:11:50 --> Router Class Initialized
INFO - 2018-05-02 09:11:50 --> Output Class Initialized
INFO - 2018-05-02 09:11:50 --> Security Class Initialized
DEBUG - 2018-05-02 09:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:11:50 --> Input Class Initialized
INFO - 2018-05-02 09:11:50 --> Language Class Initialized
INFO - 2018-05-02 09:11:50 --> Loader Class Initialized
INFO - 2018-05-02 09:11:50 --> Helper loaded: common_helper
INFO - 2018-05-02 09:11:50 --> Database Driver Class Initialized
INFO - 2018-05-02 09:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:11:50 --> Email Class Initialized
INFO - 2018-05-02 09:11:50 --> Controller Class Initialized
INFO - 2018-05-02 09:11:50 --> Helper loaded: form_helper
INFO - 2018-05-02 09:11:50 --> Form Validation Class Initialized
INFO - 2018-05-02 09:11:50 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:11:50 --> Helper loaded: url_helper
INFO - 2018-05-02 09:11:50 --> Model Class Initialized
INFO - 2018-05-02 09:11:50 --> Model Class Initialized
INFO - 2018-05-02 09:11:50 --> Model Class Initialized
DEBUG - 2018-05-02 12:41:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 12:41:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 09:12:44 --> Config Class Initialized
INFO - 2018-05-02 09:12:44 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:12:44 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:12:44 --> Utf8 Class Initialized
INFO - 2018-05-02 09:12:44 --> URI Class Initialized
INFO - 2018-05-02 09:12:44 --> Router Class Initialized
INFO - 2018-05-02 09:12:44 --> Output Class Initialized
INFO - 2018-05-02 09:12:44 --> Security Class Initialized
DEBUG - 2018-05-02 09:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:12:44 --> Input Class Initialized
INFO - 2018-05-02 09:12:44 --> Language Class Initialized
INFO - 2018-05-02 09:12:44 --> Loader Class Initialized
INFO - 2018-05-02 09:12:44 --> Helper loaded: common_helper
INFO - 2018-05-02 09:12:44 --> Database Driver Class Initialized
INFO - 2018-05-02 09:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:12:44 --> Email Class Initialized
INFO - 2018-05-02 09:12:44 --> Controller Class Initialized
INFO - 2018-05-02 09:12:44 --> Helper loaded: form_helper
INFO - 2018-05-02 09:12:44 --> Form Validation Class Initialized
INFO - 2018-05-02 09:12:44 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:12:44 --> Helper loaded: url_helper
INFO - 2018-05-02 09:12:44 --> Model Class Initialized
INFO - 2018-05-02 09:12:44 --> Model Class Initialized
INFO - 2018-05-02 09:12:44 --> Model Class Initialized
DEBUG - 2018-05-02 12:42:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 12:42:44 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-02 12:42:44 --> Query error: Column 'appId' cannot be null - Invalid query: INSERT INTO `tutorials` (`appId`, `title`, `description`, `createdTime`, `image`) VALUES (NULL, 'tutorial1', 'tutorial1', '18-05-02 12:42:44', '207211525245164.jpg')
INFO - 2018-05-02 09:12:44 --> Config Class Initialized
INFO - 2018-05-02 09:12:44 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:12:44 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:12:44 --> Utf8 Class Initialized
INFO - 2018-05-02 09:12:44 --> URI Class Initialized
INFO - 2018-05-02 09:12:44 --> Router Class Initialized
INFO - 2018-05-02 09:12:44 --> Output Class Initialized
INFO - 2018-05-02 09:12:44 --> Security Class Initialized
DEBUG - 2018-05-02 09:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:12:44 --> Input Class Initialized
INFO - 2018-05-02 09:12:44 --> Language Class Initialized
INFO - 2018-05-02 09:12:44 --> Loader Class Initialized
INFO - 2018-05-02 09:12:44 --> Helper loaded: common_helper
INFO - 2018-05-02 09:12:44 --> Database Driver Class Initialized
INFO - 2018-05-02 09:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:12:44 --> Email Class Initialized
INFO - 2018-05-02 09:12:44 --> Controller Class Initialized
INFO - 2018-05-02 09:12:44 --> Helper loaded: form_helper
INFO - 2018-05-02 09:12:44 --> Form Validation Class Initialized
INFO - 2018-05-02 09:12:44 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:12:44 --> Helper loaded: url_helper
INFO - 2018-05-02 09:12:44 --> Model Class Initialized
INFO - 2018-05-02 09:12:44 --> Model Class Initialized
INFO - 2018-05-02 09:12:44 --> Model Class Initialized
INFO - 2018-05-02 12:42:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:42:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:42:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:42:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:42:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:42:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:42:44 --> Final output sent to browser
DEBUG - 2018-05-02 12:42:44 --> Total execution time: 0.1300
INFO - 2018-05-02 09:14:53 --> Config Class Initialized
INFO - 2018-05-02 09:14:53 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:14:53 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:14:53 --> Utf8 Class Initialized
INFO - 2018-05-02 09:14:53 --> URI Class Initialized
INFO - 2018-05-02 09:14:53 --> Router Class Initialized
INFO - 2018-05-02 09:14:53 --> Output Class Initialized
INFO - 2018-05-02 09:14:53 --> Security Class Initialized
DEBUG - 2018-05-02 09:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:14:53 --> Input Class Initialized
INFO - 2018-05-02 09:14:53 --> Language Class Initialized
INFO - 2018-05-02 09:14:53 --> Loader Class Initialized
INFO - 2018-05-02 09:14:53 --> Helper loaded: common_helper
INFO - 2018-05-02 09:14:53 --> Database Driver Class Initialized
INFO - 2018-05-02 09:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:14:53 --> Email Class Initialized
INFO - 2018-05-02 09:14:53 --> Controller Class Initialized
INFO - 2018-05-02 09:14:53 --> Helper loaded: form_helper
INFO - 2018-05-02 09:14:53 --> Form Validation Class Initialized
INFO - 2018-05-02 09:14:53 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:14:53 --> Helper loaded: url_helper
INFO - 2018-05-02 09:14:53 --> Model Class Initialized
INFO - 2018-05-02 09:14:53 --> Model Class Initialized
INFO - 2018-05-02 09:14:53 --> Model Class Initialized
INFO - 2018-05-02 12:44:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:44:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:44:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:44:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:44:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:44:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:44:53 --> Final output sent to browser
DEBUG - 2018-05-02 12:44:53 --> Total execution time: 0.1400
INFO - 2018-05-02 09:15:24 --> Config Class Initialized
INFO - 2018-05-02 09:15:24 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:15:24 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:15:24 --> Utf8 Class Initialized
INFO - 2018-05-02 09:15:24 --> URI Class Initialized
INFO - 2018-05-02 09:15:24 --> Router Class Initialized
INFO - 2018-05-02 09:15:24 --> Output Class Initialized
INFO - 2018-05-02 09:15:24 --> Security Class Initialized
DEBUG - 2018-05-02 09:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:15:24 --> Input Class Initialized
INFO - 2018-05-02 09:15:24 --> Language Class Initialized
INFO - 2018-05-02 09:15:24 --> Loader Class Initialized
INFO - 2018-05-02 09:15:24 --> Helper loaded: common_helper
INFO - 2018-05-02 09:15:24 --> Database Driver Class Initialized
INFO - 2018-05-02 09:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:15:24 --> Email Class Initialized
INFO - 2018-05-02 09:15:24 --> Controller Class Initialized
INFO - 2018-05-02 09:15:24 --> Helper loaded: form_helper
INFO - 2018-05-02 09:15:24 --> Form Validation Class Initialized
INFO - 2018-05-02 09:15:24 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:15:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:15:24 --> Helper loaded: url_helper
INFO - 2018-05-02 09:15:24 --> Model Class Initialized
INFO - 2018-05-02 09:15:24 --> Model Class Initialized
INFO - 2018-05-02 09:15:24 --> Model Class Initialized
DEBUG - 2018-05-02 12:45:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 12:45:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 09:17:22 --> Config Class Initialized
INFO - 2018-05-02 09:17:22 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:17:22 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:17:22 --> Utf8 Class Initialized
INFO - 2018-05-02 09:17:22 --> URI Class Initialized
INFO - 2018-05-02 09:17:22 --> Router Class Initialized
INFO - 2018-05-02 09:17:22 --> Output Class Initialized
INFO - 2018-05-02 09:17:22 --> Security Class Initialized
DEBUG - 2018-05-02 09:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:17:22 --> Input Class Initialized
INFO - 2018-05-02 09:17:22 --> Language Class Initialized
INFO - 2018-05-02 09:17:22 --> Loader Class Initialized
INFO - 2018-05-02 09:17:22 --> Helper loaded: common_helper
INFO - 2018-05-02 09:17:22 --> Database Driver Class Initialized
INFO - 2018-05-02 09:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:17:22 --> Email Class Initialized
INFO - 2018-05-02 09:17:22 --> Controller Class Initialized
INFO - 2018-05-02 09:17:22 --> Helper loaded: form_helper
INFO - 2018-05-02 09:17:22 --> Form Validation Class Initialized
INFO - 2018-05-02 09:17:22 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:17:22 --> Helper loaded: url_helper
INFO - 2018-05-02 09:17:22 --> Model Class Initialized
INFO - 2018-05-02 09:17:22 --> Model Class Initialized
INFO - 2018-05-02 09:17:22 --> Model Class Initialized
INFO - 2018-05-02 12:47:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:47:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:47:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:47:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:47:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:47:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:47:22 --> Final output sent to browser
DEBUG - 2018-05-02 12:47:22 --> Total execution time: 0.1400
INFO - 2018-05-02 09:17:23 --> Config Class Initialized
INFO - 2018-05-02 09:17:23 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:17:23 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:17:23 --> Utf8 Class Initialized
INFO - 2018-05-02 09:17:23 --> URI Class Initialized
INFO - 2018-05-02 09:17:23 --> Router Class Initialized
INFO - 2018-05-02 09:17:23 --> Output Class Initialized
INFO - 2018-05-02 09:17:23 --> Security Class Initialized
DEBUG - 2018-05-02 09:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:17:23 --> Input Class Initialized
INFO - 2018-05-02 09:17:23 --> Language Class Initialized
INFO - 2018-05-02 09:17:23 --> Loader Class Initialized
INFO - 2018-05-02 09:17:23 --> Helper loaded: common_helper
INFO - 2018-05-02 09:17:23 --> Database Driver Class Initialized
INFO - 2018-05-02 09:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:17:23 --> Email Class Initialized
INFO - 2018-05-02 09:17:23 --> Controller Class Initialized
INFO - 2018-05-02 09:17:24 --> Helper loaded: form_helper
INFO - 2018-05-02 09:17:24 --> Form Validation Class Initialized
INFO - 2018-05-02 09:17:24 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:17:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:17:24 --> Helper loaded: url_helper
INFO - 2018-05-02 09:17:24 --> Model Class Initialized
INFO - 2018-05-02 09:17:24 --> Model Class Initialized
INFO - 2018-05-02 09:17:24 --> Model Class Initialized
INFO - 2018-05-02 12:47:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:47:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:47:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:47:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:47:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:47:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:47:24 --> Final output sent to browser
DEBUG - 2018-05-02 12:47:24 --> Total execution time: 0.1500
INFO - 2018-05-02 09:17:29 --> Config Class Initialized
INFO - 2018-05-02 09:17:29 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:17:29 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:17:29 --> Utf8 Class Initialized
INFO - 2018-05-02 09:17:29 --> URI Class Initialized
INFO - 2018-05-02 09:17:29 --> Router Class Initialized
INFO - 2018-05-02 09:17:29 --> Output Class Initialized
INFO - 2018-05-02 09:17:29 --> Security Class Initialized
DEBUG - 2018-05-02 09:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:17:29 --> Input Class Initialized
INFO - 2018-05-02 09:17:29 --> Language Class Initialized
INFO - 2018-05-02 09:17:29 --> Loader Class Initialized
INFO - 2018-05-02 09:17:29 --> Helper loaded: common_helper
INFO - 2018-05-02 09:17:29 --> Database Driver Class Initialized
INFO - 2018-05-02 09:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:17:29 --> Email Class Initialized
INFO - 2018-05-02 09:17:29 --> Controller Class Initialized
INFO - 2018-05-02 09:17:29 --> Helper loaded: form_helper
INFO - 2018-05-02 09:17:29 --> Form Validation Class Initialized
INFO - 2018-05-02 09:17:29 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:17:29 --> Helper loaded: url_helper
INFO - 2018-05-02 09:17:29 --> Model Class Initialized
INFO - 2018-05-02 09:17:29 --> Model Class Initialized
INFO - 2018-05-02 09:17:29 --> Model Class Initialized
INFO - 2018-05-02 12:47:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:47:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:47:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:47:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:47:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:47:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:47:29 --> Final output sent to browser
DEBUG - 2018-05-02 12:47:29 --> Total execution time: 0.1530
INFO - 2018-05-02 09:18:22 --> Config Class Initialized
INFO - 2018-05-02 09:18:22 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:18:22 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:18:22 --> Utf8 Class Initialized
INFO - 2018-05-02 09:18:22 --> URI Class Initialized
INFO - 2018-05-02 09:18:22 --> Router Class Initialized
INFO - 2018-05-02 09:18:22 --> Output Class Initialized
INFO - 2018-05-02 09:18:22 --> Security Class Initialized
DEBUG - 2018-05-02 09:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:18:22 --> Input Class Initialized
INFO - 2018-05-02 09:18:22 --> Language Class Initialized
INFO - 2018-05-02 09:18:22 --> Loader Class Initialized
INFO - 2018-05-02 09:18:22 --> Helper loaded: common_helper
INFO - 2018-05-02 09:18:22 --> Database Driver Class Initialized
INFO - 2018-05-02 09:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:18:22 --> Email Class Initialized
INFO - 2018-05-02 09:18:22 --> Controller Class Initialized
INFO - 2018-05-02 09:18:22 --> Helper loaded: form_helper
INFO - 2018-05-02 09:18:22 --> Form Validation Class Initialized
INFO - 2018-05-02 09:18:22 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:18:22 --> Helper loaded: url_helper
INFO - 2018-05-02 09:18:22 --> Model Class Initialized
INFO - 2018-05-02 09:18:22 --> Model Class Initialized
INFO - 2018-05-02 09:18:22 --> Model Class Initialized
INFO - 2018-05-02 12:48:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:48:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:48:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:48:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:48:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:48:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:48:22 --> Final output sent to browser
DEBUG - 2018-05-02 12:48:22 --> Total execution time: 0.1360
INFO - 2018-05-02 09:19:08 --> Config Class Initialized
INFO - 2018-05-02 09:19:08 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:19:08 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:19:08 --> Utf8 Class Initialized
INFO - 2018-05-02 09:19:08 --> URI Class Initialized
INFO - 2018-05-02 09:19:08 --> Router Class Initialized
INFO - 2018-05-02 09:19:08 --> Output Class Initialized
INFO - 2018-05-02 09:19:08 --> Security Class Initialized
DEBUG - 2018-05-02 09:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:19:08 --> Input Class Initialized
INFO - 2018-05-02 09:19:08 --> Language Class Initialized
INFO - 2018-05-02 09:19:08 --> Loader Class Initialized
INFO - 2018-05-02 09:19:08 --> Helper loaded: common_helper
INFO - 2018-05-02 09:19:08 --> Database Driver Class Initialized
INFO - 2018-05-02 09:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:19:08 --> Email Class Initialized
INFO - 2018-05-02 09:19:08 --> Controller Class Initialized
INFO - 2018-05-02 09:19:08 --> Helper loaded: form_helper
INFO - 2018-05-02 09:19:08 --> Form Validation Class Initialized
INFO - 2018-05-02 09:19:08 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:19:08 --> Helper loaded: url_helper
INFO - 2018-05-02 09:19:08 --> Model Class Initialized
INFO - 2018-05-02 09:19:08 --> Model Class Initialized
INFO - 2018-05-02 09:19:08 --> Model Class Initialized
DEBUG - 2018-05-02 12:49:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 12:49:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 09:19:22 --> Config Class Initialized
INFO - 2018-05-02 09:19:22 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:19:22 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:19:22 --> Utf8 Class Initialized
INFO - 2018-05-02 09:19:22 --> URI Class Initialized
INFO - 2018-05-02 09:19:22 --> Router Class Initialized
INFO - 2018-05-02 09:19:22 --> Output Class Initialized
INFO - 2018-05-02 09:19:22 --> Security Class Initialized
DEBUG - 2018-05-02 09:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:19:22 --> Input Class Initialized
INFO - 2018-05-02 09:19:22 --> Language Class Initialized
INFO - 2018-05-02 09:19:22 --> Loader Class Initialized
INFO - 2018-05-02 09:19:22 --> Helper loaded: common_helper
INFO - 2018-05-02 09:19:22 --> Database Driver Class Initialized
INFO - 2018-05-02 09:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:19:22 --> Email Class Initialized
INFO - 2018-05-02 09:19:22 --> Controller Class Initialized
INFO - 2018-05-02 09:19:22 --> Helper loaded: form_helper
INFO - 2018-05-02 09:19:22 --> Form Validation Class Initialized
INFO - 2018-05-02 09:19:22 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:19:22 --> Helper loaded: url_helper
INFO - 2018-05-02 09:19:22 --> Model Class Initialized
INFO - 2018-05-02 09:19:22 --> Model Class Initialized
INFO - 2018-05-02 09:19:22 --> Model Class Initialized
DEBUG - 2018-05-02 12:49:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 12:49:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 09:19:22 --> Config Class Initialized
INFO - 2018-05-02 09:19:22 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:19:22 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:19:22 --> Utf8 Class Initialized
INFO - 2018-05-02 09:19:22 --> URI Class Initialized
INFO - 2018-05-02 09:19:22 --> Router Class Initialized
INFO - 2018-05-02 09:19:22 --> Output Class Initialized
INFO - 2018-05-02 09:19:22 --> Security Class Initialized
DEBUG - 2018-05-02 09:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:19:22 --> Input Class Initialized
INFO - 2018-05-02 09:19:22 --> Language Class Initialized
INFO - 2018-05-02 09:19:22 --> Loader Class Initialized
INFO - 2018-05-02 09:19:22 --> Helper loaded: common_helper
INFO - 2018-05-02 09:19:22 --> Database Driver Class Initialized
INFO - 2018-05-02 09:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:19:22 --> Email Class Initialized
INFO - 2018-05-02 09:19:22 --> Controller Class Initialized
INFO - 2018-05-02 09:19:22 --> Helper loaded: form_helper
INFO - 2018-05-02 09:19:22 --> Form Validation Class Initialized
INFO - 2018-05-02 09:19:22 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:19:22 --> Helper loaded: url_helper
INFO - 2018-05-02 09:19:22 --> Model Class Initialized
INFO - 2018-05-02 09:19:22 --> Model Class Initialized
INFO - 2018-05-02 09:19:22 --> Model Class Initialized
INFO - 2018-05-02 12:49:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:49:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:49:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:49:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 12:49:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:49:22 --> Final output sent to browser
DEBUG - 2018-05-02 12:49:22 --> Total execution time: 0.1460
INFO - 2018-05-02 09:19:59 --> Config Class Initialized
INFO - 2018-05-02 09:19:59 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:19:59 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:19:59 --> Utf8 Class Initialized
INFO - 2018-05-02 09:19:59 --> URI Class Initialized
INFO - 2018-05-02 09:19:59 --> Router Class Initialized
INFO - 2018-05-02 09:19:59 --> Output Class Initialized
INFO - 2018-05-02 09:19:59 --> Security Class Initialized
DEBUG - 2018-05-02 09:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:19:59 --> Input Class Initialized
INFO - 2018-05-02 09:19:59 --> Language Class Initialized
ERROR - 2018-05-02 09:19:59 --> 404 Page Not Found: Tutorial/editTutorial
INFO - 2018-05-02 09:20:24 --> Config Class Initialized
INFO - 2018-05-02 09:20:24 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:20:24 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:20:24 --> Utf8 Class Initialized
INFO - 2018-05-02 09:20:24 --> URI Class Initialized
INFO - 2018-05-02 09:20:24 --> Router Class Initialized
INFO - 2018-05-02 09:20:24 --> Output Class Initialized
INFO - 2018-05-02 09:20:24 --> Security Class Initialized
DEBUG - 2018-05-02 09:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:20:24 --> Input Class Initialized
INFO - 2018-05-02 09:20:24 --> Language Class Initialized
INFO - 2018-05-02 09:20:24 --> Loader Class Initialized
INFO - 2018-05-02 09:20:24 --> Helper loaded: common_helper
INFO - 2018-05-02 09:20:24 --> Database Driver Class Initialized
INFO - 2018-05-02 09:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:20:24 --> Email Class Initialized
INFO - 2018-05-02 09:20:24 --> Controller Class Initialized
INFO - 2018-05-02 09:20:24 --> Helper loaded: form_helper
INFO - 2018-05-02 09:20:24 --> Form Validation Class Initialized
INFO - 2018-05-02 09:20:24 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:20:24 --> Helper loaded: url_helper
INFO - 2018-05-02 09:20:24 --> Model Class Initialized
INFO - 2018-05-02 09:20:24 --> Model Class Initialized
INFO - 2018-05-02 09:20:24 --> Model Class Initialized
INFO - 2018-05-02 12:50:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:50:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:50:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:50:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 12:50:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:50:24 --> Final output sent to browser
DEBUG - 2018-05-02 12:50:24 --> Total execution time: 0.1640
INFO - 2018-05-02 09:21:01 --> Config Class Initialized
INFO - 2018-05-02 09:21:01 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:21:01 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:21:01 --> Utf8 Class Initialized
INFO - 2018-05-02 09:21:01 --> URI Class Initialized
INFO - 2018-05-02 09:21:01 --> Router Class Initialized
INFO - 2018-05-02 09:21:01 --> Output Class Initialized
INFO - 2018-05-02 09:21:01 --> Security Class Initialized
DEBUG - 2018-05-02 09:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:21:01 --> Input Class Initialized
INFO - 2018-05-02 09:21:01 --> Language Class Initialized
INFO - 2018-05-02 09:21:01 --> Loader Class Initialized
INFO - 2018-05-02 09:21:01 --> Helper loaded: common_helper
INFO - 2018-05-02 09:21:01 --> Database Driver Class Initialized
INFO - 2018-05-02 09:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:21:01 --> Email Class Initialized
INFO - 2018-05-02 09:21:01 --> Controller Class Initialized
INFO - 2018-05-02 09:21:01 --> Helper loaded: form_helper
INFO - 2018-05-02 09:21:01 --> Form Validation Class Initialized
INFO - 2018-05-02 09:21:01 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:21:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:21:01 --> Helper loaded: url_helper
INFO - 2018-05-02 09:21:01 --> Model Class Initialized
INFO - 2018-05-02 09:21:01 --> Model Class Initialized
INFO - 2018-05-02 09:21:01 --> Model Class Initialized
INFO - 2018-05-02 12:51:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:51:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:51:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:51:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:51:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:51:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:51:01 --> Final output sent to browser
DEBUG - 2018-05-02 12:51:01 --> Total execution time: 0.1420
INFO - 2018-05-02 09:21:40 --> Config Class Initialized
INFO - 2018-05-02 09:21:40 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:21:40 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:21:40 --> Utf8 Class Initialized
INFO - 2018-05-02 09:21:40 --> URI Class Initialized
INFO - 2018-05-02 09:21:40 --> Router Class Initialized
INFO - 2018-05-02 09:21:40 --> Output Class Initialized
INFO - 2018-05-02 09:21:40 --> Security Class Initialized
DEBUG - 2018-05-02 09:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:21:40 --> Input Class Initialized
INFO - 2018-05-02 09:21:40 --> Language Class Initialized
INFO - 2018-05-02 09:21:40 --> Loader Class Initialized
INFO - 2018-05-02 09:21:40 --> Helper loaded: common_helper
INFO - 2018-05-02 09:21:40 --> Database Driver Class Initialized
INFO - 2018-05-02 09:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:21:40 --> Email Class Initialized
INFO - 2018-05-02 09:21:40 --> Controller Class Initialized
INFO - 2018-05-02 09:21:40 --> Helper loaded: form_helper
INFO - 2018-05-02 09:21:40 --> Form Validation Class Initialized
INFO - 2018-05-02 09:21:40 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:21:40 --> Helper loaded: url_helper
INFO - 2018-05-02 09:21:40 --> Model Class Initialized
INFO - 2018-05-02 09:21:40 --> Model Class Initialized
INFO - 2018-05-02 09:21:40 --> Model Class Initialized
DEBUG - 2018-05-02 12:51:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 12:51:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 09:21:40 --> Config Class Initialized
INFO - 2018-05-02 09:21:40 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:21:40 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:21:40 --> Utf8 Class Initialized
INFO - 2018-05-02 09:21:40 --> URI Class Initialized
INFO - 2018-05-02 09:21:40 --> Router Class Initialized
INFO - 2018-05-02 09:21:40 --> Output Class Initialized
INFO - 2018-05-02 09:21:40 --> Security Class Initialized
DEBUG - 2018-05-02 09:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:21:40 --> Input Class Initialized
INFO - 2018-05-02 09:21:40 --> Language Class Initialized
INFO - 2018-05-02 09:21:40 --> Loader Class Initialized
INFO - 2018-05-02 09:21:40 --> Helper loaded: common_helper
INFO - 2018-05-02 09:21:40 --> Database Driver Class Initialized
INFO - 2018-05-02 09:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:21:40 --> Email Class Initialized
INFO - 2018-05-02 09:21:40 --> Controller Class Initialized
INFO - 2018-05-02 09:21:40 --> Helper loaded: form_helper
INFO - 2018-05-02 09:21:40 --> Form Validation Class Initialized
INFO - 2018-05-02 09:21:40 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:21:40 --> Helper loaded: url_helper
INFO - 2018-05-02 09:21:40 --> Model Class Initialized
INFO - 2018-05-02 09:21:40 --> Model Class Initialized
INFO - 2018-05-02 09:21:40 --> Model Class Initialized
INFO - 2018-05-02 12:51:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:51:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:51:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:51:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 12:51:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:51:40 --> Final output sent to browser
DEBUG - 2018-05-02 12:51:40 --> Total execution time: 0.1670
INFO - 2018-05-02 09:22:35 --> Config Class Initialized
INFO - 2018-05-02 09:22:35 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:22:35 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:22:35 --> Utf8 Class Initialized
INFO - 2018-05-02 09:22:35 --> URI Class Initialized
INFO - 2018-05-02 09:22:35 --> Router Class Initialized
INFO - 2018-05-02 09:22:35 --> Output Class Initialized
INFO - 2018-05-02 09:22:35 --> Security Class Initialized
DEBUG - 2018-05-02 09:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:22:35 --> Input Class Initialized
INFO - 2018-05-02 09:22:35 --> Language Class Initialized
INFO - 2018-05-02 09:22:35 --> Loader Class Initialized
INFO - 2018-05-02 09:22:35 --> Helper loaded: common_helper
INFO - 2018-05-02 09:22:35 --> Database Driver Class Initialized
INFO - 2018-05-02 09:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:22:35 --> Email Class Initialized
INFO - 2018-05-02 09:22:35 --> Controller Class Initialized
INFO - 2018-05-02 09:22:35 --> Helper loaded: form_helper
INFO - 2018-05-02 09:22:35 --> Form Validation Class Initialized
INFO - 2018-05-02 09:22:35 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:22:35 --> Helper loaded: url_helper
INFO - 2018-05-02 09:22:35 --> Model Class Initialized
INFO - 2018-05-02 09:22:35 --> Model Class Initialized
INFO - 2018-05-02 09:22:35 --> Model Class Initialized
INFO - 2018-05-02 12:52:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:52:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:52:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:52:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:52:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:52:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:52:35 --> Final output sent to browser
DEBUG - 2018-05-02 12:52:35 --> Total execution time: 0.1520
INFO - 2018-05-02 09:24:49 --> Config Class Initialized
INFO - 2018-05-02 09:24:49 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:24:49 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:24:49 --> Utf8 Class Initialized
INFO - 2018-05-02 09:24:49 --> URI Class Initialized
INFO - 2018-05-02 09:24:49 --> Router Class Initialized
INFO - 2018-05-02 09:24:49 --> Output Class Initialized
INFO - 2018-05-02 09:24:49 --> Security Class Initialized
DEBUG - 2018-05-02 09:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:24:49 --> Input Class Initialized
INFO - 2018-05-02 09:24:49 --> Language Class Initialized
INFO - 2018-05-02 09:24:49 --> Loader Class Initialized
INFO - 2018-05-02 09:24:49 --> Helper loaded: common_helper
INFO - 2018-05-02 09:24:49 --> Database Driver Class Initialized
INFO - 2018-05-02 09:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:24:49 --> Email Class Initialized
INFO - 2018-05-02 09:24:49 --> Controller Class Initialized
INFO - 2018-05-02 09:24:49 --> Helper loaded: form_helper
INFO - 2018-05-02 09:24:49 --> Form Validation Class Initialized
INFO - 2018-05-02 09:24:49 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:24:49 --> Helper loaded: url_helper
INFO - 2018-05-02 09:24:49 --> Model Class Initialized
INFO - 2018-05-02 09:24:49 --> Model Class Initialized
INFO - 2018-05-02 09:24:49 --> Model Class Initialized
INFO - 2018-05-02 12:54:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:54:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:54:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:54:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:54:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:54:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:54:49 --> Final output sent to browser
DEBUG - 2018-05-02 12:54:49 --> Total execution time: 0.1590
INFO - 2018-05-02 09:26:18 --> Config Class Initialized
INFO - 2018-05-02 09:26:18 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:26:18 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:26:18 --> Utf8 Class Initialized
INFO - 2018-05-02 09:26:18 --> URI Class Initialized
INFO - 2018-05-02 09:26:18 --> Router Class Initialized
INFO - 2018-05-02 09:26:18 --> Output Class Initialized
INFO - 2018-05-02 09:26:18 --> Security Class Initialized
DEBUG - 2018-05-02 09:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:26:18 --> Input Class Initialized
INFO - 2018-05-02 09:26:18 --> Language Class Initialized
INFO - 2018-05-02 09:26:18 --> Loader Class Initialized
INFO - 2018-05-02 09:26:18 --> Helper loaded: common_helper
INFO - 2018-05-02 09:26:18 --> Database Driver Class Initialized
INFO - 2018-05-02 09:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:26:18 --> Email Class Initialized
INFO - 2018-05-02 09:26:18 --> Controller Class Initialized
INFO - 2018-05-02 09:26:18 --> Helper loaded: form_helper
INFO - 2018-05-02 09:26:18 --> Form Validation Class Initialized
INFO - 2018-05-02 09:26:18 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:26:18 --> Helper loaded: url_helper
INFO - 2018-05-02 09:26:18 --> Model Class Initialized
INFO - 2018-05-02 09:26:18 --> Model Class Initialized
INFO - 2018-05-02 09:26:18 --> Model Class Initialized
INFO - 2018-05-02 12:56:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:56:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:56:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:56:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:56:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:56:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:56:18 --> Final output sent to browser
DEBUG - 2018-05-02 12:56:18 --> Total execution time: 0.1420
INFO - 2018-05-02 09:26:52 --> Config Class Initialized
INFO - 2018-05-02 09:26:52 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:26:52 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:26:52 --> Utf8 Class Initialized
INFO - 2018-05-02 09:26:52 --> URI Class Initialized
INFO - 2018-05-02 09:26:52 --> Router Class Initialized
INFO - 2018-05-02 09:26:52 --> Output Class Initialized
INFO - 2018-05-02 09:26:52 --> Security Class Initialized
DEBUG - 2018-05-02 09:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:26:52 --> Input Class Initialized
INFO - 2018-05-02 09:26:52 --> Language Class Initialized
INFO - 2018-05-02 09:26:52 --> Loader Class Initialized
INFO - 2018-05-02 09:26:52 --> Helper loaded: common_helper
INFO - 2018-05-02 09:26:52 --> Database Driver Class Initialized
INFO - 2018-05-02 09:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:26:53 --> Email Class Initialized
INFO - 2018-05-02 09:26:53 --> Controller Class Initialized
INFO - 2018-05-02 09:26:53 --> Helper loaded: form_helper
INFO - 2018-05-02 09:26:53 --> Form Validation Class Initialized
INFO - 2018-05-02 09:26:53 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:26:53 --> Helper loaded: url_helper
INFO - 2018-05-02 09:26:53 --> Model Class Initialized
INFO - 2018-05-02 09:26:53 --> Model Class Initialized
INFO - 2018-05-02 09:26:53 --> Model Class Initialized
DEBUG - 2018-05-02 12:56:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 12:56:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 12:56:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:56:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:56:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:56:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:56:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:56:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:56:53 --> Final output sent to browser
DEBUG - 2018-05-02 12:56:53 --> Total execution time: 0.1410
INFO - 2018-05-02 09:27:39 --> Config Class Initialized
INFO - 2018-05-02 09:27:39 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:27:39 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:27:39 --> Utf8 Class Initialized
INFO - 2018-05-02 09:27:39 --> URI Class Initialized
INFO - 2018-05-02 09:27:40 --> Router Class Initialized
INFO - 2018-05-02 09:27:40 --> Output Class Initialized
INFO - 2018-05-02 09:27:40 --> Security Class Initialized
DEBUG - 2018-05-02 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:27:40 --> Input Class Initialized
INFO - 2018-05-02 09:27:40 --> Language Class Initialized
INFO - 2018-05-02 09:27:40 --> Loader Class Initialized
INFO - 2018-05-02 09:27:40 --> Helper loaded: common_helper
INFO - 2018-05-02 09:27:40 --> Database Driver Class Initialized
INFO - 2018-05-02 09:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:27:40 --> Email Class Initialized
INFO - 2018-05-02 09:27:40 --> Controller Class Initialized
INFO - 2018-05-02 09:27:40 --> Helper loaded: form_helper
INFO - 2018-05-02 09:27:40 --> Form Validation Class Initialized
INFO - 2018-05-02 09:27:40 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:27:40 --> Helper loaded: url_helper
INFO - 2018-05-02 09:27:40 --> Model Class Initialized
INFO - 2018-05-02 09:27:40 --> Model Class Initialized
INFO - 2018-05-02 09:27:40 --> Model Class Initialized
INFO - 2018-05-02 12:57:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:57:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:57:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:57:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:57:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:57:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:57:40 --> Final output sent to browser
DEBUG - 2018-05-02 12:57:40 --> Total execution time: 0.1640
INFO - 2018-05-02 09:28:29 --> Config Class Initialized
INFO - 2018-05-02 09:28:29 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:28:29 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:28:29 --> Utf8 Class Initialized
INFO - 2018-05-02 09:28:29 --> URI Class Initialized
INFO - 2018-05-02 09:28:29 --> Router Class Initialized
INFO - 2018-05-02 09:28:29 --> Output Class Initialized
INFO - 2018-05-02 09:28:29 --> Security Class Initialized
DEBUG - 2018-05-02 09:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:28:29 --> Input Class Initialized
INFO - 2018-05-02 09:28:29 --> Language Class Initialized
INFO - 2018-05-02 09:28:29 --> Loader Class Initialized
INFO - 2018-05-02 09:28:29 --> Helper loaded: common_helper
INFO - 2018-05-02 09:28:29 --> Database Driver Class Initialized
INFO - 2018-05-02 09:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:28:29 --> Email Class Initialized
INFO - 2018-05-02 09:28:29 --> Controller Class Initialized
INFO - 2018-05-02 09:28:29 --> Helper loaded: form_helper
INFO - 2018-05-02 09:28:29 --> Form Validation Class Initialized
INFO - 2018-05-02 09:28:29 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:28:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:28:29 --> Helper loaded: url_helper
INFO - 2018-05-02 09:28:29 --> Model Class Initialized
INFO - 2018-05-02 09:28:29 --> Model Class Initialized
INFO - 2018-05-02 09:28:29 --> Model Class Initialized
DEBUG - 2018-05-02 12:58:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 12:58:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 09:28:52 --> Config Class Initialized
INFO - 2018-05-02 09:28:52 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:28:52 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:28:52 --> Utf8 Class Initialized
INFO - 2018-05-02 09:28:52 --> URI Class Initialized
INFO - 2018-05-02 09:28:52 --> Router Class Initialized
INFO - 2018-05-02 09:28:52 --> Output Class Initialized
INFO - 2018-05-02 09:28:52 --> Security Class Initialized
DEBUG - 2018-05-02 09:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:28:52 --> Input Class Initialized
INFO - 2018-05-02 09:28:52 --> Language Class Initialized
INFO - 2018-05-02 09:28:52 --> Loader Class Initialized
INFO - 2018-05-02 09:28:52 --> Helper loaded: common_helper
INFO - 2018-05-02 09:28:52 --> Database Driver Class Initialized
INFO - 2018-05-02 09:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:28:52 --> Email Class Initialized
INFO - 2018-05-02 09:28:52 --> Controller Class Initialized
INFO - 2018-05-02 09:28:52 --> Helper loaded: form_helper
INFO - 2018-05-02 09:28:52 --> Form Validation Class Initialized
INFO - 2018-05-02 09:28:52 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:28:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:28:52 --> Helper loaded: url_helper
INFO - 2018-05-02 09:28:52 --> Model Class Initialized
INFO - 2018-05-02 09:28:52 --> Model Class Initialized
INFO - 2018-05-02 09:28:52 --> Model Class Initialized
INFO - 2018-05-02 12:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:58:52 --> Final output sent to browser
DEBUG - 2018-05-02 12:58:52 --> Total execution time: 0.1560
INFO - 2018-05-02 09:29:31 --> Config Class Initialized
INFO - 2018-05-02 09:29:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:29:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:29:31 --> Utf8 Class Initialized
INFO - 2018-05-02 09:29:31 --> URI Class Initialized
INFO - 2018-05-02 09:29:31 --> Router Class Initialized
INFO - 2018-05-02 09:29:31 --> Output Class Initialized
INFO - 2018-05-02 09:29:31 --> Security Class Initialized
DEBUG - 2018-05-02 09:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:29:31 --> Input Class Initialized
INFO - 2018-05-02 09:29:31 --> Language Class Initialized
INFO - 2018-05-02 09:29:31 --> Loader Class Initialized
INFO - 2018-05-02 09:29:31 --> Helper loaded: common_helper
INFO - 2018-05-02 09:29:31 --> Database Driver Class Initialized
INFO - 2018-05-02 09:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:29:31 --> Email Class Initialized
INFO - 2018-05-02 09:29:31 --> Controller Class Initialized
INFO - 2018-05-02 09:29:31 --> Helper loaded: form_helper
INFO - 2018-05-02 09:29:31 --> Form Validation Class Initialized
INFO - 2018-05-02 09:29:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:29:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:29:31 --> Helper loaded: url_helper
INFO - 2018-05-02 09:29:31 --> Model Class Initialized
INFO - 2018-05-02 09:29:31 --> Model Class Initialized
INFO - 2018-05-02 09:29:31 --> Model Class Initialized
DEBUG - 2018-05-02 12:59:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 12:59:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 09:29:47 --> Config Class Initialized
INFO - 2018-05-02 09:29:47 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:29:47 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:29:47 --> Utf8 Class Initialized
INFO - 2018-05-02 09:29:47 --> URI Class Initialized
INFO - 2018-05-02 09:29:47 --> Router Class Initialized
INFO - 2018-05-02 09:29:47 --> Output Class Initialized
INFO - 2018-05-02 09:29:47 --> Security Class Initialized
DEBUG - 2018-05-02 09:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:29:47 --> Input Class Initialized
INFO - 2018-05-02 09:29:47 --> Language Class Initialized
INFO - 2018-05-02 09:29:47 --> Loader Class Initialized
INFO - 2018-05-02 09:29:47 --> Helper loaded: common_helper
INFO - 2018-05-02 09:29:47 --> Database Driver Class Initialized
INFO - 2018-05-02 09:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:29:47 --> Email Class Initialized
INFO - 2018-05-02 09:29:47 --> Controller Class Initialized
INFO - 2018-05-02 09:29:47 --> Helper loaded: form_helper
INFO - 2018-05-02 09:29:47 --> Form Validation Class Initialized
INFO - 2018-05-02 09:29:47 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:29:47 --> Helper loaded: url_helper
INFO - 2018-05-02 09:29:47 --> Model Class Initialized
INFO - 2018-05-02 09:29:47 --> Model Class Initialized
INFO - 2018-05-02 09:29:47 --> Model Class Initialized
INFO - 2018-05-02 12:59:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 12:59:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 12:59:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:59:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 12:59:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 12:59:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 12:59:47 --> Final output sent to browser
DEBUG - 2018-05-02 12:59:47 --> Total execution time: 0.1680
INFO - 2018-05-02 09:30:27 --> Config Class Initialized
INFO - 2018-05-02 09:30:27 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:30:27 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:30:27 --> Utf8 Class Initialized
INFO - 2018-05-02 09:30:27 --> URI Class Initialized
INFO - 2018-05-02 09:30:27 --> Router Class Initialized
INFO - 2018-05-02 09:30:27 --> Output Class Initialized
INFO - 2018-05-02 09:30:27 --> Security Class Initialized
DEBUG - 2018-05-02 09:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:30:27 --> Input Class Initialized
INFO - 2018-05-02 09:30:27 --> Language Class Initialized
INFO - 2018-05-02 09:30:27 --> Loader Class Initialized
INFO - 2018-05-02 09:30:27 --> Helper loaded: common_helper
INFO - 2018-05-02 09:30:27 --> Database Driver Class Initialized
INFO - 2018-05-02 09:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:30:27 --> Email Class Initialized
INFO - 2018-05-02 09:30:27 --> Controller Class Initialized
INFO - 2018-05-02 09:30:27 --> Helper loaded: form_helper
INFO - 2018-05-02 09:30:27 --> Form Validation Class Initialized
INFO - 2018-05-02 09:30:27 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:30:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:30:27 --> Helper loaded: url_helper
INFO - 2018-05-02 09:30:27 --> Model Class Initialized
INFO - 2018-05-02 09:30:27 --> Model Class Initialized
INFO - 2018-05-02 09:30:27 --> Model Class Initialized
DEBUG - 2018-05-02 13:00:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 13:00:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 09:30:27 --> Config Class Initialized
INFO - 2018-05-02 09:30:27 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:30:27 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:30:27 --> Utf8 Class Initialized
INFO - 2018-05-02 09:30:27 --> URI Class Initialized
INFO - 2018-05-02 09:30:27 --> Router Class Initialized
INFO - 2018-05-02 09:30:27 --> Output Class Initialized
INFO - 2018-05-02 09:30:27 --> Security Class Initialized
DEBUG - 2018-05-02 09:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:30:27 --> Input Class Initialized
INFO - 2018-05-02 09:30:27 --> Language Class Initialized
INFO - 2018-05-02 09:30:27 --> Loader Class Initialized
INFO - 2018-05-02 09:30:27 --> Helper loaded: common_helper
INFO - 2018-05-02 09:30:27 --> Database Driver Class Initialized
INFO - 2018-05-02 09:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:30:27 --> Email Class Initialized
INFO - 2018-05-02 09:30:27 --> Controller Class Initialized
INFO - 2018-05-02 09:30:27 --> Helper loaded: form_helper
INFO - 2018-05-02 09:30:27 --> Form Validation Class Initialized
INFO - 2018-05-02 09:30:27 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:30:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:30:27 --> Helper loaded: url_helper
INFO - 2018-05-02 09:30:27 --> Model Class Initialized
INFO - 2018-05-02 09:30:27 --> Model Class Initialized
INFO - 2018-05-02 09:30:27 --> Model Class Initialized
INFO - 2018-05-02 13:00:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:00:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:00:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:00:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 13:00:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:00:27 --> Final output sent to browser
DEBUG - 2018-05-02 13:00:27 --> Total execution time: 0.1380
INFO - 2018-05-02 09:31:14 --> Config Class Initialized
INFO - 2018-05-02 09:31:14 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:31:14 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:31:14 --> Utf8 Class Initialized
INFO - 2018-05-02 09:31:14 --> URI Class Initialized
INFO - 2018-05-02 09:31:14 --> Router Class Initialized
INFO - 2018-05-02 09:31:14 --> Output Class Initialized
INFO - 2018-05-02 09:31:14 --> Security Class Initialized
DEBUG - 2018-05-02 09:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:31:14 --> Input Class Initialized
INFO - 2018-05-02 09:31:14 --> Language Class Initialized
INFO - 2018-05-02 09:31:14 --> Loader Class Initialized
INFO - 2018-05-02 09:31:14 --> Helper loaded: common_helper
INFO - 2018-05-02 09:31:14 --> Database Driver Class Initialized
INFO - 2018-05-02 09:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:31:14 --> Email Class Initialized
INFO - 2018-05-02 09:31:14 --> Controller Class Initialized
INFO - 2018-05-02 09:31:14 --> Helper loaded: form_helper
INFO - 2018-05-02 09:31:14 --> Form Validation Class Initialized
INFO - 2018-05-02 09:31:14 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:31:14 --> Helper loaded: url_helper
INFO - 2018-05-02 09:31:14 --> Model Class Initialized
INFO - 2018-05-02 09:31:14 --> Model Class Initialized
INFO - 2018-05-02 09:31:14 --> Model Class Initialized
INFO - 2018-05-02 13:01:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:01:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:01:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:01:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 13:01:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:01:14 --> Final output sent to browser
DEBUG - 2018-05-02 13:01:14 --> Total execution time: 0.1330
INFO - 2018-05-02 09:33:52 --> Config Class Initialized
INFO - 2018-05-02 09:33:52 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:33:52 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:33:52 --> Utf8 Class Initialized
INFO - 2018-05-02 09:33:52 --> URI Class Initialized
INFO - 2018-05-02 09:33:52 --> Router Class Initialized
INFO - 2018-05-02 09:33:52 --> Output Class Initialized
INFO - 2018-05-02 09:33:52 --> Security Class Initialized
DEBUG - 2018-05-02 09:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:33:52 --> Input Class Initialized
INFO - 2018-05-02 09:33:52 --> Language Class Initialized
INFO - 2018-05-02 09:33:52 --> Loader Class Initialized
INFO - 2018-05-02 09:33:52 --> Helper loaded: common_helper
INFO - 2018-05-02 09:33:52 --> Database Driver Class Initialized
INFO - 2018-05-02 09:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:33:52 --> Email Class Initialized
INFO - 2018-05-02 09:33:52 --> Controller Class Initialized
INFO - 2018-05-02 09:33:52 --> Helper loaded: form_helper
INFO - 2018-05-02 09:33:52 --> Form Validation Class Initialized
INFO - 2018-05-02 09:33:52 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:33:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:33:52 --> Helper loaded: url_helper
INFO - 2018-05-02 09:33:52 --> Model Class Initialized
INFO - 2018-05-02 09:33:52 --> Model Class Initialized
INFO - 2018-05-02 09:33:52 --> Model Class Initialized
INFO - 2018-05-02 13:03:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:03:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:03:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:03:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 13:03:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:03:52 --> Final output sent to browser
DEBUG - 2018-05-02 13:03:52 --> Total execution time: 0.1520
INFO - 2018-05-02 09:34:38 --> Config Class Initialized
INFO - 2018-05-02 09:34:38 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:34:38 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:34:38 --> Utf8 Class Initialized
INFO - 2018-05-02 09:34:38 --> URI Class Initialized
INFO - 2018-05-02 09:34:38 --> Router Class Initialized
INFO - 2018-05-02 09:34:38 --> Output Class Initialized
INFO - 2018-05-02 09:34:38 --> Security Class Initialized
DEBUG - 2018-05-02 09:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:34:38 --> Input Class Initialized
INFO - 2018-05-02 09:34:38 --> Language Class Initialized
INFO - 2018-05-02 09:34:38 --> Loader Class Initialized
INFO - 2018-05-02 09:34:38 --> Helper loaded: common_helper
INFO - 2018-05-02 09:34:38 --> Database Driver Class Initialized
INFO - 2018-05-02 09:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:34:38 --> Email Class Initialized
INFO - 2018-05-02 09:34:38 --> Controller Class Initialized
INFO - 2018-05-02 09:34:38 --> Helper loaded: form_helper
INFO - 2018-05-02 09:34:38 --> Form Validation Class Initialized
INFO - 2018-05-02 09:34:38 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:34:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:34:38 --> Helper loaded: url_helper
INFO - 2018-05-02 09:34:38 --> Model Class Initialized
INFO - 2018-05-02 09:34:38 --> Model Class Initialized
INFO - 2018-05-02 09:34:38 --> Model Class Initialized
INFO - 2018-05-02 13:04:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:04:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:04:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:04:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 13:04:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:04:39 --> Final output sent to browser
DEBUG - 2018-05-02 13:04:39 --> Total execution time: 0.1360
INFO - 2018-05-02 09:36:10 --> Config Class Initialized
INFO - 2018-05-02 09:36:10 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:36:10 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:36:10 --> Utf8 Class Initialized
INFO - 2018-05-02 09:36:10 --> URI Class Initialized
INFO - 2018-05-02 09:36:10 --> Router Class Initialized
INFO - 2018-05-02 09:36:10 --> Output Class Initialized
INFO - 2018-05-02 09:36:10 --> Security Class Initialized
DEBUG - 2018-05-02 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:36:10 --> Input Class Initialized
INFO - 2018-05-02 09:36:10 --> Language Class Initialized
INFO - 2018-05-02 09:36:10 --> Loader Class Initialized
INFO - 2018-05-02 09:36:10 --> Helper loaded: common_helper
INFO - 2018-05-02 09:36:10 --> Database Driver Class Initialized
INFO - 2018-05-02 09:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:36:10 --> Email Class Initialized
INFO - 2018-05-02 09:36:10 --> Controller Class Initialized
INFO - 2018-05-02 09:36:10 --> Helper loaded: form_helper
INFO - 2018-05-02 09:36:10 --> Form Validation Class Initialized
INFO - 2018-05-02 09:36:10 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:36:10 --> Helper loaded: url_helper
INFO - 2018-05-02 09:36:10 --> Model Class Initialized
INFO - 2018-05-02 09:36:10 --> Model Class Initialized
INFO - 2018-05-02 09:36:10 --> Model Class Initialized
INFO - 2018-05-02 13:06:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:06:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:06:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:06:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 13:06:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:06:10 --> Final output sent to browser
DEBUG - 2018-05-02 13:06:10 --> Total execution time: 0.1430
INFO - 2018-05-02 09:37:41 --> Config Class Initialized
INFO - 2018-05-02 09:37:41 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:37:41 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:37:41 --> Utf8 Class Initialized
INFO - 2018-05-02 09:37:41 --> URI Class Initialized
INFO - 2018-05-02 09:37:41 --> Router Class Initialized
INFO - 2018-05-02 09:37:41 --> Output Class Initialized
INFO - 2018-05-02 09:37:41 --> Security Class Initialized
DEBUG - 2018-05-02 09:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:37:41 --> Input Class Initialized
INFO - 2018-05-02 09:37:41 --> Language Class Initialized
INFO - 2018-05-02 09:37:41 --> Loader Class Initialized
INFO - 2018-05-02 09:37:41 --> Helper loaded: common_helper
INFO - 2018-05-02 09:37:41 --> Database Driver Class Initialized
INFO - 2018-05-02 09:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:37:42 --> Email Class Initialized
INFO - 2018-05-02 09:37:42 --> Controller Class Initialized
INFO - 2018-05-02 09:37:42 --> Helper loaded: form_helper
INFO - 2018-05-02 09:37:42 --> Form Validation Class Initialized
INFO - 2018-05-02 09:37:42 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:37:42 --> Helper loaded: url_helper
INFO - 2018-05-02 09:37:42 --> Model Class Initialized
INFO - 2018-05-02 09:37:42 --> Model Class Initialized
INFO - 2018-05-02 09:37:42 --> Model Class Initialized
INFO - 2018-05-02 13:07:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:07:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:07:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:07:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 13:07:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:07:42 --> Final output sent to browser
DEBUG - 2018-05-02 13:07:42 --> Total execution time: 0.1420
INFO - 2018-05-02 09:40:51 --> Config Class Initialized
INFO - 2018-05-02 09:40:51 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:40:51 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:40:51 --> Utf8 Class Initialized
INFO - 2018-05-02 09:40:51 --> URI Class Initialized
INFO - 2018-05-02 09:40:51 --> Router Class Initialized
INFO - 2018-05-02 09:40:51 --> Output Class Initialized
INFO - 2018-05-02 09:40:51 --> Security Class Initialized
DEBUG - 2018-05-02 09:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:40:51 --> Input Class Initialized
INFO - 2018-05-02 09:40:51 --> Language Class Initialized
INFO - 2018-05-02 09:40:51 --> Loader Class Initialized
INFO - 2018-05-02 09:40:51 --> Helper loaded: common_helper
INFO - 2018-05-02 09:40:51 --> Database Driver Class Initialized
INFO - 2018-05-02 09:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:40:51 --> Email Class Initialized
INFO - 2018-05-02 09:40:51 --> Controller Class Initialized
INFO - 2018-05-02 09:40:51 --> Helper loaded: form_helper
INFO - 2018-05-02 09:40:51 --> Form Validation Class Initialized
INFO - 2018-05-02 09:40:51 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:40:51 --> Helper loaded: url_helper
INFO - 2018-05-02 09:40:51 --> Model Class Initialized
INFO - 2018-05-02 09:40:51 --> Model Class Initialized
INFO - 2018-05-02 09:40:51 --> Model Class Initialized
INFO - 2018-05-02 13:10:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:10:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:10:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:10:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 13:10:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:10:51 --> Final output sent to browser
DEBUG - 2018-05-02 13:10:51 --> Total execution time: 0.1520
INFO - 2018-05-02 09:41:46 --> Config Class Initialized
INFO - 2018-05-02 09:41:46 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:41:47 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:41:47 --> Utf8 Class Initialized
INFO - 2018-05-02 09:41:47 --> URI Class Initialized
INFO - 2018-05-02 09:41:47 --> Router Class Initialized
INFO - 2018-05-02 09:41:47 --> Output Class Initialized
INFO - 2018-05-02 09:41:47 --> Security Class Initialized
DEBUG - 2018-05-02 09:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:41:47 --> Input Class Initialized
INFO - 2018-05-02 09:41:47 --> Language Class Initialized
INFO - 2018-05-02 09:41:47 --> Loader Class Initialized
INFO - 2018-05-02 09:41:47 --> Helper loaded: common_helper
INFO - 2018-05-02 09:41:47 --> Database Driver Class Initialized
INFO - 2018-05-02 09:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:41:47 --> Email Class Initialized
INFO - 2018-05-02 09:41:47 --> Controller Class Initialized
INFO - 2018-05-02 09:41:47 --> Helper loaded: form_helper
INFO - 2018-05-02 09:41:47 --> Form Validation Class Initialized
INFO - 2018-05-02 09:41:47 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:41:47 --> Helper loaded: url_helper
INFO - 2018-05-02 09:41:47 --> Model Class Initialized
INFO - 2018-05-02 09:41:47 --> Model Class Initialized
INFO - 2018-05-02 09:41:47 --> Model Class Initialized
INFO - 2018-05-02 13:11:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:11:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:11:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:11:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/tutorial.php
INFO - 2018-05-02 13:11:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:11:47 --> Final output sent to browser
DEBUG - 2018-05-02 13:11:47 --> Total execution time: 0.1360
INFO - 2018-05-02 09:43:14 --> Config Class Initialized
INFO - 2018-05-02 09:43:14 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:43:14 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:43:14 --> Utf8 Class Initialized
INFO - 2018-05-02 09:43:14 --> URI Class Initialized
INFO - 2018-05-02 09:43:14 --> Router Class Initialized
INFO - 2018-05-02 09:43:14 --> Output Class Initialized
INFO - 2018-05-02 09:43:14 --> Security Class Initialized
DEBUG - 2018-05-02 09:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:43:14 --> Input Class Initialized
INFO - 2018-05-02 09:43:14 --> Language Class Initialized
INFO - 2018-05-02 09:43:14 --> Loader Class Initialized
INFO - 2018-05-02 09:43:14 --> Helper loaded: common_helper
INFO - 2018-05-02 09:43:14 --> Database Driver Class Initialized
INFO - 2018-05-02 09:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:43:14 --> Email Class Initialized
INFO - 2018-05-02 09:43:14 --> Controller Class Initialized
INFO - 2018-05-02 09:43:14 --> Helper loaded: form_helper
INFO - 2018-05-02 09:43:14 --> Form Validation Class Initialized
INFO - 2018-05-02 09:43:14 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:43:14 --> Helper loaded: url_helper
INFO - 2018-05-02 09:43:14 --> Model Class Initialized
INFO - 2018-05-02 09:43:14 --> Model Class Initialized
INFO - 2018-05-02 09:43:14 --> Model Class Initialized
INFO - 2018-05-02 13:13:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:13:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:13:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:13:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:13:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:13:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:13:14 --> Final output sent to browser
DEBUG - 2018-05-02 13:13:14 --> Total execution time: 0.1270
INFO - 2018-05-02 09:50:24 --> Config Class Initialized
INFO - 2018-05-02 09:50:24 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:50:24 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:50:24 --> Utf8 Class Initialized
INFO - 2018-05-02 09:50:24 --> URI Class Initialized
INFO - 2018-05-02 09:50:24 --> Router Class Initialized
INFO - 2018-05-02 09:50:24 --> Output Class Initialized
INFO - 2018-05-02 09:50:24 --> Security Class Initialized
DEBUG - 2018-05-02 09:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:50:24 --> Input Class Initialized
INFO - 2018-05-02 09:50:24 --> Language Class Initialized
INFO - 2018-05-02 09:50:24 --> Loader Class Initialized
INFO - 2018-05-02 09:50:24 --> Helper loaded: common_helper
INFO - 2018-05-02 09:50:24 --> Database Driver Class Initialized
INFO - 2018-05-02 09:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:50:24 --> Email Class Initialized
INFO - 2018-05-02 09:50:24 --> Controller Class Initialized
INFO - 2018-05-02 09:50:24 --> Helper loaded: form_helper
INFO - 2018-05-02 09:50:24 --> Form Validation Class Initialized
INFO - 2018-05-02 09:50:24 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:50:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:50:24 --> Helper loaded: url_helper
INFO - 2018-05-02 09:50:24 --> Model Class Initialized
INFO - 2018-05-02 09:50:24 --> Model Class Initialized
INFO - 2018-05-02 09:50:24 --> Model Class Initialized
ERROR - 2018-05-02 13:20:24 --> Query error: Unknown column 'celebrityId' in 'where clause' - Invalid query: SELECT *
FROM `tutorials`
WHERE `celebrityId` = '3'
ERROR - 2018-05-02 13:20:24 --> Call to a member function row() on boolean
ERROR - 2018-05-02 13:20:24 --> Severity: Error --> Call to a member function row() on boolean C:\xampp\htdocs\Celebrity\admin\application\core\Healthcontroller.php 109
INFO - 2018-05-02 09:50:51 --> Config Class Initialized
INFO - 2018-05-02 09:50:51 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:50:51 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:50:51 --> Utf8 Class Initialized
INFO - 2018-05-02 09:50:51 --> URI Class Initialized
INFO - 2018-05-02 09:50:51 --> Router Class Initialized
INFO - 2018-05-02 09:50:51 --> Output Class Initialized
INFO - 2018-05-02 09:50:51 --> Security Class Initialized
DEBUG - 2018-05-02 09:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:50:51 --> Input Class Initialized
INFO - 2018-05-02 09:50:51 --> Language Class Initialized
INFO - 2018-05-02 09:50:51 --> Loader Class Initialized
INFO - 2018-05-02 09:50:51 --> Helper loaded: common_helper
INFO - 2018-05-02 09:50:51 --> Database Driver Class Initialized
INFO - 2018-05-02 09:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:50:51 --> Email Class Initialized
INFO - 2018-05-02 09:50:51 --> Controller Class Initialized
INFO - 2018-05-02 09:50:51 --> Helper loaded: form_helper
INFO - 2018-05-02 09:50:51 --> Form Validation Class Initialized
INFO - 2018-05-02 09:50:51 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:50:51 --> Helper loaded: url_helper
INFO - 2018-05-02 09:50:51 --> Model Class Initialized
INFO - 2018-05-02 09:50:51 --> Model Class Initialized
INFO - 2018-05-02 09:50:51 --> Model Class Initialized
INFO - 2018-05-02 13:20:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
ERROR - 2018-05-02 13:20:51 --> syntax error, unexpected '}'
ERROR - 2018-05-02 13:20:51 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\Celebrity\admin\application\views\tutorial\addTutorial.php 52
INFO - 2018-05-02 09:51:08 --> Config Class Initialized
INFO - 2018-05-02 09:51:08 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:51:08 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:51:08 --> Utf8 Class Initialized
INFO - 2018-05-02 09:51:08 --> URI Class Initialized
INFO - 2018-05-02 09:51:08 --> Router Class Initialized
INFO - 2018-05-02 09:51:08 --> Output Class Initialized
INFO - 2018-05-02 09:51:08 --> Security Class Initialized
DEBUG - 2018-05-02 09:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:51:08 --> Input Class Initialized
INFO - 2018-05-02 09:51:08 --> Language Class Initialized
INFO - 2018-05-02 09:51:08 --> Loader Class Initialized
INFO - 2018-05-02 09:51:08 --> Helper loaded: common_helper
INFO - 2018-05-02 09:51:08 --> Database Driver Class Initialized
INFO - 2018-05-02 09:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:51:08 --> Email Class Initialized
INFO - 2018-05-02 09:51:08 --> Controller Class Initialized
INFO - 2018-05-02 09:51:08 --> Helper loaded: form_helper
INFO - 2018-05-02 09:51:08 --> Form Validation Class Initialized
INFO - 2018-05-02 09:51:08 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:51:08 --> Helper loaded: url_helper
INFO - 2018-05-02 09:51:08 --> Model Class Initialized
INFO - 2018-05-02 09:51:08 --> Model Class Initialized
INFO - 2018-05-02 09:51:08 --> Model Class Initialized
INFO - 2018-05-02 13:21:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:21:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:21:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:21:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:21:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:21:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:21:08 --> Final output sent to browser
DEBUG - 2018-05-02 13:21:08 --> Total execution time: 0.1840
INFO - 2018-05-02 09:52:29 --> Config Class Initialized
INFO - 2018-05-02 09:52:29 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:52:29 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:52:29 --> Utf8 Class Initialized
INFO - 2018-05-02 09:52:29 --> URI Class Initialized
INFO - 2018-05-02 09:52:29 --> Router Class Initialized
INFO - 2018-05-02 09:52:29 --> Output Class Initialized
INFO - 2018-05-02 09:52:29 --> Security Class Initialized
DEBUG - 2018-05-02 09:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:52:29 --> Input Class Initialized
INFO - 2018-05-02 09:52:29 --> Language Class Initialized
INFO - 2018-05-02 09:52:29 --> Loader Class Initialized
INFO - 2018-05-02 09:52:29 --> Helper loaded: common_helper
INFO - 2018-05-02 09:52:29 --> Database Driver Class Initialized
INFO - 2018-05-02 09:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:52:29 --> Email Class Initialized
INFO - 2018-05-02 09:52:29 --> Controller Class Initialized
INFO - 2018-05-02 09:52:29 --> Helper loaded: form_helper
INFO - 2018-05-02 09:52:29 --> Form Validation Class Initialized
INFO - 2018-05-02 09:52:29 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:52:29 --> Helper loaded: url_helper
INFO - 2018-05-02 09:52:29 --> Model Class Initialized
INFO - 2018-05-02 09:52:29 --> Model Class Initialized
INFO - 2018-05-02 09:52:29 --> Model Class Initialized
DEBUG - 2018-05-02 13:22:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 13:22:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-02 13:22:30 --> Query error: Unknown column 'celebrityId' in 'where clause' - Invalid query: UPDATE `tutorials` SET `appId` = '3', `title` = 'tutorial1', `description` = 'tutorial1', `createdTime` = '18-05-02 01:22:29', `image` = '158591525247549.jpg'
WHERE `celebrityId` = '3'
INFO - 2018-05-02 09:52:30 --> Config Class Initialized
INFO - 2018-05-02 09:52:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:52:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:52:30 --> Utf8 Class Initialized
INFO - 2018-05-02 09:52:30 --> URI Class Initialized
INFO - 2018-05-02 09:52:30 --> Router Class Initialized
INFO - 2018-05-02 09:52:30 --> Output Class Initialized
INFO - 2018-05-02 09:52:30 --> Security Class Initialized
DEBUG - 2018-05-02 09:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:52:30 --> Input Class Initialized
INFO - 2018-05-02 09:52:30 --> Language Class Initialized
INFO - 2018-05-02 09:52:30 --> Loader Class Initialized
INFO - 2018-05-02 09:52:30 --> Helper loaded: common_helper
INFO - 2018-05-02 09:52:30 --> Database Driver Class Initialized
INFO - 2018-05-02 09:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:52:30 --> Email Class Initialized
INFO - 2018-05-02 09:52:30 --> Controller Class Initialized
INFO - 2018-05-02 09:52:30 --> Helper loaded: form_helper
INFO - 2018-05-02 09:52:30 --> Form Validation Class Initialized
INFO - 2018-05-02 09:52:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:52:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:52:30 --> Helper loaded: url_helper
INFO - 2018-05-02 09:52:30 --> Model Class Initialized
INFO - 2018-05-02 09:52:30 --> Model Class Initialized
INFO - 2018-05-02 09:52:30 --> Model Class Initialized
INFO - 2018-05-02 13:22:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:22:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:22:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:22:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:22:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:22:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:22:30 --> Final output sent to browser
DEBUG - 2018-05-02 13:22:30 --> Total execution time: 0.1320
INFO - 2018-05-02 09:54:40 --> Config Class Initialized
INFO - 2018-05-02 09:54:40 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:54:40 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:54:40 --> Utf8 Class Initialized
INFO - 2018-05-02 09:54:40 --> URI Class Initialized
INFO - 2018-05-02 09:54:40 --> Router Class Initialized
INFO - 2018-05-02 09:54:40 --> Output Class Initialized
INFO - 2018-05-02 09:54:40 --> Security Class Initialized
DEBUG - 2018-05-02 09:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:54:40 --> Input Class Initialized
INFO - 2018-05-02 09:54:40 --> Language Class Initialized
ERROR - 2018-05-02 09:54:40 --> Cannot use try without catch or finally
ERROR - 2018-05-02 09:54:40 --> Severity: Compile Error --> Cannot use try without catch or finally C:\xampp\htdocs\Celebrity\admin\application\controllers\Tutorial.php 118
INFO - 2018-05-02 09:54:42 --> Config Class Initialized
INFO - 2018-05-02 09:54:42 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:54:42 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:54:42 --> Utf8 Class Initialized
INFO - 2018-05-02 09:54:42 --> URI Class Initialized
INFO - 2018-05-02 09:54:42 --> Router Class Initialized
INFO - 2018-05-02 09:54:42 --> Output Class Initialized
INFO - 2018-05-02 09:54:42 --> Security Class Initialized
DEBUG - 2018-05-02 09:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:54:42 --> Input Class Initialized
INFO - 2018-05-02 09:54:42 --> Language Class Initialized
ERROR - 2018-05-02 09:54:42 --> Cannot use try without catch or finally
ERROR - 2018-05-02 09:54:42 --> Severity: Compile Error --> Cannot use try without catch or finally C:\xampp\htdocs\Celebrity\admin\application\controllers\Tutorial.php 118
INFO - 2018-05-02 09:55:00 --> Config Class Initialized
INFO - 2018-05-02 09:55:00 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:55:00 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:55:00 --> Utf8 Class Initialized
INFO - 2018-05-02 09:55:00 --> URI Class Initialized
INFO - 2018-05-02 09:55:00 --> Router Class Initialized
INFO - 2018-05-02 09:55:00 --> Output Class Initialized
INFO - 2018-05-02 09:55:00 --> Security Class Initialized
DEBUG - 2018-05-02 09:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:55:00 --> Input Class Initialized
INFO - 2018-05-02 09:55:00 --> Language Class Initialized
INFO - 2018-05-02 09:55:00 --> Loader Class Initialized
INFO - 2018-05-02 09:55:00 --> Helper loaded: common_helper
INFO - 2018-05-02 09:55:00 --> Database Driver Class Initialized
INFO - 2018-05-02 09:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:55:00 --> Email Class Initialized
INFO - 2018-05-02 09:55:00 --> Controller Class Initialized
INFO - 2018-05-02 09:55:00 --> Helper loaded: form_helper
INFO - 2018-05-02 09:55:00 --> Form Validation Class Initialized
INFO - 2018-05-02 09:55:00 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:55:00 --> Helper loaded: url_helper
INFO - 2018-05-02 09:55:00 --> Model Class Initialized
INFO - 2018-05-02 09:55:00 --> Model Class Initialized
INFO - 2018-05-02 09:55:00 --> Model Class Initialized
INFO - 2018-05-02 13:25:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:25:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:25:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:25:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:25:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:25:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:25:00 --> Final output sent to browser
DEBUG - 2018-05-02 13:25:00 --> Total execution time: 0.1470
INFO - 2018-05-02 09:56:09 --> Config Class Initialized
INFO - 2018-05-02 09:56:09 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:56:09 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:56:09 --> Utf8 Class Initialized
INFO - 2018-05-02 09:56:09 --> URI Class Initialized
INFO - 2018-05-02 09:56:09 --> Router Class Initialized
INFO - 2018-05-02 09:56:09 --> Output Class Initialized
INFO - 2018-05-02 09:56:09 --> Security Class Initialized
DEBUG - 2018-05-02 09:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:56:09 --> Input Class Initialized
INFO - 2018-05-02 09:56:09 --> Language Class Initialized
INFO - 2018-05-02 09:56:09 --> Loader Class Initialized
INFO - 2018-05-02 09:56:09 --> Helper loaded: common_helper
INFO - 2018-05-02 09:56:09 --> Database Driver Class Initialized
INFO - 2018-05-02 09:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:56:10 --> Email Class Initialized
INFO - 2018-05-02 09:56:10 --> Controller Class Initialized
INFO - 2018-05-02 09:56:10 --> Helper loaded: form_helper
INFO - 2018-05-02 09:56:10 --> Form Validation Class Initialized
INFO - 2018-05-02 09:56:10 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:56:10 --> Helper loaded: url_helper
INFO - 2018-05-02 09:56:10 --> Model Class Initialized
INFO - 2018-05-02 09:56:10 --> Model Class Initialized
INFO - 2018-05-02 09:56:10 --> Model Class Initialized
DEBUG - 2018-05-02 13:26:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 13:26:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 09:56:10 --> Config Class Initialized
INFO - 2018-05-02 09:56:10 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:56:10 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:56:10 --> Utf8 Class Initialized
INFO - 2018-05-02 09:56:10 --> URI Class Initialized
INFO - 2018-05-02 09:56:10 --> Router Class Initialized
INFO - 2018-05-02 09:56:10 --> Output Class Initialized
INFO - 2018-05-02 09:56:10 --> Security Class Initialized
DEBUG - 2018-05-02 09:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:56:10 --> Input Class Initialized
INFO - 2018-05-02 09:56:10 --> Language Class Initialized
ERROR - 2018-05-02 09:56:10 --> 404 Page Not Found: Tutorial/index
INFO - 2018-05-02 09:56:41 --> Config Class Initialized
INFO - 2018-05-02 09:56:41 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:56:41 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:56:41 --> Utf8 Class Initialized
INFO - 2018-05-02 09:56:41 --> URI Class Initialized
INFO - 2018-05-02 09:56:41 --> Router Class Initialized
INFO - 2018-05-02 09:56:41 --> Output Class Initialized
INFO - 2018-05-02 09:56:41 --> Security Class Initialized
DEBUG - 2018-05-02 09:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:56:41 --> Input Class Initialized
INFO - 2018-05-02 09:56:41 --> Language Class Initialized
INFO - 2018-05-02 09:56:41 --> Loader Class Initialized
INFO - 2018-05-02 09:56:41 --> Helper loaded: common_helper
INFO - 2018-05-02 09:56:41 --> Database Driver Class Initialized
INFO - 2018-05-02 09:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:56:41 --> Email Class Initialized
INFO - 2018-05-02 09:56:41 --> Controller Class Initialized
INFO - 2018-05-02 09:56:41 --> Helper loaded: form_helper
INFO - 2018-05-02 09:56:41 --> Form Validation Class Initialized
INFO - 2018-05-02 09:56:41 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:56:41 --> Helper loaded: url_helper
INFO - 2018-05-02 09:56:41 --> Model Class Initialized
INFO - 2018-05-02 09:56:41 --> Model Class Initialized
INFO - 2018-05-02 09:56:41 --> Model Class Initialized
INFO - 2018-05-02 13:26:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:26:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:26:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:26:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:26:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:26:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:26:41 --> Final output sent to browser
DEBUG - 2018-05-02 13:26:41 --> Total execution time: 0.1350
INFO - 2018-05-02 09:58:04 --> Config Class Initialized
INFO - 2018-05-02 09:58:04 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:58:04 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:58:04 --> Utf8 Class Initialized
INFO - 2018-05-02 09:58:04 --> URI Class Initialized
INFO - 2018-05-02 09:58:04 --> Router Class Initialized
INFO - 2018-05-02 09:58:04 --> Output Class Initialized
INFO - 2018-05-02 09:58:04 --> Security Class Initialized
DEBUG - 2018-05-02 09:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:58:04 --> Input Class Initialized
INFO - 2018-05-02 09:58:04 --> Language Class Initialized
INFO - 2018-05-02 09:58:04 --> Loader Class Initialized
INFO - 2018-05-02 09:58:04 --> Helper loaded: common_helper
INFO - 2018-05-02 09:58:04 --> Database Driver Class Initialized
INFO - 2018-05-02 09:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:58:04 --> Email Class Initialized
INFO - 2018-05-02 09:58:04 --> Controller Class Initialized
INFO - 2018-05-02 09:58:04 --> Helper loaded: form_helper
INFO - 2018-05-02 09:58:04 --> Form Validation Class Initialized
INFO - 2018-05-02 09:58:04 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:58:04 --> Helper loaded: url_helper
INFO - 2018-05-02 09:58:04 --> Model Class Initialized
INFO - 2018-05-02 09:58:04 --> Model Class Initialized
INFO - 2018-05-02 09:58:04 --> Model Class Initialized
INFO - 2018-05-02 13:28:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:28:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:28:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:28:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:28:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:28:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:28:04 --> Final output sent to browser
DEBUG - 2018-05-02 13:28:04 --> Total execution time: 0.1630
INFO - 2018-05-02 09:58:13 --> Config Class Initialized
INFO - 2018-05-02 09:58:13 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:58:13 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:58:13 --> Utf8 Class Initialized
INFO - 2018-05-02 09:58:13 --> URI Class Initialized
INFO - 2018-05-02 09:58:13 --> Router Class Initialized
INFO - 2018-05-02 09:58:13 --> Output Class Initialized
INFO - 2018-05-02 09:58:13 --> Security Class Initialized
DEBUG - 2018-05-02 09:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:58:13 --> Input Class Initialized
INFO - 2018-05-02 09:58:13 --> Language Class Initialized
INFO - 2018-05-02 09:58:13 --> Loader Class Initialized
INFO - 2018-05-02 09:58:13 --> Helper loaded: common_helper
INFO - 2018-05-02 09:58:13 --> Database Driver Class Initialized
ERROR - 2018-05-02 09:58:13 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-02 09:58:13 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-02 09:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:58:13 --> Email Class Initialized
INFO - 2018-05-02 09:58:13 --> Controller Class Initialized
INFO - 2018-05-02 09:58:13 --> Helper loaded: form_helper
INFO - 2018-05-02 09:58:13 --> Form Validation Class Initialized
INFO - 2018-05-02 09:58:13 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:58:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:58:13 --> Helper loaded: url_helper
INFO - 2018-05-02 09:58:13 --> Model Class Initialized
INFO - 2018-05-02 09:58:13 --> Model Class Initialized
INFO - 2018-05-02 09:58:13 --> Model Class Initialized
INFO - 2018-05-02 13:28:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:28:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:28:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:28:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:28:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:28:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:28:13 --> Final output sent to browser
DEBUG - 2018-05-02 13:28:13 --> Total execution time: 0.1580
INFO - 2018-05-02 09:58:13 --> Config Class Initialized
INFO - 2018-05-02 09:58:13 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:58:13 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:58:13 --> Utf8 Class Initialized
INFO - 2018-05-02 09:58:13 --> URI Class Initialized
INFO - 2018-05-02 09:58:13 --> Router Class Initialized
INFO - 2018-05-02 09:58:13 --> Output Class Initialized
INFO - 2018-05-02 09:58:13 --> Security Class Initialized
DEBUG - 2018-05-02 09:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:58:13 --> Input Class Initialized
INFO - 2018-05-02 09:58:13 --> Language Class Initialized
INFO - 2018-05-02 09:58:13 --> Loader Class Initialized
INFO - 2018-05-02 09:58:13 --> Helper loaded: common_helper
INFO - 2018-05-02 09:58:13 --> Database Driver Class Initialized
INFO - 2018-05-02 09:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:58:13 --> Config Class Initialized
INFO - 2018-05-02 09:58:13 --> Hooks Class Initialized
INFO - 2018-05-02 09:58:13 --> Email Class Initialized
INFO - 2018-05-02 09:58:13 --> Controller Class Initialized
DEBUG - 2018-05-02 09:58:13 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:58:13 --> Utf8 Class Initialized
INFO - 2018-05-02 09:58:13 --> URI Class Initialized
INFO - 2018-05-02 09:58:13 --> Helper loaded: form_helper
INFO - 2018-05-02 09:58:13 --> Router Class Initialized
INFO - 2018-05-02 09:58:13 --> Form Validation Class Initialized
INFO - 2018-05-02 09:58:13 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:58:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:58:13 --> Output Class Initialized
INFO - 2018-05-02 09:58:13 --> Helper loaded: url_helper
INFO - 2018-05-02 09:58:13 --> Security Class Initialized
INFO - 2018-05-02 09:58:13 --> Model Class Initialized
INFO - 2018-05-02 09:58:13 --> Model Class Initialized
DEBUG - 2018-05-02 09:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:58:14 --> Input Class Initialized
INFO - 2018-05-02 09:58:14 --> Model Class Initialized
INFO - 2018-05-02 09:58:14 --> Language Class Initialized
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 09:58:14 --> Loader Class Initialized
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:28:14 --> Final output sent to browser
INFO - 2018-05-02 09:58:14 --> Helper loaded: common_helper
INFO - 2018-05-02 09:58:14 --> Database Driver Class Initialized
DEBUG - 2018-05-02 13:28:14 --> Total execution time: 0.1380
INFO - 2018-05-02 09:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:58:14 --> Email Class Initialized
INFO - 2018-05-02 09:58:14 --> Controller Class Initialized
INFO - 2018-05-02 09:58:14 --> Helper loaded: form_helper
INFO - 2018-05-02 09:58:14 --> Form Validation Class Initialized
INFO - 2018-05-02 09:58:14 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:58:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:58:14 --> Helper loaded: url_helper
INFO - 2018-05-02 09:58:14 --> Model Class Initialized
INFO - 2018-05-02 09:58:14 --> Model Class Initialized
INFO - 2018-05-02 09:58:14 --> Model Class Initialized
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:28:14 --> Final output sent to browser
DEBUG - 2018-05-02 13:28:14 --> Total execution time: 0.1410
INFO - 2018-05-02 09:58:14 --> Config Class Initialized
INFO - 2018-05-02 09:58:14 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:58:14 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:58:14 --> Utf8 Class Initialized
INFO - 2018-05-02 09:58:14 --> URI Class Initialized
INFO - 2018-05-02 09:58:14 --> Router Class Initialized
INFO - 2018-05-02 09:58:14 --> Output Class Initialized
INFO - 2018-05-02 09:58:14 --> Security Class Initialized
DEBUG - 2018-05-02 09:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:58:14 --> Input Class Initialized
INFO - 2018-05-02 09:58:14 --> Language Class Initialized
INFO - 2018-05-02 09:58:14 --> Loader Class Initialized
INFO - 2018-05-02 09:58:14 --> Helper loaded: common_helper
INFO - 2018-05-02 09:58:14 --> Database Driver Class Initialized
INFO - 2018-05-02 09:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:58:14 --> Email Class Initialized
INFO - 2018-05-02 09:58:14 --> Controller Class Initialized
INFO - 2018-05-02 09:58:14 --> Helper loaded: form_helper
INFO - 2018-05-02 09:58:14 --> Form Validation Class Initialized
INFO - 2018-05-02 09:58:14 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:58:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:58:14 --> Helper loaded: url_helper
INFO - 2018-05-02 09:58:14 --> Model Class Initialized
INFO - 2018-05-02 09:58:14 --> Model Class Initialized
INFO - 2018-05-02 09:58:14 --> Model Class Initialized
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:28:14 --> Final output sent to browser
DEBUG - 2018-05-02 13:28:14 --> Total execution time: 0.1240
INFO - 2018-05-02 09:58:14 --> Config Class Initialized
INFO - 2018-05-02 09:58:14 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:58:14 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:58:14 --> Utf8 Class Initialized
INFO - 2018-05-02 09:58:14 --> URI Class Initialized
INFO - 2018-05-02 09:58:14 --> Router Class Initialized
INFO - 2018-05-02 09:58:14 --> Output Class Initialized
INFO - 2018-05-02 09:58:14 --> Security Class Initialized
DEBUG - 2018-05-02 09:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:58:14 --> Input Class Initialized
INFO - 2018-05-02 09:58:14 --> Language Class Initialized
INFO - 2018-05-02 09:58:14 --> Loader Class Initialized
INFO - 2018-05-02 09:58:14 --> Helper loaded: common_helper
INFO - 2018-05-02 09:58:14 --> Database Driver Class Initialized
INFO - 2018-05-02 09:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:58:14 --> Email Class Initialized
INFO - 2018-05-02 09:58:14 --> Controller Class Initialized
INFO - 2018-05-02 09:58:14 --> Helper loaded: form_helper
INFO - 2018-05-02 09:58:14 --> Form Validation Class Initialized
INFO - 2018-05-02 09:58:14 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:58:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:58:14 --> Helper loaded: url_helper
INFO - 2018-05-02 09:58:14 --> Model Class Initialized
INFO - 2018-05-02 09:58:14 --> Model Class Initialized
INFO - 2018-05-02 09:58:14 --> Model Class Initialized
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:28:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:28:14 --> Final output sent to browser
DEBUG - 2018-05-02 13:28:14 --> Total execution time: 0.1300
INFO - 2018-05-02 09:59:10 --> Config Class Initialized
INFO - 2018-05-02 09:59:10 --> Hooks Class Initialized
DEBUG - 2018-05-02 09:59:10 --> UTF-8 Support Enabled
INFO - 2018-05-02 09:59:10 --> Utf8 Class Initialized
INFO - 2018-05-02 09:59:10 --> URI Class Initialized
INFO - 2018-05-02 09:59:10 --> Router Class Initialized
INFO - 2018-05-02 09:59:10 --> Output Class Initialized
INFO - 2018-05-02 09:59:10 --> Security Class Initialized
DEBUG - 2018-05-02 09:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 09:59:10 --> Input Class Initialized
INFO - 2018-05-02 09:59:10 --> Language Class Initialized
INFO - 2018-05-02 09:59:10 --> Loader Class Initialized
INFO - 2018-05-02 09:59:10 --> Helper loaded: common_helper
INFO - 2018-05-02 09:59:10 --> Database Driver Class Initialized
INFO - 2018-05-02 09:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 09:59:10 --> Email Class Initialized
INFO - 2018-05-02 09:59:10 --> Controller Class Initialized
INFO - 2018-05-02 09:59:10 --> Helper loaded: form_helper
INFO - 2018-05-02 09:59:10 --> Form Validation Class Initialized
INFO - 2018-05-02 09:59:10 --> Helper loaded: email_helper
DEBUG - 2018-05-02 09:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 09:59:10 --> Helper loaded: url_helper
INFO - 2018-05-02 09:59:10 --> Model Class Initialized
INFO - 2018-05-02 09:59:10 --> Model Class Initialized
INFO - 2018-05-02 09:59:10 --> Model Class Initialized
INFO - 2018-05-02 10:00:59 --> Config Class Initialized
INFO - 2018-05-02 10:00:59 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:00:59 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:00:59 --> Utf8 Class Initialized
INFO - 2018-05-02 10:00:59 --> URI Class Initialized
INFO - 2018-05-02 10:00:59 --> Router Class Initialized
INFO - 2018-05-02 10:00:59 --> Output Class Initialized
INFO - 2018-05-02 10:00:59 --> Security Class Initialized
DEBUG - 2018-05-02 10:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:00:59 --> Input Class Initialized
INFO - 2018-05-02 10:00:59 --> Language Class Initialized
INFO - 2018-05-02 10:00:59 --> Loader Class Initialized
INFO - 2018-05-02 10:00:59 --> Helper loaded: common_helper
INFO - 2018-05-02 10:00:59 --> Database Driver Class Initialized
INFO - 2018-05-02 10:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:00:59 --> Email Class Initialized
INFO - 2018-05-02 10:00:59 --> Controller Class Initialized
INFO - 2018-05-02 10:00:59 --> Helper loaded: form_helper
INFO - 2018-05-02 10:00:59 --> Form Validation Class Initialized
INFO - 2018-05-02 10:00:59 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:00:59 --> Helper loaded: url_helper
INFO - 2018-05-02 10:00:59 --> Model Class Initialized
INFO - 2018-05-02 10:00:59 --> Model Class Initialized
INFO - 2018-05-02 10:00:59 --> Model Class Initialized
INFO - 2018-05-02 10:01:02 --> Config Class Initialized
INFO - 2018-05-02 10:01:02 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:01:02 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:01:02 --> Utf8 Class Initialized
INFO - 2018-05-02 10:01:02 --> URI Class Initialized
INFO - 2018-05-02 10:01:02 --> Router Class Initialized
INFO - 2018-05-02 10:01:02 --> Output Class Initialized
INFO - 2018-05-02 10:01:02 --> Security Class Initialized
DEBUG - 2018-05-02 10:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:01:02 --> Input Class Initialized
INFO - 2018-05-02 10:01:02 --> Language Class Initialized
INFO - 2018-05-02 10:01:02 --> Loader Class Initialized
INFO - 2018-05-02 10:01:02 --> Helper loaded: common_helper
INFO - 2018-05-02 10:01:02 --> Database Driver Class Initialized
INFO - 2018-05-02 10:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:01:02 --> Email Class Initialized
INFO - 2018-05-02 10:01:02 --> Controller Class Initialized
INFO - 2018-05-02 10:01:02 --> Helper loaded: form_helper
INFO - 2018-05-02 10:01:02 --> Form Validation Class Initialized
INFO - 2018-05-02 10:01:02 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:01:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:01:02 --> Helper loaded: url_helper
INFO - 2018-05-02 10:01:02 --> Model Class Initialized
INFO - 2018-05-02 10:01:02 --> Model Class Initialized
INFO - 2018-05-02 10:01:02 --> Model Class Initialized
INFO - 2018-05-02 10:01:18 --> Config Class Initialized
INFO - 2018-05-02 10:01:18 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:01:18 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:01:18 --> Utf8 Class Initialized
INFO - 2018-05-02 10:01:19 --> URI Class Initialized
INFO - 2018-05-02 10:01:19 --> Router Class Initialized
INFO - 2018-05-02 10:01:19 --> Output Class Initialized
INFO - 2018-05-02 10:01:19 --> Security Class Initialized
DEBUG - 2018-05-02 10:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:01:19 --> Input Class Initialized
INFO - 2018-05-02 10:01:19 --> Language Class Initialized
INFO - 2018-05-02 10:01:19 --> Loader Class Initialized
INFO - 2018-05-02 10:01:19 --> Helper loaded: common_helper
INFO - 2018-05-02 10:01:19 --> Database Driver Class Initialized
INFO - 2018-05-02 10:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:01:19 --> Email Class Initialized
INFO - 2018-05-02 10:01:19 --> Controller Class Initialized
INFO - 2018-05-02 10:01:19 --> Helper loaded: form_helper
INFO - 2018-05-02 10:01:19 --> Form Validation Class Initialized
INFO - 2018-05-02 10:01:19 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:01:19 --> Helper loaded: url_helper
INFO - 2018-05-02 10:01:19 --> Model Class Initialized
INFO - 2018-05-02 10:01:19 --> Model Class Initialized
INFO - 2018-05-02 10:01:19 --> Model Class Initialized
INFO - 2018-05-02 13:31:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:31:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:31:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:31:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:31:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:31:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:31:19 --> Final output sent to browser
DEBUG - 2018-05-02 13:31:19 --> Total execution time: 0.1560
INFO - 2018-05-02 10:02:12 --> Config Class Initialized
INFO - 2018-05-02 10:02:12 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:02:12 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:02:12 --> Utf8 Class Initialized
INFO - 2018-05-02 10:02:12 --> URI Class Initialized
INFO - 2018-05-02 10:02:12 --> Router Class Initialized
INFO - 2018-05-02 10:02:12 --> Output Class Initialized
INFO - 2018-05-02 10:02:12 --> Security Class Initialized
DEBUG - 2018-05-02 10:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:02:12 --> Input Class Initialized
INFO - 2018-05-02 10:02:12 --> Language Class Initialized
INFO - 2018-05-02 10:02:12 --> Loader Class Initialized
INFO - 2018-05-02 10:02:12 --> Helper loaded: common_helper
INFO - 2018-05-02 10:02:12 --> Database Driver Class Initialized
INFO - 2018-05-02 10:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:02:12 --> Email Class Initialized
INFO - 2018-05-02 10:02:12 --> Controller Class Initialized
INFO - 2018-05-02 10:02:12 --> Helper loaded: form_helper
INFO - 2018-05-02 10:02:12 --> Form Validation Class Initialized
INFO - 2018-05-02 10:02:12 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:02:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:02:12 --> Helper loaded: url_helper
INFO - 2018-05-02 10:02:12 --> Model Class Initialized
INFO - 2018-05-02 10:02:12 --> Model Class Initialized
INFO - 2018-05-02 10:02:12 --> Model Class Initialized
DEBUG - 2018-05-02 13:32:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 13:32:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 10:02:12 --> Config Class Initialized
INFO - 2018-05-02 10:02:12 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:02:12 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:02:12 --> Utf8 Class Initialized
INFO - 2018-05-02 10:02:12 --> URI Class Initialized
INFO - 2018-05-02 10:02:12 --> Router Class Initialized
INFO - 2018-05-02 10:02:12 --> Output Class Initialized
INFO - 2018-05-02 10:02:12 --> Security Class Initialized
DEBUG - 2018-05-02 10:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:02:12 --> Input Class Initialized
INFO - 2018-05-02 10:02:12 --> Language Class Initialized
INFO - 2018-05-02 10:02:12 --> Loader Class Initialized
INFO - 2018-05-02 10:02:12 --> Helper loaded: common_helper
INFO - 2018-05-02 10:02:12 --> Database Driver Class Initialized
INFO - 2018-05-02 10:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:02:12 --> Email Class Initialized
INFO - 2018-05-02 10:02:12 --> Controller Class Initialized
INFO - 2018-05-02 10:02:13 --> Helper loaded: form_helper
INFO - 2018-05-02 10:02:13 --> Form Validation Class Initialized
INFO - 2018-05-02 10:02:13 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:02:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:02:13 --> Helper loaded: url_helper
INFO - 2018-05-02 10:02:13 --> Model Class Initialized
INFO - 2018-05-02 10:02:13 --> Model Class Initialized
INFO - 2018-05-02 10:02:13 --> Model Class Initialized
INFO - 2018-05-02 13:32:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:32:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:32:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:32:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:32:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:32:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:32:13 --> Final output sent to browser
DEBUG - 2018-05-02 13:32:13 --> Total execution time: 0.1440
INFO - 2018-05-02 10:05:35 --> Config Class Initialized
INFO - 2018-05-02 10:05:35 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:05:35 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:05:35 --> Utf8 Class Initialized
INFO - 2018-05-02 10:05:35 --> URI Class Initialized
INFO - 2018-05-02 10:05:35 --> Router Class Initialized
INFO - 2018-05-02 10:05:35 --> Output Class Initialized
INFO - 2018-05-02 10:05:35 --> Security Class Initialized
DEBUG - 2018-05-02 10:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:05:35 --> Input Class Initialized
INFO - 2018-05-02 10:05:35 --> Language Class Initialized
INFO - 2018-05-02 10:05:35 --> Loader Class Initialized
INFO - 2018-05-02 10:05:35 --> Helper loaded: common_helper
INFO - 2018-05-02 10:05:35 --> Database Driver Class Initialized
INFO - 2018-05-02 10:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:05:35 --> Email Class Initialized
INFO - 2018-05-02 10:05:35 --> Controller Class Initialized
INFO - 2018-05-02 10:05:35 --> Helper loaded: form_helper
INFO - 2018-05-02 10:05:35 --> Form Validation Class Initialized
INFO - 2018-05-02 10:05:35 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:05:36 --> Helper loaded: url_helper
INFO - 2018-05-02 10:05:36 --> Model Class Initialized
INFO - 2018-05-02 10:05:36 --> Model Class Initialized
INFO - 2018-05-02 10:05:36 --> Model Class Initialized
INFO - 2018-05-02 13:35:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:35:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:35:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:35:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:35:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:35:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:35:36 --> Final output sent to browser
DEBUG - 2018-05-02 13:35:36 --> Total execution time: 0.1540
INFO - 2018-05-02 10:06:55 --> Config Class Initialized
INFO - 2018-05-02 10:06:55 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:06:55 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:06:55 --> Utf8 Class Initialized
INFO - 2018-05-02 10:06:55 --> URI Class Initialized
INFO - 2018-05-02 10:06:55 --> Router Class Initialized
INFO - 2018-05-02 10:06:55 --> Output Class Initialized
INFO - 2018-05-02 10:06:55 --> Security Class Initialized
DEBUG - 2018-05-02 10:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:06:55 --> Input Class Initialized
INFO - 2018-05-02 10:06:55 --> Language Class Initialized
INFO - 2018-05-02 10:06:55 --> Loader Class Initialized
INFO - 2018-05-02 10:06:55 --> Helper loaded: common_helper
INFO - 2018-05-02 10:06:55 --> Database Driver Class Initialized
INFO - 2018-05-02 10:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:06:56 --> Email Class Initialized
INFO - 2018-05-02 10:06:56 --> Controller Class Initialized
INFO - 2018-05-02 10:06:56 --> Helper loaded: form_helper
INFO - 2018-05-02 10:06:56 --> Form Validation Class Initialized
INFO - 2018-05-02 10:06:56 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:06:56 --> Helper loaded: url_helper
INFO - 2018-05-02 10:06:56 --> Model Class Initialized
INFO - 2018-05-02 10:06:56 --> Model Class Initialized
INFO - 2018-05-02 10:06:56 --> Model Class Initialized
INFO - 2018-05-02 13:36:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:36:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:36:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:36:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:36:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:36:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:36:56 --> Final output sent to browser
DEBUG - 2018-05-02 13:36:56 --> Total execution time: 0.1490
INFO - 2018-05-02 10:07:46 --> Config Class Initialized
INFO - 2018-05-02 10:07:46 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:07:46 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:07:46 --> Utf8 Class Initialized
INFO - 2018-05-02 10:07:46 --> URI Class Initialized
INFO - 2018-05-02 10:07:46 --> Router Class Initialized
INFO - 2018-05-02 10:07:46 --> Output Class Initialized
INFO - 2018-05-02 10:07:46 --> Security Class Initialized
DEBUG - 2018-05-02 10:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:07:46 --> Input Class Initialized
INFO - 2018-05-02 10:07:46 --> Language Class Initialized
INFO - 2018-05-02 10:07:46 --> Loader Class Initialized
INFO - 2018-05-02 10:07:46 --> Helper loaded: common_helper
INFO - 2018-05-02 10:07:46 --> Database Driver Class Initialized
INFO - 2018-05-02 10:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:07:46 --> Email Class Initialized
INFO - 2018-05-02 10:07:46 --> Controller Class Initialized
INFO - 2018-05-02 10:07:46 --> Helper loaded: form_helper
INFO - 2018-05-02 10:07:46 --> Form Validation Class Initialized
INFO - 2018-05-02 10:07:46 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:07:46 --> Helper loaded: url_helper
INFO - 2018-05-02 10:07:46 --> Model Class Initialized
INFO - 2018-05-02 10:07:46 --> Model Class Initialized
INFO - 2018-05-02 10:07:46 --> Model Class Initialized
INFO - 2018-05-02 13:37:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:37:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:37:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:37:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:37:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:37:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:37:46 --> Final output sent to browser
DEBUG - 2018-05-02 13:37:46 --> Total execution time: 0.1370
INFO - 2018-05-02 10:08:24 --> Config Class Initialized
INFO - 2018-05-02 10:08:24 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:24 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:24 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:24 --> URI Class Initialized
INFO - 2018-05-02 10:08:24 --> Router Class Initialized
INFO - 2018-05-02 10:08:24 --> Output Class Initialized
INFO - 2018-05-02 10:08:24 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:24 --> Input Class Initialized
INFO - 2018-05-02 10:08:24 --> Language Class Initialized
INFO - 2018-05-02 10:08:24 --> Loader Class Initialized
INFO - 2018-05-02 10:08:24 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:24 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:24 --> Email Class Initialized
INFO - 2018-05-02 10:08:24 --> Controller Class Initialized
INFO - 2018-05-02 10:08:24 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:24 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:24 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:24 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:24 --> Model Class Initialized
INFO - 2018-05-02 10:08:24 --> Model Class Initialized
INFO - 2018-05-02 10:08:24 --> Model Class Initialized
INFO - 2018-05-02 13:38:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:38:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:24 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:24 --> Total execution time: 0.1520
INFO - 2018-05-02 10:08:25 --> Config Class Initialized
INFO - 2018-05-02 10:08:25 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:25 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:25 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:25 --> URI Class Initialized
INFO - 2018-05-02 10:08:25 --> Router Class Initialized
INFO - 2018-05-02 10:08:25 --> Output Class Initialized
INFO - 2018-05-02 10:08:25 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:25 --> Input Class Initialized
INFO - 2018-05-02 10:08:25 --> Language Class Initialized
INFO - 2018-05-02 10:08:25 --> Loader Class Initialized
INFO - 2018-05-02 10:08:25 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:25 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:25 --> Email Class Initialized
INFO - 2018-05-02 10:08:25 --> Controller Class Initialized
INFO - 2018-05-02 10:08:25 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:25 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:25 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:25 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:25 --> Model Class Initialized
INFO - 2018-05-02 10:08:25 --> Model Class Initialized
INFO - 2018-05-02 10:08:25 --> Model Class Initialized
INFO - 2018-05-02 13:38:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:38:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:25 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:25 --> Total execution time: 0.1420
INFO - 2018-05-02 10:08:25 --> Config Class Initialized
INFO - 2018-05-02 10:08:25 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:26 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:26 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:26 --> URI Class Initialized
INFO - 2018-05-02 10:08:26 --> Router Class Initialized
INFO - 2018-05-02 10:08:26 --> Output Class Initialized
INFO - 2018-05-02 10:08:26 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:26 --> Input Class Initialized
INFO - 2018-05-02 10:08:26 --> Language Class Initialized
INFO - 2018-05-02 10:08:26 --> Loader Class Initialized
INFO - 2018-05-02 10:08:26 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:26 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:26 --> Email Class Initialized
INFO - 2018-05-02 10:08:26 --> Controller Class Initialized
INFO - 2018-05-02 10:08:26 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:26 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:26 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:26 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:26 --> Model Class Initialized
INFO - 2018-05-02 10:08:26 --> Model Class Initialized
INFO - 2018-05-02 10:08:26 --> Model Class Initialized
INFO - 2018-05-02 13:38:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:38:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:26 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:26 --> Total execution time: 0.1300
INFO - 2018-05-02 10:08:27 --> Config Class Initialized
INFO - 2018-05-02 10:08:27 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:27 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:27 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:27 --> URI Class Initialized
INFO - 2018-05-02 10:08:27 --> Router Class Initialized
INFO - 2018-05-02 10:08:27 --> Output Class Initialized
INFO - 2018-05-02 10:08:27 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:27 --> Input Class Initialized
INFO - 2018-05-02 10:08:27 --> Language Class Initialized
INFO - 2018-05-02 10:08:27 --> Loader Class Initialized
INFO - 2018-05-02 10:08:27 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:27 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:27 --> Email Class Initialized
INFO - 2018-05-02 10:08:27 --> Controller Class Initialized
INFO - 2018-05-02 10:08:27 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:27 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:27 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:27 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:27 --> Model Class Initialized
INFO - 2018-05-02 10:08:27 --> Model Class Initialized
INFO - 2018-05-02 10:08:27 --> Model Class Initialized
INFO - 2018-05-02 13:38:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:38:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:27 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:27 --> Total execution time: 0.1420
INFO - 2018-05-02 10:08:27 --> Config Class Initialized
INFO - 2018-05-02 10:08:27 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:27 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:27 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:27 --> URI Class Initialized
INFO - 2018-05-02 10:08:27 --> Router Class Initialized
INFO - 2018-05-02 10:08:27 --> Output Class Initialized
INFO - 2018-05-02 10:08:27 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:27 --> Input Class Initialized
INFO - 2018-05-02 10:08:27 --> Language Class Initialized
INFO - 2018-05-02 10:08:27 --> Loader Class Initialized
INFO - 2018-05-02 10:08:27 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:27 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:27 --> Email Class Initialized
INFO - 2018-05-02 10:08:27 --> Controller Class Initialized
INFO - 2018-05-02 10:08:27 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:27 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:27 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:27 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:27 --> Model Class Initialized
INFO - 2018-05-02 10:08:27 --> Model Class Initialized
INFO - 2018-05-02 10:08:27 --> Model Class Initialized
INFO - 2018-05-02 13:38:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:38:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:27 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:27 --> Total execution time: 0.1530
INFO - 2018-05-02 10:08:28 --> Config Class Initialized
INFO - 2018-05-02 10:08:28 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:28 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:28 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:28 --> URI Class Initialized
INFO - 2018-05-02 10:08:28 --> Router Class Initialized
INFO - 2018-05-02 10:08:28 --> Output Class Initialized
INFO - 2018-05-02 10:08:28 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:28 --> Input Class Initialized
INFO - 2018-05-02 10:08:28 --> Language Class Initialized
INFO - 2018-05-02 10:08:28 --> Loader Class Initialized
INFO - 2018-05-02 10:08:28 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:28 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:28 --> Email Class Initialized
INFO - 2018-05-02 10:08:28 --> Controller Class Initialized
INFO - 2018-05-02 10:08:28 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:28 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:28 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:28 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:28 --> Model Class Initialized
INFO - 2018-05-02 10:08:28 --> Model Class Initialized
INFO - 2018-05-02 10:08:28 --> Model Class Initialized
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:28 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:28 --> Total execution time: 0.1560
INFO - 2018-05-02 10:08:28 --> Config Class Initialized
INFO - 2018-05-02 10:08:28 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:28 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:28 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:28 --> URI Class Initialized
INFO - 2018-05-02 10:08:28 --> Router Class Initialized
INFO - 2018-05-02 10:08:28 --> Output Class Initialized
INFO - 2018-05-02 10:08:28 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:28 --> Input Class Initialized
INFO - 2018-05-02 10:08:28 --> Language Class Initialized
INFO - 2018-05-02 10:08:28 --> Loader Class Initialized
INFO - 2018-05-02 10:08:28 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:28 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:28 --> Email Class Initialized
INFO - 2018-05-02 10:08:28 --> Controller Class Initialized
INFO - 2018-05-02 10:08:28 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:28 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:28 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:28 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:28 --> Model Class Initialized
INFO - 2018-05-02 10:08:28 --> Model Class Initialized
INFO - 2018-05-02 10:08:28 --> Model Class Initialized
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:28 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:28 --> Total execution time: 0.1590
INFO - 2018-05-02 10:08:28 --> Config Class Initialized
INFO - 2018-05-02 10:08:28 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:28 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:28 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:28 --> URI Class Initialized
INFO - 2018-05-02 10:08:28 --> Router Class Initialized
INFO - 2018-05-02 10:08:28 --> Output Class Initialized
INFO - 2018-05-02 10:08:28 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:28 --> Input Class Initialized
INFO - 2018-05-02 10:08:28 --> Language Class Initialized
INFO - 2018-05-02 10:08:28 --> Loader Class Initialized
INFO - 2018-05-02 10:08:28 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:28 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:28 --> Email Class Initialized
INFO - 2018-05-02 10:08:28 --> Controller Class Initialized
INFO - 2018-05-02 10:08:28 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:28 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:28 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:28 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:28 --> Model Class Initialized
INFO - 2018-05-02 10:08:28 --> Model Class Initialized
INFO - 2018-05-02 10:08:28 --> Model Class Initialized
INFO - 2018-05-02 10:08:28 --> Config Class Initialized
INFO - 2018-05-02 10:08:28 --> Hooks Class Initialized
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
DEBUG - 2018-05-02 10:08:28 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:28 --> Utf8 Class Initialized
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 10:08:28 --> URI Class Initialized
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-02 13:38:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:08:28 --> Router Class Initialized
INFO - 2018-05-02 13:38:28 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:28 --> Total execution time: 0.1860
INFO - 2018-05-02 10:08:28 --> Output Class Initialized
INFO - 2018-05-02 10:08:28 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:28 --> Input Class Initialized
INFO - 2018-05-02 10:08:28 --> Language Class Initialized
INFO - 2018-05-02 10:08:28 --> Loader Class Initialized
INFO - 2018-05-02 10:08:28 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:28 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:28 --> Email Class Initialized
INFO - 2018-05-02 10:08:28 --> Controller Class Initialized
INFO - 2018-05-02 10:08:28 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:28 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:28 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:28 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:28 --> Model Class Initialized
INFO - 2018-05-02 10:08:28 --> Model Class Initialized
INFO - 2018-05-02 10:08:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:08:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
ERROR - 2018-05-02 10:08:29 --> Undefined variable: categories
ERROR - 2018-05-02 10:08:29 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-02 10:08:29 --> Trying to get property of non-object
ERROR - 2018-05-02 10:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-02 10:08:29 --> Undefined variable: articles
ERROR - 2018-05-02 10:08:29 --> Severity: Notice --> Undefined variable: articles C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-02 10:08:29 --> Trying to get property of non-object
ERROR - 2018-05-02 10:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-02 10:08:29 --> Undefined variable: subscriptions
ERROR - 2018-05-02 10:08:29 --> Severity: Notice --> Undefined variable: subscriptions C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
ERROR - 2018-05-02 10:08:29 --> Trying to get property of non-object
ERROR - 2018-05-02 10:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
INFO - 2018-05-02 10:08:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php
INFO - 2018-05-02 10:08:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:08:29 --> Final output sent to browser
DEBUG - 2018-05-02 10:08:29 --> Total execution time: 0.2380
INFO - 2018-05-02 10:08:29 --> Config Class Initialized
INFO - 2018-05-02 10:08:29 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:29 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:29 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:29 --> URI Class Initialized
DEBUG - 2018-05-02 10:08:29 --> No URI present. Default controller set.
INFO - 2018-05-02 10:08:29 --> Router Class Initialized
INFO - 2018-05-02 10:08:29 --> Output Class Initialized
INFO - 2018-05-02 10:08:29 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:29 --> Input Class Initialized
INFO - 2018-05-02 10:08:29 --> Language Class Initialized
INFO - 2018-05-02 10:08:29 --> Loader Class Initialized
INFO - 2018-05-02 10:08:29 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:29 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:29 --> Email Class Initialized
INFO - 2018-05-02 10:08:29 --> Controller Class Initialized
INFO - 2018-05-02 10:08:29 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:29 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:29 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:29 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:29 --> Model Class Initialized
INFO - 2018-05-02 10:08:29 --> Model Class Initialized
INFO - 2018-05-02 10:08:29 --> Config Class Initialized
INFO - 2018-05-02 10:08:29 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:29 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:29 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:29 --> URI Class Initialized
INFO - 2018-05-02 10:08:29 --> Router Class Initialized
INFO - 2018-05-02 10:08:29 --> Output Class Initialized
INFO - 2018-05-02 10:08:29 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:29 --> Input Class Initialized
INFO - 2018-05-02 10:08:29 --> Language Class Initialized
INFO - 2018-05-02 10:08:29 --> Loader Class Initialized
INFO - 2018-05-02 10:08:29 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:29 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:29 --> Email Class Initialized
INFO - 2018-05-02 10:08:29 --> Controller Class Initialized
INFO - 2018-05-02 10:08:29 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:29 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:29 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:29 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:29 --> Model Class Initialized
INFO - 2018-05-02 10:08:29 --> Model Class Initialized
INFO - 2018-05-02 10:08:29 --> Model Class Initialized
INFO - 2018-05-02 13:38:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 13:38:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:29 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:29 --> Total execution time: 0.1630
INFO - 2018-05-02 10:08:29 --> Config Class Initialized
INFO - 2018-05-02 10:08:29 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:29 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:29 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:29 --> URI Class Initialized
INFO - 2018-05-02 10:08:29 --> Router Class Initialized
INFO - 2018-05-02 10:08:29 --> Output Class Initialized
INFO - 2018-05-02 10:08:29 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:29 --> Input Class Initialized
INFO - 2018-05-02 10:08:29 --> Language Class Initialized
INFO - 2018-05-02 10:08:29 --> Loader Class Initialized
INFO - 2018-05-02 10:08:29 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:29 --> Database Driver Class Initialized
ERROR - 2018-05-02 10:08:29 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-02 10:08:29 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-02 10:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:29 --> Email Class Initialized
INFO - 2018-05-02 10:08:29 --> Controller Class Initialized
INFO - 2018-05-02 10:08:29 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:29 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:29 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:29 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:29 --> Model Class Initialized
INFO - 2018-05-02 10:08:29 --> Model Class Initialized
INFO - 2018-05-02 10:08:29 --> Model Class Initialized
INFO - 2018-05-02 13:38:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-02 13:38:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:29 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:29 --> Total execution time: 0.2250
INFO - 2018-05-02 10:08:30 --> Config Class Initialized
INFO - 2018-05-02 10:08:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:30 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:30 --> URI Class Initialized
INFO - 2018-05-02 10:08:30 --> Router Class Initialized
INFO - 2018-05-02 10:08:30 --> Output Class Initialized
INFO - 2018-05-02 10:08:30 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:30 --> Input Class Initialized
INFO - 2018-05-02 10:08:30 --> Language Class Initialized
INFO - 2018-05-02 10:08:30 --> Loader Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:30 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:30 --> Email Class Initialized
INFO - 2018-05-02 10:08:30 --> Controller Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:30 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:30 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:30 --> Model Class Initialized
INFO - 2018-05-02 10:08:30 --> Model Class Initialized
INFO - 2018-05-02 10:08:30 --> Model Class Initialized
INFO - 2018-05-02 13:38:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-02 13:38:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:30 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:30 --> Total execution time: 0.1680
INFO - 2018-05-02 10:08:30 --> Config Class Initialized
INFO - 2018-05-02 10:08:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:30 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:30 --> URI Class Initialized
INFO - 2018-05-02 10:08:30 --> Router Class Initialized
INFO - 2018-05-02 10:08:30 --> Output Class Initialized
INFO - 2018-05-02 10:08:30 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:30 --> Input Class Initialized
INFO - 2018-05-02 10:08:30 --> Language Class Initialized
INFO - 2018-05-02 10:08:30 --> Loader Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:30 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:30 --> Email Class Initialized
INFO - 2018-05-02 10:08:30 --> Controller Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:30 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:30 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:30 --> Model Class Initialized
INFO - 2018-05-02 10:08:30 --> Model Class Initialized
INFO - 2018-05-02 10:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
ERROR - 2018-05-02 10:08:30 --> Undefined variable: categories
ERROR - 2018-05-02 10:08:30 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-02 10:08:30 --> Trying to get property of non-object
ERROR - 2018-05-02 10:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-02 10:08:30 --> Undefined variable: articles
INFO - 2018-05-02 10:08:30 --> Config Class Initialized
INFO - 2018-05-02 10:08:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:30 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:30 --> URI Class Initialized
INFO - 2018-05-02 10:08:30 --> Router Class Initialized
ERROR - 2018-05-02 10:08:30 --> Severity: Notice --> Undefined variable: articles C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-02 10:08:30 --> Trying to get property of non-object
ERROR - 2018-05-02 10:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-02 10:08:30 --> Undefined variable: subscriptions
ERROR - 2018-05-02 10:08:30 --> Severity: Notice --> Undefined variable: subscriptions C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
ERROR - 2018-05-02 10:08:30 --> Trying to get property of non-object
ERROR - 2018-05-02 10:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
INFO - 2018-05-02 10:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php
INFO - 2018-05-02 10:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:08:30 --> Final output sent to browser
DEBUG - 2018-05-02 10:08:30 --> Total execution time: 0.1860
INFO - 2018-05-02 10:08:30 --> Output Class Initialized
INFO - 2018-05-02 10:08:30 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:30 --> Input Class Initialized
INFO - 2018-05-02 10:08:30 --> Language Class Initialized
INFO - 2018-05-02 10:08:30 --> Loader Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:30 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:30 --> Email Class Initialized
INFO - 2018-05-02 10:08:30 --> Controller Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:30 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:30 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:30 --> Model Class Initialized
INFO - 2018-05-02 10:08:30 --> Model Class Initialized
INFO - 2018-05-02 10:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
ERROR - 2018-05-02 10:08:30 --> Undefined variable: categories
ERROR - 2018-05-02 10:08:30 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-02 10:08:30 --> Trying to get property of non-object
ERROR - 2018-05-02 10:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-02 10:08:30 --> Undefined variable: articles
ERROR - 2018-05-02 10:08:30 --> Severity: Notice --> Undefined variable: articles C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-02 10:08:30 --> Trying to get property of non-object
ERROR - 2018-05-02 10:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-02 10:08:30 --> Undefined variable: subscriptions
ERROR - 2018-05-02 10:08:30 --> Severity: Notice --> Undefined variable: subscriptions C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
ERROR - 2018-05-02 10:08:30 --> Trying to get property of non-object
ERROR - 2018-05-02 10:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
INFO - 2018-05-02 10:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php
INFO - 2018-05-02 10:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:08:30 --> Final output sent to browser
DEBUG - 2018-05-02 10:08:30 --> Total execution time: 0.1570
INFO - 2018-05-02 10:08:30 --> Config Class Initialized
INFO - 2018-05-02 10:08:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:30 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:30 --> URI Class Initialized
DEBUG - 2018-05-02 10:08:30 --> No URI present. Default controller set.
INFO - 2018-05-02 10:08:30 --> Router Class Initialized
INFO - 2018-05-02 10:08:30 --> Output Class Initialized
INFO - 2018-05-02 10:08:30 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:30 --> Input Class Initialized
INFO - 2018-05-02 10:08:30 --> Language Class Initialized
INFO - 2018-05-02 10:08:30 --> Loader Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:30 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:30 --> Email Class Initialized
INFO - 2018-05-02 10:08:30 --> Controller Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:30 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:30 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:30 --> Model Class Initialized
INFO - 2018-05-02 10:08:30 --> Model Class Initialized
INFO - 2018-05-02 10:08:30 --> Config Class Initialized
INFO - 2018-05-02 10:08:30 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:30 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:30 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:30 --> URI Class Initialized
INFO - 2018-05-02 10:08:30 --> Router Class Initialized
INFO - 2018-05-02 10:08:30 --> Output Class Initialized
INFO - 2018-05-02 10:08:30 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:30 --> Input Class Initialized
INFO - 2018-05-02 10:08:30 --> Language Class Initialized
INFO - 2018-05-02 10:08:30 --> Loader Class Initialized
INFO - 2018-05-02 10:08:30 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:30 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:31 --> Email Class Initialized
INFO - 2018-05-02 10:08:31 --> Controller Class Initialized
INFO - 2018-05-02 10:08:31 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:31 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:31 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:31 --> Model Class Initialized
INFO - 2018-05-02 10:08:31 --> Model Class Initialized
INFO - 2018-05-02 10:08:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 10:08:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
ERROR - 2018-05-02 10:08:31 --> Undefined variable: categories
ERROR - 2018-05-02 10:08:31 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-02 10:08:31 --> Trying to get property of non-object
ERROR - 2018-05-02 10:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-02 10:08:31 --> Undefined variable: articles
ERROR - 2018-05-02 10:08:31 --> Severity: Notice --> Undefined variable: articles C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-02 10:08:31 --> Trying to get property of non-object
ERROR - 2018-05-02 10:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-02 10:08:31 --> Undefined variable: subscriptions
ERROR - 2018-05-02 10:08:31 --> Severity: Notice --> Undefined variable: subscriptions C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
ERROR - 2018-05-02 10:08:31 --> Trying to get property of non-object
ERROR - 2018-05-02 10:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
INFO - 2018-05-02 10:08:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php
INFO - 2018-05-02 10:08:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 10:08:31 --> Final output sent to browser
DEBUG - 2018-05-02 10:08:31 --> Total execution time: 0.1530
INFO - 2018-05-02 10:08:31 --> Config Class Initialized
INFO - 2018-05-02 10:08:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:31 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:31 --> URI Class Initialized
INFO - 2018-05-02 10:08:31 --> Router Class Initialized
INFO - 2018-05-02 10:08:31 --> Output Class Initialized
INFO - 2018-05-02 10:08:31 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:31 --> Input Class Initialized
INFO - 2018-05-02 10:08:31 --> Language Class Initialized
INFO - 2018-05-02 10:08:31 --> Loader Class Initialized
INFO - 2018-05-02 10:08:31 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:31 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:31 --> Email Class Initialized
INFO - 2018-05-02 10:08:31 --> Controller Class Initialized
INFO - 2018-05-02 10:08:31 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:31 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:31 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:31 --> Model Class Initialized
INFO - 2018-05-02 10:08:31 --> Model Class Initialized
INFO - 2018-05-02 10:08:31 --> Model Class Initialized
INFO - 2018-05-02 13:38:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 13:38:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:31 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:31 --> Total execution time: 0.1430
INFO - 2018-05-02 10:08:32 --> Config Class Initialized
INFO - 2018-05-02 10:08:32 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:32 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:32 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:32 --> URI Class Initialized
INFO - 2018-05-02 10:08:32 --> Router Class Initialized
INFO - 2018-05-02 10:08:32 --> Output Class Initialized
INFO - 2018-05-02 10:08:32 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:32 --> Input Class Initialized
INFO - 2018-05-02 10:08:32 --> Language Class Initialized
INFO - 2018-05-02 10:08:33 --> Loader Class Initialized
INFO - 2018-05-02 10:08:33 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:33 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:33 --> Email Class Initialized
INFO - 2018-05-02 10:08:33 --> Controller Class Initialized
INFO - 2018-05-02 10:08:33 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:33 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:33 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:33 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:33 --> Model Class Initialized
INFO - 2018-05-02 10:08:33 --> Model Class Initialized
INFO - 2018-05-02 10:08:33 --> Model Class Initialized
INFO - 2018-05-02 13:38:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-02 13:38:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:33 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:33 --> Total execution time: 0.1510
INFO - 2018-05-02 10:08:34 --> Config Class Initialized
INFO - 2018-05-02 10:08:34 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:08:34 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:08:34 --> Utf8 Class Initialized
INFO - 2018-05-02 10:08:34 --> URI Class Initialized
INFO - 2018-05-02 10:08:34 --> Router Class Initialized
INFO - 2018-05-02 10:08:34 --> Output Class Initialized
INFO - 2018-05-02 10:08:34 --> Security Class Initialized
DEBUG - 2018-05-02 10:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:08:34 --> Input Class Initialized
INFO - 2018-05-02 10:08:34 --> Language Class Initialized
INFO - 2018-05-02 10:08:34 --> Loader Class Initialized
INFO - 2018-05-02 10:08:34 --> Helper loaded: common_helper
INFO - 2018-05-02 10:08:34 --> Database Driver Class Initialized
INFO - 2018-05-02 10:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:08:34 --> Email Class Initialized
INFO - 2018-05-02 10:08:34 --> Controller Class Initialized
INFO - 2018-05-02 10:08:34 --> Helper loaded: form_helper
INFO - 2018-05-02 10:08:34 --> Form Validation Class Initialized
INFO - 2018-05-02 10:08:34 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:08:34 --> Helper loaded: url_helper
INFO - 2018-05-02 10:08:34 --> Model Class Initialized
INFO - 2018-05-02 10:08:34 --> Model Class Initialized
INFO - 2018-05-02 10:08:34 --> Model Class Initialized
INFO - 2018-05-02 13:38:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:38:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:38:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 13:38:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:38:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:38:34 --> Final output sent to browser
DEBUG - 2018-05-02 13:38:34 --> Total execution time: 0.1670
INFO - 2018-05-02 10:09:18 --> Config Class Initialized
INFO - 2018-05-02 10:09:18 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:09:18 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:09:18 --> Utf8 Class Initialized
INFO - 2018-05-02 10:09:18 --> URI Class Initialized
INFO - 2018-05-02 10:09:18 --> Router Class Initialized
INFO - 2018-05-02 10:09:18 --> Output Class Initialized
INFO - 2018-05-02 10:09:18 --> Security Class Initialized
DEBUG - 2018-05-02 10:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:09:18 --> Input Class Initialized
INFO - 2018-05-02 10:09:18 --> Language Class Initialized
INFO - 2018-05-02 10:09:18 --> Loader Class Initialized
INFO - 2018-05-02 10:09:18 --> Helper loaded: common_helper
INFO - 2018-05-02 10:09:18 --> Database Driver Class Initialized
INFO - 2018-05-02 10:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:09:18 --> Email Class Initialized
INFO - 2018-05-02 10:09:18 --> Controller Class Initialized
INFO - 2018-05-02 10:09:18 --> Helper loaded: form_helper
INFO - 2018-05-02 10:09:18 --> Form Validation Class Initialized
INFO - 2018-05-02 10:09:18 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:09:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:09:18 --> Helper loaded: url_helper
INFO - 2018-05-02 10:09:18 --> Model Class Initialized
INFO - 2018-05-02 10:09:18 --> Model Class Initialized
INFO - 2018-05-02 10:09:18 --> Model Class Initialized
INFO - 2018-05-02 13:39:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:39:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:39:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:39:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:39:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:39:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:39:18 --> Final output sent to browser
DEBUG - 2018-05-02 13:39:18 --> Total execution time: 0.1430
INFO - 2018-05-02 10:09:54 --> Config Class Initialized
INFO - 2018-05-02 10:09:54 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:09:54 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:09:54 --> Utf8 Class Initialized
INFO - 2018-05-02 10:09:54 --> URI Class Initialized
INFO - 2018-05-02 10:09:54 --> Router Class Initialized
INFO - 2018-05-02 10:09:54 --> Output Class Initialized
INFO - 2018-05-02 10:09:54 --> Security Class Initialized
DEBUG - 2018-05-02 10:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:09:54 --> Input Class Initialized
INFO - 2018-05-02 10:09:54 --> Language Class Initialized
INFO - 2018-05-02 10:09:54 --> Loader Class Initialized
INFO - 2018-05-02 10:09:54 --> Helper loaded: common_helper
INFO - 2018-05-02 10:09:54 --> Database Driver Class Initialized
INFO - 2018-05-02 10:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:09:54 --> Email Class Initialized
INFO - 2018-05-02 10:09:54 --> Controller Class Initialized
INFO - 2018-05-02 10:09:54 --> Helper loaded: form_helper
INFO - 2018-05-02 10:09:54 --> Form Validation Class Initialized
INFO - 2018-05-02 10:09:54 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:09:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:09:54 --> Helper loaded: url_helper
INFO - 2018-05-02 10:09:54 --> Model Class Initialized
INFO - 2018-05-02 10:09:54 --> Model Class Initialized
INFO - 2018-05-02 10:09:54 --> Model Class Initialized
INFO - 2018-05-02 13:39:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:39:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:39:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 13:39:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:39:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:39:54 --> Final output sent to browser
DEBUG - 2018-05-02 13:39:54 --> Total execution time: 0.1400
INFO - 2018-05-02 10:10:00 --> Config Class Initialized
INFO - 2018-05-02 10:10:00 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:10:00 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:10:00 --> Utf8 Class Initialized
INFO - 2018-05-02 10:10:00 --> URI Class Initialized
INFO - 2018-05-02 10:10:00 --> Router Class Initialized
INFO - 2018-05-02 10:10:00 --> Output Class Initialized
INFO - 2018-05-02 10:10:00 --> Security Class Initialized
DEBUG - 2018-05-02 10:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:10:00 --> Input Class Initialized
INFO - 2018-05-02 10:10:00 --> Language Class Initialized
INFO - 2018-05-02 10:10:00 --> Loader Class Initialized
INFO - 2018-05-02 10:10:00 --> Helper loaded: common_helper
INFO - 2018-05-02 10:10:00 --> Database Driver Class Initialized
INFO - 2018-05-02 10:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:10:00 --> Email Class Initialized
INFO - 2018-05-02 10:10:00 --> Controller Class Initialized
INFO - 2018-05-02 10:10:00 --> Helper loaded: form_helper
INFO - 2018-05-02 10:10:00 --> Form Validation Class Initialized
INFO - 2018-05-02 10:10:00 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:10:00 --> Helper loaded: url_helper
INFO - 2018-05-02 10:10:00 --> Model Class Initialized
INFO - 2018-05-02 10:10:00 --> Model Class Initialized
INFO - 2018-05-02 10:10:00 --> Model Class Initialized
INFO - 2018-05-02 13:40:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:40:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:40:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 13:40:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:40:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:40:00 --> Final output sent to browser
DEBUG - 2018-05-02 13:40:00 --> Total execution time: 0.1330
INFO - 2018-05-02 10:10:31 --> Config Class Initialized
INFO - 2018-05-02 10:10:31 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:10:31 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:10:31 --> Utf8 Class Initialized
INFO - 2018-05-02 10:10:31 --> URI Class Initialized
INFO - 2018-05-02 10:10:31 --> Router Class Initialized
INFO - 2018-05-02 10:10:31 --> Output Class Initialized
INFO - 2018-05-02 10:10:31 --> Security Class Initialized
DEBUG - 2018-05-02 10:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:10:31 --> Input Class Initialized
INFO - 2018-05-02 10:10:31 --> Language Class Initialized
INFO - 2018-05-02 10:10:31 --> Loader Class Initialized
INFO - 2018-05-02 10:10:31 --> Helper loaded: common_helper
INFO - 2018-05-02 10:10:31 --> Database Driver Class Initialized
INFO - 2018-05-02 10:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:10:31 --> Email Class Initialized
INFO - 2018-05-02 10:10:31 --> Controller Class Initialized
INFO - 2018-05-02 10:10:31 --> Helper loaded: form_helper
INFO - 2018-05-02 10:10:31 --> Form Validation Class Initialized
INFO - 2018-05-02 10:10:31 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:10:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:10:31 --> Helper loaded: url_helper
INFO - 2018-05-02 10:10:31 --> Model Class Initialized
INFO - 2018-05-02 10:10:31 --> Model Class Initialized
INFO - 2018-05-02 10:10:31 --> Model Class Initialized
INFO - 2018-05-02 13:40:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:40:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:40:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:40:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 13:40:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:40:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:40:31 --> Final output sent to browser
DEBUG - 2018-05-02 13:40:31 --> Total execution time: 0.2150
INFO - 2018-05-02 10:11:25 --> Config Class Initialized
INFO - 2018-05-02 10:11:25 --> Hooks Class Initialized
DEBUG - 2018-05-02 10:11:25 --> UTF-8 Support Enabled
INFO - 2018-05-02 10:11:25 --> Utf8 Class Initialized
INFO - 2018-05-02 10:11:25 --> URI Class Initialized
INFO - 2018-05-02 10:11:25 --> Router Class Initialized
INFO - 2018-05-02 10:11:25 --> Output Class Initialized
INFO - 2018-05-02 10:11:25 --> Security Class Initialized
DEBUG - 2018-05-02 10:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 10:11:25 --> Input Class Initialized
INFO - 2018-05-02 10:11:25 --> Language Class Initialized
INFO - 2018-05-02 10:11:25 --> Loader Class Initialized
INFO - 2018-05-02 10:11:25 --> Helper loaded: common_helper
INFO - 2018-05-02 10:11:25 --> Database Driver Class Initialized
INFO - 2018-05-02 10:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 10:11:25 --> Email Class Initialized
INFO - 2018-05-02 10:11:25 --> Controller Class Initialized
INFO - 2018-05-02 10:11:25 --> Helper loaded: form_helper
INFO - 2018-05-02 10:11:25 --> Form Validation Class Initialized
INFO - 2018-05-02 10:11:25 --> Helper loaded: email_helper
DEBUG - 2018-05-02 10:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 10:11:25 --> Helper loaded: url_helper
INFO - 2018-05-02 10:11:25 --> Model Class Initialized
INFO - 2018-05-02 10:11:25 --> Model Class Initialized
INFO - 2018-05-02 10:11:25 --> Model Class Initialized
INFO - 2018-05-02 13:41:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 13:41:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 13:41:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-02 13:41:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 13:41:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 13:41:25 --> Final output sent to browser
DEBUG - 2018-05-02 13:41:25 --> Total execution time: 0.1500
INFO - 2018-05-02 11:09:10 --> Config Class Initialized
INFO - 2018-05-02 11:09:10 --> Hooks Class Initialized
DEBUG - 2018-05-02 11:09:10 --> UTF-8 Support Enabled
INFO - 2018-05-02 11:09:10 --> Utf8 Class Initialized
INFO - 2018-05-02 11:09:10 --> URI Class Initialized
INFO - 2018-05-02 11:09:10 --> Router Class Initialized
INFO - 2018-05-02 11:09:10 --> Output Class Initialized
INFO - 2018-05-02 11:09:10 --> Security Class Initialized
DEBUG - 2018-05-02 11:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 11:09:10 --> Input Class Initialized
INFO - 2018-05-02 11:09:10 --> Language Class Initialized
INFO - 2018-05-02 11:09:10 --> Loader Class Initialized
INFO - 2018-05-02 11:09:10 --> Helper loaded: common_helper
INFO - 2018-05-02 11:09:10 --> Database Driver Class Initialized
INFO - 2018-05-02 11:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 11:09:10 --> Email Class Initialized
INFO - 2018-05-02 11:09:10 --> Controller Class Initialized
INFO - 2018-05-02 11:09:10 --> Helper loaded: form_helper
INFO - 2018-05-02 11:09:10 --> Form Validation Class Initialized
INFO - 2018-05-02 11:09:10 --> Helper loaded: email_helper
DEBUG - 2018-05-02 11:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 11:09:10 --> Helper loaded: url_helper
INFO - 2018-05-02 11:09:10 --> Model Class Initialized
INFO - 2018-05-02 11:09:10 --> Model Class Initialized
INFO - 2018-05-02 11:09:10 --> Model Class Initialized
INFO - 2018-05-02 14:39:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 14:39:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 14:39:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 14:39:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 14:39:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 14:39:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 14:39:10 --> Final output sent to browser
DEBUG - 2018-05-02 14:39:10 --> Total execution time: 0.1390
INFO - 2018-05-02 11:09:52 --> Config Class Initialized
INFO - 2018-05-02 11:09:52 --> Hooks Class Initialized
DEBUG - 2018-05-02 11:09:52 --> UTF-8 Support Enabled
INFO - 2018-05-02 11:09:52 --> Utf8 Class Initialized
INFO - 2018-05-02 11:09:52 --> URI Class Initialized
INFO - 2018-05-02 11:09:52 --> Router Class Initialized
INFO - 2018-05-02 11:09:52 --> Output Class Initialized
INFO - 2018-05-02 11:09:52 --> Security Class Initialized
DEBUG - 2018-05-02 11:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 11:09:52 --> Input Class Initialized
INFO - 2018-05-02 11:09:52 --> Language Class Initialized
INFO - 2018-05-02 11:09:52 --> Loader Class Initialized
INFO - 2018-05-02 11:09:52 --> Helper loaded: common_helper
INFO - 2018-05-02 11:09:52 --> Database Driver Class Initialized
INFO - 2018-05-02 11:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 11:09:52 --> Email Class Initialized
INFO - 2018-05-02 11:09:52 --> Controller Class Initialized
INFO - 2018-05-02 11:09:52 --> Helper loaded: form_helper
INFO - 2018-05-02 11:09:52 --> Form Validation Class Initialized
INFO - 2018-05-02 11:09:52 --> Helper loaded: email_helper
DEBUG - 2018-05-02 11:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 11:09:52 --> Helper loaded: url_helper
INFO - 2018-05-02 11:09:52 --> Model Class Initialized
INFO - 2018-05-02 11:09:52 --> Model Class Initialized
INFO - 2018-05-02 11:09:52 --> Model Class Initialized
DEBUG - 2018-05-02 14:39:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-02 14:39:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-02 11:09:52 --> Config Class Initialized
INFO - 2018-05-02 11:09:52 --> Hooks Class Initialized
DEBUG - 2018-05-02 11:09:52 --> UTF-8 Support Enabled
INFO - 2018-05-02 11:09:52 --> Utf8 Class Initialized
INFO - 2018-05-02 11:09:52 --> URI Class Initialized
INFO - 2018-05-02 11:09:52 --> Router Class Initialized
INFO - 2018-05-02 11:09:52 --> Output Class Initialized
INFO - 2018-05-02 11:09:52 --> Security Class Initialized
DEBUG - 2018-05-02 11:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-02 11:09:52 --> Input Class Initialized
INFO - 2018-05-02 11:09:52 --> Language Class Initialized
INFO - 2018-05-02 11:09:52 --> Loader Class Initialized
INFO - 2018-05-02 11:09:52 --> Helper loaded: common_helper
INFO - 2018-05-02 11:09:52 --> Database Driver Class Initialized
INFO - 2018-05-02 11:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-02 11:09:53 --> Email Class Initialized
INFO - 2018-05-02 11:09:53 --> Controller Class Initialized
INFO - 2018-05-02 11:09:53 --> Helper loaded: form_helper
INFO - 2018-05-02 11:09:53 --> Form Validation Class Initialized
INFO - 2018-05-02 11:09:53 --> Helper loaded: email_helper
DEBUG - 2018-05-02 11:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-02 11:09:53 --> Helper loaded: url_helper
INFO - 2018-05-02 11:09:53 --> Model Class Initialized
INFO - 2018-05-02 11:09:53 --> Model Class Initialized
INFO - 2018-05-02 11:09:53 --> Model Class Initialized
INFO - 2018-05-02 14:39:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-02 14:39:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-02 14:39:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 14:39:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\tutorial/addTutorial.php
INFO - 2018-05-02 14:39:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-02 14:39:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-02 14:39:53 --> Final output sent to browser
DEBUG - 2018-05-02 14:39:53 --> Total execution time: 0.1230
