<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-04 06:38:34 --> Config Class Initialized
INFO - 2018-05-04 06:38:34 --> Hooks Class Initialized
DEBUG - 2018-05-04 06:38:34 --> UTF-8 Support Enabled
INFO - 2018-05-04 06:38:34 --> Utf8 Class Initialized
INFO - 2018-05-04 06:38:34 --> URI Class Initialized
INFO - 2018-05-04 06:38:34 --> Router Class Initialized
INFO - 2018-05-04 06:38:34 --> Output Class Initialized
INFO - 2018-05-04 06:38:34 --> Security Class Initialized
DEBUG - 2018-05-04 06:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 06:38:34 --> Input Class Initialized
INFO - 2018-05-04 06:38:34 --> Language Class Initialized
INFO - 2018-05-04 06:38:34 --> Loader Class Initialized
INFO - 2018-05-04 06:38:34 --> Helper loaded: common_helper
INFO - 2018-05-04 06:38:34 --> Database Driver Class Initialized
ERROR - 2018-05-04 06:38:34 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-04 06:38:34 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-04 06:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 06:38:34 --> Email Class Initialized
INFO - 2018-05-04 06:38:34 --> Controller Class Initialized
INFO - 2018-05-04 06:38:34 --> Helper loaded: form_helper
INFO - 2018-05-04 06:38:34 --> Form Validation Class Initialized
INFO - 2018-05-04 06:38:34 --> Helper loaded: email_helper
DEBUG - 2018-05-04 06:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 06:38:34 --> Helper loaded: url_helper
INFO - 2018-05-04 06:38:34 --> Model Class Initialized
INFO - 2018-05-04 06:38:34 --> Model Class Initialized
INFO - 2018-05-04 06:38:34 --> Model Class Initialized
INFO - 2018-05-04 06:38:35 --> Config Class Initialized
INFO - 2018-05-04 06:38:35 --> Hooks Class Initialized
DEBUG - 2018-05-04 06:38:35 --> UTF-8 Support Enabled
INFO - 2018-05-04 06:38:35 --> Utf8 Class Initialized
INFO - 2018-05-04 06:38:35 --> URI Class Initialized
INFO - 2018-05-04 06:38:35 --> Router Class Initialized
INFO - 2018-05-04 06:38:35 --> Output Class Initialized
INFO - 2018-05-04 06:38:35 --> Security Class Initialized
DEBUG - 2018-05-04 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 06:38:35 --> Input Class Initialized
INFO - 2018-05-04 06:38:35 --> Language Class Initialized
INFO - 2018-05-04 06:38:35 --> Loader Class Initialized
INFO - 2018-05-04 06:38:35 --> Helper loaded: common_helper
INFO - 2018-05-04 06:38:35 --> Database Driver Class Initialized
ERROR - 2018-05-04 06:38:35 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-04 06:38:35 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-04 06:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 06:38:35 --> Email Class Initialized
INFO - 2018-05-04 06:38:35 --> Controller Class Initialized
INFO - 2018-05-04 06:38:35 --> Helper loaded: form_helper
INFO - 2018-05-04 06:38:35 --> Form Validation Class Initialized
INFO - 2018-05-04 06:38:35 --> Helper loaded: email_helper
DEBUG - 2018-05-04 06:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 06:38:35 --> Helper loaded: url_helper
INFO - 2018-05-04 06:38:35 --> Model Class Initialized
INFO - 2018-05-04 06:38:35 --> Model Class Initialized
INFO - 2018-05-04 06:38:35 --> Config Class Initialized
INFO - 2018-05-04 06:38:35 --> Hooks Class Initialized
DEBUG - 2018-05-04 06:38:35 --> UTF-8 Support Enabled
INFO - 2018-05-04 06:38:35 --> Utf8 Class Initialized
INFO - 2018-05-04 06:38:35 --> URI Class Initialized
DEBUG - 2018-05-04 06:38:35 --> No URI present. Default controller set.
INFO - 2018-05-04 06:38:35 --> Router Class Initialized
INFO - 2018-05-04 06:38:35 --> Output Class Initialized
INFO - 2018-05-04 06:38:35 --> Security Class Initialized
DEBUG - 2018-05-04 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 06:38:35 --> Input Class Initialized
INFO - 2018-05-04 06:38:35 --> Language Class Initialized
INFO - 2018-05-04 06:38:35 --> Loader Class Initialized
INFO - 2018-05-04 06:38:35 --> Helper loaded: common_helper
INFO - 2018-05-04 06:38:35 --> Database Driver Class Initialized
INFO - 2018-05-04 06:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 06:38:35 --> Email Class Initialized
INFO - 2018-05-04 06:38:35 --> Controller Class Initialized
INFO - 2018-05-04 06:38:35 --> Helper loaded: form_helper
INFO - 2018-05-04 06:38:35 --> Form Validation Class Initialized
INFO - 2018-05-04 06:38:35 --> Helper loaded: email_helper
DEBUG - 2018-05-04 06:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 06:38:35 --> Helper loaded: url_helper
INFO - 2018-05-04 06:38:35 --> Model Class Initialized
INFO - 2018-05-04 06:38:35 --> Model Class Initialized
INFO - 2018-05-04 06:38:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\index.php
INFO - 2018-05-04 06:38:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 06:38:35 --> Final output sent to browser
DEBUG - 2018-05-04 06:38:35 --> Total execution time: 0.1840
INFO - 2018-05-04 06:38:37 --> Config Class Initialized
INFO - 2018-05-04 06:38:37 --> Hooks Class Initialized
DEBUG - 2018-05-04 06:38:37 --> UTF-8 Support Enabled
INFO - 2018-05-04 06:38:37 --> Utf8 Class Initialized
INFO - 2018-05-04 06:38:37 --> URI Class Initialized
DEBUG - 2018-05-04 06:38:37 --> No URI present. Default controller set.
INFO - 2018-05-04 06:38:37 --> Router Class Initialized
INFO - 2018-05-04 06:38:37 --> Output Class Initialized
INFO - 2018-05-04 06:38:37 --> Security Class Initialized
DEBUG - 2018-05-04 06:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 06:38:37 --> Input Class Initialized
INFO - 2018-05-04 06:38:37 --> Language Class Initialized
INFO - 2018-05-04 06:38:37 --> Loader Class Initialized
INFO - 2018-05-04 06:38:37 --> Helper loaded: common_helper
INFO - 2018-05-04 06:38:37 --> Database Driver Class Initialized
INFO - 2018-05-04 06:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 06:38:37 --> Email Class Initialized
INFO - 2018-05-04 06:38:37 --> Controller Class Initialized
INFO - 2018-05-04 06:38:37 --> Helper loaded: form_helper
INFO - 2018-05-04 06:38:37 --> Form Validation Class Initialized
INFO - 2018-05-04 06:38:37 --> Helper loaded: email_helper
DEBUG - 2018-05-04 06:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 06:38:37 --> Helper loaded: url_helper
INFO - 2018-05-04 06:38:37 --> Model Class Initialized
INFO - 2018-05-04 06:38:37 --> Model Class Initialized
DEBUG - 2018-05-04 06:38:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-04 06:38:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-04 06:38:37 --> Config Class Initialized
INFO - 2018-05-04 06:38:37 --> Hooks Class Initialized
DEBUG - 2018-05-04 06:38:37 --> UTF-8 Support Enabled
INFO - 2018-05-04 06:38:37 --> Utf8 Class Initialized
INFO - 2018-05-04 06:38:37 --> URI Class Initialized
INFO - 2018-05-04 06:38:37 --> Router Class Initialized
INFO - 2018-05-04 06:38:37 --> Output Class Initialized
INFO - 2018-05-04 06:38:37 --> Security Class Initialized
DEBUG - 2018-05-04 06:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 06:38:37 --> Input Class Initialized
INFO - 2018-05-04 06:38:37 --> Language Class Initialized
INFO - 2018-05-04 06:38:37 --> Loader Class Initialized
INFO - 2018-05-04 06:38:37 --> Helper loaded: common_helper
INFO - 2018-05-04 06:38:37 --> Database Driver Class Initialized
INFO - 2018-05-04 06:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 06:38:37 --> Email Class Initialized
INFO - 2018-05-04 06:38:37 --> Controller Class Initialized
INFO - 2018-05-04 06:38:37 --> Helper loaded: form_helper
INFO - 2018-05-04 06:38:37 --> Form Validation Class Initialized
INFO - 2018-05-04 06:38:37 --> Helper loaded: email_helper
DEBUG - 2018-05-04 06:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 06:38:37 --> Helper loaded: url_helper
INFO - 2018-05-04 06:38:37 --> Model Class Initialized
INFO - 2018-05-04 06:38:37 --> Model Class Initialized
INFO - 2018-05-04 06:38:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 06:38:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
ERROR - 2018-05-04 06:38:37 --> Undefined variable: categories
ERROR - 2018-05-04 06:38:37 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-04 06:38:37 --> Trying to get property of non-object
ERROR - 2018-05-04 06:38:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-04 06:38:37 --> Undefined variable: articles
ERROR - 2018-05-04 06:38:37 --> Severity: Notice --> Undefined variable: articles C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-04 06:38:37 --> Trying to get property of non-object
ERROR - 2018-05-04 06:38:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-04 06:38:37 --> Undefined variable: subscriptions
ERROR - 2018-05-04 06:38:37 --> Severity: Notice --> Undefined variable: subscriptions C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
ERROR - 2018-05-04 06:38:37 --> Trying to get property of non-object
ERROR - 2018-05-04 06:38:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
INFO - 2018-05-04 06:38:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php
INFO - 2018-05-04 06:38:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 06:38:37 --> Final output sent to browser
DEBUG - 2018-05-04 06:38:37 --> Total execution time: 0.1580
INFO - 2018-05-04 07:13:54 --> Config Class Initialized
INFO - 2018-05-04 07:13:54 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:13:54 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:13:54 --> Utf8 Class Initialized
INFO - 2018-05-04 07:13:54 --> URI Class Initialized
INFO - 2018-05-04 07:13:54 --> Router Class Initialized
INFO - 2018-05-04 07:13:54 --> Output Class Initialized
INFO - 2018-05-04 07:13:54 --> Security Class Initialized
DEBUG - 2018-05-04 07:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:13:54 --> Input Class Initialized
INFO - 2018-05-04 07:13:54 --> Language Class Initialized
INFO - 2018-05-04 07:13:54 --> Loader Class Initialized
INFO - 2018-05-04 07:13:54 --> Helper loaded: common_helper
INFO - 2018-05-04 07:13:54 --> Database Driver Class Initialized
INFO - 2018-05-04 07:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:13:54 --> Email Class Initialized
INFO - 2018-05-04 07:13:54 --> Controller Class Initialized
INFO - 2018-05-04 07:13:54 --> Helper loaded: form_helper
INFO - 2018-05-04 07:13:54 --> Form Validation Class Initialized
INFO - 2018-05-04 07:13:54 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:13:54 --> Helper loaded: url_helper
INFO - 2018-05-04 07:13:54 --> Model Class Initialized
INFO - 2018-05-04 07:13:54 --> Model Class Initialized
INFO - 2018-05-04 07:13:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:13:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
ERROR - 2018-05-04 07:13:54 --> Undefined variable: categories
ERROR - 2018-05-04 07:13:54 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-04 07:13:54 --> Trying to get property of non-object
ERROR - 2018-05-04 07:13:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-04 07:13:54 --> Undefined variable: articles
ERROR - 2018-05-04 07:13:54 --> Severity: Notice --> Undefined variable: articles C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-04 07:13:54 --> Trying to get property of non-object
ERROR - 2018-05-04 07:13:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-04 07:13:54 --> Undefined variable: subscriptions
ERROR - 2018-05-04 07:13:54 --> Severity: Notice --> Undefined variable: subscriptions C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
ERROR - 2018-05-04 07:13:54 --> Trying to get property of non-object
ERROR - 2018-05-04 07:13:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
INFO - 2018-05-04 07:13:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php
INFO - 2018-05-04 07:13:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:13:54 --> Final output sent to browser
DEBUG - 2018-05-04 07:13:54 --> Total execution time: 0.1570
INFO - 2018-05-04 07:14:46 --> Config Class Initialized
INFO - 2018-05-04 07:14:46 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:14:46 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:14:46 --> Utf8 Class Initialized
INFO - 2018-05-04 07:14:46 --> URI Class Initialized
INFO - 2018-05-04 07:14:46 --> Router Class Initialized
INFO - 2018-05-04 07:14:46 --> Output Class Initialized
INFO - 2018-05-04 07:14:46 --> Security Class Initialized
DEBUG - 2018-05-04 07:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:14:46 --> Input Class Initialized
INFO - 2018-05-04 07:14:46 --> Language Class Initialized
INFO - 2018-05-04 07:14:46 --> Loader Class Initialized
INFO - 2018-05-04 07:14:46 --> Helper loaded: common_helper
INFO - 2018-05-04 07:14:46 --> Database Driver Class Initialized
INFO - 2018-05-04 07:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:14:46 --> Email Class Initialized
INFO - 2018-05-04 07:14:46 --> Controller Class Initialized
INFO - 2018-05-04 07:14:46 --> Helper loaded: form_helper
INFO - 2018-05-04 07:14:46 --> Form Validation Class Initialized
INFO - 2018-05-04 07:14:46 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:14:46 --> Helper loaded: url_helper
INFO - 2018-05-04 07:14:46 --> Model Class Initialized
INFO - 2018-05-04 07:14:46 --> Model Class Initialized
INFO - 2018-05-04 07:14:46 --> Model Class Initialized
INFO - 2018-05-04 10:44:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:44:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:44:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:44:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 10:44:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:44:46 --> Final output sent to browser
DEBUG - 2018-05-04 10:44:46 --> Total execution time: 0.1410
INFO - 2018-05-04 07:18:43 --> Config Class Initialized
INFO - 2018-05-04 07:18:43 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:18:43 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:18:43 --> Utf8 Class Initialized
INFO - 2018-05-04 07:18:43 --> URI Class Initialized
INFO - 2018-05-04 07:18:43 --> Router Class Initialized
INFO - 2018-05-04 07:18:43 --> Output Class Initialized
INFO - 2018-05-04 07:18:43 --> Security Class Initialized
DEBUG - 2018-05-04 07:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:18:43 --> Input Class Initialized
INFO - 2018-05-04 07:18:43 --> Language Class Initialized
INFO - 2018-05-04 07:18:43 --> Loader Class Initialized
INFO - 2018-05-04 07:18:43 --> Helper loaded: common_helper
INFO - 2018-05-04 07:18:43 --> Database Driver Class Initialized
INFO - 2018-05-04 07:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:18:43 --> Email Class Initialized
INFO - 2018-05-04 07:18:43 --> Controller Class Initialized
INFO - 2018-05-04 07:18:43 --> Helper loaded: form_helper
INFO - 2018-05-04 07:18:43 --> Form Validation Class Initialized
INFO - 2018-05-04 07:18:43 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:18:43 --> Helper loaded: url_helper
INFO - 2018-05-04 07:18:43 --> Model Class Initialized
INFO - 2018-05-04 07:18:43 --> Model Class Initialized
INFO - 2018-05-04 07:18:43 --> Model Class Initialized
INFO - 2018-05-04 10:48:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:48:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:48:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:48:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 10:48:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:48:43 --> Final output sent to browser
DEBUG - 2018-05-04 10:48:43 --> Total execution time: 0.1420
INFO - 2018-05-04 07:20:23 --> Config Class Initialized
INFO - 2018-05-04 07:20:23 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:20:23 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:20:23 --> Utf8 Class Initialized
INFO - 2018-05-04 07:20:23 --> URI Class Initialized
INFO - 2018-05-04 07:20:23 --> Router Class Initialized
INFO - 2018-05-04 07:20:23 --> Output Class Initialized
INFO - 2018-05-04 07:20:23 --> Security Class Initialized
DEBUG - 2018-05-04 07:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:20:23 --> Input Class Initialized
INFO - 2018-05-04 07:20:23 --> Language Class Initialized
INFO - 2018-05-04 07:20:23 --> Loader Class Initialized
INFO - 2018-05-04 07:20:23 --> Helper loaded: common_helper
INFO - 2018-05-04 07:20:24 --> Database Driver Class Initialized
INFO - 2018-05-04 07:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:20:24 --> Email Class Initialized
INFO - 2018-05-04 07:20:24 --> Controller Class Initialized
INFO - 2018-05-04 07:20:24 --> Helper loaded: form_helper
INFO - 2018-05-04 07:20:24 --> Form Validation Class Initialized
INFO - 2018-05-04 07:20:24 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:20:24 --> Helper loaded: url_helper
INFO - 2018-05-04 07:20:24 --> Model Class Initialized
INFO - 2018-05-04 07:20:24 --> Model Class Initialized
INFO - 2018-05-04 07:20:24 --> Model Class Initialized
INFO - 2018-05-04 10:50:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:50:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:50:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-04 10:50:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:50:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:50:24 --> Final output sent to browser
DEBUG - 2018-05-04 10:50:24 --> Total execution time: 0.1320
INFO - 2018-05-04 07:20:27 --> Config Class Initialized
INFO - 2018-05-04 07:20:27 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:20:27 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:20:27 --> Utf8 Class Initialized
INFO - 2018-05-04 07:20:27 --> URI Class Initialized
INFO - 2018-05-04 07:20:27 --> Router Class Initialized
INFO - 2018-05-04 07:20:27 --> Output Class Initialized
INFO - 2018-05-04 07:20:27 --> Security Class Initialized
DEBUG - 2018-05-04 07:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:20:28 --> Input Class Initialized
INFO - 2018-05-04 07:20:28 --> Language Class Initialized
INFO - 2018-05-04 07:20:28 --> Loader Class Initialized
INFO - 2018-05-04 07:20:28 --> Helper loaded: common_helper
INFO - 2018-05-04 07:20:28 --> Database Driver Class Initialized
INFO - 2018-05-04 07:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:20:28 --> Email Class Initialized
INFO - 2018-05-04 07:20:28 --> Controller Class Initialized
INFO - 2018-05-04 07:20:28 --> Helper loaded: form_helper
INFO - 2018-05-04 07:20:28 --> Form Validation Class Initialized
INFO - 2018-05-04 07:20:28 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:20:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:20:28 --> Helper loaded: url_helper
INFO - 2018-05-04 07:20:28 --> Model Class Initialized
INFO - 2018-05-04 07:20:28 --> Model Class Initialized
INFO - 2018-05-04 07:20:28 --> Model Class Initialized
INFO - 2018-05-04 10:50:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:50:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:50:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:50:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 10:50:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:50:28 --> Final output sent to browser
DEBUG - 2018-05-04 10:50:28 --> Total execution time: 0.1420
INFO - 2018-05-04 07:20:29 --> Config Class Initialized
INFO - 2018-05-04 07:20:29 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:20:29 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:20:29 --> Utf8 Class Initialized
INFO - 2018-05-04 07:20:29 --> URI Class Initialized
INFO - 2018-05-04 07:20:29 --> Router Class Initialized
INFO - 2018-05-04 07:20:29 --> Output Class Initialized
INFO - 2018-05-04 07:20:29 --> Security Class Initialized
DEBUG - 2018-05-04 07:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:20:29 --> Input Class Initialized
INFO - 2018-05-04 07:20:29 --> Language Class Initialized
INFO - 2018-05-04 07:20:29 --> Loader Class Initialized
INFO - 2018-05-04 07:20:29 --> Helper loaded: common_helper
INFO - 2018-05-04 07:20:29 --> Database Driver Class Initialized
INFO - 2018-05-04 07:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:20:29 --> Email Class Initialized
INFO - 2018-05-04 07:20:29 --> Controller Class Initialized
INFO - 2018-05-04 07:20:29 --> Helper loaded: form_helper
INFO - 2018-05-04 07:20:29 --> Form Validation Class Initialized
INFO - 2018-05-04 07:20:29 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:20:29 --> Helper loaded: url_helper
INFO - 2018-05-04 07:20:29 --> Model Class Initialized
INFO - 2018-05-04 07:20:29 --> Model Class Initialized
INFO - 2018-05-04 07:20:29 --> Model Class Initialized
INFO - 2018-05-04 10:50:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:50:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 10:50:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:50:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:50:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 10:50:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:50:29 --> Final output sent to browser
DEBUG - 2018-05-04 10:50:29 --> Total execution time: 0.1310
INFO - 2018-05-04 07:20:33 --> Config Class Initialized
INFO - 2018-05-04 07:20:33 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:20:33 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:20:33 --> Utf8 Class Initialized
INFO - 2018-05-04 07:20:33 --> URI Class Initialized
INFO - 2018-05-04 07:20:33 --> Router Class Initialized
INFO - 2018-05-04 07:20:33 --> Output Class Initialized
INFO - 2018-05-04 07:20:33 --> Security Class Initialized
DEBUG - 2018-05-04 07:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:20:33 --> Input Class Initialized
INFO - 2018-05-04 07:20:33 --> Language Class Initialized
INFO - 2018-05-04 07:20:33 --> Loader Class Initialized
INFO - 2018-05-04 07:20:33 --> Helper loaded: common_helper
INFO - 2018-05-04 07:20:33 --> Database Driver Class Initialized
INFO - 2018-05-04 07:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:20:33 --> Email Class Initialized
INFO - 2018-05-04 07:20:33 --> Controller Class Initialized
INFO - 2018-05-04 07:20:33 --> Helper loaded: form_helper
INFO - 2018-05-04 07:20:33 --> Form Validation Class Initialized
INFO - 2018-05-04 07:20:33 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:20:33 --> Helper loaded: url_helper
INFO - 2018-05-04 07:20:33 --> Model Class Initialized
INFO - 2018-05-04 07:20:33 --> Model Class Initialized
INFO - 2018-05-04 07:20:33 --> Model Class Initialized
INFO - 2018-05-04 07:20:33 --> Config Class Initialized
INFO - 2018-05-04 07:20:33 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:20:33 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:20:33 --> Utf8 Class Initialized
INFO - 2018-05-04 07:20:33 --> URI Class Initialized
INFO - 2018-05-04 07:20:33 --> Router Class Initialized
INFO - 2018-05-04 07:20:33 --> Output Class Initialized
INFO - 2018-05-04 07:20:33 --> Security Class Initialized
DEBUG - 2018-05-04 07:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:20:33 --> Input Class Initialized
INFO - 2018-05-04 07:20:33 --> Language Class Initialized
INFO - 2018-05-04 07:20:33 --> Loader Class Initialized
INFO - 2018-05-04 07:20:33 --> Helper loaded: common_helper
INFO - 2018-05-04 07:20:33 --> Database Driver Class Initialized
INFO - 2018-05-04 07:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:20:33 --> Email Class Initialized
INFO - 2018-05-04 07:20:33 --> Controller Class Initialized
INFO - 2018-05-04 07:20:33 --> Helper loaded: form_helper
INFO - 2018-05-04 07:20:33 --> Form Validation Class Initialized
INFO - 2018-05-04 07:20:33 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:20:33 --> Helper loaded: url_helper
INFO - 2018-05-04 07:20:33 --> Model Class Initialized
INFO - 2018-05-04 07:20:33 --> Model Class Initialized
INFO - 2018-05-04 07:20:33 --> Model Class Initialized
INFO - 2018-05-04 10:50:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:50:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:50:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:50:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 10:50:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:50:33 --> Final output sent to browser
DEBUG - 2018-05-04 10:50:33 --> Total execution time: 0.1200
INFO - 2018-05-04 07:20:33 --> Config Class Initialized
INFO - 2018-05-04 07:20:33 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:20:33 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:20:33 --> Utf8 Class Initialized
INFO - 2018-05-04 07:20:33 --> URI Class Initialized
INFO - 2018-05-04 07:20:33 --> Router Class Initialized
INFO - 2018-05-04 07:20:33 --> Output Class Initialized
INFO - 2018-05-04 07:20:33 --> Security Class Initialized
DEBUG - 2018-05-04 07:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:20:33 --> Input Class Initialized
INFO - 2018-05-04 07:20:33 --> Language Class Initialized
INFO - 2018-05-04 07:20:33 --> Loader Class Initialized
INFO - 2018-05-04 07:20:33 --> Helper loaded: common_helper
INFO - 2018-05-04 07:20:33 --> Database Driver Class Initialized
INFO - 2018-05-04 07:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:20:33 --> Email Class Initialized
INFO - 2018-05-04 07:20:33 --> Controller Class Initialized
INFO - 2018-05-04 07:20:33 --> Helper loaded: form_helper
INFO - 2018-05-04 07:20:33 --> Form Validation Class Initialized
INFO - 2018-05-04 07:20:33 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:20:33 --> Helper loaded: url_helper
INFO - 2018-05-04 07:20:33 --> Model Class Initialized
INFO - 2018-05-04 07:20:33 --> Model Class Initialized
INFO - 2018-05-04 07:20:33 --> Model Class Initialized
INFO - 2018-05-04 10:50:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:50:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 10:50:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:50:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:50:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 10:50:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:50:33 --> Final output sent to browser
DEBUG - 2018-05-04 10:50:33 --> Total execution time: 0.1280
INFO - 2018-05-04 07:20:54 --> Config Class Initialized
INFO - 2018-05-04 07:20:54 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:20:54 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:20:54 --> Utf8 Class Initialized
INFO - 2018-05-04 07:20:54 --> URI Class Initialized
INFO - 2018-05-04 07:20:54 --> Router Class Initialized
INFO - 2018-05-04 07:20:54 --> Output Class Initialized
INFO - 2018-05-04 07:20:54 --> Security Class Initialized
DEBUG - 2018-05-04 07:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:20:54 --> Input Class Initialized
INFO - 2018-05-04 07:20:54 --> Language Class Initialized
INFO - 2018-05-04 07:20:54 --> Loader Class Initialized
INFO - 2018-05-04 07:20:54 --> Helper loaded: common_helper
INFO - 2018-05-04 07:20:54 --> Database Driver Class Initialized
INFO - 2018-05-04 07:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:20:54 --> Email Class Initialized
INFO - 2018-05-04 07:20:54 --> Controller Class Initialized
INFO - 2018-05-04 07:20:54 --> Helper loaded: form_helper
INFO - 2018-05-04 07:20:54 --> Form Validation Class Initialized
INFO - 2018-05-04 07:20:54 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:20:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:20:54 --> Helper loaded: url_helper
INFO - 2018-05-04 07:20:54 --> Model Class Initialized
INFO - 2018-05-04 07:20:54 --> Model Class Initialized
INFO - 2018-05-04 07:20:54 --> Model Class Initialized
INFO - 2018-05-04 10:50:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:50:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 10:50:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:50:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:50:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 10:50:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:50:54 --> Final output sent to browser
DEBUG - 2018-05-04 10:50:54 --> Total execution time: 0.1410
INFO - 2018-05-04 07:20:58 --> Config Class Initialized
INFO - 2018-05-04 07:20:58 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:20:58 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:20:58 --> Utf8 Class Initialized
INFO - 2018-05-04 07:20:58 --> URI Class Initialized
INFO - 2018-05-04 07:20:58 --> Router Class Initialized
INFO - 2018-05-04 07:20:58 --> Output Class Initialized
INFO - 2018-05-04 07:20:58 --> Security Class Initialized
DEBUG - 2018-05-04 07:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:20:58 --> Input Class Initialized
INFO - 2018-05-04 07:20:58 --> Language Class Initialized
INFO - 2018-05-04 07:20:58 --> Loader Class Initialized
INFO - 2018-05-04 07:20:58 --> Helper loaded: common_helper
INFO - 2018-05-04 07:20:58 --> Database Driver Class Initialized
INFO - 2018-05-04 07:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:20:58 --> Email Class Initialized
INFO - 2018-05-04 07:20:58 --> Controller Class Initialized
INFO - 2018-05-04 07:20:58 --> Helper loaded: form_helper
INFO - 2018-05-04 07:20:58 --> Form Validation Class Initialized
INFO - 2018-05-04 07:20:58 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:20:58 --> Helper loaded: url_helper
INFO - 2018-05-04 07:20:58 --> Model Class Initialized
INFO - 2018-05-04 07:20:58 --> Model Class Initialized
INFO - 2018-05-04 07:20:58 --> Model Class Initialized
INFO - 2018-05-04 07:20:58 --> Config Class Initialized
INFO - 2018-05-04 07:20:58 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:20:58 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:20:58 --> Utf8 Class Initialized
INFO - 2018-05-04 07:20:58 --> URI Class Initialized
INFO - 2018-05-04 07:20:58 --> Router Class Initialized
INFO - 2018-05-04 07:20:58 --> Output Class Initialized
INFO - 2018-05-04 07:20:58 --> Security Class Initialized
DEBUG - 2018-05-04 07:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:20:58 --> Input Class Initialized
INFO - 2018-05-04 07:20:58 --> Language Class Initialized
INFO - 2018-05-04 07:20:58 --> Loader Class Initialized
INFO - 2018-05-04 07:20:58 --> Helper loaded: common_helper
INFO - 2018-05-04 07:20:58 --> Database Driver Class Initialized
INFO - 2018-05-04 07:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:20:58 --> Email Class Initialized
INFO - 2018-05-04 07:20:58 --> Controller Class Initialized
INFO - 2018-05-04 07:20:58 --> Helper loaded: form_helper
INFO - 2018-05-04 07:20:58 --> Form Validation Class Initialized
INFO - 2018-05-04 07:20:58 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:20:58 --> Helper loaded: url_helper
INFO - 2018-05-04 07:20:58 --> Model Class Initialized
INFO - 2018-05-04 07:20:58 --> Model Class Initialized
INFO - 2018-05-04 07:20:58 --> Model Class Initialized
INFO - 2018-05-04 10:50:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:50:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:50:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:50:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 10:50:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:50:58 --> Final output sent to browser
DEBUG - 2018-05-04 10:50:58 --> Total execution time: 0.1230
INFO - 2018-05-04 07:20:58 --> Config Class Initialized
INFO - 2018-05-04 07:20:58 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:20:58 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:20:58 --> Utf8 Class Initialized
INFO - 2018-05-04 07:20:58 --> URI Class Initialized
INFO - 2018-05-04 07:20:58 --> Router Class Initialized
INFO - 2018-05-04 07:20:58 --> Output Class Initialized
INFO - 2018-05-04 07:20:58 --> Security Class Initialized
DEBUG - 2018-05-04 07:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:20:58 --> Input Class Initialized
INFO - 2018-05-04 07:20:58 --> Language Class Initialized
INFO - 2018-05-04 07:20:58 --> Loader Class Initialized
INFO - 2018-05-04 07:20:58 --> Helper loaded: common_helper
INFO - 2018-05-04 07:20:58 --> Database Driver Class Initialized
INFO - 2018-05-04 07:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:20:58 --> Email Class Initialized
INFO - 2018-05-04 07:20:58 --> Controller Class Initialized
INFO - 2018-05-04 07:20:58 --> Helper loaded: form_helper
INFO - 2018-05-04 07:20:58 --> Form Validation Class Initialized
INFO - 2018-05-04 07:20:58 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:20:58 --> Helper loaded: url_helper
INFO - 2018-05-04 07:20:58 --> Model Class Initialized
INFO - 2018-05-04 07:20:58 --> Model Class Initialized
INFO - 2018-05-04 07:20:58 --> Model Class Initialized
INFO - 2018-05-04 10:50:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:50:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 10:50:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:50:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:50:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 10:50:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:50:58 --> Final output sent to browser
DEBUG - 2018-05-04 10:50:58 --> Total execution time: 0.1320
INFO - 2018-05-04 07:28:21 --> Config Class Initialized
INFO - 2018-05-04 07:28:21 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:28:21 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:28:21 --> Utf8 Class Initialized
INFO - 2018-05-04 07:28:21 --> URI Class Initialized
INFO - 2018-05-04 07:28:21 --> Router Class Initialized
INFO - 2018-05-04 07:28:21 --> Output Class Initialized
INFO - 2018-05-04 07:28:21 --> Security Class Initialized
DEBUG - 2018-05-04 07:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:28:21 --> Input Class Initialized
INFO - 2018-05-04 07:28:21 --> Language Class Initialized
INFO - 2018-05-04 07:28:21 --> Loader Class Initialized
INFO - 2018-05-04 07:28:21 --> Helper loaded: common_helper
INFO - 2018-05-04 07:28:21 --> Database Driver Class Initialized
INFO - 2018-05-04 07:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:28:21 --> Email Class Initialized
INFO - 2018-05-04 07:28:21 --> Controller Class Initialized
INFO - 2018-05-04 07:28:21 --> Helper loaded: form_helper
INFO - 2018-05-04 07:28:21 --> Form Validation Class Initialized
INFO - 2018-05-04 07:28:21 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:28:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:28:21 --> Helper loaded: url_helper
INFO - 2018-05-04 07:28:21 --> Model Class Initialized
INFO - 2018-05-04 07:28:21 --> Model Class Initialized
INFO - 2018-05-04 07:28:21 --> Model Class Initialized
INFO - 2018-05-04 10:58:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:58:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:58:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:58:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 10:58:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:58:21 --> Final output sent to browser
DEBUG - 2018-05-04 10:58:21 --> Total execution time: 0.1430
INFO - 2018-05-04 07:28:22 --> Config Class Initialized
INFO - 2018-05-04 07:28:22 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:28:22 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:28:22 --> Utf8 Class Initialized
INFO - 2018-05-04 07:28:22 --> URI Class Initialized
INFO - 2018-05-04 07:28:22 --> Router Class Initialized
INFO - 2018-05-04 07:28:22 --> Output Class Initialized
INFO - 2018-05-04 07:28:22 --> Security Class Initialized
DEBUG - 2018-05-04 07:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:28:22 --> Input Class Initialized
INFO - 2018-05-04 07:28:22 --> Language Class Initialized
INFO - 2018-05-04 07:28:22 --> Loader Class Initialized
INFO - 2018-05-04 07:28:22 --> Helper loaded: common_helper
INFO - 2018-05-04 07:28:22 --> Database Driver Class Initialized
INFO - 2018-05-04 07:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:28:23 --> Email Class Initialized
INFO - 2018-05-04 07:28:23 --> Controller Class Initialized
INFO - 2018-05-04 07:28:23 --> Helper loaded: form_helper
INFO - 2018-05-04 07:28:23 --> Form Validation Class Initialized
INFO - 2018-05-04 07:28:23 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:28:23 --> Helper loaded: url_helper
INFO - 2018-05-04 07:28:23 --> Model Class Initialized
INFO - 2018-05-04 07:28:23 --> Model Class Initialized
INFO - 2018-05-04 07:28:23 --> Model Class Initialized
INFO - 2018-05-04 10:58:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:58:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:58:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-04 10:58:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:58:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:58:23 --> Final output sent to browser
DEBUG - 2018-05-04 10:58:23 --> Total execution time: 0.1340
INFO - 2018-05-04 07:28:25 --> Config Class Initialized
INFO - 2018-05-04 07:28:25 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:28:25 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:28:25 --> Utf8 Class Initialized
INFO - 2018-05-04 07:28:25 --> URI Class Initialized
INFO - 2018-05-04 07:28:25 --> Router Class Initialized
INFO - 2018-05-04 07:28:25 --> Output Class Initialized
INFO - 2018-05-04 07:28:25 --> Security Class Initialized
DEBUG - 2018-05-04 07:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:28:25 --> Input Class Initialized
INFO - 2018-05-04 07:28:25 --> Language Class Initialized
INFO - 2018-05-04 07:28:25 --> Loader Class Initialized
INFO - 2018-05-04 07:28:25 --> Helper loaded: common_helper
INFO - 2018-05-04 07:28:25 --> Database Driver Class Initialized
INFO - 2018-05-04 07:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:28:25 --> Email Class Initialized
INFO - 2018-05-04 07:28:25 --> Controller Class Initialized
INFO - 2018-05-04 07:28:25 --> Helper loaded: form_helper
INFO - 2018-05-04 07:28:25 --> Form Validation Class Initialized
INFO - 2018-05-04 07:28:25 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:28:25 --> Helper loaded: url_helper
INFO - 2018-05-04 07:28:25 --> Model Class Initialized
INFO - 2018-05-04 07:28:25 --> Model Class Initialized
INFO - 2018-05-04 07:28:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:28:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:28:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:28:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-04 07:28:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:28:25 --> Final output sent to browser
DEBUG - 2018-05-04 07:28:25 --> Total execution time: 0.1390
INFO - 2018-05-04 07:28:26 --> Config Class Initialized
INFO - 2018-05-04 07:28:26 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:28:26 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:28:26 --> Utf8 Class Initialized
INFO - 2018-05-04 07:28:26 --> URI Class Initialized
INFO - 2018-05-04 07:28:26 --> Router Class Initialized
INFO - 2018-05-04 07:28:26 --> Output Class Initialized
INFO - 2018-05-04 07:28:26 --> Security Class Initialized
DEBUG - 2018-05-04 07:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:28:26 --> Input Class Initialized
INFO - 2018-05-04 07:28:26 --> Language Class Initialized
INFO - 2018-05-04 07:28:26 --> Loader Class Initialized
INFO - 2018-05-04 07:28:26 --> Helper loaded: common_helper
INFO - 2018-05-04 07:28:26 --> Database Driver Class Initialized
INFO - 2018-05-04 07:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:28:26 --> Email Class Initialized
INFO - 2018-05-04 07:28:26 --> Controller Class Initialized
INFO - 2018-05-04 07:28:26 --> Helper loaded: form_helper
INFO - 2018-05-04 07:28:26 --> Form Validation Class Initialized
INFO - 2018-05-04 07:28:26 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:28:26 --> Helper loaded: url_helper
INFO - 2018-05-04 07:28:26 --> Model Class Initialized
INFO - 2018-05-04 07:28:26 --> Model Class Initialized
INFO - 2018-05-04 07:28:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:28:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:28:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:28:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/addFoundation.php
INFO - 2018-05-04 07:28:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:28:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:28:26 --> Final output sent to browser
DEBUG - 2018-05-04 07:28:26 --> Total execution time: 0.1250
INFO - 2018-05-04 07:28:38 --> Config Class Initialized
INFO - 2018-05-04 07:28:38 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:28:38 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:28:38 --> Utf8 Class Initialized
INFO - 2018-05-04 07:28:38 --> URI Class Initialized
INFO - 2018-05-04 07:28:38 --> Router Class Initialized
INFO - 2018-05-04 07:28:38 --> Output Class Initialized
INFO - 2018-05-04 07:28:38 --> Security Class Initialized
DEBUG - 2018-05-04 07:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:28:38 --> Input Class Initialized
INFO - 2018-05-04 07:28:38 --> Language Class Initialized
INFO - 2018-05-04 07:28:38 --> Loader Class Initialized
INFO - 2018-05-04 07:28:38 --> Helper loaded: common_helper
INFO - 2018-05-04 07:28:38 --> Database Driver Class Initialized
INFO - 2018-05-04 07:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:28:38 --> Email Class Initialized
INFO - 2018-05-04 07:28:38 --> Controller Class Initialized
INFO - 2018-05-04 07:28:38 --> Helper loaded: form_helper
INFO - 2018-05-04 07:28:38 --> Form Validation Class Initialized
INFO - 2018-05-04 07:28:38 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:28:38 --> Helper loaded: url_helper
INFO - 2018-05-04 07:28:38 --> Model Class Initialized
INFO - 2018-05-04 07:28:38 --> Model Class Initialized
INFO - 2018-05-04 07:28:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:28:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:28:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:28:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-04 07:28:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:28:38 --> Final output sent to browser
DEBUG - 2018-05-04 07:28:38 --> Total execution time: 0.1460
INFO - 2018-05-04 07:28:40 --> Config Class Initialized
INFO - 2018-05-04 07:28:40 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:28:40 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:28:40 --> Utf8 Class Initialized
INFO - 2018-05-04 07:28:40 --> URI Class Initialized
INFO - 2018-05-04 07:28:40 --> Router Class Initialized
INFO - 2018-05-04 07:28:40 --> Output Class Initialized
INFO - 2018-05-04 07:28:40 --> Security Class Initialized
DEBUG - 2018-05-04 07:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:28:40 --> Input Class Initialized
INFO - 2018-05-04 07:28:40 --> Language Class Initialized
INFO - 2018-05-04 07:28:40 --> Loader Class Initialized
INFO - 2018-05-04 07:28:40 --> Helper loaded: common_helper
INFO - 2018-05-04 07:28:40 --> Database Driver Class Initialized
INFO - 2018-05-04 07:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:28:40 --> Email Class Initialized
INFO - 2018-05-04 07:28:40 --> Controller Class Initialized
INFO - 2018-05-04 07:28:40 --> Helper loaded: form_helper
INFO - 2018-05-04 07:28:40 --> Form Validation Class Initialized
INFO - 2018-05-04 07:28:40 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:28:40 --> Helper loaded: url_helper
INFO - 2018-05-04 07:28:40 --> Model Class Initialized
INFO - 2018-05-04 07:28:40 --> Model Class Initialized
INFO - 2018-05-04 07:28:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:28:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:28:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:28:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/addFoundation.php
INFO - 2018-05-04 07:28:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:28:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:28:40 --> Final output sent to browser
DEBUG - 2018-05-04 07:28:40 --> Total execution time: 0.1450
INFO - 2018-05-04 07:28:48 --> Config Class Initialized
INFO - 2018-05-04 07:28:48 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:28:48 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:28:48 --> Utf8 Class Initialized
INFO - 2018-05-04 07:28:48 --> URI Class Initialized
INFO - 2018-05-04 07:28:48 --> Router Class Initialized
INFO - 2018-05-04 07:28:48 --> Output Class Initialized
INFO - 2018-05-04 07:28:48 --> Security Class Initialized
DEBUG - 2018-05-04 07:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:28:48 --> Input Class Initialized
INFO - 2018-05-04 07:28:48 --> Language Class Initialized
INFO - 2018-05-04 07:28:48 --> Loader Class Initialized
INFO - 2018-05-04 07:28:48 --> Helper loaded: common_helper
INFO - 2018-05-04 07:28:48 --> Database Driver Class Initialized
INFO - 2018-05-04 07:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:28:48 --> Email Class Initialized
INFO - 2018-05-04 07:28:48 --> Controller Class Initialized
INFO - 2018-05-04 07:28:48 --> Helper loaded: form_helper
INFO - 2018-05-04 07:28:48 --> Form Validation Class Initialized
INFO - 2018-05-04 07:28:48 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:28:48 --> Helper loaded: url_helper
INFO - 2018-05-04 07:28:48 --> Model Class Initialized
INFO - 2018-05-04 07:28:48 --> Model Class Initialized
INFO - 2018-05-04 07:28:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:28:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:28:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:28:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-04 07:28:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:28:48 --> Final output sent to browser
DEBUG - 2018-05-04 07:28:48 --> Total execution time: 0.1440
INFO - 2018-05-04 07:28:52 --> Config Class Initialized
INFO - 2018-05-04 07:28:52 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:28:52 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:28:52 --> Utf8 Class Initialized
INFO - 2018-05-04 07:28:52 --> URI Class Initialized
INFO - 2018-05-04 07:28:52 --> Router Class Initialized
INFO - 2018-05-04 07:28:52 --> Output Class Initialized
INFO - 2018-05-04 07:28:52 --> Security Class Initialized
DEBUG - 2018-05-04 07:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:28:52 --> Input Class Initialized
INFO - 2018-05-04 07:28:52 --> Language Class Initialized
INFO - 2018-05-04 07:28:52 --> Loader Class Initialized
INFO - 2018-05-04 07:28:52 --> Helper loaded: common_helper
INFO - 2018-05-04 07:28:52 --> Database Driver Class Initialized
INFO - 2018-05-04 07:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:28:52 --> Email Class Initialized
INFO - 2018-05-04 07:28:52 --> Controller Class Initialized
INFO - 2018-05-04 07:28:52 --> Helper loaded: form_helper
INFO - 2018-05-04 07:28:52 --> Form Validation Class Initialized
INFO - 2018-05-04 07:28:52 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:28:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:28:52 --> Helper loaded: url_helper
INFO - 2018-05-04 07:28:52 --> Model Class Initialized
INFO - 2018-05-04 07:28:52 --> Model Class Initialized
INFO - 2018-05-04 07:28:52 --> Model Class Initialized
INFO - 2018-05-04 10:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-04 10:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:58:52 --> Final output sent to browser
DEBUG - 2018-05-04 10:58:52 --> Total execution time: 0.1360
INFO - 2018-05-04 07:28:53 --> Config Class Initialized
INFO - 2018-05-04 07:28:53 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:28:53 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:28:53 --> Utf8 Class Initialized
INFO - 2018-05-04 07:28:53 --> URI Class Initialized
INFO - 2018-05-04 07:28:53 --> Router Class Initialized
INFO - 2018-05-04 07:28:53 --> Output Class Initialized
INFO - 2018-05-04 07:28:53 --> Security Class Initialized
DEBUG - 2018-05-04 07:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:28:53 --> Input Class Initialized
INFO - 2018-05-04 07:28:53 --> Language Class Initialized
INFO - 2018-05-04 07:28:53 --> Loader Class Initialized
INFO - 2018-05-04 07:28:53 --> Helper loaded: common_helper
INFO - 2018-05-04 07:28:53 --> Database Driver Class Initialized
INFO - 2018-05-04 07:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:28:53 --> Email Class Initialized
INFO - 2018-05-04 07:28:54 --> Controller Class Initialized
INFO - 2018-05-04 07:28:54 --> Helper loaded: form_helper
INFO - 2018-05-04 07:28:54 --> Form Validation Class Initialized
INFO - 2018-05-04 07:28:54 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:28:54 --> Helper loaded: url_helper
INFO - 2018-05-04 07:28:54 --> Model Class Initialized
INFO - 2018-05-04 07:28:54 --> Model Class Initialized
INFO - 2018-05-04 07:28:54 --> Model Class Initialized
INFO - 2018-05-04 10:58:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:58:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:58:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:58:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 10:58:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:58:54 --> Final output sent to browser
DEBUG - 2018-05-04 10:58:54 --> Total execution time: 0.1510
INFO - 2018-05-04 07:29:03 --> Config Class Initialized
INFO - 2018-05-04 07:29:03 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:29:03 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:29:03 --> Utf8 Class Initialized
INFO - 2018-05-04 07:29:03 --> URI Class Initialized
INFO - 2018-05-04 07:29:03 --> Router Class Initialized
INFO - 2018-05-04 07:29:03 --> Output Class Initialized
INFO - 2018-05-04 07:29:03 --> Security Class Initialized
DEBUG - 2018-05-04 07:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:29:03 --> Input Class Initialized
INFO - 2018-05-04 07:29:03 --> Language Class Initialized
INFO - 2018-05-04 07:29:03 --> Loader Class Initialized
INFO - 2018-05-04 07:29:03 --> Helper loaded: common_helper
INFO - 2018-05-04 07:29:03 --> Database Driver Class Initialized
INFO - 2018-05-04 07:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:29:03 --> Email Class Initialized
INFO - 2018-05-04 07:29:03 --> Controller Class Initialized
INFO - 2018-05-04 07:29:03 --> Helper loaded: form_helper
INFO - 2018-05-04 07:29:03 --> Form Validation Class Initialized
INFO - 2018-05-04 07:29:03 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:29:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:29:03 --> Helper loaded: url_helper
INFO - 2018-05-04 07:29:03 --> Model Class Initialized
INFO - 2018-05-04 07:29:03 --> Model Class Initialized
INFO - 2018-05-04 07:29:03 --> Model Class Initialized
INFO - 2018-05-04 10:59:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 10:59:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 10:59:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-04 10:59:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 10:59:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 10:59:03 --> Final output sent to browser
DEBUG - 2018-05-04 10:59:03 --> Total execution time: 0.1420
INFO - 2018-05-04 07:29:06 --> Config Class Initialized
INFO - 2018-05-04 07:29:06 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:29:06 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:29:06 --> Utf8 Class Initialized
INFO - 2018-05-04 07:29:06 --> URI Class Initialized
INFO - 2018-05-04 07:29:06 --> Router Class Initialized
INFO - 2018-05-04 07:29:06 --> Output Class Initialized
INFO - 2018-05-04 07:29:06 --> Security Class Initialized
DEBUG - 2018-05-04 07:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:29:06 --> Input Class Initialized
INFO - 2018-05-04 07:29:06 --> Language Class Initialized
INFO - 2018-05-04 07:29:06 --> Loader Class Initialized
INFO - 2018-05-04 07:29:06 --> Helper loaded: common_helper
INFO - 2018-05-04 07:29:06 --> Database Driver Class Initialized
INFO - 2018-05-04 07:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:29:06 --> Email Class Initialized
INFO - 2018-05-04 07:29:06 --> Controller Class Initialized
INFO - 2018-05-04 07:29:06 --> Helper loaded: form_helper
INFO - 2018-05-04 07:29:06 --> Form Validation Class Initialized
INFO - 2018-05-04 07:29:06 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:29:06 --> Helper loaded: url_helper
INFO - 2018-05-04 07:29:06 --> Model Class Initialized
INFO - 2018-05-04 07:29:06 --> Model Class Initialized
INFO - 2018-05-04 07:29:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:29:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:29:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:29:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-04 07:29:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:29:06 --> Final output sent to browser
DEBUG - 2018-05-04 07:29:06 --> Total execution time: 0.2090
INFO - 2018-05-04 07:29:07 --> Config Class Initialized
INFO - 2018-05-04 07:29:07 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:29:07 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:29:07 --> Utf8 Class Initialized
INFO - 2018-05-04 07:29:07 --> URI Class Initialized
INFO - 2018-05-04 07:29:07 --> Router Class Initialized
INFO - 2018-05-04 07:29:07 --> Output Class Initialized
INFO - 2018-05-04 07:29:07 --> Security Class Initialized
DEBUG - 2018-05-04 07:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:29:07 --> Input Class Initialized
INFO - 2018-05-04 07:29:07 --> Language Class Initialized
INFO - 2018-05-04 07:29:07 --> Loader Class Initialized
INFO - 2018-05-04 07:29:07 --> Helper loaded: common_helper
INFO - 2018-05-04 07:29:07 --> Database Driver Class Initialized
INFO - 2018-05-04 07:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:29:07 --> Email Class Initialized
INFO - 2018-05-04 07:29:07 --> Controller Class Initialized
INFO - 2018-05-04 07:29:07 --> Helper loaded: form_helper
INFO - 2018-05-04 07:29:07 --> Form Validation Class Initialized
INFO - 2018-05-04 07:29:07 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:29:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:29:07 --> Helper loaded: url_helper
INFO - 2018-05-04 07:29:07 --> Model Class Initialized
INFO - 2018-05-04 07:29:07 --> Model Class Initialized
INFO - 2018-05-04 07:29:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:29:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 07:29:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:29:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:29:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/addSocialService.php
INFO - 2018-05-04 07:29:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:29:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:29:07 --> Final output sent to browser
DEBUG - 2018-05-04 07:29:07 --> Total execution time: 0.1720
INFO - 2018-05-04 07:31:09 --> Config Class Initialized
INFO - 2018-05-04 07:31:09 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:31:09 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:31:09 --> Utf8 Class Initialized
INFO - 2018-05-04 07:31:09 --> URI Class Initialized
INFO - 2018-05-04 07:31:09 --> Router Class Initialized
INFO - 2018-05-04 07:31:09 --> Output Class Initialized
INFO - 2018-05-04 07:31:09 --> Security Class Initialized
DEBUG - 2018-05-04 07:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:31:09 --> Input Class Initialized
INFO - 2018-05-04 07:31:09 --> Language Class Initialized
INFO - 2018-05-04 07:31:09 --> Loader Class Initialized
INFO - 2018-05-04 07:31:09 --> Helper loaded: common_helper
INFO - 2018-05-04 07:31:09 --> Database Driver Class Initialized
INFO - 2018-05-04 07:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:31:09 --> Email Class Initialized
INFO - 2018-05-04 07:31:09 --> Controller Class Initialized
INFO - 2018-05-04 07:31:09 --> Helper loaded: form_helper
INFO - 2018-05-04 07:31:09 --> Form Validation Class Initialized
INFO - 2018-05-04 07:31:09 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:31:09 --> Helper loaded: url_helper
INFO - 2018-05-04 07:31:09 --> Model Class Initialized
INFO - 2018-05-04 07:31:09 --> Model Class Initialized
INFO - 2018-05-04 07:31:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:31:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 07:31:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:31:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:31:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/addSocialService.php
INFO - 2018-05-04 07:31:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:31:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:31:09 --> Final output sent to browser
DEBUG - 2018-05-04 07:31:09 --> Total execution time: 0.1275
INFO - 2018-05-04 07:34:43 --> Config Class Initialized
INFO - 2018-05-04 07:34:43 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:34:43 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:34:43 --> Utf8 Class Initialized
INFO - 2018-05-04 07:34:43 --> URI Class Initialized
INFO - 2018-05-04 07:34:43 --> Router Class Initialized
INFO - 2018-05-04 07:34:43 --> Output Class Initialized
INFO - 2018-05-04 07:34:43 --> Security Class Initialized
DEBUG - 2018-05-04 07:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:34:43 --> Input Class Initialized
INFO - 2018-05-04 07:34:43 --> Language Class Initialized
INFO - 2018-05-04 07:34:43 --> Loader Class Initialized
INFO - 2018-05-04 07:34:43 --> Helper loaded: common_helper
INFO - 2018-05-04 07:34:43 --> Database Driver Class Initialized
INFO - 2018-05-04 07:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:34:43 --> Email Class Initialized
INFO - 2018-05-04 07:34:43 --> Controller Class Initialized
INFO - 2018-05-04 07:34:43 --> Helper loaded: form_helper
INFO - 2018-05-04 07:34:43 --> Form Validation Class Initialized
INFO - 2018-05-04 07:34:43 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:34:43 --> Helper loaded: url_helper
INFO - 2018-05-04 07:34:43 --> Model Class Initialized
INFO - 2018-05-04 07:34:43 --> Model Class Initialized
INFO - 2018-05-04 07:34:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:34:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 07:34:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:34:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:34:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/addSocialService.php
INFO - 2018-05-04 07:34:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:34:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:34:43 --> Final output sent to browser
DEBUG - 2018-05-04 07:34:43 --> Total execution time: 0.1320
INFO - 2018-05-04 07:35:14 --> Config Class Initialized
INFO - 2018-05-04 07:35:14 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:35:14 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:35:14 --> Utf8 Class Initialized
INFO - 2018-05-04 07:35:14 --> URI Class Initialized
INFO - 2018-05-04 07:35:14 --> Router Class Initialized
INFO - 2018-05-04 07:35:14 --> Output Class Initialized
INFO - 2018-05-04 07:35:14 --> Security Class Initialized
DEBUG - 2018-05-04 07:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:35:14 --> Input Class Initialized
INFO - 2018-05-04 07:35:14 --> Language Class Initialized
INFO - 2018-05-04 07:35:14 --> Loader Class Initialized
INFO - 2018-05-04 07:35:14 --> Helper loaded: common_helper
INFO - 2018-05-04 07:35:14 --> Database Driver Class Initialized
INFO - 2018-05-04 07:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:35:14 --> Email Class Initialized
INFO - 2018-05-04 07:35:14 --> Controller Class Initialized
INFO - 2018-05-04 07:35:14 --> Helper loaded: form_helper
INFO - 2018-05-04 07:35:14 --> Form Validation Class Initialized
INFO - 2018-05-04 07:35:14 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:35:14 --> Helper loaded: url_helper
INFO - 2018-05-04 07:35:14 --> Model Class Initialized
INFO - 2018-05-04 07:35:14 --> Model Class Initialized
INFO - 2018-05-04 07:35:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:35:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 07:35:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:35:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:35:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/addSocialService.php
INFO - 2018-05-04 07:35:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:35:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:35:14 --> Final output sent to browser
DEBUG - 2018-05-04 07:35:14 --> Total execution time: 0.1350
INFO - 2018-05-04 07:36:07 --> Config Class Initialized
INFO - 2018-05-04 07:36:07 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:36:07 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:36:07 --> Utf8 Class Initialized
INFO - 2018-05-04 07:36:07 --> URI Class Initialized
INFO - 2018-05-04 07:36:07 --> Router Class Initialized
INFO - 2018-05-04 07:36:07 --> Output Class Initialized
INFO - 2018-05-04 07:36:07 --> Security Class Initialized
DEBUG - 2018-05-04 07:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:36:07 --> Input Class Initialized
INFO - 2018-05-04 07:36:07 --> Language Class Initialized
INFO - 2018-05-04 07:36:07 --> Loader Class Initialized
INFO - 2018-05-04 07:36:07 --> Helper loaded: common_helper
INFO - 2018-05-04 07:36:07 --> Database Driver Class Initialized
INFO - 2018-05-04 07:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:36:07 --> Email Class Initialized
INFO - 2018-05-04 07:36:07 --> Controller Class Initialized
INFO - 2018-05-04 07:36:07 --> Helper loaded: form_helper
INFO - 2018-05-04 07:36:07 --> Form Validation Class Initialized
INFO - 2018-05-04 07:36:07 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:36:07 --> Helper loaded: url_helper
INFO - 2018-05-04 07:36:07 --> Model Class Initialized
INFO - 2018-05-04 07:36:07 --> Model Class Initialized
INFO - 2018-05-04 07:36:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:36:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 07:36:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:36:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:36:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/addSocialService.php
INFO - 2018-05-04 07:36:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:36:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:36:07 --> Final output sent to browser
DEBUG - 2018-05-04 07:36:07 --> Total execution time: 0.1320
INFO - 2018-05-04 07:36:53 --> Config Class Initialized
INFO - 2018-05-04 07:36:53 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:36:53 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:36:53 --> Utf8 Class Initialized
INFO - 2018-05-04 07:36:53 --> URI Class Initialized
INFO - 2018-05-04 07:36:53 --> Router Class Initialized
INFO - 2018-05-04 07:36:53 --> Output Class Initialized
INFO - 2018-05-04 07:36:53 --> Security Class Initialized
DEBUG - 2018-05-04 07:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:36:53 --> Input Class Initialized
INFO - 2018-05-04 07:36:53 --> Language Class Initialized
INFO - 2018-05-04 07:36:53 --> Loader Class Initialized
INFO - 2018-05-04 07:36:53 --> Helper loaded: common_helper
INFO - 2018-05-04 07:36:53 --> Database Driver Class Initialized
INFO - 2018-05-04 07:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:36:53 --> Email Class Initialized
INFO - 2018-05-04 07:36:53 --> Controller Class Initialized
INFO - 2018-05-04 07:36:53 --> Helper loaded: form_helper
INFO - 2018-05-04 07:36:53 --> Form Validation Class Initialized
INFO - 2018-05-04 07:36:53 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:36:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:36:53 --> Helper loaded: url_helper
INFO - 2018-05-04 07:36:53 --> Model Class Initialized
INFO - 2018-05-04 07:36:53 --> Model Class Initialized
INFO - 2018-05-04 07:36:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:36:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 07:36:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:36:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:36:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/addSocialService.php
INFO - 2018-05-04 07:36:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:36:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:36:53 --> Final output sent to browser
DEBUG - 2018-05-04 07:36:53 --> Total execution time: 0.1375
INFO - 2018-05-04 07:37:35 --> Config Class Initialized
INFO - 2018-05-04 07:37:35 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:37:35 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:37:35 --> Utf8 Class Initialized
INFO - 2018-05-04 07:37:35 --> URI Class Initialized
INFO - 2018-05-04 07:37:35 --> Router Class Initialized
INFO - 2018-05-04 07:37:35 --> Output Class Initialized
INFO - 2018-05-04 07:37:35 --> Security Class Initialized
DEBUG - 2018-05-04 07:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:37:35 --> Input Class Initialized
INFO - 2018-05-04 07:37:35 --> Language Class Initialized
INFO - 2018-05-04 07:37:35 --> Loader Class Initialized
INFO - 2018-05-04 07:37:35 --> Helper loaded: common_helper
INFO - 2018-05-04 07:37:35 --> Database Driver Class Initialized
INFO - 2018-05-04 07:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:37:35 --> Email Class Initialized
INFO - 2018-05-04 07:37:35 --> Controller Class Initialized
INFO - 2018-05-04 07:37:35 --> Helper loaded: form_helper
INFO - 2018-05-04 07:37:35 --> Form Validation Class Initialized
INFO - 2018-05-04 07:37:35 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:37:36 --> Helper loaded: url_helper
INFO - 2018-05-04 07:37:36 --> Model Class Initialized
INFO - 2018-05-04 07:37:36 --> Model Class Initialized
INFO - 2018-05-04 07:37:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 07:37:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 07:37:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 07:37:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-04 07:37:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 07:37:36 --> Final output sent to browser
DEBUG - 2018-05-04 07:37:36 --> Total execution time: 0.1530
INFO - 2018-05-04 07:37:39 --> Config Class Initialized
INFO - 2018-05-04 07:37:39 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:37:39 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:37:39 --> Utf8 Class Initialized
INFO - 2018-05-04 07:37:39 --> URI Class Initialized
INFO - 2018-05-04 07:37:39 --> Router Class Initialized
INFO - 2018-05-04 07:37:40 --> Output Class Initialized
INFO - 2018-05-04 07:37:40 --> Security Class Initialized
DEBUG - 2018-05-04 07:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:37:40 --> Input Class Initialized
INFO - 2018-05-04 07:37:40 --> Language Class Initialized
INFO - 2018-05-04 07:37:40 --> Loader Class Initialized
INFO - 2018-05-04 07:37:40 --> Helper loaded: common_helper
INFO - 2018-05-04 07:37:40 --> Database Driver Class Initialized
INFO - 2018-05-04 07:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:37:40 --> Email Class Initialized
INFO - 2018-05-04 07:37:40 --> Controller Class Initialized
INFO - 2018-05-04 07:37:40 --> Helper loaded: form_helper
INFO - 2018-05-04 07:37:40 --> Form Validation Class Initialized
INFO - 2018-05-04 07:37:40 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:37:40 --> Helper loaded: url_helper
INFO - 2018-05-04 07:37:40 --> Model Class Initialized
INFO - 2018-05-04 07:37:40 --> Model Class Initialized
INFO - 2018-05-04 07:37:40 --> Model Class Initialized
INFO - 2018-05-04 11:07:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:07:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:07:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-04 11:07:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:07:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:07:40 --> Final output sent to browser
DEBUG - 2018-05-04 11:07:40 --> Total execution time: 0.1360
INFO - 2018-05-04 07:37:42 --> Config Class Initialized
INFO - 2018-05-04 07:37:42 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:37:42 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:37:42 --> Utf8 Class Initialized
INFO - 2018-05-04 07:37:42 --> URI Class Initialized
INFO - 2018-05-04 07:37:42 --> Router Class Initialized
INFO - 2018-05-04 07:37:42 --> Output Class Initialized
INFO - 2018-05-04 07:37:42 --> Security Class Initialized
DEBUG - 2018-05-04 07:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:37:42 --> Input Class Initialized
INFO - 2018-05-04 07:37:42 --> Language Class Initialized
INFO - 2018-05-04 07:37:42 --> Loader Class Initialized
INFO - 2018-05-04 07:37:42 --> Helper loaded: common_helper
INFO - 2018-05-04 07:37:42 --> Database Driver Class Initialized
INFO - 2018-05-04 07:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:37:42 --> Email Class Initialized
INFO - 2018-05-04 07:37:42 --> Controller Class Initialized
INFO - 2018-05-04 07:37:42 --> Helper loaded: form_helper
INFO - 2018-05-04 07:37:42 --> Form Validation Class Initialized
INFO - 2018-05-04 07:37:42 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:37:42 --> Helper loaded: url_helper
INFO - 2018-05-04 07:37:42 --> Model Class Initialized
INFO - 2018-05-04 07:37:42 --> Model Class Initialized
INFO - 2018-05-04 07:37:42 --> Model Class Initialized
INFO - 2018-05-04 11:07:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:07:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:07:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:07:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:07:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:07:42 --> Final output sent to browser
DEBUG - 2018-05-04 11:07:42 --> Total execution time: 0.1390
INFO - 2018-05-04 07:37:46 --> Config Class Initialized
INFO - 2018-05-04 07:37:46 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:37:46 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:37:46 --> Utf8 Class Initialized
INFO - 2018-05-04 07:37:46 --> URI Class Initialized
INFO - 2018-05-04 07:37:46 --> Router Class Initialized
INFO - 2018-05-04 07:37:46 --> Output Class Initialized
INFO - 2018-05-04 07:37:46 --> Security Class Initialized
DEBUG - 2018-05-04 07:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:37:46 --> Input Class Initialized
INFO - 2018-05-04 07:37:46 --> Language Class Initialized
INFO - 2018-05-04 07:37:46 --> Loader Class Initialized
INFO - 2018-05-04 07:37:46 --> Helper loaded: common_helper
INFO - 2018-05-04 07:37:46 --> Database Driver Class Initialized
INFO - 2018-05-04 07:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:37:46 --> Email Class Initialized
INFO - 2018-05-04 07:37:46 --> Controller Class Initialized
INFO - 2018-05-04 07:37:46 --> Helper loaded: form_helper
INFO - 2018-05-04 07:37:46 --> Form Validation Class Initialized
INFO - 2018-05-04 07:37:46 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:37:46 --> Helper loaded: url_helper
INFO - 2018-05-04 07:37:46 --> Model Class Initialized
INFO - 2018-05-04 07:37:46 --> Model Class Initialized
INFO - 2018-05-04 07:37:46 --> Model Class Initialized
INFO - 2018-05-04 11:07:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:07:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:07:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:07:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/aboutMovie.php
INFO - 2018-05-04 11:07:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:07:46 --> Final output sent to browser
DEBUG - 2018-05-04 11:07:46 --> Total execution time: 0.1330
INFO - 2018-05-04 07:37:47 --> Config Class Initialized
INFO - 2018-05-04 07:37:47 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:37:47 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:37:47 --> Utf8 Class Initialized
INFO - 2018-05-04 07:37:47 --> URI Class Initialized
INFO - 2018-05-04 07:37:47 --> Router Class Initialized
INFO - 2018-05-04 07:37:47 --> Output Class Initialized
INFO - 2018-05-04 07:37:47 --> Security Class Initialized
DEBUG - 2018-05-04 07:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:37:47 --> Input Class Initialized
INFO - 2018-05-04 07:37:47 --> Language Class Initialized
INFO - 2018-05-04 07:37:47 --> Loader Class Initialized
INFO - 2018-05-04 07:37:47 --> Helper loaded: common_helper
INFO - 2018-05-04 07:37:47 --> Database Driver Class Initialized
INFO - 2018-05-04 07:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:37:47 --> Email Class Initialized
INFO - 2018-05-04 07:37:47 --> Controller Class Initialized
INFO - 2018-05-04 07:37:48 --> Helper loaded: form_helper
INFO - 2018-05-04 07:37:48 --> Form Validation Class Initialized
INFO - 2018-05-04 07:37:48 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:37:48 --> Helper loaded: url_helper
INFO - 2018-05-04 07:37:48 --> Model Class Initialized
INFO - 2018-05-04 07:37:48 --> Model Class Initialized
INFO - 2018-05-04 07:37:48 --> Model Class Initialized
INFO - 2018-05-04 11:07:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:07:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:07:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:07:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:07:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:07:48 --> Final output sent to browser
DEBUG - 2018-05-04 11:07:48 --> Total execution time: 0.1480
INFO - 2018-05-04 07:37:54 --> Config Class Initialized
INFO - 2018-05-04 07:37:54 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:37:54 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:37:54 --> Utf8 Class Initialized
INFO - 2018-05-04 07:37:54 --> URI Class Initialized
INFO - 2018-05-04 07:37:54 --> Router Class Initialized
INFO - 2018-05-04 07:37:54 --> Output Class Initialized
INFO - 2018-05-04 07:37:54 --> Security Class Initialized
DEBUG - 2018-05-04 07:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:37:54 --> Input Class Initialized
INFO - 2018-05-04 07:37:54 --> Language Class Initialized
INFO - 2018-05-04 07:37:54 --> Loader Class Initialized
INFO - 2018-05-04 07:37:54 --> Helper loaded: common_helper
INFO - 2018-05-04 07:37:54 --> Database Driver Class Initialized
INFO - 2018-05-04 07:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:37:54 --> Email Class Initialized
INFO - 2018-05-04 07:37:54 --> Controller Class Initialized
INFO - 2018-05-04 07:37:54 --> Helper loaded: form_helper
INFO - 2018-05-04 07:37:54 --> Form Validation Class Initialized
INFO - 2018-05-04 07:37:54 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:37:54 --> Helper loaded: url_helper
INFO - 2018-05-04 07:37:54 --> Model Class Initialized
INFO - 2018-05-04 07:37:54 --> Model Class Initialized
INFO - 2018-05-04 07:37:54 --> Model Class Initialized
INFO - 2018-05-04 11:07:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:07:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:07:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:07:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:07:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:07:55 --> Final output sent to browser
DEBUG - 2018-05-04 11:07:55 --> Total execution time: 0.1390
INFO - 2018-05-04 07:37:57 --> Config Class Initialized
INFO - 2018-05-04 07:37:57 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:37:57 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:37:57 --> Utf8 Class Initialized
INFO - 2018-05-04 07:37:57 --> URI Class Initialized
INFO - 2018-05-04 07:37:57 --> Router Class Initialized
INFO - 2018-05-04 07:37:57 --> Output Class Initialized
INFO - 2018-05-04 07:37:57 --> Security Class Initialized
DEBUG - 2018-05-04 07:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:37:57 --> Input Class Initialized
INFO - 2018-05-04 07:37:57 --> Language Class Initialized
INFO - 2018-05-04 07:37:57 --> Loader Class Initialized
INFO - 2018-05-04 07:37:57 --> Helper loaded: common_helper
INFO - 2018-05-04 07:37:57 --> Database Driver Class Initialized
INFO - 2018-05-04 07:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:37:57 --> Email Class Initialized
INFO - 2018-05-04 07:37:57 --> Controller Class Initialized
INFO - 2018-05-04 07:37:57 --> Helper loaded: form_helper
INFO - 2018-05-04 07:37:57 --> Form Validation Class Initialized
INFO - 2018-05-04 07:37:57 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:37:57 --> Helper loaded: url_helper
INFO - 2018-05-04 07:37:57 --> Model Class Initialized
INFO - 2018-05-04 07:37:57 --> Model Class Initialized
INFO - 2018-05-04 07:37:57 --> Model Class Initialized
INFO - 2018-05-04 11:07:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:07:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:07:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:07:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:07:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:07:57 --> Final output sent to browser
DEBUG - 2018-05-04 11:07:57 --> Total execution time: 0.2810
INFO - 2018-05-04 07:38:00 --> Config Class Initialized
INFO - 2018-05-04 07:38:00 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:00 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:00 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:00 --> URI Class Initialized
INFO - 2018-05-04 07:38:00 --> Router Class Initialized
INFO - 2018-05-04 07:38:00 --> Output Class Initialized
INFO - 2018-05-04 07:38:00 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:00 --> Input Class Initialized
INFO - 2018-05-04 07:38:00 --> Language Class Initialized
INFO - 2018-05-04 07:38:00 --> Loader Class Initialized
INFO - 2018-05-04 07:38:00 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:00 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:00 --> Email Class Initialized
INFO - 2018-05-04 07:38:00 --> Controller Class Initialized
INFO - 2018-05-04 07:38:00 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:00 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:00 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:00 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:00 --> Model Class Initialized
INFO - 2018-05-04 07:38:00 --> Model Class Initialized
INFO - 2018-05-04 07:38:00 --> Model Class Initialized
INFO - 2018-05-04 11:08:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:08:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:00 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:00 --> Total execution time: 0.1450
INFO - 2018-05-04 07:38:08 --> Config Class Initialized
INFO - 2018-05-04 07:38:08 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:08 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:08 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:08 --> URI Class Initialized
INFO - 2018-05-04 07:38:08 --> Router Class Initialized
INFO - 2018-05-04 07:38:08 --> Output Class Initialized
INFO - 2018-05-04 07:38:08 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:08 --> Input Class Initialized
INFO - 2018-05-04 07:38:08 --> Language Class Initialized
INFO - 2018-05-04 07:38:08 --> Loader Class Initialized
INFO - 2018-05-04 07:38:08 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:08 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:08 --> Email Class Initialized
INFO - 2018-05-04 07:38:08 --> Controller Class Initialized
INFO - 2018-05-04 07:38:08 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:08 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:08 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:08 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:08 --> Model Class Initialized
INFO - 2018-05-04 07:38:08 --> Model Class Initialized
INFO - 2018-05-04 07:38:08 --> Model Class Initialized
INFO - 2018-05-04 11:08:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-04 11:08:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:08 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:08 --> Total execution time: 0.1560
INFO - 2018-05-04 07:38:24 --> Config Class Initialized
INFO - 2018-05-04 07:38:24 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:24 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:24 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:24 --> URI Class Initialized
INFO - 2018-05-04 07:38:24 --> Router Class Initialized
INFO - 2018-05-04 07:38:24 --> Output Class Initialized
INFO - 2018-05-04 07:38:24 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:24 --> Input Class Initialized
INFO - 2018-05-04 07:38:24 --> Language Class Initialized
INFO - 2018-05-04 07:38:24 --> Loader Class Initialized
INFO - 2018-05-04 07:38:24 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:24 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:24 --> Email Class Initialized
INFO - 2018-05-04 07:38:24 --> Controller Class Initialized
INFO - 2018-05-04 07:38:24 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:24 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:24 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:24 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:24 --> Model Class Initialized
INFO - 2018-05-04 07:38:24 --> Model Class Initialized
INFO - 2018-05-04 07:38:24 --> Model Class Initialized
DEBUG - 2018-05-04 11:08:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-04 11:08:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-04 07:38:24 --> Config Class Initialized
INFO - 2018-05-04 07:38:24 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:24 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:24 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:24 --> URI Class Initialized
INFO - 2018-05-04 07:38:24 --> Router Class Initialized
INFO - 2018-05-04 07:38:24 --> Output Class Initialized
INFO - 2018-05-04 07:38:24 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:24 --> Input Class Initialized
INFO - 2018-05-04 07:38:24 --> Language Class Initialized
INFO - 2018-05-04 07:38:24 --> Loader Class Initialized
INFO - 2018-05-04 07:38:24 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:24 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:24 --> Email Class Initialized
INFO - 2018-05-04 07:38:24 --> Controller Class Initialized
INFO - 2018-05-04 07:38:24 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:24 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:24 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:24 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:24 --> Model Class Initialized
INFO - 2018-05-04 07:38:24 --> Model Class Initialized
INFO - 2018-05-04 07:38:24 --> Model Class Initialized
INFO - 2018-05-04 11:08:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:08:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:24 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:24 --> Total execution time: 0.1330
INFO - 2018-05-04 07:38:27 --> Config Class Initialized
INFO - 2018-05-04 07:38:27 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:27 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:27 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:27 --> URI Class Initialized
INFO - 2018-05-04 07:38:27 --> Router Class Initialized
INFO - 2018-05-04 07:38:27 --> Output Class Initialized
INFO - 2018-05-04 07:38:27 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:27 --> Input Class Initialized
INFO - 2018-05-04 07:38:27 --> Language Class Initialized
INFO - 2018-05-04 07:38:27 --> Loader Class Initialized
INFO - 2018-05-04 07:38:27 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:27 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:27 --> Email Class Initialized
INFO - 2018-05-04 07:38:27 --> Controller Class Initialized
INFO - 2018-05-04 07:38:27 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:27 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:27 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:27 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:27 --> Model Class Initialized
INFO - 2018-05-04 07:38:27 --> Model Class Initialized
INFO - 2018-05-04 07:38:27 --> Model Class Initialized
INFO - 2018-05-04 11:08:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:08:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:27 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:27 --> Total execution time: 0.1300
INFO - 2018-05-04 07:38:30 --> Config Class Initialized
INFO - 2018-05-04 07:38:30 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:30 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:30 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:30 --> URI Class Initialized
INFO - 2018-05-04 07:38:30 --> Router Class Initialized
INFO - 2018-05-04 07:38:30 --> Output Class Initialized
INFO - 2018-05-04 07:38:30 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:30 --> Input Class Initialized
INFO - 2018-05-04 07:38:30 --> Language Class Initialized
INFO - 2018-05-04 07:38:30 --> Loader Class Initialized
INFO - 2018-05-04 07:38:30 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:30 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:30 --> Email Class Initialized
INFO - 2018-05-04 07:38:30 --> Controller Class Initialized
INFO - 2018-05-04 07:38:30 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:30 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:30 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:30 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:30 --> Model Class Initialized
INFO - 2018-05-04 07:38:30 --> Model Class Initialized
INFO - 2018-05-04 07:38:30 --> Model Class Initialized
INFO - 2018-05-04 11:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:08:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:30 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:30 --> Total execution time: 0.1340
INFO - 2018-05-04 07:38:37 --> Config Class Initialized
INFO - 2018-05-04 07:38:37 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:37 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:38 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:38 --> URI Class Initialized
INFO - 2018-05-04 07:38:38 --> Router Class Initialized
INFO - 2018-05-04 07:38:38 --> Output Class Initialized
INFO - 2018-05-04 07:38:38 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:38 --> Input Class Initialized
INFO - 2018-05-04 07:38:38 --> Language Class Initialized
INFO - 2018-05-04 07:38:38 --> Loader Class Initialized
INFO - 2018-05-04 07:38:38 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:38 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:38 --> Email Class Initialized
INFO - 2018-05-04 07:38:38 --> Controller Class Initialized
INFO - 2018-05-04 07:38:38 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:38 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:38 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:38 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:38 --> Model Class Initialized
INFO - 2018-05-04 07:38:38 --> Model Class Initialized
INFO - 2018-05-04 07:38:38 --> Model Class Initialized
INFO - 2018-05-04 11:08:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:08:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:38 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:38 --> Total execution time: 0.1460
INFO - 2018-05-04 07:38:39 --> Config Class Initialized
INFO - 2018-05-04 07:38:39 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:39 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:39 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:39 --> URI Class Initialized
INFO - 2018-05-04 07:38:39 --> Router Class Initialized
INFO - 2018-05-04 07:38:39 --> Output Class Initialized
INFO - 2018-05-04 07:38:39 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:39 --> Input Class Initialized
INFO - 2018-05-04 07:38:39 --> Language Class Initialized
INFO - 2018-05-04 07:38:39 --> Loader Class Initialized
INFO - 2018-05-04 07:38:39 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:39 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:39 --> Email Class Initialized
INFO - 2018-05-04 07:38:39 --> Controller Class Initialized
INFO - 2018-05-04 07:38:39 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:39 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:39 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:39 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:39 --> Model Class Initialized
INFO - 2018-05-04 07:38:39 --> Model Class Initialized
INFO - 2018-05-04 07:38:39 --> Model Class Initialized
INFO - 2018-05-04 11:08:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:08:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:39 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:39 --> Total execution time: 0.1340
INFO - 2018-05-04 07:38:42 --> Config Class Initialized
INFO - 2018-05-04 07:38:42 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:42 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:42 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:42 --> URI Class Initialized
INFO - 2018-05-04 07:38:42 --> Router Class Initialized
INFO - 2018-05-04 07:38:42 --> Output Class Initialized
INFO - 2018-05-04 07:38:42 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:42 --> Input Class Initialized
INFO - 2018-05-04 07:38:42 --> Language Class Initialized
INFO - 2018-05-04 07:38:42 --> Loader Class Initialized
INFO - 2018-05-04 07:38:42 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:42 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:42 --> Email Class Initialized
INFO - 2018-05-04 07:38:42 --> Controller Class Initialized
INFO - 2018-05-04 07:38:42 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:42 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:42 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:42 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:42 --> Model Class Initialized
INFO - 2018-05-04 07:38:42 --> Model Class Initialized
INFO - 2018-05-04 07:38:42 --> Model Class Initialized
INFO - 2018-05-04 11:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:42 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:42 --> Total execution time: 0.1590
INFO - 2018-05-04 07:38:43 --> Config Class Initialized
INFO - 2018-05-04 07:38:43 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:43 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:43 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:43 --> URI Class Initialized
INFO - 2018-05-04 07:38:43 --> Router Class Initialized
INFO - 2018-05-04 07:38:43 --> Output Class Initialized
INFO - 2018-05-04 07:38:43 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:43 --> Input Class Initialized
INFO - 2018-05-04 07:38:43 --> Language Class Initialized
INFO - 2018-05-04 07:38:43 --> Loader Class Initialized
INFO - 2018-05-04 07:38:43 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:43 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:43 --> Email Class Initialized
INFO - 2018-05-04 07:38:43 --> Controller Class Initialized
INFO - 2018-05-04 07:38:43 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:43 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:43 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:43 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:43 --> Model Class Initialized
INFO - 2018-05-04 07:38:43 --> Model Class Initialized
INFO - 2018-05-04 07:38:43 --> Model Class Initialized
INFO - 2018-05-04 11:08:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:08:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:43 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:43 --> Total execution time: 0.1330
INFO - 2018-05-04 07:38:44 --> Config Class Initialized
INFO - 2018-05-04 07:38:44 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:44 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:44 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:44 --> URI Class Initialized
INFO - 2018-05-04 07:38:44 --> Router Class Initialized
INFO - 2018-05-04 07:38:44 --> Output Class Initialized
INFO - 2018-05-04 07:38:44 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:44 --> Input Class Initialized
INFO - 2018-05-04 07:38:44 --> Language Class Initialized
INFO - 2018-05-04 07:38:44 --> Loader Class Initialized
INFO - 2018-05-04 07:38:44 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:44 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:45 --> Email Class Initialized
INFO - 2018-05-04 07:38:45 --> Controller Class Initialized
INFO - 2018-05-04 07:38:45 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:45 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:45 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:45 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:45 --> Model Class Initialized
INFO - 2018-05-04 07:38:45 --> Model Class Initialized
INFO - 2018-05-04 07:38:45 --> Model Class Initialized
INFO - 2018-05-04 11:08:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:08:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:45 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:45 --> Total execution time: 0.1450
INFO - 2018-05-04 07:38:50 --> Config Class Initialized
INFO - 2018-05-04 07:38:50 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:50 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:50 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:50 --> URI Class Initialized
INFO - 2018-05-04 07:38:50 --> Router Class Initialized
INFO - 2018-05-04 07:38:50 --> Output Class Initialized
INFO - 2018-05-04 07:38:50 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:50 --> Input Class Initialized
INFO - 2018-05-04 07:38:50 --> Language Class Initialized
INFO - 2018-05-04 07:38:50 --> Loader Class Initialized
INFO - 2018-05-04 07:38:50 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:50 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:50 --> Email Class Initialized
INFO - 2018-05-04 07:38:50 --> Controller Class Initialized
INFO - 2018-05-04 07:38:50 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:50 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:50 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:50 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:50 --> Model Class Initialized
INFO - 2018-05-04 07:38:50 --> Model Class Initialized
INFO - 2018-05-04 07:38:50 --> Model Class Initialized
INFO - 2018-05-04 11:08:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:08:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:50 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:50 --> Total execution time: 0.1470
INFO - 2018-05-04 07:38:55 --> Config Class Initialized
INFO - 2018-05-04 07:38:55 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:55 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:55 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:55 --> URI Class Initialized
INFO - 2018-05-04 07:38:55 --> Router Class Initialized
INFO - 2018-05-04 07:38:55 --> Output Class Initialized
INFO - 2018-05-04 07:38:55 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:55 --> Input Class Initialized
INFO - 2018-05-04 07:38:55 --> Language Class Initialized
INFO - 2018-05-04 07:38:55 --> Loader Class Initialized
INFO - 2018-05-04 07:38:55 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:55 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:55 --> Email Class Initialized
INFO - 2018-05-04 07:38:55 --> Controller Class Initialized
INFO - 2018-05-04 07:38:55 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:55 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:55 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:55 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:55 --> Model Class Initialized
INFO - 2018-05-04 07:38:55 --> Model Class Initialized
INFO - 2018-05-04 07:38:55 --> Model Class Initialized
INFO - 2018-05-04 07:38:55 --> Config Class Initialized
INFO - 2018-05-04 07:38:55 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:55 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:55 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:55 --> URI Class Initialized
INFO - 2018-05-04 07:38:55 --> Router Class Initialized
INFO - 2018-05-04 07:38:55 --> Output Class Initialized
INFO - 2018-05-04 07:38:55 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:55 --> Input Class Initialized
INFO - 2018-05-04 07:38:55 --> Language Class Initialized
INFO - 2018-05-04 07:38:55 --> Loader Class Initialized
INFO - 2018-05-04 07:38:55 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:55 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:55 --> Email Class Initialized
INFO - 2018-05-04 07:38:55 --> Controller Class Initialized
INFO - 2018-05-04 07:38:55 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:55 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:55 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:55 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:55 --> Model Class Initialized
INFO - 2018-05-04 07:38:55 --> Model Class Initialized
INFO - 2018-05-04 07:38:55 --> Model Class Initialized
INFO - 2018-05-04 11:08:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:08:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:55 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:55 --> Total execution time: 0.1260
INFO - 2018-05-04 07:38:56 --> Config Class Initialized
INFO - 2018-05-04 07:38:56 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:38:56 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:38:56 --> Utf8 Class Initialized
INFO - 2018-05-04 07:38:56 --> URI Class Initialized
INFO - 2018-05-04 07:38:56 --> Router Class Initialized
INFO - 2018-05-04 07:38:56 --> Output Class Initialized
INFO - 2018-05-04 07:38:56 --> Security Class Initialized
DEBUG - 2018-05-04 07:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:38:56 --> Input Class Initialized
INFO - 2018-05-04 07:38:56 --> Language Class Initialized
INFO - 2018-05-04 07:38:56 --> Loader Class Initialized
INFO - 2018-05-04 07:38:56 --> Helper loaded: common_helper
INFO - 2018-05-04 07:38:56 --> Database Driver Class Initialized
INFO - 2018-05-04 07:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:38:56 --> Email Class Initialized
INFO - 2018-05-04 07:38:56 --> Controller Class Initialized
INFO - 2018-05-04 07:38:56 --> Helper loaded: form_helper
INFO - 2018-05-04 07:38:56 --> Form Validation Class Initialized
INFO - 2018-05-04 07:38:56 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:38:56 --> Helper loaded: url_helper
INFO - 2018-05-04 07:38:56 --> Model Class Initialized
INFO - 2018-05-04 07:38:56 --> Model Class Initialized
INFO - 2018-05-04 07:38:56 --> Model Class Initialized
INFO - 2018-05-04 11:08:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:08:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:08:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:08:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:08:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:08:56 --> Final output sent to browser
DEBUG - 2018-05-04 11:08:56 --> Total execution time: 0.1320
INFO - 2018-05-04 07:39:04 --> Config Class Initialized
INFO - 2018-05-04 07:39:04 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:39:04 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:39:04 --> Utf8 Class Initialized
INFO - 2018-05-04 07:39:04 --> URI Class Initialized
INFO - 2018-05-04 07:39:04 --> Router Class Initialized
INFO - 2018-05-04 07:39:04 --> Output Class Initialized
INFO - 2018-05-04 07:39:04 --> Security Class Initialized
DEBUG - 2018-05-04 07:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:39:04 --> Input Class Initialized
INFO - 2018-05-04 07:39:04 --> Language Class Initialized
INFO - 2018-05-04 07:39:04 --> Loader Class Initialized
INFO - 2018-05-04 07:39:04 --> Helper loaded: common_helper
INFO - 2018-05-04 07:39:04 --> Database Driver Class Initialized
INFO - 2018-05-04 07:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:39:04 --> Email Class Initialized
INFO - 2018-05-04 07:39:04 --> Controller Class Initialized
INFO - 2018-05-04 07:39:04 --> Helper loaded: form_helper
INFO - 2018-05-04 07:39:04 --> Form Validation Class Initialized
INFO - 2018-05-04 07:39:04 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:39:04 --> Helper loaded: url_helper
INFO - 2018-05-04 07:39:04 --> Model Class Initialized
INFO - 2018-05-04 07:39:04 --> Model Class Initialized
INFO - 2018-05-04 07:39:04 --> Model Class Initialized
INFO - 2018-05-04 07:39:04 --> Config Class Initialized
INFO - 2018-05-04 07:39:04 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:39:04 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:39:04 --> Utf8 Class Initialized
INFO - 2018-05-04 07:39:04 --> URI Class Initialized
INFO - 2018-05-04 07:39:04 --> Router Class Initialized
INFO - 2018-05-04 07:39:04 --> Output Class Initialized
INFO - 2018-05-04 07:39:04 --> Security Class Initialized
DEBUG - 2018-05-04 07:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:39:04 --> Input Class Initialized
INFO - 2018-05-04 07:39:04 --> Language Class Initialized
INFO - 2018-05-04 07:39:04 --> Loader Class Initialized
INFO - 2018-05-04 07:39:04 --> Helper loaded: common_helper
INFO - 2018-05-04 07:39:04 --> Database Driver Class Initialized
INFO - 2018-05-04 07:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:39:04 --> Email Class Initialized
INFO - 2018-05-04 07:39:04 --> Controller Class Initialized
INFO - 2018-05-04 07:39:04 --> Helper loaded: form_helper
INFO - 2018-05-04 07:39:04 --> Form Validation Class Initialized
INFO - 2018-05-04 07:39:04 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:39:04 --> Helper loaded: url_helper
INFO - 2018-05-04 07:39:04 --> Model Class Initialized
INFO - 2018-05-04 07:39:04 --> Model Class Initialized
INFO - 2018-05-04 07:39:04 --> Model Class Initialized
INFO - 2018-05-04 11:09:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:09:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:09:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:09:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:09:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:09:04 --> Final output sent to browser
DEBUG - 2018-05-04 11:09:04 --> Total execution time: 0.1220
INFO - 2018-05-04 07:39:04 --> Config Class Initialized
INFO - 2018-05-04 07:39:04 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:39:04 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:39:04 --> Utf8 Class Initialized
INFO - 2018-05-04 07:39:04 --> URI Class Initialized
INFO - 2018-05-04 07:39:04 --> Router Class Initialized
INFO - 2018-05-04 07:39:04 --> Output Class Initialized
INFO - 2018-05-04 07:39:04 --> Security Class Initialized
DEBUG - 2018-05-04 07:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:39:04 --> Input Class Initialized
INFO - 2018-05-04 07:39:04 --> Language Class Initialized
INFO - 2018-05-04 07:39:04 --> Loader Class Initialized
INFO - 2018-05-04 07:39:04 --> Helper loaded: common_helper
INFO - 2018-05-04 07:39:04 --> Database Driver Class Initialized
INFO - 2018-05-04 07:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:39:04 --> Email Class Initialized
INFO - 2018-05-04 07:39:04 --> Controller Class Initialized
INFO - 2018-05-04 07:39:04 --> Helper loaded: form_helper
INFO - 2018-05-04 07:39:04 --> Form Validation Class Initialized
INFO - 2018-05-04 07:39:04 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:39:04 --> Helper loaded: url_helper
INFO - 2018-05-04 07:39:04 --> Model Class Initialized
INFO - 2018-05-04 07:39:04 --> Model Class Initialized
INFO - 2018-05-04 07:39:04 --> Model Class Initialized
INFO - 2018-05-04 11:09:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:09:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:09:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:09:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:09:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:09:04 --> Final output sent to browser
DEBUG - 2018-05-04 11:09:04 --> Total execution time: 0.1340
INFO - 2018-05-04 07:40:13 --> Config Class Initialized
INFO - 2018-05-04 07:40:13 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:40:13 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:40:13 --> Utf8 Class Initialized
INFO - 2018-05-04 07:40:13 --> URI Class Initialized
INFO - 2018-05-04 07:40:13 --> Router Class Initialized
INFO - 2018-05-04 07:40:13 --> Output Class Initialized
INFO - 2018-05-04 07:40:13 --> Security Class Initialized
DEBUG - 2018-05-04 07:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:40:13 --> Input Class Initialized
INFO - 2018-05-04 07:40:13 --> Language Class Initialized
INFO - 2018-05-04 07:40:13 --> Loader Class Initialized
INFO - 2018-05-04 07:40:13 --> Helper loaded: common_helper
INFO - 2018-05-04 07:40:13 --> Database Driver Class Initialized
INFO - 2018-05-04 07:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:40:13 --> Email Class Initialized
INFO - 2018-05-04 07:40:13 --> Controller Class Initialized
INFO - 2018-05-04 07:40:13 --> Helper loaded: form_helper
INFO - 2018-05-04 07:40:13 --> Form Validation Class Initialized
INFO - 2018-05-04 07:40:13 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:40:13 --> Helper loaded: url_helper
INFO - 2018-05-04 07:40:13 --> Model Class Initialized
INFO - 2018-05-04 07:40:13 --> Model Class Initialized
INFO - 2018-05-04 07:40:13 --> Model Class Initialized
INFO - 2018-05-04 07:40:13 --> Config Class Initialized
INFO - 2018-05-04 07:40:13 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:40:13 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:40:13 --> Utf8 Class Initialized
INFO - 2018-05-04 07:40:13 --> URI Class Initialized
INFO - 2018-05-04 07:40:13 --> Router Class Initialized
INFO - 2018-05-04 07:40:13 --> Output Class Initialized
INFO - 2018-05-04 07:40:13 --> Security Class Initialized
DEBUG - 2018-05-04 07:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:40:13 --> Input Class Initialized
INFO - 2018-05-04 07:40:13 --> Language Class Initialized
INFO - 2018-05-04 07:40:13 --> Loader Class Initialized
INFO - 2018-05-04 07:40:13 --> Helper loaded: common_helper
INFO - 2018-05-04 07:40:13 --> Database Driver Class Initialized
INFO - 2018-05-04 07:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:40:13 --> Email Class Initialized
INFO - 2018-05-04 07:40:13 --> Controller Class Initialized
INFO - 2018-05-04 07:40:13 --> Helper loaded: form_helper
INFO - 2018-05-04 07:40:13 --> Form Validation Class Initialized
INFO - 2018-05-04 07:40:13 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:40:13 --> Helper loaded: url_helper
INFO - 2018-05-04 07:40:13 --> Model Class Initialized
INFO - 2018-05-04 07:40:13 --> Model Class Initialized
INFO - 2018-05-04 07:40:13 --> Model Class Initialized
INFO - 2018-05-04 11:10:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:10:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:10:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:10:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:10:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:10:13 --> Final output sent to browser
DEBUG - 2018-05-04 11:10:13 --> Total execution time: 0.1270
INFO - 2018-05-04 07:40:13 --> Config Class Initialized
INFO - 2018-05-04 07:40:13 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:40:13 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:40:13 --> Utf8 Class Initialized
INFO - 2018-05-04 07:40:13 --> URI Class Initialized
INFO - 2018-05-04 07:40:13 --> Router Class Initialized
INFO - 2018-05-04 07:40:13 --> Output Class Initialized
INFO - 2018-05-04 07:40:13 --> Security Class Initialized
DEBUG - 2018-05-04 07:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:40:13 --> Input Class Initialized
INFO - 2018-05-04 07:40:13 --> Language Class Initialized
INFO - 2018-05-04 07:40:13 --> Loader Class Initialized
INFO - 2018-05-04 07:40:13 --> Helper loaded: common_helper
INFO - 2018-05-04 07:40:13 --> Database Driver Class Initialized
INFO - 2018-05-04 07:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:40:13 --> Email Class Initialized
INFO - 2018-05-04 07:40:13 --> Controller Class Initialized
INFO - 2018-05-04 07:40:13 --> Helper loaded: form_helper
INFO - 2018-05-04 07:40:13 --> Form Validation Class Initialized
INFO - 2018-05-04 07:40:13 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:40:13 --> Helper loaded: url_helper
INFO - 2018-05-04 07:40:13 --> Model Class Initialized
INFO - 2018-05-04 07:40:13 --> Model Class Initialized
INFO - 2018-05-04 07:40:13 --> Model Class Initialized
INFO - 2018-05-04 11:10:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:10:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:10:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:10:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:10:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:10:13 --> Final output sent to browser
DEBUG - 2018-05-04 11:10:13 --> Total execution time: 0.1340
INFO - 2018-05-04 07:41:53 --> Config Class Initialized
INFO - 2018-05-04 07:41:53 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:41:53 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:41:53 --> Utf8 Class Initialized
INFO - 2018-05-04 07:41:53 --> URI Class Initialized
INFO - 2018-05-04 07:41:53 --> Router Class Initialized
INFO - 2018-05-04 07:41:53 --> Output Class Initialized
INFO - 2018-05-04 07:41:53 --> Security Class Initialized
DEBUG - 2018-05-04 07:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:41:53 --> Input Class Initialized
INFO - 2018-05-04 07:41:53 --> Language Class Initialized
INFO - 2018-05-04 07:41:53 --> Loader Class Initialized
INFO - 2018-05-04 07:41:53 --> Helper loaded: common_helper
INFO - 2018-05-04 07:41:53 --> Database Driver Class Initialized
ERROR - 2018-05-04 07:41:53 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-04 07:41:53 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-04 07:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:41:53 --> Email Class Initialized
INFO - 2018-05-04 07:41:53 --> Controller Class Initialized
INFO - 2018-05-04 07:41:53 --> Helper loaded: form_helper
INFO - 2018-05-04 07:41:53 --> Form Validation Class Initialized
INFO - 2018-05-04 07:41:53 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:41:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:41:53 --> Helper loaded: url_helper
INFO - 2018-05-04 07:41:53 --> Model Class Initialized
INFO - 2018-05-04 07:41:53 --> Model Class Initialized
INFO - 2018-05-04 07:41:53 --> Model Class Initialized
INFO - 2018-05-04 11:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:11:53 --> Final output sent to browser
DEBUG - 2018-05-04 11:11:53 --> Total execution time: 0.2450
INFO - 2018-05-04 07:41:53 --> Config Class Initialized
INFO - 2018-05-04 07:41:53 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:41:53 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:41:53 --> Utf8 Class Initialized
INFO - 2018-05-04 07:41:53 --> URI Class Initialized
INFO - 2018-05-04 07:41:53 --> Router Class Initialized
INFO - 2018-05-04 07:41:53 --> Output Class Initialized
INFO - 2018-05-04 07:41:53 --> Security Class Initialized
DEBUG - 2018-05-04 07:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:41:53 --> Input Class Initialized
INFO - 2018-05-04 07:41:53 --> Language Class Initialized
INFO - 2018-05-04 07:41:53 --> Loader Class Initialized
INFO - 2018-05-04 07:41:53 --> Helper loaded: common_helper
INFO - 2018-05-04 07:41:53 --> Database Driver Class Initialized
INFO - 2018-05-04 07:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:41:53 --> Email Class Initialized
INFO - 2018-05-04 07:41:53 --> Controller Class Initialized
INFO - 2018-05-04 07:41:53 --> Helper loaded: form_helper
INFO - 2018-05-04 07:41:53 --> Form Validation Class Initialized
INFO - 2018-05-04 07:41:53 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:41:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:41:53 --> Helper loaded: url_helper
INFO - 2018-05-04 07:41:53 --> Model Class Initialized
INFO - 2018-05-04 07:41:53 --> Model Class Initialized
INFO - 2018-05-04 07:41:53 --> Model Class Initialized
INFO - 2018-05-04 11:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:11:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:11:53 --> Final output sent to browser
DEBUG - 2018-05-04 11:11:53 --> Total execution time: 0.1660
INFO - 2018-05-04 07:42:03 --> Config Class Initialized
INFO - 2018-05-04 07:42:03 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:42:03 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:42:03 --> Utf8 Class Initialized
INFO - 2018-05-04 07:42:03 --> URI Class Initialized
INFO - 2018-05-04 07:42:03 --> Router Class Initialized
INFO - 2018-05-04 07:42:03 --> Output Class Initialized
INFO - 2018-05-04 07:42:03 --> Security Class Initialized
DEBUG - 2018-05-04 07:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:42:03 --> Input Class Initialized
INFO - 2018-05-04 07:42:03 --> Language Class Initialized
INFO - 2018-05-04 07:42:03 --> Loader Class Initialized
INFO - 2018-05-04 07:42:03 --> Helper loaded: common_helper
INFO - 2018-05-04 07:42:03 --> Database Driver Class Initialized
INFO - 2018-05-04 07:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:42:03 --> Email Class Initialized
INFO - 2018-05-04 07:42:03 --> Controller Class Initialized
INFO - 2018-05-04 07:42:04 --> Helper loaded: form_helper
INFO - 2018-05-04 07:42:04 --> Form Validation Class Initialized
INFO - 2018-05-04 07:42:04 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:42:04 --> Helper loaded: url_helper
INFO - 2018-05-04 07:42:04 --> Model Class Initialized
INFO - 2018-05-04 07:42:04 --> Model Class Initialized
INFO - 2018-05-04 07:42:04 --> Model Class Initialized
INFO - 2018-05-04 07:42:04 --> Config Class Initialized
INFO - 2018-05-04 07:42:04 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:42:04 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:42:04 --> Utf8 Class Initialized
INFO - 2018-05-04 07:42:04 --> URI Class Initialized
INFO - 2018-05-04 07:42:04 --> Router Class Initialized
INFO - 2018-05-04 07:42:04 --> Output Class Initialized
INFO - 2018-05-04 07:42:04 --> Security Class Initialized
DEBUG - 2018-05-04 07:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:42:04 --> Input Class Initialized
INFO - 2018-05-04 07:42:04 --> Language Class Initialized
INFO - 2018-05-04 07:42:04 --> Loader Class Initialized
INFO - 2018-05-04 07:42:04 --> Helper loaded: common_helper
INFO - 2018-05-04 07:42:04 --> Database Driver Class Initialized
INFO - 2018-05-04 07:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:42:04 --> Email Class Initialized
INFO - 2018-05-04 07:42:04 --> Controller Class Initialized
INFO - 2018-05-04 07:42:04 --> Helper loaded: form_helper
INFO - 2018-05-04 07:42:04 --> Form Validation Class Initialized
INFO - 2018-05-04 07:42:04 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:42:04 --> Helper loaded: url_helper
INFO - 2018-05-04 07:42:04 --> Model Class Initialized
INFO - 2018-05-04 07:42:04 --> Model Class Initialized
INFO - 2018-05-04 07:42:04 --> Model Class Initialized
INFO - 2018-05-04 11:12:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:12:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:12:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:12:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:12:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:12:04 --> Final output sent to browser
DEBUG - 2018-05-04 11:12:04 --> Total execution time: 0.1220
INFO - 2018-05-04 07:42:04 --> Config Class Initialized
INFO - 2018-05-04 07:42:04 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:42:04 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:42:04 --> Utf8 Class Initialized
INFO - 2018-05-04 07:42:04 --> URI Class Initialized
INFO - 2018-05-04 07:42:04 --> Router Class Initialized
INFO - 2018-05-04 07:42:04 --> Output Class Initialized
INFO - 2018-05-04 07:42:04 --> Security Class Initialized
DEBUG - 2018-05-04 07:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:42:04 --> Input Class Initialized
INFO - 2018-05-04 07:42:04 --> Language Class Initialized
INFO - 2018-05-04 07:42:04 --> Loader Class Initialized
INFO - 2018-05-04 07:42:04 --> Helper loaded: common_helper
INFO - 2018-05-04 07:42:04 --> Database Driver Class Initialized
INFO - 2018-05-04 07:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:42:04 --> Email Class Initialized
INFO - 2018-05-04 07:42:04 --> Controller Class Initialized
INFO - 2018-05-04 07:42:04 --> Helper loaded: form_helper
INFO - 2018-05-04 07:42:04 --> Form Validation Class Initialized
INFO - 2018-05-04 07:42:04 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:42:04 --> Helper loaded: url_helper
INFO - 2018-05-04 07:42:04 --> Model Class Initialized
INFO - 2018-05-04 07:42:04 --> Model Class Initialized
INFO - 2018-05-04 07:42:04 --> Model Class Initialized
INFO - 2018-05-04 11:12:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:12:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:12:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:12:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:12:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:12:04 --> Final output sent to browser
DEBUG - 2018-05-04 11:12:04 --> Total execution time: 0.1340
INFO - 2018-05-04 07:42:09 --> Config Class Initialized
INFO - 2018-05-04 07:42:09 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:42:09 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:42:09 --> Utf8 Class Initialized
INFO - 2018-05-04 07:42:09 --> URI Class Initialized
INFO - 2018-05-04 07:42:09 --> Router Class Initialized
INFO - 2018-05-04 07:42:09 --> Output Class Initialized
INFO - 2018-05-04 07:42:09 --> Security Class Initialized
DEBUG - 2018-05-04 07:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:42:09 --> Input Class Initialized
INFO - 2018-05-04 07:42:09 --> Language Class Initialized
INFO - 2018-05-04 07:42:09 --> Loader Class Initialized
INFO - 2018-05-04 07:42:09 --> Helper loaded: common_helper
INFO - 2018-05-04 07:42:09 --> Database Driver Class Initialized
INFO - 2018-05-04 07:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:42:09 --> Email Class Initialized
INFO - 2018-05-04 07:42:09 --> Controller Class Initialized
INFO - 2018-05-04 07:42:09 --> Helper loaded: form_helper
INFO - 2018-05-04 07:42:09 --> Form Validation Class Initialized
INFO - 2018-05-04 07:42:09 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:42:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:42:09 --> Helper loaded: url_helper
INFO - 2018-05-04 07:42:09 --> Model Class Initialized
INFO - 2018-05-04 07:42:09 --> Model Class Initialized
INFO - 2018-05-04 07:42:09 --> Model Class Initialized
INFO - 2018-05-04 07:42:09 --> Config Class Initialized
INFO - 2018-05-04 07:42:09 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:42:09 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:42:09 --> Utf8 Class Initialized
INFO - 2018-05-04 07:42:09 --> URI Class Initialized
INFO - 2018-05-04 07:42:09 --> Router Class Initialized
INFO - 2018-05-04 07:42:09 --> Output Class Initialized
INFO - 2018-05-04 07:42:09 --> Security Class Initialized
DEBUG - 2018-05-04 07:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:42:09 --> Input Class Initialized
INFO - 2018-05-04 07:42:09 --> Language Class Initialized
INFO - 2018-05-04 07:42:09 --> Loader Class Initialized
INFO - 2018-05-04 07:42:09 --> Helper loaded: common_helper
INFO - 2018-05-04 07:42:09 --> Database Driver Class Initialized
INFO - 2018-05-04 07:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:42:09 --> Email Class Initialized
INFO - 2018-05-04 07:42:09 --> Controller Class Initialized
INFO - 2018-05-04 07:42:09 --> Helper loaded: form_helper
INFO - 2018-05-04 07:42:09 --> Form Validation Class Initialized
INFO - 2018-05-04 07:42:09 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:42:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:42:09 --> Helper loaded: url_helper
INFO - 2018-05-04 07:42:09 --> Model Class Initialized
INFO - 2018-05-04 07:42:09 --> Model Class Initialized
INFO - 2018-05-04 07:42:09 --> Model Class Initialized
INFO - 2018-05-04 11:12:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:12:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:12:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:12:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:12:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:12:09 --> Final output sent to browser
DEBUG - 2018-05-04 11:12:09 --> Total execution time: 0.1340
INFO - 2018-05-04 07:42:09 --> Config Class Initialized
INFO - 2018-05-04 07:42:09 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:42:09 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:42:09 --> Utf8 Class Initialized
INFO - 2018-05-04 07:42:09 --> URI Class Initialized
INFO - 2018-05-04 07:42:09 --> Router Class Initialized
INFO - 2018-05-04 07:42:09 --> Output Class Initialized
INFO - 2018-05-04 07:42:09 --> Security Class Initialized
DEBUG - 2018-05-04 07:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:42:09 --> Input Class Initialized
INFO - 2018-05-04 07:42:09 --> Language Class Initialized
INFO - 2018-05-04 07:42:09 --> Loader Class Initialized
INFO - 2018-05-04 07:42:09 --> Helper loaded: common_helper
INFO - 2018-05-04 07:42:09 --> Database Driver Class Initialized
INFO - 2018-05-04 07:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:42:09 --> Email Class Initialized
INFO - 2018-05-04 07:42:09 --> Controller Class Initialized
INFO - 2018-05-04 07:42:09 --> Helper loaded: form_helper
INFO - 2018-05-04 07:42:09 --> Form Validation Class Initialized
INFO - 2018-05-04 07:42:09 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:42:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:42:09 --> Helper loaded: url_helper
INFO - 2018-05-04 07:42:09 --> Model Class Initialized
INFO - 2018-05-04 07:42:09 --> Model Class Initialized
INFO - 2018-05-04 07:42:09 --> Model Class Initialized
INFO - 2018-05-04 11:12:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:12:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:12:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:12:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:12:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:12:09 --> Final output sent to browser
DEBUG - 2018-05-04 11:12:09 --> Total execution time: 0.1500
INFO - 2018-05-04 07:42:35 --> Config Class Initialized
INFO - 2018-05-04 07:42:35 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:42:35 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:42:35 --> Utf8 Class Initialized
INFO - 2018-05-04 07:42:35 --> URI Class Initialized
INFO - 2018-05-04 07:42:35 --> Router Class Initialized
INFO - 2018-05-04 07:42:35 --> Output Class Initialized
INFO - 2018-05-04 07:42:35 --> Security Class Initialized
DEBUG - 2018-05-04 07:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:42:35 --> Input Class Initialized
INFO - 2018-05-04 07:42:35 --> Language Class Initialized
INFO - 2018-05-04 07:42:35 --> Loader Class Initialized
INFO - 2018-05-04 07:42:35 --> Helper loaded: common_helper
INFO - 2018-05-04 07:42:35 --> Database Driver Class Initialized
INFO - 2018-05-04 07:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:42:35 --> Email Class Initialized
INFO - 2018-05-04 07:42:35 --> Controller Class Initialized
INFO - 2018-05-04 07:42:35 --> Helper loaded: form_helper
INFO - 2018-05-04 07:42:35 --> Form Validation Class Initialized
INFO - 2018-05-04 07:42:35 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:42:35 --> Helper loaded: url_helper
INFO - 2018-05-04 07:42:35 --> Model Class Initialized
INFO - 2018-05-04 07:42:35 --> Model Class Initialized
INFO - 2018-05-04 07:42:35 --> Model Class Initialized
INFO - 2018-05-04 11:12:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:12:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:12:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:12:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:12:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:12:35 --> Final output sent to browser
DEBUG - 2018-05-04 11:12:35 --> Total execution time: 0.1390
INFO - 2018-05-04 07:42:39 --> Config Class Initialized
INFO - 2018-05-04 07:42:39 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:42:39 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:42:39 --> Utf8 Class Initialized
INFO - 2018-05-04 07:42:39 --> URI Class Initialized
INFO - 2018-05-04 07:42:39 --> Router Class Initialized
INFO - 2018-05-04 07:42:39 --> Output Class Initialized
INFO - 2018-05-04 07:42:39 --> Security Class Initialized
DEBUG - 2018-05-04 07:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:42:39 --> Input Class Initialized
INFO - 2018-05-04 07:42:39 --> Language Class Initialized
INFO - 2018-05-04 07:42:39 --> Loader Class Initialized
INFO - 2018-05-04 07:42:39 --> Helper loaded: common_helper
INFO - 2018-05-04 07:42:39 --> Database Driver Class Initialized
INFO - 2018-05-04 07:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:42:39 --> Email Class Initialized
INFO - 2018-05-04 07:42:39 --> Controller Class Initialized
INFO - 2018-05-04 07:42:39 --> Helper loaded: form_helper
INFO - 2018-05-04 07:42:39 --> Form Validation Class Initialized
INFO - 2018-05-04 07:42:39 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:42:39 --> Helper loaded: url_helper
INFO - 2018-05-04 07:42:39 --> Model Class Initialized
INFO - 2018-05-04 07:42:39 --> Model Class Initialized
INFO - 2018-05-04 07:42:39 --> Model Class Initialized
INFO - 2018-05-04 07:42:39 --> Config Class Initialized
INFO - 2018-05-04 07:42:39 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:42:39 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:42:39 --> Utf8 Class Initialized
INFO - 2018-05-04 07:42:39 --> URI Class Initialized
INFO - 2018-05-04 07:42:39 --> Router Class Initialized
INFO - 2018-05-04 07:42:39 --> Output Class Initialized
INFO - 2018-05-04 07:42:39 --> Security Class Initialized
DEBUG - 2018-05-04 07:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:42:39 --> Input Class Initialized
INFO - 2018-05-04 07:42:39 --> Language Class Initialized
INFO - 2018-05-04 07:42:39 --> Loader Class Initialized
INFO - 2018-05-04 07:42:39 --> Helper loaded: common_helper
INFO - 2018-05-04 07:42:39 --> Database Driver Class Initialized
INFO - 2018-05-04 07:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:42:39 --> Email Class Initialized
INFO - 2018-05-04 07:42:39 --> Controller Class Initialized
INFO - 2018-05-04 07:42:39 --> Helper loaded: form_helper
INFO - 2018-05-04 07:42:39 --> Form Validation Class Initialized
INFO - 2018-05-04 07:42:39 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:42:39 --> Helper loaded: url_helper
INFO - 2018-05-04 07:42:39 --> Model Class Initialized
INFO - 2018-05-04 07:42:39 --> Model Class Initialized
INFO - 2018-05-04 07:42:39 --> Model Class Initialized
INFO - 2018-05-04 11:12:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:12:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:12:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:12:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:12:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:12:39 --> Final output sent to browser
DEBUG - 2018-05-04 11:12:39 --> Total execution time: 0.1320
INFO - 2018-05-04 07:42:50 --> Config Class Initialized
INFO - 2018-05-04 07:42:50 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:42:50 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:42:50 --> Utf8 Class Initialized
INFO - 2018-05-04 07:42:50 --> URI Class Initialized
INFO - 2018-05-04 07:42:50 --> Router Class Initialized
INFO - 2018-05-04 07:42:50 --> Output Class Initialized
INFO - 2018-05-04 07:42:50 --> Security Class Initialized
DEBUG - 2018-05-04 07:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:42:50 --> Input Class Initialized
INFO - 2018-05-04 07:42:50 --> Language Class Initialized
INFO - 2018-05-04 07:42:50 --> Loader Class Initialized
INFO - 2018-05-04 07:42:50 --> Helper loaded: common_helper
INFO - 2018-05-04 07:42:50 --> Database Driver Class Initialized
INFO - 2018-05-04 07:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:42:50 --> Email Class Initialized
INFO - 2018-05-04 07:42:50 --> Controller Class Initialized
INFO - 2018-05-04 07:42:50 --> Helper loaded: form_helper
INFO - 2018-05-04 07:42:50 --> Form Validation Class Initialized
INFO - 2018-05-04 07:42:50 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:42:50 --> Helper loaded: url_helper
INFO - 2018-05-04 07:42:50 --> Model Class Initialized
INFO - 2018-05-04 07:42:50 --> Model Class Initialized
INFO - 2018-05-04 07:42:50 --> Model Class Initialized
INFO - 2018-05-04 11:12:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:12:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:12:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:12:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:12:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:12:50 --> Final output sent to browser
DEBUG - 2018-05-04 11:12:50 --> Total execution time: 0.1440
INFO - 2018-05-04 07:44:00 --> Config Class Initialized
INFO - 2018-05-04 07:44:00 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:44:00 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:44:00 --> Utf8 Class Initialized
INFO - 2018-05-04 07:44:00 --> URI Class Initialized
INFO - 2018-05-04 07:44:00 --> Router Class Initialized
INFO - 2018-05-04 07:44:00 --> Output Class Initialized
INFO - 2018-05-04 07:44:00 --> Security Class Initialized
DEBUG - 2018-05-04 07:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:44:00 --> Input Class Initialized
INFO - 2018-05-04 07:44:00 --> Language Class Initialized
INFO - 2018-05-04 07:44:00 --> Loader Class Initialized
INFO - 2018-05-04 07:44:00 --> Helper loaded: common_helper
INFO - 2018-05-04 07:44:00 --> Database Driver Class Initialized
INFO - 2018-05-04 07:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:44:00 --> Email Class Initialized
INFO - 2018-05-04 07:44:00 --> Controller Class Initialized
INFO - 2018-05-04 07:44:00 --> Helper loaded: form_helper
INFO - 2018-05-04 07:44:00 --> Form Validation Class Initialized
INFO - 2018-05-04 07:44:00 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:44:00 --> Helper loaded: url_helper
INFO - 2018-05-04 07:44:00 --> Model Class Initialized
INFO - 2018-05-04 07:44:00 --> Model Class Initialized
INFO - 2018-05-04 07:44:00 --> Model Class Initialized
INFO - 2018-05-04 11:14:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:14:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:14:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:14:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:14:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:14:00 --> Final output sent to browser
DEBUG - 2018-05-04 11:14:00 --> Total execution time: 0.1380
INFO - 2018-05-04 07:44:04 --> Config Class Initialized
INFO - 2018-05-04 07:44:04 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:44:04 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:44:04 --> Utf8 Class Initialized
INFO - 2018-05-04 07:44:04 --> URI Class Initialized
INFO - 2018-05-04 07:44:04 --> Router Class Initialized
INFO - 2018-05-04 07:44:04 --> Output Class Initialized
INFO - 2018-05-04 07:44:04 --> Security Class Initialized
DEBUG - 2018-05-04 07:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:44:04 --> Input Class Initialized
INFO - 2018-05-04 07:44:04 --> Language Class Initialized
INFO - 2018-05-04 07:44:04 --> Loader Class Initialized
INFO - 2018-05-04 07:44:04 --> Helper loaded: common_helper
INFO - 2018-05-04 07:44:04 --> Database Driver Class Initialized
INFO - 2018-05-04 07:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:44:04 --> Email Class Initialized
INFO - 2018-05-04 07:44:04 --> Controller Class Initialized
INFO - 2018-05-04 07:44:04 --> Helper loaded: form_helper
INFO - 2018-05-04 07:44:04 --> Form Validation Class Initialized
INFO - 2018-05-04 07:44:04 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:44:04 --> Helper loaded: url_helper
INFO - 2018-05-04 07:44:04 --> Model Class Initialized
INFO - 2018-05-04 07:44:04 --> Model Class Initialized
INFO - 2018-05-04 07:44:04 --> Model Class Initialized
INFO - 2018-05-04 07:44:05 --> Config Class Initialized
INFO - 2018-05-04 07:44:05 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:44:05 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:44:05 --> Utf8 Class Initialized
INFO - 2018-05-04 07:44:05 --> URI Class Initialized
INFO - 2018-05-04 07:44:05 --> Router Class Initialized
INFO - 2018-05-04 07:44:05 --> Output Class Initialized
INFO - 2018-05-04 07:44:05 --> Security Class Initialized
DEBUG - 2018-05-04 07:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:44:05 --> Input Class Initialized
INFO - 2018-05-04 07:44:05 --> Language Class Initialized
INFO - 2018-05-04 07:44:05 --> Loader Class Initialized
INFO - 2018-05-04 07:44:05 --> Helper loaded: common_helper
INFO - 2018-05-04 07:44:05 --> Database Driver Class Initialized
INFO - 2018-05-04 07:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:44:05 --> Email Class Initialized
INFO - 2018-05-04 07:44:05 --> Controller Class Initialized
INFO - 2018-05-04 07:44:05 --> Helper loaded: form_helper
INFO - 2018-05-04 07:44:05 --> Form Validation Class Initialized
INFO - 2018-05-04 07:44:05 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:44:05 --> Helper loaded: url_helper
INFO - 2018-05-04 07:44:05 --> Model Class Initialized
INFO - 2018-05-04 07:44:05 --> Model Class Initialized
INFO - 2018-05-04 07:44:05 --> Model Class Initialized
INFO - 2018-05-04 11:14:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:14:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:14:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:14:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:14:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:14:05 --> Final output sent to browser
DEBUG - 2018-05-04 11:14:05 --> Total execution time: 0.1220
INFO - 2018-05-04 07:44:09 --> Config Class Initialized
INFO - 2018-05-04 07:44:09 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:44:09 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:44:09 --> Utf8 Class Initialized
INFO - 2018-05-04 07:44:09 --> URI Class Initialized
INFO - 2018-05-04 07:44:09 --> Router Class Initialized
INFO - 2018-05-04 07:44:09 --> Output Class Initialized
INFO - 2018-05-04 07:44:09 --> Security Class Initialized
DEBUG - 2018-05-04 07:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:44:09 --> Input Class Initialized
INFO - 2018-05-04 07:44:09 --> Language Class Initialized
INFO - 2018-05-04 07:44:09 --> Loader Class Initialized
INFO - 2018-05-04 07:44:09 --> Helper loaded: common_helper
INFO - 2018-05-04 07:44:09 --> Database Driver Class Initialized
INFO - 2018-05-04 07:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:44:09 --> Email Class Initialized
INFO - 2018-05-04 07:44:09 --> Controller Class Initialized
INFO - 2018-05-04 07:44:09 --> Helper loaded: form_helper
INFO - 2018-05-04 07:44:09 --> Form Validation Class Initialized
INFO - 2018-05-04 07:44:09 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:44:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:44:09 --> Helper loaded: url_helper
INFO - 2018-05-04 07:44:09 --> Model Class Initialized
INFO - 2018-05-04 07:44:09 --> Model Class Initialized
INFO - 2018-05-04 07:44:09 --> Model Class Initialized
INFO - 2018-05-04 11:14:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:14:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:14:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:14:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:14:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:14:09 --> Final output sent to browser
DEBUG - 2018-05-04 11:14:09 --> Total execution time: 0.1890
INFO - 2018-05-04 07:46:08 --> Config Class Initialized
INFO - 2018-05-04 07:46:08 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:46:08 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:46:08 --> Utf8 Class Initialized
INFO - 2018-05-04 07:46:08 --> URI Class Initialized
INFO - 2018-05-04 07:46:08 --> Router Class Initialized
INFO - 2018-05-04 07:46:08 --> Output Class Initialized
INFO - 2018-05-04 07:46:08 --> Security Class Initialized
DEBUG - 2018-05-04 07:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:46:08 --> Input Class Initialized
INFO - 2018-05-04 07:46:08 --> Language Class Initialized
INFO - 2018-05-04 07:46:08 --> Loader Class Initialized
INFO - 2018-05-04 07:46:08 --> Helper loaded: common_helper
INFO - 2018-05-04 07:46:08 --> Database Driver Class Initialized
INFO - 2018-05-04 07:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:46:08 --> Email Class Initialized
INFO - 2018-05-04 07:46:08 --> Controller Class Initialized
INFO - 2018-05-04 07:46:08 --> Helper loaded: form_helper
INFO - 2018-05-04 07:46:08 --> Form Validation Class Initialized
INFO - 2018-05-04 07:46:08 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:46:08 --> Helper loaded: url_helper
INFO - 2018-05-04 07:46:08 --> Model Class Initialized
INFO - 2018-05-04 07:46:08 --> Model Class Initialized
INFO - 2018-05-04 07:46:08 --> Model Class Initialized
INFO - 2018-05-04 11:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:16:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:16:08 --> Final output sent to browser
DEBUG - 2018-05-04 11:16:08 --> Total execution time: 0.1430
INFO - 2018-05-04 07:46:16 --> Config Class Initialized
INFO - 2018-05-04 07:46:16 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:46:16 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:46:16 --> Utf8 Class Initialized
INFO - 2018-05-04 07:46:16 --> URI Class Initialized
INFO - 2018-05-04 07:46:16 --> Router Class Initialized
INFO - 2018-05-04 07:46:16 --> Output Class Initialized
INFO - 2018-05-04 07:46:16 --> Security Class Initialized
DEBUG - 2018-05-04 07:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:46:16 --> Input Class Initialized
INFO - 2018-05-04 07:46:16 --> Language Class Initialized
INFO - 2018-05-04 07:46:16 --> Loader Class Initialized
INFO - 2018-05-04 07:46:16 --> Helper loaded: common_helper
INFO - 2018-05-04 07:46:16 --> Database Driver Class Initialized
INFO - 2018-05-04 07:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:46:16 --> Email Class Initialized
INFO - 2018-05-04 07:46:16 --> Controller Class Initialized
INFO - 2018-05-04 07:46:16 --> Helper loaded: form_helper
INFO - 2018-05-04 07:46:16 --> Form Validation Class Initialized
INFO - 2018-05-04 07:46:16 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:46:16 --> Helper loaded: url_helper
INFO - 2018-05-04 07:46:16 --> Model Class Initialized
INFO - 2018-05-04 07:46:16 --> Model Class Initialized
INFO - 2018-05-04 07:46:16 --> Model Class Initialized
INFO - 2018-05-04 07:46:16 --> Config Class Initialized
INFO - 2018-05-04 07:46:16 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:46:16 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:46:16 --> Utf8 Class Initialized
INFO - 2018-05-04 07:46:16 --> URI Class Initialized
INFO - 2018-05-04 07:46:16 --> Router Class Initialized
INFO - 2018-05-04 07:46:16 --> Output Class Initialized
INFO - 2018-05-04 07:46:16 --> Security Class Initialized
DEBUG - 2018-05-04 07:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:46:16 --> Input Class Initialized
INFO - 2018-05-04 07:46:16 --> Language Class Initialized
INFO - 2018-05-04 07:46:16 --> Loader Class Initialized
INFO - 2018-05-04 07:46:16 --> Helper loaded: common_helper
INFO - 2018-05-04 07:46:16 --> Database Driver Class Initialized
INFO - 2018-05-04 07:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:46:16 --> Email Class Initialized
INFO - 2018-05-04 07:46:16 --> Controller Class Initialized
INFO - 2018-05-04 07:46:16 --> Helper loaded: form_helper
INFO - 2018-05-04 07:46:16 --> Form Validation Class Initialized
INFO - 2018-05-04 07:46:16 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:46:16 --> Helper loaded: url_helper
INFO - 2018-05-04 07:46:16 --> Model Class Initialized
INFO - 2018-05-04 07:46:16 --> Model Class Initialized
INFO - 2018-05-04 07:46:16 --> Model Class Initialized
INFO - 2018-05-04 11:16:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:16:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:16:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:16:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:16:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:16:16 --> Final output sent to browser
DEBUG - 2018-05-04 11:16:16 --> Total execution time: 0.1230
INFO - 2018-05-04 07:46:16 --> Config Class Initialized
INFO - 2018-05-04 07:46:16 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:46:16 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:46:16 --> Utf8 Class Initialized
INFO - 2018-05-04 07:46:16 --> URI Class Initialized
INFO - 2018-05-04 07:46:16 --> Router Class Initialized
INFO - 2018-05-04 07:46:16 --> Output Class Initialized
INFO - 2018-05-04 07:46:16 --> Security Class Initialized
DEBUG - 2018-05-04 07:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:46:16 --> Input Class Initialized
INFO - 2018-05-04 07:46:16 --> Language Class Initialized
INFO - 2018-05-04 07:46:17 --> Loader Class Initialized
INFO - 2018-05-04 07:46:17 --> Helper loaded: common_helper
INFO - 2018-05-04 07:46:17 --> Database Driver Class Initialized
INFO - 2018-05-04 07:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:46:17 --> Email Class Initialized
INFO - 2018-05-04 07:46:17 --> Controller Class Initialized
INFO - 2018-05-04 07:46:17 --> Helper loaded: form_helper
INFO - 2018-05-04 07:46:17 --> Form Validation Class Initialized
INFO - 2018-05-04 07:46:17 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:46:17 --> Helper loaded: url_helper
INFO - 2018-05-04 07:46:17 --> Model Class Initialized
INFO - 2018-05-04 07:46:17 --> Model Class Initialized
INFO - 2018-05-04 07:46:17 --> Model Class Initialized
INFO - 2018-05-04 11:16:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:16:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:16:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:16:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:16:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:16:17 --> Final output sent to browser
DEBUG - 2018-05-04 11:16:17 --> Total execution time: 0.1340
INFO - 2018-05-04 07:50:32 --> Config Class Initialized
INFO - 2018-05-04 07:50:32 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:50:32 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:50:32 --> Utf8 Class Initialized
INFO - 2018-05-04 07:50:32 --> URI Class Initialized
INFO - 2018-05-04 07:50:32 --> Router Class Initialized
INFO - 2018-05-04 07:50:32 --> Output Class Initialized
INFO - 2018-05-04 07:50:32 --> Security Class Initialized
DEBUG - 2018-05-04 07:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:50:32 --> Input Class Initialized
INFO - 2018-05-04 07:50:32 --> Language Class Initialized
INFO - 2018-05-04 07:50:32 --> Loader Class Initialized
INFO - 2018-05-04 07:50:32 --> Helper loaded: common_helper
INFO - 2018-05-04 07:50:32 --> Database Driver Class Initialized
INFO - 2018-05-04 07:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:50:32 --> Email Class Initialized
INFO - 2018-05-04 07:50:32 --> Controller Class Initialized
INFO - 2018-05-04 07:50:32 --> Helper loaded: form_helper
INFO - 2018-05-04 07:50:32 --> Form Validation Class Initialized
INFO - 2018-05-04 07:50:32 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:50:32 --> Helper loaded: url_helper
INFO - 2018-05-04 07:50:32 --> Model Class Initialized
INFO - 2018-05-04 07:50:32 --> Model Class Initialized
INFO - 2018-05-04 07:50:32 --> Model Class Initialized
INFO - 2018-05-04 11:20:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:20:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:20:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:20:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:20:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:20:32 --> Final output sent to browser
DEBUG - 2018-05-04 11:20:32 --> Total execution time: 0.1440
INFO - 2018-05-04 07:50:34 --> Config Class Initialized
INFO - 2018-05-04 07:50:34 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:50:34 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:50:34 --> Utf8 Class Initialized
INFO - 2018-05-04 07:50:34 --> URI Class Initialized
INFO - 2018-05-04 07:50:34 --> Router Class Initialized
INFO - 2018-05-04 07:50:34 --> Output Class Initialized
INFO - 2018-05-04 07:50:34 --> Security Class Initialized
DEBUG - 2018-05-04 07:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:50:34 --> Input Class Initialized
INFO - 2018-05-04 07:50:34 --> Language Class Initialized
INFO - 2018-05-04 07:50:34 --> Loader Class Initialized
INFO - 2018-05-04 07:50:34 --> Helper loaded: common_helper
INFO - 2018-05-04 07:50:34 --> Database Driver Class Initialized
INFO - 2018-05-04 07:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:50:34 --> Email Class Initialized
INFO - 2018-05-04 07:50:34 --> Controller Class Initialized
INFO - 2018-05-04 07:50:34 --> Helper loaded: form_helper
INFO - 2018-05-04 07:50:34 --> Form Validation Class Initialized
INFO - 2018-05-04 07:50:34 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:50:34 --> Helper loaded: url_helper
INFO - 2018-05-04 07:50:34 --> Model Class Initialized
INFO - 2018-05-04 07:50:34 --> Model Class Initialized
INFO - 2018-05-04 07:50:34 --> Model Class Initialized
INFO - 2018-05-04 11:20:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:20:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:20:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:20:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:20:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:20:34 --> Final output sent to browser
DEBUG - 2018-05-04 11:20:34 --> Total execution time: 0.1480
INFO - 2018-05-04 07:50:37 --> Config Class Initialized
INFO - 2018-05-04 07:50:37 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:50:37 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:50:37 --> Utf8 Class Initialized
INFO - 2018-05-04 07:50:37 --> URI Class Initialized
INFO - 2018-05-04 07:50:37 --> Router Class Initialized
INFO - 2018-05-04 07:50:37 --> Output Class Initialized
INFO - 2018-05-04 07:50:37 --> Security Class Initialized
DEBUG - 2018-05-04 07:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:50:37 --> Input Class Initialized
INFO - 2018-05-04 07:50:37 --> Language Class Initialized
INFO - 2018-05-04 07:50:37 --> Loader Class Initialized
INFO - 2018-05-04 07:50:37 --> Helper loaded: common_helper
INFO - 2018-05-04 07:50:37 --> Database Driver Class Initialized
INFO - 2018-05-04 07:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:50:37 --> Email Class Initialized
INFO - 2018-05-04 07:50:37 --> Controller Class Initialized
INFO - 2018-05-04 07:50:37 --> Helper loaded: form_helper
INFO - 2018-05-04 07:50:37 --> Form Validation Class Initialized
INFO - 2018-05-04 07:50:37 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:50:37 --> Helper loaded: url_helper
INFO - 2018-05-04 07:50:37 --> Model Class Initialized
INFO - 2018-05-04 07:50:37 --> Model Class Initialized
INFO - 2018-05-04 07:50:37 --> Model Class Initialized
INFO - 2018-05-04 11:20:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:20:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:20:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:20:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:20:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:20:37 --> Final output sent to browser
DEBUG - 2018-05-04 11:20:37 --> Total execution time: 0.1290
INFO - 2018-05-04 07:50:42 --> Config Class Initialized
INFO - 2018-05-04 07:50:42 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:50:42 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:50:42 --> Utf8 Class Initialized
INFO - 2018-05-04 07:50:42 --> URI Class Initialized
INFO - 2018-05-04 07:50:42 --> Router Class Initialized
INFO - 2018-05-04 07:50:42 --> Output Class Initialized
INFO - 2018-05-04 07:50:42 --> Security Class Initialized
DEBUG - 2018-05-04 07:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:50:42 --> Input Class Initialized
INFO - 2018-05-04 07:50:42 --> Language Class Initialized
INFO - 2018-05-04 07:50:42 --> Loader Class Initialized
INFO - 2018-05-04 07:50:42 --> Helper loaded: common_helper
INFO - 2018-05-04 07:50:42 --> Database Driver Class Initialized
INFO - 2018-05-04 07:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:50:42 --> Email Class Initialized
INFO - 2018-05-04 07:50:42 --> Controller Class Initialized
INFO - 2018-05-04 07:50:42 --> Helper loaded: form_helper
INFO - 2018-05-04 07:50:42 --> Form Validation Class Initialized
INFO - 2018-05-04 07:50:42 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:50:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:50:42 --> Helper loaded: url_helper
INFO - 2018-05-04 07:50:42 --> Model Class Initialized
INFO - 2018-05-04 07:50:42 --> Model Class Initialized
INFO - 2018-05-04 07:50:42 --> Model Class Initialized
INFO - 2018-05-04 07:50:42 --> Config Class Initialized
INFO - 2018-05-04 07:50:42 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:50:42 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:50:42 --> Utf8 Class Initialized
INFO - 2018-05-04 07:50:42 --> URI Class Initialized
INFO - 2018-05-04 07:50:42 --> Router Class Initialized
INFO - 2018-05-04 07:50:42 --> Output Class Initialized
INFO - 2018-05-04 07:50:42 --> Security Class Initialized
DEBUG - 2018-05-04 07:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:50:42 --> Input Class Initialized
INFO - 2018-05-04 07:50:42 --> Language Class Initialized
INFO - 2018-05-04 07:50:42 --> Loader Class Initialized
INFO - 2018-05-04 07:50:42 --> Helper loaded: common_helper
INFO - 2018-05-04 07:50:42 --> Database Driver Class Initialized
INFO - 2018-05-04 07:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:50:42 --> Email Class Initialized
INFO - 2018-05-04 07:50:42 --> Controller Class Initialized
INFO - 2018-05-04 07:50:42 --> Helper loaded: form_helper
INFO - 2018-05-04 07:50:42 --> Form Validation Class Initialized
INFO - 2018-05-04 07:50:42 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:50:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:50:42 --> Helper loaded: url_helper
INFO - 2018-05-04 07:50:42 --> Model Class Initialized
INFO - 2018-05-04 07:50:42 --> Model Class Initialized
INFO - 2018-05-04 07:50:42 --> Model Class Initialized
INFO - 2018-05-04 11:20:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:20:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:20:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:20:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:20:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:20:42 --> Final output sent to browser
DEBUG - 2018-05-04 11:20:42 --> Total execution time: 0.1410
INFO - 2018-05-04 07:50:51 --> Config Class Initialized
INFO - 2018-05-04 07:50:51 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:50:51 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:50:51 --> Utf8 Class Initialized
INFO - 2018-05-04 07:50:51 --> URI Class Initialized
INFO - 2018-05-04 07:50:51 --> Router Class Initialized
INFO - 2018-05-04 07:50:51 --> Output Class Initialized
INFO - 2018-05-04 07:50:51 --> Security Class Initialized
DEBUG - 2018-05-04 07:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:50:51 --> Input Class Initialized
INFO - 2018-05-04 07:50:51 --> Language Class Initialized
INFO - 2018-05-04 07:50:51 --> Loader Class Initialized
INFO - 2018-05-04 07:50:51 --> Helper loaded: common_helper
INFO - 2018-05-04 07:50:51 --> Database Driver Class Initialized
INFO - 2018-05-04 07:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:50:51 --> Email Class Initialized
INFO - 2018-05-04 07:50:51 --> Controller Class Initialized
INFO - 2018-05-04 07:50:51 --> Helper loaded: form_helper
INFO - 2018-05-04 07:50:51 --> Form Validation Class Initialized
INFO - 2018-05-04 07:50:51 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:50:51 --> Helper loaded: url_helper
INFO - 2018-05-04 07:50:51 --> Model Class Initialized
INFO - 2018-05-04 07:50:51 --> Model Class Initialized
INFO - 2018-05-04 07:50:51 --> Model Class Initialized
INFO - 2018-05-04 11:20:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:20:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:20:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:20:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:20:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:20:51 --> Final output sent to browser
DEBUG - 2018-05-04 11:20:51 --> Total execution time: 0.1840
INFO - 2018-05-04 07:50:54 --> Config Class Initialized
INFO - 2018-05-04 07:50:54 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:50:54 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:50:54 --> Utf8 Class Initialized
INFO - 2018-05-04 07:50:54 --> URI Class Initialized
INFO - 2018-05-04 07:50:54 --> Router Class Initialized
INFO - 2018-05-04 07:50:54 --> Output Class Initialized
INFO - 2018-05-04 07:50:54 --> Security Class Initialized
DEBUG - 2018-05-04 07:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:50:54 --> Input Class Initialized
INFO - 2018-05-04 07:50:54 --> Language Class Initialized
INFO - 2018-05-04 07:50:54 --> Loader Class Initialized
INFO - 2018-05-04 07:50:54 --> Helper loaded: common_helper
INFO - 2018-05-04 07:50:54 --> Database Driver Class Initialized
INFO - 2018-05-04 07:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:50:54 --> Email Class Initialized
INFO - 2018-05-04 07:50:54 --> Controller Class Initialized
INFO - 2018-05-04 07:50:54 --> Helper loaded: form_helper
INFO - 2018-05-04 07:50:54 --> Form Validation Class Initialized
INFO - 2018-05-04 07:50:54 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:50:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:50:54 --> Helper loaded: url_helper
INFO - 2018-05-04 07:50:54 --> Model Class Initialized
INFO - 2018-05-04 07:50:54 --> Model Class Initialized
INFO - 2018-05-04 07:50:54 --> Model Class Initialized
INFO - 2018-05-04 11:20:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:20:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:20:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:20:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:20:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:20:54 --> Final output sent to browser
DEBUG - 2018-05-04 11:20:54 --> Total execution time: 0.1290
INFO - 2018-05-04 07:51:03 --> Config Class Initialized
INFO - 2018-05-04 07:51:03 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:51:03 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:51:03 --> Utf8 Class Initialized
INFO - 2018-05-04 07:51:03 --> URI Class Initialized
INFO - 2018-05-04 07:51:03 --> Router Class Initialized
INFO - 2018-05-04 07:51:03 --> Output Class Initialized
INFO - 2018-05-04 07:51:03 --> Security Class Initialized
DEBUG - 2018-05-04 07:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:51:03 --> Input Class Initialized
INFO - 2018-05-04 07:51:03 --> Language Class Initialized
INFO - 2018-05-04 07:51:03 --> Loader Class Initialized
INFO - 2018-05-04 07:51:03 --> Helper loaded: common_helper
INFO - 2018-05-04 07:51:03 --> Database Driver Class Initialized
INFO - 2018-05-04 07:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:51:03 --> Email Class Initialized
INFO - 2018-05-04 07:51:03 --> Controller Class Initialized
INFO - 2018-05-04 07:51:03 --> Helper loaded: form_helper
INFO - 2018-05-04 07:51:03 --> Form Validation Class Initialized
INFO - 2018-05-04 07:51:03 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:51:03 --> Helper loaded: url_helper
INFO - 2018-05-04 07:51:03 --> Model Class Initialized
INFO - 2018-05-04 07:51:03 --> Model Class Initialized
INFO - 2018-05-04 07:51:03 --> Model Class Initialized
INFO - 2018-05-04 11:21:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:21:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:21:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:21:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:21:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:21:03 --> Final output sent to browser
DEBUG - 2018-05-04 11:21:03 --> Total execution time: 0.1440
INFO - 2018-05-04 07:51:05 --> Config Class Initialized
INFO - 2018-05-04 07:51:05 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:51:05 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:51:05 --> Utf8 Class Initialized
INFO - 2018-05-04 07:51:05 --> URI Class Initialized
INFO - 2018-05-04 07:51:05 --> Router Class Initialized
INFO - 2018-05-04 07:51:05 --> Output Class Initialized
INFO - 2018-05-04 07:51:05 --> Security Class Initialized
DEBUG - 2018-05-04 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:51:05 --> Input Class Initialized
INFO - 2018-05-04 07:51:05 --> Language Class Initialized
INFO - 2018-05-04 07:51:05 --> Loader Class Initialized
INFO - 2018-05-04 07:51:05 --> Helper loaded: common_helper
INFO - 2018-05-04 07:51:05 --> Database Driver Class Initialized
INFO - 2018-05-04 07:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:51:05 --> Email Class Initialized
INFO - 2018-05-04 07:51:05 --> Controller Class Initialized
INFO - 2018-05-04 07:51:05 --> Helper loaded: form_helper
INFO - 2018-05-04 07:51:05 --> Form Validation Class Initialized
INFO - 2018-05-04 07:51:05 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:51:05 --> Helper loaded: url_helper
INFO - 2018-05-04 07:51:05 --> Model Class Initialized
INFO - 2018-05-04 07:51:05 --> Model Class Initialized
INFO - 2018-05-04 07:51:05 --> Model Class Initialized
INFO - 2018-05-04 11:21:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:21:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:21:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:21:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:21:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:21:05 --> Final output sent to browser
DEBUG - 2018-05-04 11:21:05 --> Total execution time: 0.1450
INFO - 2018-05-04 07:51:10 --> Config Class Initialized
INFO - 2018-05-04 07:51:10 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:51:10 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:51:10 --> Utf8 Class Initialized
INFO - 2018-05-04 07:51:10 --> URI Class Initialized
INFO - 2018-05-04 07:51:10 --> Router Class Initialized
INFO - 2018-05-04 07:51:10 --> Output Class Initialized
INFO - 2018-05-04 07:51:10 --> Security Class Initialized
DEBUG - 2018-05-04 07:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:51:10 --> Input Class Initialized
INFO - 2018-05-04 07:51:10 --> Language Class Initialized
INFO - 2018-05-04 07:51:10 --> Loader Class Initialized
INFO - 2018-05-04 07:51:10 --> Helper loaded: common_helper
INFO - 2018-05-04 07:51:10 --> Database Driver Class Initialized
INFO - 2018-05-04 07:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:51:10 --> Email Class Initialized
INFO - 2018-05-04 07:51:10 --> Controller Class Initialized
INFO - 2018-05-04 07:51:10 --> Helper loaded: form_helper
INFO - 2018-05-04 07:51:10 --> Form Validation Class Initialized
INFO - 2018-05-04 07:51:10 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:51:10 --> Helper loaded: url_helper
INFO - 2018-05-04 07:51:10 --> Model Class Initialized
INFO - 2018-05-04 07:51:10 --> Model Class Initialized
INFO - 2018-05-04 07:51:10 --> Model Class Initialized
INFO - 2018-05-04 11:21:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:21:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:21:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:21:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:21:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:21:10 --> Final output sent to browser
DEBUG - 2018-05-04 11:21:10 --> Total execution time: 0.1460
INFO - 2018-05-04 07:51:14 --> Config Class Initialized
INFO - 2018-05-04 07:51:14 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:51:14 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:51:14 --> Utf8 Class Initialized
INFO - 2018-05-04 07:51:14 --> URI Class Initialized
INFO - 2018-05-04 07:51:14 --> Router Class Initialized
INFO - 2018-05-04 07:51:14 --> Output Class Initialized
INFO - 2018-05-04 07:51:14 --> Security Class Initialized
DEBUG - 2018-05-04 07:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:51:14 --> Input Class Initialized
INFO - 2018-05-04 07:51:14 --> Language Class Initialized
INFO - 2018-05-04 07:51:14 --> Loader Class Initialized
INFO - 2018-05-04 07:51:14 --> Helper loaded: common_helper
INFO - 2018-05-04 07:51:14 --> Database Driver Class Initialized
INFO - 2018-05-04 07:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:51:14 --> Email Class Initialized
INFO - 2018-05-04 07:51:14 --> Controller Class Initialized
INFO - 2018-05-04 07:51:14 --> Helper loaded: form_helper
INFO - 2018-05-04 07:51:14 --> Form Validation Class Initialized
INFO - 2018-05-04 07:51:14 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:51:14 --> Helper loaded: url_helper
INFO - 2018-05-04 07:51:14 --> Model Class Initialized
INFO - 2018-05-04 07:51:14 --> Model Class Initialized
INFO - 2018-05-04 07:51:14 --> Model Class Initialized
INFO - 2018-05-04 07:51:14 --> Config Class Initialized
INFO - 2018-05-04 07:51:14 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:51:14 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:51:14 --> Utf8 Class Initialized
INFO - 2018-05-04 07:51:14 --> URI Class Initialized
INFO - 2018-05-04 07:51:14 --> Router Class Initialized
INFO - 2018-05-04 07:51:14 --> Output Class Initialized
INFO - 2018-05-04 07:51:14 --> Security Class Initialized
DEBUG - 2018-05-04 07:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:51:14 --> Input Class Initialized
INFO - 2018-05-04 07:51:14 --> Language Class Initialized
INFO - 2018-05-04 07:51:14 --> Loader Class Initialized
INFO - 2018-05-04 07:51:14 --> Helper loaded: common_helper
INFO - 2018-05-04 07:51:14 --> Database Driver Class Initialized
INFO - 2018-05-04 07:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:51:14 --> Email Class Initialized
INFO - 2018-05-04 07:51:14 --> Controller Class Initialized
INFO - 2018-05-04 07:51:14 --> Helper loaded: form_helper
INFO - 2018-05-04 07:51:14 --> Form Validation Class Initialized
INFO - 2018-05-04 07:51:14 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:51:14 --> Helper loaded: url_helper
INFO - 2018-05-04 07:51:14 --> Model Class Initialized
INFO - 2018-05-04 07:51:14 --> Model Class Initialized
INFO - 2018-05-04 07:51:14 --> Model Class Initialized
INFO - 2018-05-04 11:21:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:21:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:21:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:21:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:21:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:21:14 --> Final output sent to browser
DEBUG - 2018-05-04 11:21:14 --> Total execution time: 0.1210
INFO - 2018-05-04 07:51:14 --> Config Class Initialized
INFO - 2018-05-04 07:51:14 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:51:14 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:51:14 --> Utf8 Class Initialized
INFO - 2018-05-04 07:51:14 --> URI Class Initialized
INFO - 2018-05-04 07:51:14 --> Router Class Initialized
INFO - 2018-05-04 07:51:14 --> Output Class Initialized
INFO - 2018-05-04 07:51:14 --> Security Class Initialized
DEBUG - 2018-05-04 07:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:51:14 --> Input Class Initialized
INFO - 2018-05-04 07:51:14 --> Language Class Initialized
INFO - 2018-05-04 07:51:14 --> Loader Class Initialized
INFO - 2018-05-04 07:51:14 --> Helper loaded: common_helper
INFO - 2018-05-04 07:51:14 --> Database Driver Class Initialized
INFO - 2018-05-04 07:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:51:14 --> Email Class Initialized
INFO - 2018-05-04 07:51:14 --> Controller Class Initialized
INFO - 2018-05-04 07:51:15 --> Helper loaded: form_helper
INFO - 2018-05-04 07:51:15 --> Form Validation Class Initialized
INFO - 2018-05-04 07:51:15 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:51:15 --> Helper loaded: url_helper
INFO - 2018-05-04 07:51:15 --> Model Class Initialized
INFO - 2018-05-04 07:51:15 --> Model Class Initialized
INFO - 2018-05-04 07:51:15 --> Model Class Initialized
INFO - 2018-05-04 11:21:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:21:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:21:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:21:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:21:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:21:15 --> Final output sent to browser
DEBUG - 2018-05-04 11:21:15 --> Total execution time: 0.1270
INFO - 2018-05-04 07:51:45 --> Config Class Initialized
INFO - 2018-05-04 07:51:45 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:51:45 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:51:45 --> Utf8 Class Initialized
INFO - 2018-05-04 07:51:45 --> URI Class Initialized
INFO - 2018-05-04 07:51:45 --> Router Class Initialized
INFO - 2018-05-04 07:51:45 --> Output Class Initialized
INFO - 2018-05-04 07:51:45 --> Security Class Initialized
DEBUG - 2018-05-04 07:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:51:45 --> Input Class Initialized
INFO - 2018-05-04 07:51:45 --> Language Class Initialized
INFO - 2018-05-04 07:51:45 --> Loader Class Initialized
INFO - 2018-05-04 07:51:45 --> Helper loaded: common_helper
INFO - 2018-05-04 07:51:45 --> Database Driver Class Initialized
INFO - 2018-05-04 07:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:51:45 --> Email Class Initialized
INFO - 2018-05-04 07:51:45 --> Controller Class Initialized
INFO - 2018-05-04 07:51:45 --> Helper loaded: form_helper
INFO - 2018-05-04 07:51:45 --> Form Validation Class Initialized
INFO - 2018-05-04 07:51:45 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:51:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:51:45 --> Helper loaded: url_helper
INFO - 2018-05-04 07:51:45 --> Model Class Initialized
INFO - 2018-05-04 07:51:45 --> Model Class Initialized
INFO - 2018-05-04 07:51:45 --> Model Class Initialized
INFO - 2018-05-04 11:21:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:21:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:21:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:21:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:21:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:21:45 --> Final output sent to browser
DEBUG - 2018-05-04 11:21:45 --> Total execution time: 0.1320
INFO - 2018-05-04 07:51:48 --> Config Class Initialized
INFO - 2018-05-04 07:51:48 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:51:48 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:51:48 --> Utf8 Class Initialized
INFO - 2018-05-04 07:51:48 --> URI Class Initialized
INFO - 2018-05-04 07:51:48 --> Router Class Initialized
INFO - 2018-05-04 07:51:48 --> Output Class Initialized
INFO - 2018-05-04 07:51:48 --> Security Class Initialized
DEBUG - 2018-05-04 07:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:51:48 --> Input Class Initialized
INFO - 2018-05-04 07:51:48 --> Language Class Initialized
INFO - 2018-05-04 07:51:48 --> Loader Class Initialized
INFO - 2018-05-04 07:51:48 --> Helper loaded: common_helper
INFO - 2018-05-04 07:51:48 --> Database Driver Class Initialized
INFO - 2018-05-04 07:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:51:48 --> Email Class Initialized
INFO - 2018-05-04 07:51:48 --> Controller Class Initialized
INFO - 2018-05-04 07:51:48 --> Helper loaded: form_helper
INFO - 2018-05-04 07:51:48 --> Form Validation Class Initialized
INFO - 2018-05-04 07:51:48 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:51:48 --> Helper loaded: url_helper
INFO - 2018-05-04 07:51:48 --> Model Class Initialized
INFO - 2018-05-04 07:51:48 --> Model Class Initialized
INFO - 2018-05-04 07:51:48 --> Model Class Initialized
INFO - 2018-05-04 11:21:49 --> Final output sent to browser
DEBUG - 2018-05-04 11:21:49 --> Total execution time: 0.2390
INFO - 2018-05-04 07:51:49 --> Config Class Initialized
INFO - 2018-05-04 07:51:49 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:51:49 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:51:49 --> Utf8 Class Initialized
INFO - 2018-05-04 07:51:49 --> URI Class Initialized
INFO - 2018-05-04 07:51:49 --> Router Class Initialized
INFO - 2018-05-04 07:51:49 --> Output Class Initialized
INFO - 2018-05-04 07:51:49 --> Security Class Initialized
DEBUG - 2018-05-04 07:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:51:49 --> Input Class Initialized
INFO - 2018-05-04 07:51:49 --> Language Class Initialized
INFO - 2018-05-04 07:51:49 --> Loader Class Initialized
INFO - 2018-05-04 07:51:49 --> Helper loaded: common_helper
INFO - 2018-05-04 07:51:49 --> Database Driver Class Initialized
INFO - 2018-05-04 07:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:51:49 --> Email Class Initialized
INFO - 2018-05-04 07:51:49 --> Controller Class Initialized
INFO - 2018-05-04 07:51:49 --> Helper loaded: form_helper
INFO - 2018-05-04 07:51:49 --> Form Validation Class Initialized
INFO - 2018-05-04 07:51:49 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:51:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:51:49 --> Helper loaded: url_helper
INFO - 2018-05-04 07:51:49 --> Model Class Initialized
INFO - 2018-05-04 07:51:49 --> Model Class Initialized
INFO - 2018-05-04 07:51:49 --> Model Class Initialized
INFO - 2018-05-04 11:21:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:21:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:21:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:21:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:21:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:21:49 --> Final output sent to browser
DEBUG - 2018-05-04 11:21:49 --> Total execution time: 0.1420
INFO - 2018-05-04 07:51:52 --> Config Class Initialized
INFO - 2018-05-04 07:51:52 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:51:52 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:51:52 --> Utf8 Class Initialized
INFO - 2018-05-04 07:51:52 --> URI Class Initialized
INFO - 2018-05-04 07:51:52 --> Router Class Initialized
INFO - 2018-05-04 07:51:52 --> Output Class Initialized
INFO - 2018-05-04 07:51:52 --> Security Class Initialized
DEBUG - 2018-05-04 07:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:51:52 --> Input Class Initialized
INFO - 2018-05-04 07:51:52 --> Language Class Initialized
INFO - 2018-05-04 07:51:52 --> Loader Class Initialized
INFO - 2018-05-04 07:51:52 --> Helper loaded: common_helper
INFO - 2018-05-04 07:51:52 --> Database Driver Class Initialized
INFO - 2018-05-04 07:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:51:52 --> Email Class Initialized
INFO - 2018-05-04 07:51:52 --> Controller Class Initialized
INFO - 2018-05-04 07:51:52 --> Helper loaded: form_helper
INFO - 2018-05-04 07:51:52 --> Form Validation Class Initialized
INFO - 2018-05-04 07:51:52 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:51:52 --> Helper loaded: url_helper
INFO - 2018-05-04 07:51:52 --> Model Class Initialized
INFO - 2018-05-04 07:51:52 --> Model Class Initialized
INFO - 2018-05-04 07:51:52 --> Model Class Initialized
INFO - 2018-05-04 11:21:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:21:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:21:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:21:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:21:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:21:53 --> Final output sent to browser
DEBUG - 2018-05-04 11:21:53 --> Total execution time: 0.1400
INFO - 2018-05-04 07:51:54 --> Config Class Initialized
INFO - 2018-05-04 07:51:54 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:51:54 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:51:54 --> Utf8 Class Initialized
INFO - 2018-05-04 07:51:54 --> URI Class Initialized
INFO - 2018-05-04 07:51:54 --> Router Class Initialized
INFO - 2018-05-04 07:51:54 --> Output Class Initialized
INFO - 2018-05-04 07:51:54 --> Security Class Initialized
DEBUG - 2018-05-04 07:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:51:54 --> Input Class Initialized
INFO - 2018-05-04 07:51:54 --> Language Class Initialized
INFO - 2018-05-04 07:51:54 --> Loader Class Initialized
INFO - 2018-05-04 07:51:54 --> Helper loaded: common_helper
INFO - 2018-05-04 07:51:54 --> Database Driver Class Initialized
INFO - 2018-05-04 07:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:51:54 --> Email Class Initialized
INFO - 2018-05-04 07:51:54 --> Controller Class Initialized
INFO - 2018-05-04 07:51:54 --> Helper loaded: form_helper
INFO - 2018-05-04 07:51:54 --> Form Validation Class Initialized
INFO - 2018-05-04 07:51:54 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:51:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:51:54 --> Helper loaded: url_helper
INFO - 2018-05-04 07:51:54 --> Model Class Initialized
INFO - 2018-05-04 07:51:54 --> Model Class Initialized
INFO - 2018-05-04 07:51:54 --> Model Class Initialized
INFO - 2018-05-04 11:21:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:21:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:21:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:21:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-04 11:21:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:21:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:21:54 --> Final output sent to browser
DEBUG - 2018-05-04 11:21:54 --> Total execution time: 0.1320
INFO - 2018-05-04 07:51:57 --> Config Class Initialized
INFO - 2018-05-04 07:51:57 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:51:57 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:51:57 --> Utf8 Class Initialized
INFO - 2018-05-04 07:51:57 --> URI Class Initialized
INFO - 2018-05-04 07:51:57 --> Router Class Initialized
INFO - 2018-05-04 07:51:57 --> Output Class Initialized
INFO - 2018-05-04 07:51:57 --> Security Class Initialized
DEBUG - 2018-05-04 07:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:51:57 --> Input Class Initialized
INFO - 2018-05-04 07:51:57 --> Language Class Initialized
INFO - 2018-05-04 07:51:57 --> Loader Class Initialized
INFO - 2018-05-04 07:51:57 --> Helper loaded: common_helper
INFO - 2018-05-04 07:51:57 --> Database Driver Class Initialized
INFO - 2018-05-04 07:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:51:57 --> Email Class Initialized
INFO - 2018-05-04 07:51:57 --> Controller Class Initialized
INFO - 2018-05-04 07:51:57 --> Helper loaded: form_helper
INFO - 2018-05-04 07:51:57 --> Form Validation Class Initialized
INFO - 2018-05-04 07:51:57 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:51:57 --> Helper loaded: url_helper
INFO - 2018-05-04 07:51:57 --> Model Class Initialized
INFO - 2018-05-04 07:51:57 --> Model Class Initialized
INFO - 2018-05-04 07:51:57 --> Model Class Initialized
INFO - 2018-05-04 11:21:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:21:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:21:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:21:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:21:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:21:57 --> Final output sent to browser
DEBUG - 2018-05-04 11:21:57 --> Total execution time: 0.1370
INFO - 2018-05-04 07:53:54 --> Config Class Initialized
INFO - 2018-05-04 07:53:54 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:53:54 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:53:54 --> Utf8 Class Initialized
INFO - 2018-05-04 07:53:54 --> URI Class Initialized
INFO - 2018-05-04 07:53:54 --> Router Class Initialized
INFO - 2018-05-04 07:53:54 --> Output Class Initialized
INFO - 2018-05-04 07:53:54 --> Security Class Initialized
DEBUG - 2018-05-04 07:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:53:54 --> Input Class Initialized
INFO - 2018-05-04 07:53:54 --> Language Class Initialized
INFO - 2018-05-04 07:53:54 --> Loader Class Initialized
INFO - 2018-05-04 07:53:54 --> Helper loaded: common_helper
INFO - 2018-05-04 07:53:54 --> Database Driver Class Initialized
INFO - 2018-05-04 07:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:53:54 --> Email Class Initialized
INFO - 2018-05-04 07:53:54 --> Controller Class Initialized
INFO - 2018-05-04 07:53:54 --> Helper loaded: form_helper
INFO - 2018-05-04 07:53:54 --> Form Validation Class Initialized
INFO - 2018-05-04 07:53:54 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:53:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:53:54 --> Helper loaded: url_helper
INFO - 2018-05-04 07:53:54 --> Model Class Initialized
INFO - 2018-05-04 07:53:54 --> Model Class Initialized
INFO - 2018-05-04 07:53:54 --> Model Class Initialized
INFO - 2018-05-04 11:23:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:23:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:23:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:23:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:23:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:23:54 --> Final output sent to browser
DEBUG - 2018-05-04 11:23:54 --> Total execution time: 0.1280
INFO - 2018-05-04 07:53:56 --> Config Class Initialized
INFO - 2018-05-04 07:53:56 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:53:56 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:53:56 --> Utf8 Class Initialized
INFO - 2018-05-04 07:53:56 --> URI Class Initialized
INFO - 2018-05-04 07:53:56 --> Router Class Initialized
INFO - 2018-05-04 07:53:56 --> Output Class Initialized
INFO - 2018-05-04 07:53:56 --> Security Class Initialized
DEBUG - 2018-05-04 07:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:53:56 --> Input Class Initialized
INFO - 2018-05-04 07:53:56 --> Language Class Initialized
INFO - 2018-05-04 07:53:56 --> Loader Class Initialized
INFO - 2018-05-04 07:53:56 --> Helper loaded: common_helper
INFO - 2018-05-04 07:53:56 --> Database Driver Class Initialized
INFO - 2018-05-04 07:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:53:56 --> Email Class Initialized
INFO - 2018-05-04 07:53:56 --> Controller Class Initialized
INFO - 2018-05-04 07:53:56 --> Helper loaded: form_helper
INFO - 2018-05-04 07:53:56 --> Form Validation Class Initialized
INFO - 2018-05-04 07:53:56 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:53:56 --> Helper loaded: url_helper
INFO - 2018-05-04 07:53:56 --> Model Class Initialized
INFO - 2018-05-04 07:53:56 --> Model Class Initialized
INFO - 2018-05-04 07:53:56 --> Model Class Initialized
INFO - 2018-05-04 11:23:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:23:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:23:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:23:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:23:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:23:56 --> Final output sent to browser
DEBUG - 2018-05-04 11:23:56 --> Total execution time: 0.1320
INFO - 2018-05-04 07:53:58 --> Config Class Initialized
INFO - 2018-05-04 07:53:58 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:53:58 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:53:58 --> Utf8 Class Initialized
INFO - 2018-05-04 07:53:58 --> URI Class Initialized
INFO - 2018-05-04 07:53:58 --> Router Class Initialized
INFO - 2018-05-04 07:53:58 --> Output Class Initialized
INFO - 2018-05-04 07:53:58 --> Security Class Initialized
DEBUG - 2018-05-04 07:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:53:58 --> Input Class Initialized
INFO - 2018-05-04 07:53:58 --> Language Class Initialized
INFO - 2018-05-04 07:53:58 --> Loader Class Initialized
INFO - 2018-05-04 07:53:58 --> Helper loaded: common_helper
INFO - 2018-05-04 07:53:58 --> Database Driver Class Initialized
INFO - 2018-05-04 07:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:53:58 --> Email Class Initialized
INFO - 2018-05-04 07:53:58 --> Controller Class Initialized
INFO - 2018-05-04 07:53:58 --> Helper loaded: form_helper
INFO - 2018-05-04 07:53:58 --> Form Validation Class Initialized
INFO - 2018-05-04 07:53:58 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:53:58 --> Helper loaded: url_helper
INFO - 2018-05-04 07:53:58 --> Model Class Initialized
INFO - 2018-05-04 07:53:58 --> Model Class Initialized
INFO - 2018-05-04 07:53:58 --> Model Class Initialized
INFO - 2018-05-04 11:23:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:23:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:23:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:23:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:23:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:23:58 --> Final output sent to browser
DEBUG - 2018-05-04 11:23:58 --> Total execution time: 0.1650
INFO - 2018-05-04 07:54:08 --> Config Class Initialized
INFO - 2018-05-04 07:54:08 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:54:08 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:54:08 --> Utf8 Class Initialized
INFO - 2018-05-04 07:54:08 --> URI Class Initialized
INFO - 2018-05-04 07:54:08 --> Router Class Initialized
INFO - 2018-05-04 07:54:08 --> Output Class Initialized
INFO - 2018-05-04 07:54:08 --> Security Class Initialized
DEBUG - 2018-05-04 07:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:54:08 --> Input Class Initialized
INFO - 2018-05-04 07:54:08 --> Language Class Initialized
INFO - 2018-05-04 07:54:08 --> Loader Class Initialized
INFO - 2018-05-04 07:54:08 --> Helper loaded: common_helper
INFO - 2018-05-04 07:54:08 --> Database Driver Class Initialized
INFO - 2018-05-04 07:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:54:08 --> Email Class Initialized
INFO - 2018-05-04 07:54:08 --> Controller Class Initialized
INFO - 2018-05-04 07:54:08 --> Helper loaded: form_helper
INFO - 2018-05-04 07:54:08 --> Form Validation Class Initialized
INFO - 2018-05-04 07:54:08 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:54:08 --> Helper loaded: url_helper
INFO - 2018-05-04 07:54:08 --> Model Class Initialized
INFO - 2018-05-04 07:54:08 --> Model Class Initialized
INFO - 2018-05-04 07:54:08 --> Model Class Initialized
INFO - 2018-05-04 11:24:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:24:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:24:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:24:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/imagedata.php
INFO - 2018-05-04 11:24:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:24:08 --> Final output sent to browser
DEBUG - 2018-05-04 11:24:08 --> Total execution time: 0.1310
INFO - 2018-05-04 07:54:09 --> Config Class Initialized
INFO - 2018-05-04 07:54:09 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:54:09 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:54:09 --> Utf8 Class Initialized
INFO - 2018-05-04 07:54:09 --> URI Class Initialized
INFO - 2018-05-04 07:54:09 --> Router Class Initialized
INFO - 2018-05-04 07:54:09 --> Output Class Initialized
INFO - 2018-05-04 07:54:09 --> Security Class Initialized
DEBUG - 2018-05-04 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:54:09 --> Input Class Initialized
INFO - 2018-05-04 07:54:09 --> Language Class Initialized
INFO - 2018-05-04 07:54:09 --> Loader Class Initialized
INFO - 2018-05-04 07:54:09 --> Helper loaded: common_helper
INFO - 2018-05-04 07:54:09 --> Database Driver Class Initialized
INFO - 2018-05-04 07:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:54:09 --> Email Class Initialized
INFO - 2018-05-04 07:54:09 --> Controller Class Initialized
INFO - 2018-05-04 07:54:09 --> Helper loaded: form_helper
INFO - 2018-05-04 07:54:09 --> Form Validation Class Initialized
INFO - 2018-05-04 07:54:09 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:54:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:54:09 --> Helper loaded: url_helper
INFO - 2018-05-04 07:54:09 --> Model Class Initialized
INFO - 2018-05-04 07:54:09 --> Model Class Initialized
INFO - 2018-05-04 07:54:09 --> Model Class Initialized
INFO - 2018-05-04 11:24:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:24:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:24:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:24:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:24:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:24:09 --> Final output sent to browser
DEBUG - 2018-05-04 11:24:09 --> Total execution time: 0.1720
INFO - 2018-05-04 07:57:46 --> Config Class Initialized
INFO - 2018-05-04 07:57:46 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:57:46 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:57:46 --> Utf8 Class Initialized
INFO - 2018-05-04 07:57:46 --> URI Class Initialized
INFO - 2018-05-04 07:57:46 --> Router Class Initialized
INFO - 2018-05-04 07:57:46 --> Output Class Initialized
INFO - 2018-05-04 07:57:46 --> Security Class Initialized
DEBUG - 2018-05-04 07:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:57:46 --> Input Class Initialized
INFO - 2018-05-04 07:57:46 --> Language Class Initialized
INFO - 2018-05-04 07:57:46 --> Loader Class Initialized
INFO - 2018-05-04 07:57:46 --> Helper loaded: common_helper
INFO - 2018-05-04 07:57:47 --> Database Driver Class Initialized
INFO - 2018-05-04 07:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:57:47 --> Email Class Initialized
INFO - 2018-05-04 07:57:47 --> Controller Class Initialized
INFO - 2018-05-04 07:57:47 --> Helper loaded: form_helper
INFO - 2018-05-04 07:57:47 --> Form Validation Class Initialized
INFO - 2018-05-04 07:57:47 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:57:47 --> Helper loaded: url_helper
INFO - 2018-05-04 07:57:47 --> Model Class Initialized
INFO - 2018-05-04 07:57:47 --> Model Class Initialized
INFO - 2018-05-04 07:57:47 --> Model Class Initialized
INFO - 2018-05-04 11:27:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:27:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:27:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:27:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:27:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:27:47 --> Final output sent to browser
DEBUG - 2018-05-04 11:27:47 --> Total execution time: 0.3790
INFO - 2018-05-04 07:57:48 --> Config Class Initialized
INFO - 2018-05-04 07:57:48 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:57:48 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:57:48 --> Utf8 Class Initialized
INFO - 2018-05-04 07:57:48 --> URI Class Initialized
INFO - 2018-05-04 07:57:48 --> Router Class Initialized
INFO - 2018-05-04 07:57:48 --> Output Class Initialized
INFO - 2018-05-04 07:57:48 --> Security Class Initialized
DEBUG - 2018-05-04 07:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:57:48 --> Input Class Initialized
INFO - 2018-05-04 07:57:48 --> Language Class Initialized
INFO - 2018-05-04 07:57:48 --> Loader Class Initialized
INFO - 2018-05-04 07:57:48 --> Helper loaded: common_helper
INFO - 2018-05-04 07:57:48 --> Database Driver Class Initialized
INFO - 2018-05-04 07:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:57:48 --> Email Class Initialized
INFO - 2018-05-04 07:57:48 --> Controller Class Initialized
INFO - 2018-05-04 07:57:48 --> Helper loaded: form_helper
INFO - 2018-05-04 07:57:48 --> Form Validation Class Initialized
INFO - 2018-05-04 07:57:48 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:57:48 --> Helper loaded: url_helper
INFO - 2018-05-04 07:57:48 --> Model Class Initialized
INFO - 2018-05-04 07:57:48 --> Model Class Initialized
INFO - 2018-05-04 07:57:48 --> Model Class Initialized
INFO - 2018-05-04 11:27:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:27:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:27:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:27:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addGeleryImages.php
INFO - 2018-05-04 11:27:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:27:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:27:48 --> Final output sent to browser
DEBUG - 2018-05-04 11:27:48 --> Total execution time: 0.1500
INFO - 2018-05-04 07:57:49 --> Config Class Initialized
INFO - 2018-05-04 07:57:49 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:57:49 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:57:49 --> Utf8 Class Initialized
INFO - 2018-05-04 07:57:49 --> URI Class Initialized
INFO - 2018-05-04 07:57:49 --> Router Class Initialized
INFO - 2018-05-04 07:57:49 --> Output Class Initialized
INFO - 2018-05-04 07:57:49 --> Security Class Initialized
DEBUG - 2018-05-04 07:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:57:49 --> Input Class Initialized
INFO - 2018-05-04 07:57:49 --> Language Class Initialized
INFO - 2018-05-04 07:57:49 --> Loader Class Initialized
INFO - 2018-05-04 07:57:49 --> Helper loaded: common_helper
INFO - 2018-05-04 07:57:49 --> Database Driver Class Initialized
INFO - 2018-05-04 07:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:57:49 --> Email Class Initialized
INFO - 2018-05-04 07:57:49 --> Controller Class Initialized
INFO - 2018-05-04 07:57:49 --> Helper loaded: form_helper
INFO - 2018-05-04 07:57:49 --> Form Validation Class Initialized
INFO - 2018-05-04 07:57:49 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:57:49 --> Helper loaded: url_helper
INFO - 2018-05-04 07:57:49 --> Model Class Initialized
INFO - 2018-05-04 07:57:49 --> Model Class Initialized
INFO - 2018-05-04 07:57:49 --> Model Class Initialized
INFO - 2018-05-04 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:27:49 --> Final output sent to browser
DEBUG - 2018-05-04 11:27:49 --> Total execution time: 0.1470
INFO - 2018-05-04 07:57:49 --> Config Class Initialized
INFO - 2018-05-04 07:57:49 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:57:49 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:57:49 --> Utf8 Class Initialized
INFO - 2018-05-04 07:57:49 --> URI Class Initialized
INFO - 2018-05-04 07:57:49 --> Router Class Initialized
INFO - 2018-05-04 07:57:49 --> Output Class Initialized
INFO - 2018-05-04 07:57:49 --> Security Class Initialized
DEBUG - 2018-05-04 07:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:57:49 --> Input Class Initialized
INFO - 2018-05-04 07:57:49 --> Language Class Initialized
INFO - 2018-05-04 07:57:49 --> Loader Class Initialized
INFO - 2018-05-04 07:57:49 --> Helper loaded: common_helper
INFO - 2018-05-04 07:57:49 --> Database Driver Class Initialized
INFO - 2018-05-04 07:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:57:49 --> Email Class Initialized
INFO - 2018-05-04 07:57:49 --> Controller Class Initialized
INFO - 2018-05-04 07:57:49 --> Helper loaded: form_helper
INFO - 2018-05-04 07:57:49 --> Form Validation Class Initialized
INFO - 2018-05-04 07:57:49 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:57:49 --> Helper loaded: url_helper
INFO - 2018-05-04 07:57:49 --> Model Class Initialized
INFO - 2018-05-04 07:57:49 --> Model Class Initialized
INFO - 2018-05-04 07:57:49 --> Model Class Initialized
INFO - 2018-05-04 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:27:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:27:49 --> Final output sent to browser
DEBUG - 2018-05-04 11:27:49 --> Total execution time: 0.1540
INFO - 2018-05-04 07:57:50 --> Config Class Initialized
INFO - 2018-05-04 07:57:50 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:57:50 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:57:50 --> Utf8 Class Initialized
INFO - 2018-05-04 07:57:50 --> URI Class Initialized
INFO - 2018-05-04 07:57:50 --> Router Class Initialized
INFO - 2018-05-04 07:57:50 --> Output Class Initialized
INFO - 2018-05-04 07:57:50 --> Security Class Initialized
DEBUG - 2018-05-04 07:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:57:50 --> Input Class Initialized
INFO - 2018-05-04 07:57:50 --> Language Class Initialized
INFO - 2018-05-04 07:57:50 --> Loader Class Initialized
INFO - 2018-05-04 07:57:50 --> Helper loaded: common_helper
INFO - 2018-05-04 07:57:50 --> Database Driver Class Initialized
INFO - 2018-05-04 07:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:57:50 --> Email Class Initialized
INFO - 2018-05-04 07:57:50 --> Controller Class Initialized
INFO - 2018-05-04 07:57:50 --> Helper loaded: form_helper
INFO - 2018-05-04 07:57:50 --> Form Validation Class Initialized
INFO - 2018-05-04 07:57:50 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:57:50 --> Helper loaded: url_helper
INFO - 2018-05-04 07:57:50 --> Model Class Initialized
INFO - 2018-05-04 07:57:50 --> Model Class Initialized
INFO - 2018-05-04 07:57:50 --> Model Class Initialized
INFO - 2018-05-04 11:27:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:27:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:27:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-04 11:27:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:27:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:27:50 --> Final output sent to browser
DEBUG - 2018-05-04 11:27:50 --> Total execution time: 0.1490
INFO - 2018-05-04 07:57:51 --> Config Class Initialized
INFO - 2018-05-04 07:57:51 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:57:51 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:57:51 --> Utf8 Class Initialized
INFO - 2018-05-04 07:57:51 --> URI Class Initialized
INFO - 2018-05-04 07:57:51 --> Router Class Initialized
INFO - 2018-05-04 07:57:51 --> Output Class Initialized
INFO - 2018-05-04 07:57:51 --> Security Class Initialized
DEBUG - 2018-05-04 07:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:57:51 --> Input Class Initialized
INFO - 2018-05-04 07:57:51 --> Language Class Initialized
INFO - 2018-05-04 07:57:51 --> Loader Class Initialized
INFO - 2018-05-04 07:57:51 --> Helper loaded: common_helper
INFO - 2018-05-04 07:57:51 --> Database Driver Class Initialized
INFO - 2018-05-04 07:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:57:51 --> Email Class Initialized
INFO - 2018-05-04 07:57:51 --> Controller Class Initialized
INFO - 2018-05-04 07:57:51 --> Helper loaded: form_helper
INFO - 2018-05-04 07:57:51 --> Form Validation Class Initialized
INFO - 2018-05-04 07:57:51 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:57:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:57:51 --> Helper loaded: url_helper
INFO - 2018-05-04 07:57:51 --> Model Class Initialized
INFO - 2018-05-04 07:57:51 --> Model Class Initialized
INFO - 2018-05-04 07:57:51 --> Model Class Initialized
INFO - 2018-05-04 11:27:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:27:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:27:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:27:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:27:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:27:51 --> Final output sent to browser
DEBUG - 2018-05-04 11:27:51 --> Total execution time: 0.1620
INFO - 2018-05-04 07:57:52 --> Config Class Initialized
INFO - 2018-05-04 07:57:52 --> Hooks Class Initialized
DEBUG - 2018-05-04 07:57:52 --> UTF-8 Support Enabled
INFO - 2018-05-04 07:57:52 --> Utf8 Class Initialized
INFO - 2018-05-04 07:57:52 --> URI Class Initialized
INFO - 2018-05-04 07:57:52 --> Router Class Initialized
INFO - 2018-05-04 07:57:52 --> Output Class Initialized
INFO - 2018-05-04 07:57:52 --> Security Class Initialized
DEBUG - 2018-05-04 07:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 07:57:52 --> Input Class Initialized
INFO - 2018-05-04 07:57:52 --> Language Class Initialized
INFO - 2018-05-04 07:57:52 --> Loader Class Initialized
INFO - 2018-05-04 07:57:52 --> Helper loaded: common_helper
INFO - 2018-05-04 07:57:52 --> Database Driver Class Initialized
INFO - 2018-05-04 07:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 07:57:52 --> Email Class Initialized
INFO - 2018-05-04 07:57:52 --> Controller Class Initialized
INFO - 2018-05-04 07:57:52 --> Helper loaded: form_helper
INFO - 2018-05-04 07:57:52 --> Form Validation Class Initialized
INFO - 2018-05-04 07:57:52 --> Helper loaded: email_helper
DEBUG - 2018-05-04 07:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 07:57:52 --> Helper loaded: url_helper
INFO - 2018-05-04 07:57:52 --> Model Class Initialized
INFO - 2018-05-04 07:57:52 --> Model Class Initialized
INFO - 2018-05-04 07:57:52 --> Model Class Initialized
INFO - 2018-05-04 11:27:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:27:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:27:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-04 11:27:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:27:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:27:52 --> Final output sent to browser
DEBUG - 2018-05-04 11:27:52 --> Total execution time: 0.1390
INFO - 2018-05-04 08:04:24 --> Config Class Initialized
INFO - 2018-05-04 08:04:24 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:04:24 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:04:24 --> Utf8 Class Initialized
INFO - 2018-05-04 08:04:24 --> URI Class Initialized
INFO - 2018-05-04 08:04:24 --> Router Class Initialized
INFO - 2018-05-04 08:04:24 --> Output Class Initialized
INFO - 2018-05-04 08:04:24 --> Security Class Initialized
DEBUG - 2018-05-04 08:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:04:24 --> Input Class Initialized
INFO - 2018-05-04 08:04:24 --> Language Class Initialized
INFO - 2018-05-04 08:04:24 --> Loader Class Initialized
INFO - 2018-05-04 08:04:24 --> Helper loaded: common_helper
INFO - 2018-05-04 08:04:24 --> Database Driver Class Initialized
INFO - 2018-05-04 08:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:04:24 --> Email Class Initialized
INFO - 2018-05-04 08:04:24 --> Controller Class Initialized
INFO - 2018-05-04 08:04:24 --> Helper loaded: form_helper
INFO - 2018-05-04 08:04:24 --> Form Validation Class Initialized
INFO - 2018-05-04 08:04:24 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:04:24 --> Helper loaded: url_helper
INFO - 2018-05-04 08:04:24 --> Model Class Initialized
INFO - 2018-05-04 08:04:24 --> Model Class Initialized
INFO - 2018-05-04 08:04:24 --> Model Class Initialized
INFO - 2018-05-04 11:34:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:34:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:34:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:34:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:34:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:34:24 --> Final output sent to browser
DEBUG - 2018-05-04 11:34:24 --> Total execution time: 0.1430
INFO - 2018-05-04 08:04:26 --> Config Class Initialized
INFO - 2018-05-04 08:04:26 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:04:26 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:04:26 --> Utf8 Class Initialized
INFO - 2018-05-04 08:04:26 --> URI Class Initialized
INFO - 2018-05-04 08:04:26 --> Router Class Initialized
INFO - 2018-05-04 08:04:26 --> Output Class Initialized
INFO - 2018-05-04 08:04:26 --> Security Class Initialized
DEBUG - 2018-05-04 08:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:04:26 --> Input Class Initialized
INFO - 2018-05-04 08:04:26 --> Language Class Initialized
INFO - 2018-05-04 08:04:26 --> Loader Class Initialized
INFO - 2018-05-04 08:04:26 --> Helper loaded: common_helper
INFO - 2018-05-04 08:04:26 --> Database Driver Class Initialized
INFO - 2018-05-04 08:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:04:26 --> Email Class Initialized
INFO - 2018-05-04 08:04:26 --> Controller Class Initialized
INFO - 2018-05-04 08:04:26 --> Helper loaded: form_helper
INFO - 2018-05-04 08:04:26 --> Form Validation Class Initialized
INFO - 2018-05-04 08:04:26 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:04:26 --> Helper loaded: url_helper
INFO - 2018-05-04 08:04:26 --> Model Class Initialized
INFO - 2018-05-04 08:04:26 --> Model Class Initialized
INFO - 2018-05-04 08:04:26 --> Model Class Initialized
INFO - 2018-05-04 11:34:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:34:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:34:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:34:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:34:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 11:34:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:34:26 --> Final output sent to browser
DEBUG - 2018-05-04 11:34:26 --> Total execution time: 0.1540
INFO - 2018-05-04 08:09:11 --> Config Class Initialized
INFO - 2018-05-04 08:09:11 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:09:11 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:09:11 --> Utf8 Class Initialized
INFO - 2018-05-04 08:09:11 --> URI Class Initialized
INFO - 2018-05-04 08:09:11 --> Router Class Initialized
INFO - 2018-05-04 08:09:11 --> Output Class Initialized
INFO - 2018-05-04 08:09:11 --> Security Class Initialized
DEBUG - 2018-05-04 08:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:09:11 --> Input Class Initialized
INFO - 2018-05-04 08:09:11 --> Language Class Initialized
INFO - 2018-05-04 08:09:11 --> Loader Class Initialized
INFO - 2018-05-04 08:09:11 --> Helper loaded: common_helper
INFO - 2018-05-04 08:09:11 --> Database Driver Class Initialized
INFO - 2018-05-04 08:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:09:11 --> Email Class Initialized
INFO - 2018-05-04 08:09:11 --> Controller Class Initialized
INFO - 2018-05-04 08:09:11 --> Helper loaded: form_helper
INFO - 2018-05-04 08:09:11 --> Form Validation Class Initialized
INFO - 2018-05-04 08:09:11 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:09:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:09:11 --> Helper loaded: url_helper
INFO - 2018-05-04 08:09:11 --> Model Class Initialized
INFO - 2018-05-04 08:09:11 --> Model Class Initialized
INFO - 2018-05-04 08:09:11 --> Model Class Initialized
INFO - 2018-05-04 08:09:11 --> Config Class Initialized
INFO - 2018-05-04 08:09:11 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:09:11 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:09:11 --> Utf8 Class Initialized
INFO - 2018-05-04 08:09:11 --> URI Class Initialized
INFO - 2018-05-04 08:09:11 --> Router Class Initialized
INFO - 2018-05-04 08:09:11 --> Output Class Initialized
INFO - 2018-05-04 08:09:11 --> Security Class Initialized
DEBUG - 2018-05-04 08:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:09:11 --> Input Class Initialized
INFO - 2018-05-04 08:09:11 --> Language Class Initialized
INFO - 2018-05-04 08:09:11 --> Loader Class Initialized
INFO - 2018-05-04 08:09:11 --> Helper loaded: common_helper
INFO - 2018-05-04 08:09:11 --> Database Driver Class Initialized
INFO - 2018-05-04 08:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:09:11 --> Email Class Initialized
INFO - 2018-05-04 08:09:11 --> Controller Class Initialized
INFO - 2018-05-04 08:09:11 --> Helper loaded: form_helper
INFO - 2018-05-04 08:09:11 --> Form Validation Class Initialized
INFO - 2018-05-04 08:09:11 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:09:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:09:11 --> Helper loaded: url_helper
INFO - 2018-05-04 08:09:11 --> Model Class Initialized
INFO - 2018-05-04 08:09:11 --> Model Class Initialized
INFO - 2018-05-04 08:09:11 --> Model Class Initialized
INFO - 2018-05-04 11:39:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:39:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:39:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:39:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:39:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:39:11 --> Final output sent to browser
DEBUG - 2018-05-04 11:39:11 --> Total execution time: 0.1250
INFO - 2018-05-04 08:09:11 --> Config Class Initialized
INFO - 2018-05-04 08:09:11 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:09:11 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:09:11 --> Utf8 Class Initialized
INFO - 2018-05-04 08:09:11 --> URI Class Initialized
INFO - 2018-05-04 08:09:11 --> Router Class Initialized
INFO - 2018-05-04 08:09:11 --> Output Class Initialized
INFO - 2018-05-04 08:09:11 --> Security Class Initialized
DEBUG - 2018-05-04 08:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:09:11 --> Input Class Initialized
INFO - 2018-05-04 08:09:11 --> Language Class Initialized
INFO - 2018-05-04 08:09:11 --> Loader Class Initialized
INFO - 2018-05-04 08:09:11 --> Helper loaded: common_helper
INFO - 2018-05-04 08:09:11 --> Database Driver Class Initialized
INFO - 2018-05-04 08:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:09:11 --> Email Class Initialized
INFO - 2018-05-04 08:09:11 --> Controller Class Initialized
INFO - 2018-05-04 08:09:11 --> Helper loaded: form_helper
INFO - 2018-05-04 08:09:11 --> Form Validation Class Initialized
INFO - 2018-05-04 08:09:11 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:09:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:09:11 --> Helper loaded: url_helper
INFO - 2018-05-04 08:09:11 --> Model Class Initialized
INFO - 2018-05-04 08:09:11 --> Model Class Initialized
INFO - 2018-05-04 08:09:11 --> Model Class Initialized
INFO - 2018-05-04 11:39:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:39:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:39:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:39:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:39:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 11:39:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:39:11 --> Final output sent to browser
DEBUG - 2018-05-04 11:39:11 --> Total execution time: 0.1350
INFO - 2018-05-04 08:10:00 --> Config Class Initialized
INFO - 2018-05-04 08:10:00 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:10:00 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:10:00 --> Utf8 Class Initialized
INFO - 2018-05-04 08:10:00 --> URI Class Initialized
INFO - 2018-05-04 08:10:00 --> Router Class Initialized
INFO - 2018-05-04 08:10:00 --> Output Class Initialized
INFO - 2018-05-04 08:10:00 --> Security Class Initialized
DEBUG - 2018-05-04 08:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:10:00 --> Input Class Initialized
INFO - 2018-05-04 08:10:00 --> Language Class Initialized
INFO - 2018-05-04 08:10:00 --> Loader Class Initialized
INFO - 2018-05-04 08:10:00 --> Helper loaded: common_helper
INFO - 2018-05-04 08:10:00 --> Database Driver Class Initialized
INFO - 2018-05-04 08:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:10:00 --> Email Class Initialized
INFO - 2018-05-04 08:10:00 --> Controller Class Initialized
INFO - 2018-05-04 08:10:00 --> Helper loaded: form_helper
INFO - 2018-05-04 08:10:00 --> Form Validation Class Initialized
INFO - 2018-05-04 08:10:00 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:10:00 --> Helper loaded: url_helper
INFO - 2018-05-04 08:10:00 --> Model Class Initialized
INFO - 2018-05-04 08:10:00 --> Model Class Initialized
INFO - 2018-05-04 08:10:00 --> Model Class Initialized
INFO - 2018-05-04 11:40:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:40:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:40:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:40:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:40:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 11:40:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:40:00 --> Final output sent to browser
DEBUG - 2018-05-04 11:40:00 --> Total execution time: 0.1670
INFO - 2018-05-04 08:10:07 --> Config Class Initialized
INFO - 2018-05-04 08:10:07 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:10:07 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:10:07 --> Utf8 Class Initialized
INFO - 2018-05-04 08:10:07 --> URI Class Initialized
INFO - 2018-05-04 08:10:07 --> Router Class Initialized
INFO - 2018-05-04 08:10:07 --> Output Class Initialized
INFO - 2018-05-04 08:10:07 --> Security Class Initialized
DEBUG - 2018-05-04 08:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:10:07 --> Input Class Initialized
INFO - 2018-05-04 08:10:07 --> Language Class Initialized
INFO - 2018-05-04 08:10:07 --> Loader Class Initialized
INFO - 2018-05-04 08:10:07 --> Helper loaded: common_helper
INFO - 2018-05-04 08:10:07 --> Database Driver Class Initialized
INFO - 2018-05-04 08:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:10:07 --> Email Class Initialized
INFO - 2018-05-04 08:10:07 --> Controller Class Initialized
INFO - 2018-05-04 08:10:07 --> Helper loaded: form_helper
INFO - 2018-05-04 08:10:07 --> Form Validation Class Initialized
INFO - 2018-05-04 08:10:07 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:10:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:10:07 --> Helper loaded: url_helper
INFO - 2018-05-04 08:10:07 --> Model Class Initialized
INFO - 2018-05-04 08:10:07 --> Model Class Initialized
INFO - 2018-05-04 08:10:07 --> Model Class Initialized
INFO - 2018-05-04 11:40:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:40:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:40:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:40:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:40:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 11:40:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:40:07 --> Final output sent to browser
DEBUG - 2018-05-04 11:40:07 --> Total execution time: 0.1310
INFO - 2018-05-04 08:10:10 --> Config Class Initialized
INFO - 2018-05-04 08:10:10 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:10:10 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:10:10 --> Utf8 Class Initialized
INFO - 2018-05-04 08:10:10 --> URI Class Initialized
INFO - 2018-05-04 08:10:10 --> Router Class Initialized
INFO - 2018-05-04 08:10:10 --> Output Class Initialized
INFO - 2018-05-04 08:10:10 --> Security Class Initialized
DEBUG - 2018-05-04 08:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:10:10 --> Input Class Initialized
INFO - 2018-05-04 08:10:10 --> Language Class Initialized
INFO - 2018-05-04 08:10:10 --> Loader Class Initialized
INFO - 2018-05-04 08:10:10 --> Helper loaded: common_helper
INFO - 2018-05-04 08:10:10 --> Database Driver Class Initialized
INFO - 2018-05-04 08:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:10:10 --> Email Class Initialized
INFO - 2018-05-04 08:10:10 --> Controller Class Initialized
INFO - 2018-05-04 08:10:10 --> Helper loaded: form_helper
INFO - 2018-05-04 08:10:10 --> Form Validation Class Initialized
INFO - 2018-05-04 08:10:10 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:10:10 --> Helper loaded: url_helper
INFO - 2018-05-04 08:10:10 --> Model Class Initialized
INFO - 2018-05-04 08:10:10 --> Model Class Initialized
INFO - 2018-05-04 08:10:10 --> Model Class Initialized
INFO - 2018-05-04 08:10:10 --> Config Class Initialized
INFO - 2018-05-04 08:10:10 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:10:10 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:10:10 --> Utf8 Class Initialized
INFO - 2018-05-04 08:10:10 --> URI Class Initialized
INFO - 2018-05-04 08:10:10 --> Router Class Initialized
INFO - 2018-05-04 08:10:10 --> Output Class Initialized
INFO - 2018-05-04 08:10:10 --> Security Class Initialized
DEBUG - 2018-05-04 08:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:10:10 --> Input Class Initialized
INFO - 2018-05-04 08:10:10 --> Language Class Initialized
INFO - 2018-05-04 08:10:10 --> Loader Class Initialized
INFO - 2018-05-04 08:10:10 --> Helper loaded: common_helper
INFO - 2018-05-04 08:10:10 --> Database Driver Class Initialized
INFO - 2018-05-04 08:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:10:10 --> Email Class Initialized
INFO - 2018-05-04 08:10:10 --> Controller Class Initialized
INFO - 2018-05-04 08:10:10 --> Helper loaded: form_helper
INFO - 2018-05-04 08:10:10 --> Form Validation Class Initialized
INFO - 2018-05-04 08:10:10 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:10:10 --> Helper loaded: url_helper
INFO - 2018-05-04 08:10:10 --> Model Class Initialized
INFO - 2018-05-04 08:10:10 --> Model Class Initialized
INFO - 2018-05-04 08:10:10 --> Model Class Initialized
INFO - 2018-05-04 11:40:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:40:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:40:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:40:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:40:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:40:10 --> Final output sent to browser
DEBUG - 2018-05-04 11:40:10 --> Total execution time: 0.1280
INFO - 2018-05-04 08:10:10 --> Config Class Initialized
INFO - 2018-05-04 08:10:10 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:10:10 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:10:10 --> Utf8 Class Initialized
INFO - 2018-05-04 08:10:10 --> URI Class Initialized
INFO - 2018-05-04 08:10:10 --> Router Class Initialized
INFO - 2018-05-04 08:10:10 --> Output Class Initialized
INFO - 2018-05-04 08:10:10 --> Security Class Initialized
DEBUG - 2018-05-04 08:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:10:10 --> Input Class Initialized
INFO - 2018-05-04 08:10:10 --> Language Class Initialized
INFO - 2018-05-04 08:10:10 --> Loader Class Initialized
INFO - 2018-05-04 08:10:10 --> Helper loaded: common_helper
INFO - 2018-05-04 08:10:10 --> Database Driver Class Initialized
INFO - 2018-05-04 08:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:10:10 --> Email Class Initialized
INFO - 2018-05-04 08:10:10 --> Controller Class Initialized
INFO - 2018-05-04 08:10:10 --> Helper loaded: form_helper
INFO - 2018-05-04 08:10:10 --> Form Validation Class Initialized
INFO - 2018-05-04 08:10:10 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:10:10 --> Helper loaded: url_helper
INFO - 2018-05-04 08:10:10 --> Model Class Initialized
INFO - 2018-05-04 08:10:10 --> Model Class Initialized
INFO - 2018-05-04 08:10:10 --> Model Class Initialized
INFO - 2018-05-04 11:40:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:40:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:40:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:40:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:40:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 11:40:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:40:10 --> Final output sent to browser
DEBUG - 2018-05-04 11:40:10 --> Total execution time: 0.1350
INFO - 2018-05-04 08:10:14 --> Config Class Initialized
INFO - 2018-05-04 08:10:14 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:10:14 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:10:14 --> Utf8 Class Initialized
INFO - 2018-05-04 08:10:14 --> URI Class Initialized
INFO - 2018-05-04 08:10:14 --> Router Class Initialized
INFO - 2018-05-04 08:10:14 --> Output Class Initialized
INFO - 2018-05-04 08:10:14 --> Security Class Initialized
DEBUG - 2018-05-04 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:10:14 --> Input Class Initialized
INFO - 2018-05-04 08:10:14 --> Language Class Initialized
INFO - 2018-05-04 08:10:14 --> Loader Class Initialized
INFO - 2018-05-04 08:10:14 --> Helper loaded: common_helper
INFO - 2018-05-04 08:10:14 --> Database Driver Class Initialized
INFO - 2018-05-04 08:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:10:14 --> Email Class Initialized
INFO - 2018-05-04 08:10:14 --> Controller Class Initialized
INFO - 2018-05-04 08:10:14 --> Helper loaded: form_helper
INFO - 2018-05-04 08:10:14 --> Form Validation Class Initialized
INFO - 2018-05-04 08:10:14 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:10:14 --> Helper loaded: url_helper
INFO - 2018-05-04 08:10:14 --> Model Class Initialized
INFO - 2018-05-04 08:10:14 --> Model Class Initialized
INFO - 2018-05-04 08:10:14 --> Model Class Initialized
INFO - 2018-05-04 08:10:14 --> Config Class Initialized
INFO - 2018-05-04 08:10:14 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:10:14 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:10:14 --> Utf8 Class Initialized
INFO - 2018-05-04 08:10:14 --> URI Class Initialized
INFO - 2018-05-04 08:10:14 --> Router Class Initialized
INFO - 2018-05-04 08:10:14 --> Output Class Initialized
INFO - 2018-05-04 08:10:14 --> Security Class Initialized
DEBUG - 2018-05-04 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:10:14 --> Input Class Initialized
INFO - 2018-05-04 08:10:14 --> Language Class Initialized
INFO - 2018-05-04 08:10:14 --> Loader Class Initialized
INFO - 2018-05-04 08:10:14 --> Helper loaded: common_helper
INFO - 2018-05-04 08:10:14 --> Database Driver Class Initialized
INFO - 2018-05-04 08:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:10:14 --> Email Class Initialized
INFO - 2018-05-04 08:10:14 --> Controller Class Initialized
INFO - 2018-05-04 08:10:14 --> Helper loaded: form_helper
INFO - 2018-05-04 08:10:14 --> Form Validation Class Initialized
INFO - 2018-05-04 08:10:14 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:10:14 --> Helper loaded: url_helper
INFO - 2018-05-04 08:10:14 --> Model Class Initialized
INFO - 2018-05-04 08:10:14 --> Model Class Initialized
INFO - 2018-05-04 08:10:14 --> Model Class Initialized
INFO - 2018-05-04 11:40:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:40:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:40:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:40:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:40:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:40:14 --> Final output sent to browser
DEBUG - 2018-05-04 11:40:14 --> Total execution time: 0.1230
INFO - 2018-05-04 08:10:14 --> Config Class Initialized
INFO - 2018-05-04 08:10:14 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:10:14 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:10:14 --> Utf8 Class Initialized
INFO - 2018-05-04 08:10:14 --> URI Class Initialized
INFO - 2018-05-04 08:10:14 --> Router Class Initialized
INFO - 2018-05-04 08:10:14 --> Output Class Initialized
INFO - 2018-05-04 08:10:14 --> Security Class Initialized
DEBUG - 2018-05-04 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:10:14 --> Input Class Initialized
INFO - 2018-05-04 08:10:14 --> Language Class Initialized
INFO - 2018-05-04 08:10:14 --> Loader Class Initialized
INFO - 2018-05-04 08:10:14 --> Helper loaded: common_helper
INFO - 2018-05-04 08:10:14 --> Database Driver Class Initialized
INFO - 2018-05-04 08:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:10:14 --> Email Class Initialized
INFO - 2018-05-04 08:10:14 --> Controller Class Initialized
INFO - 2018-05-04 08:10:14 --> Helper loaded: form_helper
INFO - 2018-05-04 08:10:14 --> Form Validation Class Initialized
INFO - 2018-05-04 08:10:14 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:10:14 --> Helper loaded: url_helper
INFO - 2018-05-04 08:10:14 --> Model Class Initialized
INFO - 2018-05-04 08:10:14 --> Model Class Initialized
INFO - 2018-05-04 08:10:14 --> Model Class Initialized
INFO - 2018-05-04 11:40:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:40:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:40:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:40:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:40:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 11:40:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:40:14 --> Final output sent to browser
DEBUG - 2018-05-04 11:40:14 --> Total execution time: 0.1280
INFO - 2018-05-04 08:10:23 --> Config Class Initialized
INFO - 2018-05-04 08:10:23 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:10:23 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:10:23 --> Utf8 Class Initialized
INFO - 2018-05-04 08:10:23 --> URI Class Initialized
INFO - 2018-05-04 08:10:23 --> Router Class Initialized
INFO - 2018-05-04 08:10:23 --> Output Class Initialized
INFO - 2018-05-04 08:10:23 --> Security Class Initialized
DEBUG - 2018-05-04 08:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:10:23 --> Input Class Initialized
INFO - 2018-05-04 08:10:23 --> Language Class Initialized
INFO - 2018-05-04 08:10:23 --> Loader Class Initialized
INFO - 2018-05-04 08:10:23 --> Helper loaded: common_helper
INFO - 2018-05-04 08:10:23 --> Database Driver Class Initialized
INFO - 2018-05-04 08:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:10:23 --> Email Class Initialized
INFO - 2018-05-04 08:10:23 --> Controller Class Initialized
INFO - 2018-05-04 08:10:23 --> Helper loaded: form_helper
INFO - 2018-05-04 08:10:23 --> Form Validation Class Initialized
INFO - 2018-05-04 08:10:23 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:10:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:10:23 --> Helper loaded: url_helper
INFO - 2018-05-04 08:10:23 --> Model Class Initialized
INFO - 2018-05-04 08:10:23 --> Model Class Initialized
INFO - 2018-05-04 08:10:23 --> Model Class Initialized
INFO - 2018-05-04 08:10:24 --> Config Class Initialized
INFO - 2018-05-04 08:10:24 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:10:24 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:10:24 --> Utf8 Class Initialized
INFO - 2018-05-04 08:10:24 --> URI Class Initialized
INFO - 2018-05-04 08:10:24 --> Router Class Initialized
INFO - 2018-05-04 08:10:24 --> Output Class Initialized
INFO - 2018-05-04 08:10:24 --> Security Class Initialized
DEBUG - 2018-05-04 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:10:24 --> Input Class Initialized
INFO - 2018-05-04 08:10:24 --> Language Class Initialized
INFO - 2018-05-04 08:10:24 --> Loader Class Initialized
INFO - 2018-05-04 08:10:24 --> Helper loaded: common_helper
INFO - 2018-05-04 08:10:24 --> Database Driver Class Initialized
INFO - 2018-05-04 08:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:10:24 --> Email Class Initialized
INFO - 2018-05-04 08:10:24 --> Controller Class Initialized
INFO - 2018-05-04 08:10:24 --> Helper loaded: form_helper
INFO - 2018-05-04 08:10:24 --> Form Validation Class Initialized
INFO - 2018-05-04 08:10:24 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:10:24 --> Helper loaded: url_helper
INFO - 2018-05-04 08:10:24 --> Model Class Initialized
INFO - 2018-05-04 08:10:24 --> Model Class Initialized
INFO - 2018-05-04 08:10:24 --> Model Class Initialized
INFO - 2018-05-04 11:40:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:40:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:40:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:40:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:40:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:40:24 --> Final output sent to browser
DEBUG - 2018-05-04 11:40:24 --> Total execution time: 0.1260
INFO - 2018-05-04 08:10:24 --> Config Class Initialized
INFO - 2018-05-04 08:10:24 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:10:24 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:10:24 --> Utf8 Class Initialized
INFO - 2018-05-04 08:10:24 --> URI Class Initialized
INFO - 2018-05-04 08:10:24 --> Router Class Initialized
INFO - 2018-05-04 08:10:24 --> Output Class Initialized
INFO - 2018-05-04 08:10:24 --> Security Class Initialized
DEBUG - 2018-05-04 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:10:24 --> Input Class Initialized
INFO - 2018-05-04 08:10:24 --> Language Class Initialized
INFO - 2018-05-04 08:10:24 --> Loader Class Initialized
INFO - 2018-05-04 08:10:24 --> Helper loaded: common_helper
INFO - 2018-05-04 08:10:24 --> Database Driver Class Initialized
INFO - 2018-05-04 08:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:10:24 --> Email Class Initialized
INFO - 2018-05-04 08:10:24 --> Controller Class Initialized
INFO - 2018-05-04 08:10:24 --> Helper loaded: form_helper
INFO - 2018-05-04 08:10:24 --> Form Validation Class Initialized
INFO - 2018-05-04 08:10:24 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:10:24 --> Helper loaded: url_helper
INFO - 2018-05-04 08:10:24 --> Model Class Initialized
INFO - 2018-05-04 08:10:24 --> Model Class Initialized
INFO - 2018-05-04 08:10:24 --> Model Class Initialized
INFO - 2018-05-04 11:40:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:40:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:40:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:40:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:40:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 11:40:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:40:24 --> Final output sent to browser
DEBUG - 2018-05-04 11:40:24 --> Total execution time: 0.1460
INFO - 2018-05-04 08:11:04 --> Config Class Initialized
INFO - 2018-05-04 08:11:04 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:11:04 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:11:04 --> Utf8 Class Initialized
INFO - 2018-05-04 08:11:04 --> URI Class Initialized
INFO - 2018-05-04 08:11:04 --> Router Class Initialized
INFO - 2018-05-04 08:11:04 --> Output Class Initialized
INFO - 2018-05-04 08:11:04 --> Security Class Initialized
DEBUG - 2018-05-04 08:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:11:04 --> Input Class Initialized
INFO - 2018-05-04 08:11:04 --> Language Class Initialized
INFO - 2018-05-04 08:11:04 --> Loader Class Initialized
INFO - 2018-05-04 08:11:04 --> Helper loaded: common_helper
INFO - 2018-05-04 08:11:04 --> Database Driver Class Initialized
INFO - 2018-05-04 08:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:11:04 --> Email Class Initialized
INFO - 2018-05-04 08:11:04 --> Controller Class Initialized
INFO - 2018-05-04 08:11:04 --> Helper loaded: form_helper
INFO - 2018-05-04 08:11:04 --> Form Validation Class Initialized
INFO - 2018-05-04 08:11:04 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:11:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:11:04 --> Helper loaded: url_helper
INFO - 2018-05-04 08:11:04 --> Model Class Initialized
INFO - 2018-05-04 08:11:04 --> Model Class Initialized
INFO - 2018-05-04 08:11:04 --> Model Class Initialized
INFO - 2018-05-04 11:41:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:41:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:41:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:41:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:41:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 11:41:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:41:04 --> Final output sent to browser
DEBUG - 2018-05-04 11:41:04 --> Total execution time: 0.1370
INFO - 2018-05-04 08:11:07 --> Config Class Initialized
INFO - 2018-05-04 08:11:07 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:11:07 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:11:07 --> Utf8 Class Initialized
INFO - 2018-05-04 08:11:07 --> URI Class Initialized
INFO - 2018-05-04 08:11:07 --> Router Class Initialized
INFO - 2018-05-04 08:11:07 --> Output Class Initialized
INFO - 2018-05-04 08:11:07 --> Security Class Initialized
DEBUG - 2018-05-04 08:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:11:07 --> Input Class Initialized
INFO - 2018-05-04 08:11:07 --> Language Class Initialized
INFO - 2018-05-04 08:11:07 --> Loader Class Initialized
INFO - 2018-05-04 08:11:07 --> Helper loaded: common_helper
INFO - 2018-05-04 08:11:07 --> Database Driver Class Initialized
INFO - 2018-05-04 08:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:11:07 --> Email Class Initialized
INFO - 2018-05-04 08:11:07 --> Controller Class Initialized
INFO - 2018-05-04 08:11:07 --> Helper loaded: form_helper
INFO - 2018-05-04 08:11:07 --> Form Validation Class Initialized
INFO - 2018-05-04 08:11:07 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:11:07 --> Helper loaded: url_helper
INFO - 2018-05-04 08:11:07 --> Model Class Initialized
INFO - 2018-05-04 08:11:07 --> Model Class Initialized
INFO - 2018-05-04 08:11:07 --> Model Class Initialized
INFO - 2018-05-04 11:41:08 --> Final output sent to browser
DEBUG - 2018-05-04 11:41:08 --> Total execution time: 0.2700
INFO - 2018-05-04 08:11:08 --> Config Class Initialized
INFO - 2018-05-04 08:11:08 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:11:08 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:11:08 --> Utf8 Class Initialized
INFO - 2018-05-04 08:11:08 --> URI Class Initialized
INFO - 2018-05-04 08:11:08 --> Router Class Initialized
INFO - 2018-05-04 08:11:08 --> Output Class Initialized
INFO - 2018-05-04 08:11:08 --> Security Class Initialized
DEBUG - 2018-05-04 08:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:11:08 --> Input Class Initialized
INFO - 2018-05-04 08:11:08 --> Language Class Initialized
INFO - 2018-05-04 08:11:08 --> Loader Class Initialized
INFO - 2018-05-04 08:11:08 --> Helper loaded: common_helper
INFO - 2018-05-04 08:11:08 --> Database Driver Class Initialized
INFO - 2018-05-04 08:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:11:08 --> Email Class Initialized
INFO - 2018-05-04 08:11:08 --> Controller Class Initialized
INFO - 2018-05-04 08:11:08 --> Helper loaded: form_helper
INFO - 2018-05-04 08:11:08 --> Form Validation Class Initialized
INFO - 2018-05-04 08:11:08 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:11:08 --> Helper loaded: url_helper
INFO - 2018-05-04 08:11:08 --> Model Class Initialized
INFO - 2018-05-04 08:11:08 --> Model Class Initialized
INFO - 2018-05-04 08:11:08 --> Model Class Initialized
INFO - 2018-05-04 11:41:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:41:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:41:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:41:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:41:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 11:41:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:41:08 --> Final output sent to browser
DEBUG - 2018-05-04 11:41:08 --> Total execution time: 0.1440
INFO - 2018-05-04 08:11:13 --> Config Class Initialized
INFO - 2018-05-04 08:11:13 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:11:13 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:11:13 --> Utf8 Class Initialized
INFO - 2018-05-04 08:11:13 --> URI Class Initialized
INFO - 2018-05-04 08:11:13 --> Router Class Initialized
INFO - 2018-05-04 08:11:13 --> Output Class Initialized
INFO - 2018-05-04 08:11:13 --> Security Class Initialized
DEBUG - 2018-05-04 08:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:11:13 --> Input Class Initialized
INFO - 2018-05-04 08:11:13 --> Language Class Initialized
INFO - 2018-05-04 08:11:13 --> Loader Class Initialized
INFO - 2018-05-04 08:11:13 --> Helper loaded: common_helper
INFO - 2018-05-04 08:11:13 --> Database Driver Class Initialized
INFO - 2018-05-04 08:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:11:13 --> Email Class Initialized
INFO - 2018-05-04 08:11:13 --> Controller Class Initialized
INFO - 2018-05-04 08:11:13 --> Helper loaded: form_helper
INFO - 2018-05-04 08:11:13 --> Form Validation Class Initialized
INFO - 2018-05-04 08:11:13 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:11:13 --> Helper loaded: url_helper
INFO - 2018-05-04 08:11:13 --> Model Class Initialized
INFO - 2018-05-04 08:11:13 --> Model Class Initialized
INFO - 2018-05-04 08:11:13 --> Model Class Initialized
INFO - 2018-05-04 11:41:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:41:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:41:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:41:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:41:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:41:13 --> Final output sent to browser
DEBUG - 2018-05-04 11:41:13 --> Total execution time: 0.2110
INFO - 2018-05-04 08:11:15 --> Config Class Initialized
INFO - 2018-05-04 08:11:15 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:11:15 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:11:15 --> Utf8 Class Initialized
INFO - 2018-05-04 08:11:15 --> URI Class Initialized
INFO - 2018-05-04 08:11:15 --> Router Class Initialized
INFO - 2018-05-04 08:11:15 --> Output Class Initialized
INFO - 2018-05-04 08:11:15 --> Security Class Initialized
DEBUG - 2018-05-04 08:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:11:15 --> Input Class Initialized
INFO - 2018-05-04 08:11:15 --> Language Class Initialized
INFO - 2018-05-04 08:11:15 --> Loader Class Initialized
INFO - 2018-05-04 08:11:15 --> Helper loaded: common_helper
INFO - 2018-05-04 08:11:15 --> Database Driver Class Initialized
INFO - 2018-05-04 08:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:11:15 --> Email Class Initialized
INFO - 2018-05-04 08:11:15 --> Controller Class Initialized
INFO - 2018-05-04 08:11:15 --> Helper loaded: form_helper
INFO - 2018-05-04 08:11:15 --> Form Validation Class Initialized
INFO - 2018-05-04 08:11:15 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:11:15 --> Helper loaded: url_helper
INFO - 2018-05-04 08:11:15 --> Model Class Initialized
INFO - 2018-05-04 08:11:15 --> Model Class Initialized
INFO - 2018-05-04 08:11:15 --> Model Class Initialized
INFO - 2018-05-04 11:41:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:41:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:41:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:41:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:41:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:41:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:41:15 --> Final output sent to browser
DEBUG - 2018-05-04 11:41:15 --> Total execution time: 0.1670
INFO - 2018-05-04 08:11:18 --> Config Class Initialized
INFO - 2018-05-04 08:11:18 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:11:18 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:11:18 --> Utf8 Class Initialized
INFO - 2018-05-04 08:11:18 --> URI Class Initialized
INFO - 2018-05-04 08:11:18 --> Router Class Initialized
INFO - 2018-05-04 08:11:18 --> Output Class Initialized
INFO - 2018-05-04 08:11:18 --> Security Class Initialized
DEBUG - 2018-05-04 08:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:11:18 --> Input Class Initialized
INFO - 2018-05-04 08:11:18 --> Language Class Initialized
INFO - 2018-05-04 08:11:18 --> Loader Class Initialized
INFO - 2018-05-04 08:11:18 --> Helper loaded: common_helper
INFO - 2018-05-04 08:11:18 --> Database Driver Class Initialized
INFO - 2018-05-04 08:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:11:18 --> Email Class Initialized
INFO - 2018-05-04 08:11:18 --> Controller Class Initialized
INFO - 2018-05-04 08:11:18 --> Helper loaded: form_helper
INFO - 2018-05-04 08:11:18 --> Form Validation Class Initialized
INFO - 2018-05-04 08:11:18 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:11:18 --> Helper loaded: url_helper
INFO - 2018-05-04 08:11:18 --> Model Class Initialized
INFO - 2018-05-04 08:11:18 --> Model Class Initialized
INFO - 2018-05-04 08:11:18 --> Model Class Initialized
INFO - 2018-05-04 11:41:18 --> Final output sent to browser
DEBUG - 2018-05-04 11:41:18 --> Total execution time: 0.1320
INFO - 2018-05-04 08:11:18 --> Config Class Initialized
INFO - 2018-05-04 08:11:18 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:11:18 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:11:18 --> Utf8 Class Initialized
INFO - 2018-05-04 08:11:18 --> URI Class Initialized
INFO - 2018-05-04 08:11:18 --> Router Class Initialized
INFO - 2018-05-04 08:11:18 --> Output Class Initialized
INFO - 2018-05-04 08:11:18 --> Security Class Initialized
DEBUG - 2018-05-04 08:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:11:18 --> Input Class Initialized
INFO - 2018-05-04 08:11:18 --> Language Class Initialized
INFO - 2018-05-04 08:11:18 --> Loader Class Initialized
INFO - 2018-05-04 08:11:18 --> Helper loaded: common_helper
INFO - 2018-05-04 08:11:18 --> Database Driver Class Initialized
INFO - 2018-05-04 08:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:11:18 --> Email Class Initialized
INFO - 2018-05-04 08:11:18 --> Controller Class Initialized
INFO - 2018-05-04 08:11:18 --> Helper loaded: form_helper
INFO - 2018-05-04 08:11:18 --> Form Validation Class Initialized
INFO - 2018-05-04 08:11:18 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:11:18 --> Helper loaded: url_helper
INFO - 2018-05-04 08:11:18 --> Model Class Initialized
INFO - 2018-05-04 08:11:18 --> Model Class Initialized
INFO - 2018-05-04 08:11:18 --> Model Class Initialized
INFO - 2018-05-04 11:41:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:41:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:41:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:41:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:41:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:41:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:41:18 --> Final output sent to browser
DEBUG - 2018-05-04 11:41:18 --> Total execution time: 0.1380
INFO - 2018-05-04 08:11:23 --> Config Class Initialized
INFO - 2018-05-04 08:11:23 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:11:23 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:11:23 --> Utf8 Class Initialized
INFO - 2018-05-04 08:11:23 --> URI Class Initialized
INFO - 2018-05-04 08:11:23 --> Router Class Initialized
INFO - 2018-05-04 08:11:23 --> Output Class Initialized
INFO - 2018-05-04 08:11:23 --> Security Class Initialized
DEBUG - 2018-05-04 08:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:11:23 --> Input Class Initialized
INFO - 2018-05-04 08:11:23 --> Language Class Initialized
INFO - 2018-05-04 08:11:23 --> Loader Class Initialized
INFO - 2018-05-04 08:11:23 --> Helper loaded: common_helper
INFO - 2018-05-04 08:11:23 --> Database Driver Class Initialized
INFO - 2018-05-04 08:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:11:23 --> Email Class Initialized
INFO - 2018-05-04 08:11:23 --> Controller Class Initialized
INFO - 2018-05-04 08:11:23 --> Helper loaded: form_helper
INFO - 2018-05-04 08:11:23 --> Form Validation Class Initialized
INFO - 2018-05-04 08:11:23 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:11:23 --> Helper loaded: url_helper
INFO - 2018-05-04 08:11:23 --> Model Class Initialized
INFO - 2018-05-04 08:11:23 --> Model Class Initialized
INFO - 2018-05-04 08:11:23 --> Model Class Initialized
INFO - 2018-05-04 11:41:23 --> Final output sent to browser
DEBUG - 2018-05-04 11:41:23 --> Total execution time: 0.1290
INFO - 2018-05-04 08:11:23 --> Config Class Initialized
INFO - 2018-05-04 08:11:23 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:11:23 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:11:23 --> Utf8 Class Initialized
INFO - 2018-05-04 08:11:23 --> URI Class Initialized
INFO - 2018-05-04 08:11:23 --> Router Class Initialized
INFO - 2018-05-04 08:11:23 --> Output Class Initialized
INFO - 2018-05-04 08:11:23 --> Security Class Initialized
DEBUG - 2018-05-04 08:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:11:23 --> Input Class Initialized
INFO - 2018-05-04 08:11:23 --> Language Class Initialized
INFO - 2018-05-04 08:11:23 --> Loader Class Initialized
INFO - 2018-05-04 08:11:23 --> Helper loaded: common_helper
INFO - 2018-05-04 08:11:23 --> Database Driver Class Initialized
INFO - 2018-05-04 08:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:11:23 --> Email Class Initialized
INFO - 2018-05-04 08:11:23 --> Controller Class Initialized
INFO - 2018-05-04 08:11:23 --> Helper loaded: form_helper
INFO - 2018-05-04 08:11:23 --> Form Validation Class Initialized
INFO - 2018-05-04 08:11:23 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:11:23 --> Helper loaded: url_helper
INFO - 2018-05-04 08:11:23 --> Model Class Initialized
INFO - 2018-05-04 08:11:23 --> Model Class Initialized
INFO - 2018-05-04 08:11:23 --> Model Class Initialized
INFO - 2018-05-04 11:41:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:41:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:41:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:41:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:41:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:41:23 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:41:23 --> Final output sent to browser
DEBUG - 2018-05-04 11:41:23 --> Total execution time: 0.1390
INFO - 2018-05-04 08:13:35 --> Config Class Initialized
INFO - 2018-05-04 08:13:35 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:13:35 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:13:35 --> Utf8 Class Initialized
INFO - 2018-05-04 08:13:35 --> URI Class Initialized
INFO - 2018-05-04 08:13:35 --> Router Class Initialized
INFO - 2018-05-04 08:13:35 --> Output Class Initialized
INFO - 2018-05-04 08:13:35 --> Security Class Initialized
DEBUG - 2018-05-04 08:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:13:35 --> Input Class Initialized
INFO - 2018-05-04 08:13:35 --> Language Class Initialized
INFO - 2018-05-04 08:13:35 --> Loader Class Initialized
INFO - 2018-05-04 08:13:35 --> Helper loaded: common_helper
INFO - 2018-05-04 08:13:35 --> Database Driver Class Initialized
INFO - 2018-05-04 08:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:13:35 --> Email Class Initialized
INFO - 2018-05-04 08:13:35 --> Controller Class Initialized
INFO - 2018-05-04 08:13:35 --> Helper loaded: form_helper
INFO - 2018-05-04 08:13:35 --> Form Validation Class Initialized
INFO - 2018-05-04 08:13:35 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:13:35 --> Helper loaded: url_helper
INFO - 2018-05-04 08:13:35 --> Model Class Initialized
INFO - 2018-05-04 08:13:35 --> Model Class Initialized
INFO - 2018-05-04 08:13:35 --> Model Class Initialized
INFO - 2018-05-04 11:43:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:43:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:43:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:43:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:43:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:43:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:43:35 --> Final output sent to browser
DEBUG - 2018-05-04 11:43:35 --> Total execution time: 0.1470
INFO - 2018-05-04 08:13:38 --> Config Class Initialized
INFO - 2018-05-04 08:13:38 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:13:38 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:13:38 --> Utf8 Class Initialized
INFO - 2018-05-04 08:13:38 --> URI Class Initialized
INFO - 2018-05-04 08:13:38 --> Router Class Initialized
INFO - 2018-05-04 08:13:38 --> Output Class Initialized
INFO - 2018-05-04 08:13:38 --> Security Class Initialized
DEBUG - 2018-05-04 08:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:13:38 --> Input Class Initialized
INFO - 2018-05-04 08:13:38 --> Language Class Initialized
INFO - 2018-05-04 08:13:38 --> Loader Class Initialized
INFO - 2018-05-04 08:13:38 --> Helper loaded: common_helper
INFO - 2018-05-04 08:13:38 --> Database Driver Class Initialized
INFO - 2018-05-04 08:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:13:38 --> Email Class Initialized
INFO - 2018-05-04 08:13:38 --> Controller Class Initialized
INFO - 2018-05-04 08:13:38 --> Helper loaded: form_helper
INFO - 2018-05-04 08:13:38 --> Form Validation Class Initialized
INFO - 2018-05-04 08:13:38 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:13:38 --> Helper loaded: url_helper
INFO - 2018-05-04 08:13:38 --> Model Class Initialized
INFO - 2018-05-04 08:13:38 --> Model Class Initialized
INFO - 2018-05-04 08:13:38 --> Model Class Initialized
INFO - 2018-05-04 08:13:50 --> Config Class Initialized
INFO - 2018-05-04 08:13:50 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:13:50 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:13:50 --> Utf8 Class Initialized
INFO - 2018-05-04 08:13:50 --> URI Class Initialized
INFO - 2018-05-04 08:13:50 --> Router Class Initialized
INFO - 2018-05-04 08:13:50 --> Output Class Initialized
INFO - 2018-05-04 08:13:50 --> Security Class Initialized
DEBUG - 2018-05-04 08:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:13:50 --> Input Class Initialized
INFO - 2018-05-04 08:13:50 --> Language Class Initialized
INFO - 2018-05-04 08:13:50 --> Loader Class Initialized
INFO - 2018-05-04 08:13:50 --> Helper loaded: common_helper
INFO - 2018-05-04 08:13:50 --> Database Driver Class Initialized
INFO - 2018-05-04 08:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:13:50 --> Email Class Initialized
INFO - 2018-05-04 08:13:50 --> Controller Class Initialized
INFO - 2018-05-04 08:13:50 --> Helper loaded: form_helper
INFO - 2018-05-04 08:13:50 --> Form Validation Class Initialized
INFO - 2018-05-04 08:13:50 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:13:50 --> Helper loaded: url_helper
INFO - 2018-05-04 08:13:50 --> Model Class Initialized
INFO - 2018-05-04 08:13:50 --> Model Class Initialized
INFO - 2018-05-04 08:13:50 --> Model Class Initialized
INFO - 2018-05-04 11:43:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:43:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:43:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:43:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:43:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:43:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:43:50 --> Final output sent to browser
DEBUG - 2018-05-04 11:43:50 --> Total execution time: 0.1520
INFO - 2018-05-04 08:15:25 --> Config Class Initialized
INFO - 2018-05-04 08:15:25 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:15:25 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:15:25 --> Utf8 Class Initialized
INFO - 2018-05-04 08:15:25 --> URI Class Initialized
INFO - 2018-05-04 08:15:25 --> Router Class Initialized
INFO - 2018-05-04 08:15:25 --> Output Class Initialized
INFO - 2018-05-04 08:15:25 --> Security Class Initialized
DEBUG - 2018-05-04 08:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:15:25 --> Input Class Initialized
INFO - 2018-05-04 08:15:25 --> Language Class Initialized
INFO - 2018-05-04 08:15:25 --> Loader Class Initialized
INFO - 2018-05-04 08:15:25 --> Helper loaded: common_helper
INFO - 2018-05-04 08:15:25 --> Database Driver Class Initialized
INFO - 2018-05-04 08:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:15:25 --> Email Class Initialized
INFO - 2018-05-04 08:15:25 --> Controller Class Initialized
INFO - 2018-05-04 08:15:25 --> Helper loaded: form_helper
INFO - 2018-05-04 08:15:25 --> Form Validation Class Initialized
INFO - 2018-05-04 08:15:25 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:15:25 --> Helper loaded: url_helper
INFO - 2018-05-04 08:15:25 --> Model Class Initialized
INFO - 2018-05-04 08:15:25 --> Model Class Initialized
INFO - 2018-05-04 08:15:25 --> Model Class Initialized
INFO - 2018-05-04 11:45:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:45:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:45:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:45:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:45:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:45:25 --> Final output sent to browser
DEBUG - 2018-05-04 11:45:25 --> Total execution time: 0.1390
INFO - 2018-05-04 08:15:27 --> Config Class Initialized
INFO - 2018-05-04 08:15:27 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:15:27 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:15:27 --> Utf8 Class Initialized
INFO - 2018-05-04 08:15:27 --> URI Class Initialized
INFO - 2018-05-04 08:15:27 --> Router Class Initialized
INFO - 2018-05-04 08:15:27 --> Output Class Initialized
INFO - 2018-05-04 08:15:27 --> Security Class Initialized
DEBUG - 2018-05-04 08:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:15:27 --> Input Class Initialized
INFO - 2018-05-04 08:15:27 --> Language Class Initialized
INFO - 2018-05-04 08:15:27 --> Loader Class Initialized
INFO - 2018-05-04 08:15:27 --> Helper loaded: common_helper
INFO - 2018-05-04 08:15:27 --> Database Driver Class Initialized
INFO - 2018-05-04 08:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:15:27 --> Email Class Initialized
INFO - 2018-05-04 08:15:27 --> Controller Class Initialized
INFO - 2018-05-04 08:15:27 --> Helper loaded: form_helper
INFO - 2018-05-04 08:15:27 --> Form Validation Class Initialized
INFO - 2018-05-04 08:15:27 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:15:27 --> Helper loaded: url_helper
INFO - 2018-05-04 08:15:27 --> Model Class Initialized
INFO - 2018-05-04 08:15:27 --> Model Class Initialized
INFO - 2018-05-04 08:15:27 --> Model Class Initialized
INFO - 2018-05-04 11:45:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:45:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:45:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:45:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:45:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:45:27 --> Final output sent to browser
DEBUG - 2018-05-04 11:45:27 --> Total execution time: 0.1360
INFO - 2018-05-04 08:15:29 --> Config Class Initialized
INFO - 2018-05-04 08:15:29 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:15:29 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:15:29 --> Utf8 Class Initialized
INFO - 2018-05-04 08:15:29 --> URI Class Initialized
INFO - 2018-05-04 08:15:29 --> Router Class Initialized
INFO - 2018-05-04 08:15:29 --> Output Class Initialized
INFO - 2018-05-04 08:15:29 --> Security Class Initialized
DEBUG - 2018-05-04 08:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:15:29 --> Input Class Initialized
INFO - 2018-05-04 08:15:29 --> Language Class Initialized
INFO - 2018-05-04 08:15:29 --> Loader Class Initialized
INFO - 2018-05-04 08:15:29 --> Helper loaded: common_helper
INFO - 2018-05-04 08:15:29 --> Database Driver Class Initialized
INFO - 2018-05-04 08:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:15:29 --> Email Class Initialized
INFO - 2018-05-04 08:15:29 --> Controller Class Initialized
INFO - 2018-05-04 08:15:29 --> Helper loaded: form_helper
INFO - 2018-05-04 08:15:29 --> Form Validation Class Initialized
INFO - 2018-05-04 08:15:29 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:15:29 --> Helper loaded: url_helper
INFO - 2018-05-04 08:15:29 --> Model Class Initialized
INFO - 2018-05-04 08:15:29 --> Model Class Initialized
INFO - 2018-05-04 08:15:29 --> Model Class Initialized
INFO - 2018-05-04 11:45:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:45:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:45:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:45:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-04 11:45:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:45:29 --> Final output sent to browser
DEBUG - 2018-05-04 11:45:29 --> Total execution time: 0.1290
INFO - 2018-05-04 08:15:31 --> Config Class Initialized
INFO - 2018-05-04 08:15:31 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:15:31 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:15:31 --> Utf8 Class Initialized
INFO - 2018-05-04 08:15:31 --> URI Class Initialized
INFO - 2018-05-04 08:15:31 --> Router Class Initialized
INFO - 2018-05-04 08:15:31 --> Output Class Initialized
INFO - 2018-05-04 08:15:31 --> Security Class Initialized
DEBUG - 2018-05-04 08:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:15:31 --> Input Class Initialized
INFO - 2018-05-04 08:15:31 --> Language Class Initialized
INFO - 2018-05-04 08:15:31 --> Loader Class Initialized
INFO - 2018-05-04 08:15:31 --> Helper loaded: common_helper
INFO - 2018-05-04 08:15:31 --> Database Driver Class Initialized
INFO - 2018-05-04 08:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:15:31 --> Email Class Initialized
INFO - 2018-05-04 08:15:31 --> Controller Class Initialized
INFO - 2018-05-04 08:15:31 --> Helper loaded: form_helper
INFO - 2018-05-04 08:15:31 --> Form Validation Class Initialized
INFO - 2018-05-04 08:15:31 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:15:31 --> Helper loaded: url_helper
INFO - 2018-05-04 08:15:31 --> Model Class Initialized
INFO - 2018-05-04 08:15:31 --> Model Class Initialized
INFO - 2018-05-04 08:15:31 --> Model Class Initialized
INFO - 2018-05-04 11:45:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:45:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:45:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:45:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:45:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:45:31 --> Final output sent to browser
DEBUG - 2018-05-04 11:45:31 --> Total execution time: 0.1720
INFO - 2018-05-04 08:15:32 --> Config Class Initialized
INFO - 2018-05-04 08:15:32 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:15:32 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:15:32 --> Utf8 Class Initialized
INFO - 2018-05-04 08:15:32 --> URI Class Initialized
INFO - 2018-05-04 08:15:32 --> Router Class Initialized
INFO - 2018-05-04 08:15:32 --> Output Class Initialized
INFO - 2018-05-04 08:15:32 --> Security Class Initialized
DEBUG - 2018-05-04 08:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:15:32 --> Input Class Initialized
INFO - 2018-05-04 08:15:32 --> Language Class Initialized
INFO - 2018-05-04 08:15:32 --> Loader Class Initialized
INFO - 2018-05-04 08:15:32 --> Helper loaded: common_helper
INFO - 2018-05-04 08:15:32 --> Database Driver Class Initialized
INFO - 2018-05-04 08:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:15:32 --> Email Class Initialized
INFO - 2018-05-04 08:15:32 --> Controller Class Initialized
INFO - 2018-05-04 08:15:32 --> Helper loaded: form_helper
INFO - 2018-05-04 08:15:32 --> Form Validation Class Initialized
INFO - 2018-05-04 08:15:32 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:15:32 --> Helper loaded: url_helper
INFO - 2018-05-04 08:15:32 --> Model Class Initialized
INFO - 2018-05-04 08:15:32 --> Model Class Initialized
INFO - 2018-05-04 08:15:32 --> Model Class Initialized
INFO - 2018-05-04 11:45:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:45:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:45:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:45:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:45:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:45:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:45:32 --> Final output sent to browser
DEBUG - 2018-05-04 11:45:32 --> Total execution time: 0.1390
INFO - 2018-05-04 08:15:39 --> Config Class Initialized
INFO - 2018-05-04 08:15:39 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:15:39 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:15:39 --> Utf8 Class Initialized
INFO - 2018-05-04 08:15:39 --> URI Class Initialized
INFO - 2018-05-04 08:15:39 --> Router Class Initialized
INFO - 2018-05-04 08:15:39 --> Output Class Initialized
INFO - 2018-05-04 08:15:39 --> Security Class Initialized
DEBUG - 2018-05-04 08:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:15:39 --> Input Class Initialized
INFO - 2018-05-04 08:15:39 --> Language Class Initialized
INFO - 2018-05-04 08:15:39 --> Loader Class Initialized
INFO - 2018-05-04 08:15:39 --> Helper loaded: common_helper
INFO - 2018-05-04 08:15:39 --> Database Driver Class Initialized
INFO - 2018-05-04 08:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:15:39 --> Email Class Initialized
INFO - 2018-05-04 08:15:39 --> Controller Class Initialized
INFO - 2018-05-04 08:15:39 --> Helper loaded: form_helper
INFO - 2018-05-04 08:15:39 --> Form Validation Class Initialized
INFO - 2018-05-04 08:15:39 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:15:39 --> Helper loaded: url_helper
INFO - 2018-05-04 08:15:39 --> Model Class Initialized
INFO - 2018-05-04 08:15:39 --> Model Class Initialized
INFO - 2018-05-04 08:15:39 --> Model Class Initialized
INFO - 2018-05-04 08:15:41 --> Config Class Initialized
INFO - 2018-05-04 08:15:41 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:15:41 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:15:41 --> Utf8 Class Initialized
INFO - 2018-05-04 08:15:41 --> URI Class Initialized
INFO - 2018-05-04 08:15:41 --> Router Class Initialized
INFO - 2018-05-04 08:15:41 --> Output Class Initialized
INFO - 2018-05-04 08:15:41 --> Security Class Initialized
DEBUG - 2018-05-04 08:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:15:41 --> Input Class Initialized
INFO - 2018-05-04 08:15:41 --> Language Class Initialized
INFO - 2018-05-04 08:15:41 --> Loader Class Initialized
INFO - 2018-05-04 08:15:41 --> Helper loaded: common_helper
INFO - 2018-05-04 08:15:41 --> Database Driver Class Initialized
INFO - 2018-05-04 08:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:15:41 --> Email Class Initialized
INFO - 2018-05-04 08:15:41 --> Controller Class Initialized
INFO - 2018-05-04 08:15:41 --> Helper loaded: form_helper
INFO - 2018-05-04 08:15:41 --> Form Validation Class Initialized
INFO - 2018-05-04 08:15:41 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:15:41 --> Helper loaded: url_helper
INFO - 2018-05-04 08:15:41 --> Model Class Initialized
INFO - 2018-05-04 08:15:41 --> Model Class Initialized
INFO - 2018-05-04 08:15:41 --> Model Class Initialized
INFO - 2018-05-04 11:45:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:45:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:45:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:45:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:45:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:45:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:45:41 --> Final output sent to browser
DEBUG - 2018-05-04 11:45:41 --> Total execution time: 0.1440
INFO - 2018-05-04 08:15:55 --> Config Class Initialized
INFO - 2018-05-04 08:15:55 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:15:55 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:15:55 --> Utf8 Class Initialized
INFO - 2018-05-04 08:15:55 --> URI Class Initialized
INFO - 2018-05-04 08:15:55 --> Router Class Initialized
INFO - 2018-05-04 08:15:55 --> Output Class Initialized
INFO - 2018-05-04 08:15:55 --> Security Class Initialized
DEBUG - 2018-05-04 08:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:15:55 --> Input Class Initialized
INFO - 2018-05-04 08:15:55 --> Language Class Initialized
INFO - 2018-05-04 08:15:55 --> Loader Class Initialized
INFO - 2018-05-04 08:15:55 --> Helper loaded: common_helper
INFO - 2018-05-04 08:15:55 --> Database Driver Class Initialized
INFO - 2018-05-04 08:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:15:55 --> Email Class Initialized
INFO - 2018-05-04 08:15:55 --> Controller Class Initialized
INFO - 2018-05-04 08:15:55 --> Helper loaded: form_helper
INFO - 2018-05-04 08:15:55 --> Form Validation Class Initialized
INFO - 2018-05-04 08:15:55 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:15:55 --> Helper loaded: url_helper
INFO - 2018-05-04 08:15:55 --> Model Class Initialized
INFO - 2018-05-04 08:15:55 --> Model Class Initialized
INFO - 2018-05-04 08:15:55 --> Model Class Initialized
INFO - 2018-05-04 11:45:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:45:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:45:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:45:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:45:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:45:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:45:55 --> Final output sent to browser
DEBUG - 2018-05-04 11:45:55 --> Total execution time: 0.1570
INFO - 2018-05-04 08:15:59 --> Config Class Initialized
INFO - 2018-05-04 08:15:59 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:15:59 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:15:59 --> Utf8 Class Initialized
INFO - 2018-05-04 08:15:59 --> URI Class Initialized
INFO - 2018-05-04 08:15:59 --> Router Class Initialized
INFO - 2018-05-04 08:15:59 --> Output Class Initialized
INFO - 2018-05-04 08:15:59 --> Security Class Initialized
DEBUG - 2018-05-04 08:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:15:59 --> Input Class Initialized
INFO - 2018-05-04 08:15:59 --> Language Class Initialized
INFO - 2018-05-04 08:15:59 --> Loader Class Initialized
INFO - 2018-05-04 08:15:59 --> Helper loaded: common_helper
INFO - 2018-05-04 08:15:59 --> Database Driver Class Initialized
INFO - 2018-05-04 08:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:15:59 --> Email Class Initialized
INFO - 2018-05-04 08:15:59 --> Controller Class Initialized
INFO - 2018-05-04 08:15:59 --> Helper loaded: form_helper
INFO - 2018-05-04 08:15:59 --> Form Validation Class Initialized
INFO - 2018-05-04 08:15:59 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:15:59 --> Helper loaded: url_helper
INFO - 2018-05-04 08:15:59 --> Model Class Initialized
INFO - 2018-05-04 08:15:59 --> Model Class Initialized
INFO - 2018-05-04 08:15:59 --> Model Class Initialized
INFO - 2018-05-04 08:16:01 --> Config Class Initialized
INFO - 2018-05-04 08:16:01 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:16:01 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:16:01 --> Utf8 Class Initialized
INFO - 2018-05-04 08:16:01 --> URI Class Initialized
INFO - 2018-05-04 08:16:01 --> Router Class Initialized
INFO - 2018-05-04 08:16:01 --> Output Class Initialized
INFO - 2018-05-04 08:16:01 --> Security Class Initialized
DEBUG - 2018-05-04 08:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:16:01 --> Input Class Initialized
INFO - 2018-05-04 08:16:01 --> Language Class Initialized
INFO - 2018-05-04 08:16:01 --> Loader Class Initialized
INFO - 2018-05-04 08:16:01 --> Helper loaded: common_helper
INFO - 2018-05-04 08:16:01 --> Database Driver Class Initialized
INFO - 2018-05-04 08:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:16:01 --> Email Class Initialized
INFO - 2018-05-04 08:16:01 --> Controller Class Initialized
INFO - 2018-05-04 08:16:01 --> Helper loaded: form_helper
INFO - 2018-05-04 08:16:01 --> Form Validation Class Initialized
INFO - 2018-05-04 08:16:01 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:16:01 --> Helper loaded: url_helper
INFO - 2018-05-04 08:16:01 --> Model Class Initialized
INFO - 2018-05-04 08:16:01 --> Model Class Initialized
INFO - 2018-05-04 08:16:01 --> Model Class Initialized
INFO - 2018-05-04 11:46:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:46:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:46:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:46:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:46:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:46:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:46:01 --> Final output sent to browser
DEBUG - 2018-05-04 11:46:01 --> Total execution time: 0.1820
INFO - 2018-05-04 08:16:42 --> Config Class Initialized
INFO - 2018-05-04 08:16:42 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:16:42 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:16:42 --> Utf8 Class Initialized
INFO - 2018-05-04 08:16:42 --> URI Class Initialized
INFO - 2018-05-04 08:16:42 --> Router Class Initialized
INFO - 2018-05-04 08:16:42 --> Output Class Initialized
INFO - 2018-05-04 08:16:42 --> Security Class Initialized
DEBUG - 2018-05-04 08:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:16:42 --> Input Class Initialized
INFO - 2018-05-04 08:16:42 --> Language Class Initialized
INFO - 2018-05-04 08:16:42 --> Loader Class Initialized
INFO - 2018-05-04 08:16:42 --> Helper loaded: common_helper
INFO - 2018-05-04 08:16:42 --> Database Driver Class Initialized
INFO - 2018-05-04 08:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:16:42 --> Email Class Initialized
INFO - 2018-05-04 08:16:42 --> Controller Class Initialized
INFO - 2018-05-04 08:16:42 --> Helper loaded: form_helper
INFO - 2018-05-04 08:16:42 --> Form Validation Class Initialized
INFO - 2018-05-04 08:16:42 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:16:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:16:42 --> Helper loaded: url_helper
INFO - 2018-05-04 08:16:42 --> Model Class Initialized
INFO - 2018-05-04 08:16:42 --> Model Class Initialized
INFO - 2018-05-04 08:16:42 --> Model Class Initialized
INFO - 2018-05-04 11:46:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:46:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:46:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:46:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:46:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:46:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:46:42 --> Final output sent to browser
DEBUG - 2018-05-04 11:46:42 --> Total execution time: 0.1480
INFO - 2018-05-04 08:16:45 --> Config Class Initialized
INFO - 2018-05-04 08:16:45 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:16:45 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:16:45 --> Utf8 Class Initialized
INFO - 2018-05-04 08:16:45 --> URI Class Initialized
INFO - 2018-05-04 08:16:45 --> Router Class Initialized
INFO - 2018-05-04 08:16:45 --> Output Class Initialized
INFO - 2018-05-04 08:16:45 --> Security Class Initialized
DEBUG - 2018-05-04 08:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:16:45 --> Input Class Initialized
INFO - 2018-05-04 08:16:45 --> Language Class Initialized
INFO - 2018-05-04 08:16:45 --> Loader Class Initialized
INFO - 2018-05-04 08:16:45 --> Helper loaded: common_helper
INFO - 2018-05-04 08:16:45 --> Database Driver Class Initialized
INFO - 2018-05-04 08:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:16:45 --> Email Class Initialized
INFO - 2018-05-04 08:16:45 --> Controller Class Initialized
INFO - 2018-05-04 08:16:45 --> Helper loaded: form_helper
INFO - 2018-05-04 08:16:45 --> Form Validation Class Initialized
INFO - 2018-05-04 08:16:45 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:16:45 --> Helper loaded: url_helper
INFO - 2018-05-04 08:16:45 --> Model Class Initialized
INFO - 2018-05-04 08:16:45 --> Model Class Initialized
INFO - 2018-05-04 08:16:45 --> Model Class Initialized
INFO - 2018-05-04 08:16:46 --> Config Class Initialized
INFO - 2018-05-04 08:16:46 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:16:46 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:16:46 --> Utf8 Class Initialized
INFO - 2018-05-04 08:16:46 --> URI Class Initialized
INFO - 2018-05-04 08:16:46 --> Router Class Initialized
INFO - 2018-05-04 08:16:46 --> Output Class Initialized
INFO - 2018-05-04 08:16:46 --> Security Class Initialized
DEBUG - 2018-05-04 08:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:16:46 --> Input Class Initialized
INFO - 2018-05-04 08:16:46 --> Language Class Initialized
INFO - 2018-05-04 08:16:46 --> Loader Class Initialized
INFO - 2018-05-04 08:16:46 --> Helper loaded: common_helper
INFO - 2018-05-04 08:16:46 --> Database Driver Class Initialized
INFO - 2018-05-04 08:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:16:46 --> Email Class Initialized
INFO - 2018-05-04 08:16:46 --> Controller Class Initialized
INFO - 2018-05-04 08:16:46 --> Helper loaded: form_helper
INFO - 2018-05-04 08:16:46 --> Form Validation Class Initialized
INFO - 2018-05-04 08:16:46 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:16:46 --> Helper loaded: url_helper
INFO - 2018-05-04 08:16:46 --> Model Class Initialized
INFO - 2018-05-04 08:16:46 --> Model Class Initialized
INFO - 2018-05-04 08:16:46 --> Model Class Initialized
INFO - 2018-05-04 11:46:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:46:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:46:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:46:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:46:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:46:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:46:46 --> Final output sent to browser
DEBUG - 2018-05-04 11:46:46 --> Total execution time: 0.1400
INFO - 2018-05-04 08:17:22 --> Config Class Initialized
INFO - 2018-05-04 08:17:22 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:17:22 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:17:22 --> Utf8 Class Initialized
INFO - 2018-05-04 08:17:22 --> URI Class Initialized
INFO - 2018-05-04 08:17:22 --> Router Class Initialized
INFO - 2018-05-04 08:17:22 --> Output Class Initialized
INFO - 2018-05-04 08:17:22 --> Security Class Initialized
DEBUG - 2018-05-04 08:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:17:22 --> Input Class Initialized
INFO - 2018-05-04 08:17:22 --> Language Class Initialized
INFO - 2018-05-04 08:17:22 --> Loader Class Initialized
INFO - 2018-05-04 08:17:22 --> Helper loaded: common_helper
INFO - 2018-05-04 08:17:22 --> Database Driver Class Initialized
INFO - 2018-05-04 08:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:17:22 --> Email Class Initialized
INFO - 2018-05-04 08:17:22 --> Controller Class Initialized
INFO - 2018-05-04 08:17:22 --> Helper loaded: form_helper
INFO - 2018-05-04 08:17:22 --> Form Validation Class Initialized
INFO - 2018-05-04 08:17:22 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:17:22 --> Helper loaded: url_helper
INFO - 2018-05-04 08:17:22 --> Model Class Initialized
INFO - 2018-05-04 08:17:22 --> Model Class Initialized
INFO - 2018-05-04 08:17:22 --> Model Class Initialized
INFO - 2018-05-04 11:47:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:47:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:47:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:47:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:47:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:47:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:47:22 --> Final output sent to browser
DEBUG - 2018-05-04 11:47:22 --> Total execution time: 0.1410
INFO - 2018-05-04 08:17:25 --> Config Class Initialized
INFO - 2018-05-04 08:17:25 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:17:25 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:17:25 --> Utf8 Class Initialized
INFO - 2018-05-04 08:17:25 --> URI Class Initialized
INFO - 2018-05-04 08:17:25 --> Router Class Initialized
INFO - 2018-05-04 08:17:25 --> Output Class Initialized
INFO - 2018-05-04 08:17:25 --> Security Class Initialized
DEBUG - 2018-05-04 08:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:17:25 --> Input Class Initialized
INFO - 2018-05-04 08:17:25 --> Language Class Initialized
INFO - 2018-05-04 08:17:25 --> Loader Class Initialized
INFO - 2018-05-04 08:17:25 --> Helper loaded: common_helper
INFO - 2018-05-04 08:17:25 --> Database Driver Class Initialized
INFO - 2018-05-04 08:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:17:25 --> Email Class Initialized
INFO - 2018-05-04 08:17:25 --> Controller Class Initialized
INFO - 2018-05-04 08:17:25 --> Helper loaded: form_helper
INFO - 2018-05-04 08:17:25 --> Form Validation Class Initialized
INFO - 2018-05-04 08:17:25 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:17:25 --> Helper loaded: url_helper
INFO - 2018-05-04 08:17:25 --> Model Class Initialized
INFO - 2018-05-04 08:17:25 --> Model Class Initialized
INFO - 2018-05-04 08:17:25 --> Model Class Initialized
INFO - 2018-05-04 08:17:31 --> Config Class Initialized
INFO - 2018-05-04 08:17:31 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:17:31 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:17:31 --> Utf8 Class Initialized
INFO - 2018-05-04 08:17:31 --> URI Class Initialized
INFO - 2018-05-04 08:17:31 --> Router Class Initialized
INFO - 2018-05-04 08:17:31 --> Output Class Initialized
INFO - 2018-05-04 08:17:31 --> Security Class Initialized
DEBUG - 2018-05-04 08:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:17:31 --> Input Class Initialized
INFO - 2018-05-04 08:17:31 --> Language Class Initialized
INFO - 2018-05-04 08:17:31 --> Loader Class Initialized
INFO - 2018-05-04 08:17:31 --> Helper loaded: common_helper
INFO - 2018-05-04 08:17:31 --> Database Driver Class Initialized
INFO - 2018-05-04 08:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:17:31 --> Email Class Initialized
INFO - 2018-05-04 08:17:31 --> Controller Class Initialized
INFO - 2018-05-04 08:17:31 --> Helper loaded: form_helper
INFO - 2018-05-04 08:17:31 --> Form Validation Class Initialized
INFO - 2018-05-04 08:17:31 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:17:31 --> Helper loaded: url_helper
INFO - 2018-05-04 08:17:31 --> Model Class Initialized
INFO - 2018-05-04 08:17:31 --> Model Class Initialized
INFO - 2018-05-04 08:17:31 --> Model Class Initialized
INFO - 2018-05-04 11:47:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:47:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:47:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:47:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:47:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:47:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:47:31 --> Final output sent to browser
DEBUG - 2018-05-04 11:47:31 --> Total execution time: 0.1500
INFO - 2018-05-04 08:17:50 --> Config Class Initialized
INFO - 2018-05-04 08:17:50 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:17:50 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:17:50 --> Utf8 Class Initialized
INFO - 2018-05-04 08:17:50 --> URI Class Initialized
INFO - 2018-05-04 08:17:50 --> Router Class Initialized
INFO - 2018-05-04 08:17:50 --> Output Class Initialized
INFO - 2018-05-04 08:17:50 --> Security Class Initialized
DEBUG - 2018-05-04 08:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:17:50 --> Input Class Initialized
INFO - 2018-05-04 08:17:50 --> Language Class Initialized
INFO - 2018-05-04 08:17:50 --> Loader Class Initialized
INFO - 2018-05-04 08:17:50 --> Helper loaded: common_helper
INFO - 2018-05-04 08:17:50 --> Database Driver Class Initialized
INFO - 2018-05-04 08:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:17:50 --> Email Class Initialized
INFO - 2018-05-04 08:17:50 --> Controller Class Initialized
INFO - 2018-05-04 08:17:50 --> Helper loaded: form_helper
INFO - 2018-05-04 08:17:50 --> Form Validation Class Initialized
INFO - 2018-05-04 08:17:50 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:17:50 --> Helper loaded: url_helper
INFO - 2018-05-04 08:17:50 --> Model Class Initialized
INFO - 2018-05-04 08:17:50 --> Model Class Initialized
INFO - 2018-05-04 08:17:50 --> Model Class Initialized
INFO - 2018-05-04 08:17:51 --> Config Class Initialized
INFO - 2018-05-04 08:17:51 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:17:51 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:17:51 --> Utf8 Class Initialized
INFO - 2018-05-04 08:17:51 --> URI Class Initialized
INFO - 2018-05-04 08:17:51 --> Router Class Initialized
INFO - 2018-05-04 08:17:51 --> Output Class Initialized
INFO - 2018-05-04 08:17:51 --> Security Class Initialized
DEBUG - 2018-05-04 08:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:17:51 --> Input Class Initialized
INFO - 2018-05-04 08:17:51 --> Language Class Initialized
INFO - 2018-05-04 08:17:51 --> Loader Class Initialized
INFO - 2018-05-04 08:17:51 --> Helper loaded: common_helper
INFO - 2018-05-04 08:17:51 --> Database Driver Class Initialized
INFO - 2018-05-04 08:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:17:51 --> Email Class Initialized
INFO - 2018-05-04 08:17:51 --> Controller Class Initialized
INFO - 2018-05-04 08:17:51 --> Helper loaded: form_helper
INFO - 2018-05-04 08:17:51 --> Form Validation Class Initialized
INFO - 2018-05-04 08:17:51 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:17:51 --> Helper loaded: url_helper
INFO - 2018-05-04 08:17:51 --> Model Class Initialized
INFO - 2018-05-04 08:17:51 --> Model Class Initialized
INFO - 2018-05-04 08:17:51 --> Model Class Initialized
INFO - 2018-05-04 11:47:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:47:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:47:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:47:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:47:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:47:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:47:51 --> Final output sent to browser
DEBUG - 2018-05-04 11:47:51 --> Total execution time: 0.1500
INFO - 2018-05-04 08:18:33 --> Config Class Initialized
INFO - 2018-05-04 08:18:33 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:18:33 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:18:33 --> Utf8 Class Initialized
INFO - 2018-05-04 08:18:33 --> URI Class Initialized
INFO - 2018-05-04 08:18:33 --> Router Class Initialized
INFO - 2018-05-04 08:18:33 --> Output Class Initialized
INFO - 2018-05-04 08:18:33 --> Security Class Initialized
DEBUG - 2018-05-04 08:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:18:33 --> Input Class Initialized
INFO - 2018-05-04 08:18:33 --> Language Class Initialized
INFO - 2018-05-04 08:18:33 --> Loader Class Initialized
INFO - 2018-05-04 08:18:33 --> Helper loaded: common_helper
INFO - 2018-05-04 08:18:33 --> Database Driver Class Initialized
INFO - 2018-05-04 08:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:18:33 --> Email Class Initialized
INFO - 2018-05-04 08:18:33 --> Controller Class Initialized
INFO - 2018-05-04 08:18:33 --> Helper loaded: form_helper
INFO - 2018-05-04 08:18:33 --> Form Validation Class Initialized
INFO - 2018-05-04 08:18:33 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:18:33 --> Helper loaded: url_helper
INFO - 2018-05-04 08:18:33 --> Model Class Initialized
INFO - 2018-05-04 08:18:33 --> Model Class Initialized
INFO - 2018-05-04 08:18:33 --> Model Class Initialized
INFO - 2018-05-04 11:48:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:48:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:48:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:48:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:48:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:48:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:48:33 --> Final output sent to browser
DEBUG - 2018-05-04 11:48:33 --> Total execution time: 0.1440
INFO - 2018-05-04 08:18:37 --> Config Class Initialized
INFO - 2018-05-04 08:18:37 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:18:37 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:18:37 --> Utf8 Class Initialized
INFO - 2018-05-04 08:18:37 --> URI Class Initialized
INFO - 2018-05-04 08:18:37 --> Router Class Initialized
INFO - 2018-05-04 08:18:37 --> Output Class Initialized
INFO - 2018-05-04 08:18:37 --> Security Class Initialized
DEBUG - 2018-05-04 08:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:18:37 --> Input Class Initialized
INFO - 2018-05-04 08:18:37 --> Language Class Initialized
INFO - 2018-05-04 08:18:37 --> Loader Class Initialized
INFO - 2018-05-04 08:18:37 --> Helper loaded: common_helper
INFO - 2018-05-04 08:18:37 --> Database Driver Class Initialized
INFO - 2018-05-04 08:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:18:37 --> Email Class Initialized
INFO - 2018-05-04 08:18:37 --> Controller Class Initialized
INFO - 2018-05-04 08:18:37 --> Helper loaded: form_helper
INFO - 2018-05-04 08:18:37 --> Form Validation Class Initialized
INFO - 2018-05-04 08:18:37 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:18:37 --> Helper loaded: url_helper
INFO - 2018-05-04 08:18:37 --> Model Class Initialized
INFO - 2018-05-04 08:18:37 --> Model Class Initialized
INFO - 2018-05-04 08:18:37 --> Model Class Initialized
INFO - 2018-05-04 08:18:38 --> Config Class Initialized
INFO - 2018-05-04 08:18:38 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:18:38 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:18:38 --> Utf8 Class Initialized
INFO - 2018-05-04 08:18:38 --> URI Class Initialized
INFO - 2018-05-04 08:18:38 --> Router Class Initialized
INFO - 2018-05-04 08:18:38 --> Output Class Initialized
INFO - 2018-05-04 08:18:38 --> Security Class Initialized
DEBUG - 2018-05-04 08:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:18:38 --> Input Class Initialized
INFO - 2018-05-04 08:18:38 --> Language Class Initialized
INFO - 2018-05-04 08:18:39 --> Loader Class Initialized
INFO - 2018-05-04 08:18:39 --> Helper loaded: common_helper
INFO - 2018-05-04 08:18:39 --> Database Driver Class Initialized
INFO - 2018-05-04 08:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:18:39 --> Email Class Initialized
INFO - 2018-05-04 08:18:39 --> Controller Class Initialized
INFO - 2018-05-04 08:18:39 --> Helper loaded: form_helper
INFO - 2018-05-04 08:18:39 --> Form Validation Class Initialized
INFO - 2018-05-04 08:18:39 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:18:39 --> Helper loaded: url_helper
INFO - 2018-05-04 08:18:39 --> Model Class Initialized
INFO - 2018-05-04 08:18:39 --> Model Class Initialized
INFO - 2018-05-04 08:18:39 --> Model Class Initialized
INFO - 2018-05-04 11:48:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:48:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:48:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:48:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:48:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 11:48:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:48:39 --> Final output sent to browser
DEBUG - 2018-05-04 11:48:39 --> Total execution time: 0.1470
INFO - 2018-05-04 08:19:00 --> Config Class Initialized
INFO - 2018-05-04 08:19:00 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:19:00 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:19:00 --> Utf8 Class Initialized
INFO - 2018-05-04 08:19:00 --> URI Class Initialized
INFO - 2018-05-04 08:19:00 --> Router Class Initialized
INFO - 2018-05-04 08:19:00 --> Output Class Initialized
INFO - 2018-05-04 08:19:00 --> Security Class Initialized
DEBUG - 2018-05-04 08:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:19:00 --> Input Class Initialized
INFO - 2018-05-04 08:19:00 --> Language Class Initialized
INFO - 2018-05-04 08:19:00 --> Loader Class Initialized
INFO - 2018-05-04 08:19:00 --> Helper loaded: common_helper
INFO - 2018-05-04 08:19:00 --> Database Driver Class Initialized
INFO - 2018-05-04 08:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:19:00 --> Email Class Initialized
INFO - 2018-05-04 08:19:00 --> Controller Class Initialized
INFO - 2018-05-04 08:19:00 --> Helper loaded: form_helper
INFO - 2018-05-04 08:19:00 --> Form Validation Class Initialized
INFO - 2018-05-04 08:19:00 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:19:00 --> Helper loaded: url_helper
INFO - 2018-05-04 08:19:00 --> Model Class Initialized
INFO - 2018-05-04 08:19:00 --> Model Class Initialized
INFO - 2018-05-04 08:19:00 --> Model Class Initialized
INFO - 2018-05-04 11:49:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:49:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:49:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:49:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:49:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:49:00 --> Final output sent to browser
DEBUG - 2018-05-04 11:49:00 --> Total execution time: 0.1700
INFO - 2018-05-04 08:19:02 --> Config Class Initialized
INFO - 2018-05-04 08:19:02 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:19:02 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:19:02 --> Utf8 Class Initialized
INFO - 2018-05-04 08:19:02 --> URI Class Initialized
INFO - 2018-05-04 08:19:02 --> Router Class Initialized
INFO - 2018-05-04 08:19:02 --> Output Class Initialized
INFO - 2018-05-04 08:19:03 --> Security Class Initialized
DEBUG - 2018-05-04 08:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:19:03 --> Input Class Initialized
INFO - 2018-05-04 08:19:03 --> Language Class Initialized
INFO - 2018-05-04 08:19:03 --> Loader Class Initialized
INFO - 2018-05-04 08:19:03 --> Helper loaded: common_helper
INFO - 2018-05-04 08:19:03 --> Database Driver Class Initialized
INFO - 2018-05-04 08:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:19:03 --> Email Class Initialized
INFO - 2018-05-04 08:19:03 --> Controller Class Initialized
INFO - 2018-05-04 08:19:03 --> Helper loaded: form_helper
INFO - 2018-05-04 08:19:03 --> Form Validation Class Initialized
INFO - 2018-05-04 08:19:03 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:19:03 --> Helper loaded: url_helper
INFO - 2018-05-04 08:19:03 --> Model Class Initialized
INFO - 2018-05-04 08:19:03 --> Model Class Initialized
INFO - 2018-05-04 08:19:03 --> Model Class Initialized
INFO - 2018-05-04 11:49:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:49:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 11:49:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:49:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:49:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 11:49:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:49:03 --> Final output sent to browser
DEBUG - 2018-05-04 11:49:03 --> Total execution time: 0.1590
INFO - 2018-05-04 08:19:04 --> Config Class Initialized
INFO - 2018-05-04 08:19:04 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:19:04 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:19:04 --> Utf8 Class Initialized
INFO - 2018-05-04 08:19:04 --> URI Class Initialized
INFO - 2018-05-04 08:19:04 --> Router Class Initialized
INFO - 2018-05-04 08:19:04 --> Output Class Initialized
INFO - 2018-05-04 08:19:04 --> Security Class Initialized
DEBUG - 2018-05-04 08:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:19:04 --> Input Class Initialized
INFO - 2018-05-04 08:19:04 --> Language Class Initialized
INFO - 2018-05-04 08:19:04 --> Loader Class Initialized
INFO - 2018-05-04 08:19:04 --> Helper loaded: common_helper
INFO - 2018-05-04 08:19:04 --> Database Driver Class Initialized
INFO - 2018-05-04 08:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:19:04 --> Email Class Initialized
INFO - 2018-05-04 08:19:04 --> Controller Class Initialized
INFO - 2018-05-04 08:19:04 --> Helper loaded: form_helper
INFO - 2018-05-04 08:19:04 --> Form Validation Class Initialized
INFO - 2018-05-04 08:19:04 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:19:04 --> Helper loaded: url_helper
INFO - 2018-05-04 08:19:04 --> Model Class Initialized
INFO - 2018-05-04 08:19:04 --> Model Class Initialized
INFO - 2018-05-04 08:19:04 --> Model Class Initialized
INFO - 2018-05-04 11:49:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:49:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:49:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:49:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 11:49:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:49:04 --> Final output sent to browser
DEBUG - 2018-05-04 11:49:04 --> Total execution time: 0.1490
INFO - 2018-05-04 08:28:15 --> Config Class Initialized
INFO - 2018-05-04 08:28:15 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:28:15 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:28:15 --> Utf8 Class Initialized
INFO - 2018-05-04 08:28:15 --> URI Class Initialized
INFO - 2018-05-04 08:28:15 --> Router Class Initialized
INFO - 2018-05-04 08:28:15 --> Output Class Initialized
INFO - 2018-05-04 08:28:15 --> Security Class Initialized
DEBUG - 2018-05-04 08:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:28:15 --> Input Class Initialized
INFO - 2018-05-04 08:28:15 --> Language Class Initialized
INFO - 2018-05-04 08:28:15 --> Loader Class Initialized
INFO - 2018-05-04 08:28:15 --> Helper loaded: common_helper
INFO - 2018-05-04 08:28:15 --> Database Driver Class Initialized
INFO - 2018-05-04 08:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:28:15 --> Email Class Initialized
INFO - 2018-05-04 08:28:15 --> Controller Class Initialized
INFO - 2018-05-04 08:28:15 --> Helper loaded: form_helper
INFO - 2018-05-04 08:28:15 --> Form Validation Class Initialized
INFO - 2018-05-04 08:28:15 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:28:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:28:15 --> Helper loaded: url_helper
INFO - 2018-05-04 08:28:15 --> Model Class Initialized
INFO - 2018-05-04 08:28:15 --> Model Class Initialized
INFO - 2018-05-04 08:28:15 --> Model Class Initialized
INFO - 2018-05-04 11:58:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:58:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:58:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-04 11:58:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:58:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:58:15 --> Final output sent to browser
DEBUG - 2018-05-04 11:58:15 --> Total execution time: 0.1540
INFO - 2018-05-04 08:28:16 --> Config Class Initialized
INFO - 2018-05-04 08:28:16 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:28:16 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:28:16 --> Utf8 Class Initialized
INFO - 2018-05-04 08:28:16 --> URI Class Initialized
INFO - 2018-05-04 08:28:16 --> Router Class Initialized
INFO - 2018-05-04 08:28:16 --> Output Class Initialized
INFO - 2018-05-04 08:28:16 --> Security Class Initialized
DEBUG - 2018-05-04 08:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:28:16 --> Input Class Initialized
INFO - 2018-05-04 08:28:16 --> Language Class Initialized
INFO - 2018-05-04 08:28:16 --> Loader Class Initialized
INFO - 2018-05-04 08:28:16 --> Helper loaded: common_helper
INFO - 2018-05-04 08:28:16 --> Database Driver Class Initialized
INFO - 2018-05-04 08:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:28:16 --> Email Class Initialized
INFO - 2018-05-04 08:28:16 --> Controller Class Initialized
INFO - 2018-05-04 08:28:16 --> Helper loaded: form_helper
INFO - 2018-05-04 08:28:16 --> Form Validation Class Initialized
INFO - 2018-05-04 08:28:16 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:28:16 --> Helper loaded: url_helper
INFO - 2018-05-04 08:28:16 --> Model Class Initialized
INFO - 2018-05-04 08:28:16 --> Model Class Initialized
INFO - 2018-05-04 08:28:16 --> Model Class Initialized
INFO - 2018-05-04 11:58:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:58:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:58:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:58:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-04 11:58:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:58:16 --> Final output sent to browser
DEBUG - 2018-05-04 11:58:16 --> Total execution time: 0.1540
INFO - 2018-05-04 08:28:17 --> Config Class Initialized
INFO - 2018-05-04 08:28:17 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:28:17 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:28:17 --> Utf8 Class Initialized
INFO - 2018-05-04 08:28:17 --> URI Class Initialized
INFO - 2018-05-04 08:28:17 --> Router Class Initialized
INFO - 2018-05-04 08:28:17 --> Output Class Initialized
INFO - 2018-05-04 08:28:17 --> Security Class Initialized
DEBUG - 2018-05-04 08:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:28:17 --> Input Class Initialized
INFO - 2018-05-04 08:28:17 --> Language Class Initialized
INFO - 2018-05-04 08:28:17 --> Loader Class Initialized
INFO - 2018-05-04 08:28:17 --> Helper loaded: common_helper
INFO - 2018-05-04 08:28:17 --> Database Driver Class Initialized
INFO - 2018-05-04 08:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:28:17 --> Email Class Initialized
INFO - 2018-05-04 08:28:17 --> Controller Class Initialized
INFO - 2018-05-04 08:28:17 --> Helper loaded: form_helper
INFO - 2018-05-04 08:28:17 --> Form Validation Class Initialized
INFO - 2018-05-04 08:28:17 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:28:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:28:17 --> Helper loaded: url_helper
INFO - 2018-05-04 08:28:17 --> Model Class Initialized
INFO - 2018-05-04 08:28:17 --> Model Class Initialized
INFO - 2018-05-04 08:28:17 --> Model Class Initialized
INFO - 2018-05-04 11:58:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:58:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:58:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-04 11:58:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:58:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:58:17 --> Final output sent to browser
DEBUG - 2018-05-04 11:58:17 --> Total execution time: 0.1350
INFO - 2018-05-04 08:28:18 --> Config Class Initialized
INFO - 2018-05-04 08:28:18 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:28:18 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:28:18 --> Utf8 Class Initialized
INFO - 2018-05-04 08:28:18 --> URI Class Initialized
INFO - 2018-05-04 08:28:18 --> Router Class Initialized
INFO - 2018-05-04 08:28:18 --> Output Class Initialized
INFO - 2018-05-04 08:28:18 --> Security Class Initialized
DEBUG - 2018-05-04 08:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:28:18 --> Input Class Initialized
INFO - 2018-05-04 08:28:18 --> Language Class Initialized
INFO - 2018-05-04 08:28:18 --> Loader Class Initialized
INFO - 2018-05-04 08:28:18 --> Helper loaded: common_helper
INFO - 2018-05-04 08:28:18 --> Database Driver Class Initialized
INFO - 2018-05-04 08:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:28:18 --> Email Class Initialized
INFO - 2018-05-04 08:28:18 --> Controller Class Initialized
INFO - 2018-05-04 08:28:18 --> Helper loaded: form_helper
INFO - 2018-05-04 08:28:18 --> Form Validation Class Initialized
INFO - 2018-05-04 08:28:18 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:28:18 --> Helper loaded: url_helper
INFO - 2018-05-04 08:28:18 --> Model Class Initialized
INFO - 2018-05-04 08:28:18 --> Model Class Initialized
INFO - 2018-05-04 08:28:18 --> Model Class Initialized
INFO - 2018-05-04 11:58:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:58:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:58:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:58:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-04 11:58:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:58:19 --> Final output sent to browser
DEBUG - 2018-05-04 11:58:19 --> Total execution time: 0.2240
INFO - 2018-05-04 08:29:08 --> Config Class Initialized
INFO - 2018-05-04 08:29:08 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:29:08 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:29:08 --> Utf8 Class Initialized
INFO - 2018-05-04 08:29:08 --> URI Class Initialized
INFO - 2018-05-04 08:29:08 --> Router Class Initialized
INFO - 2018-05-04 08:29:08 --> Output Class Initialized
INFO - 2018-05-04 08:29:08 --> Security Class Initialized
DEBUG - 2018-05-04 08:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:29:08 --> Input Class Initialized
INFO - 2018-05-04 08:29:08 --> Language Class Initialized
INFO - 2018-05-04 08:29:08 --> Loader Class Initialized
INFO - 2018-05-04 08:29:08 --> Helper loaded: common_helper
INFO - 2018-05-04 08:29:08 --> Database Driver Class Initialized
INFO - 2018-05-04 08:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:29:08 --> Email Class Initialized
INFO - 2018-05-04 08:29:08 --> Controller Class Initialized
INFO - 2018-05-04 08:29:08 --> Helper loaded: form_helper
INFO - 2018-05-04 08:29:08 --> Form Validation Class Initialized
INFO - 2018-05-04 08:29:08 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:29:08 --> Helper loaded: url_helper
INFO - 2018-05-04 08:29:08 --> Model Class Initialized
INFO - 2018-05-04 08:29:08 --> Model Class Initialized
INFO - 2018-05-04 08:29:08 --> Model Class Initialized
INFO - 2018-05-04 11:59:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:59:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:59:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:59:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-04 11:59:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:59:08 --> Final output sent to browser
DEBUG - 2018-05-04 11:59:08 --> Total execution time: 0.1460
INFO - 2018-05-04 08:29:48 --> Config Class Initialized
INFO - 2018-05-04 08:29:48 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:29:48 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:29:48 --> Utf8 Class Initialized
INFO - 2018-05-04 08:29:48 --> URI Class Initialized
INFO - 2018-05-04 08:29:48 --> Router Class Initialized
INFO - 2018-05-04 08:29:48 --> Output Class Initialized
INFO - 2018-05-04 08:29:48 --> Security Class Initialized
DEBUG - 2018-05-04 08:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:29:48 --> Input Class Initialized
INFO - 2018-05-04 08:29:48 --> Language Class Initialized
INFO - 2018-05-04 08:29:48 --> Loader Class Initialized
INFO - 2018-05-04 08:29:48 --> Helper loaded: common_helper
INFO - 2018-05-04 08:29:48 --> Database Driver Class Initialized
INFO - 2018-05-04 08:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:29:48 --> Email Class Initialized
INFO - 2018-05-04 08:29:48 --> Controller Class Initialized
INFO - 2018-05-04 08:29:48 --> Helper loaded: form_helper
INFO - 2018-05-04 08:29:48 --> Form Validation Class Initialized
INFO - 2018-05-04 08:29:48 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:29:48 --> Helper loaded: url_helper
INFO - 2018-05-04 08:29:48 --> Model Class Initialized
INFO - 2018-05-04 08:29:48 --> Model Class Initialized
INFO - 2018-05-04 08:29:48 --> Model Class Initialized
INFO - 2018-05-04 11:59:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 11:59:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 11:59:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 11:59:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-04 11:59:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 11:59:48 --> Final output sent to browser
DEBUG - 2018-05-04 11:59:48 --> Total execution time: 0.1400
INFO - 2018-05-04 08:41:30 --> Config Class Initialized
INFO - 2018-05-04 08:41:30 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:41:30 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:41:30 --> Utf8 Class Initialized
INFO - 2018-05-04 08:41:30 --> URI Class Initialized
INFO - 2018-05-04 08:41:30 --> Router Class Initialized
INFO - 2018-05-04 08:41:30 --> Output Class Initialized
INFO - 2018-05-04 08:41:30 --> Security Class Initialized
DEBUG - 2018-05-04 08:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:41:30 --> Input Class Initialized
INFO - 2018-05-04 08:41:30 --> Language Class Initialized
INFO - 2018-05-04 08:41:30 --> Loader Class Initialized
INFO - 2018-05-04 08:41:30 --> Helper loaded: common_helper
INFO - 2018-05-04 08:41:30 --> Database Driver Class Initialized
INFO - 2018-05-04 08:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:41:30 --> Email Class Initialized
INFO - 2018-05-04 08:41:30 --> Controller Class Initialized
INFO - 2018-05-04 08:41:30 --> Helper loaded: form_helper
INFO - 2018-05-04 08:41:30 --> Form Validation Class Initialized
INFO - 2018-05-04 08:41:30 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:41:30 --> Helper loaded: url_helper
INFO - 2018-05-04 08:41:30 --> Model Class Initialized
INFO - 2018-05-04 08:41:30 --> Model Class Initialized
INFO - 2018-05-04 08:41:30 --> Model Class Initialized
INFO - 2018-05-04 12:11:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 12:11:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 12:11:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 12:11:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-04 12:11:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 12:11:30 --> Final output sent to browser
DEBUG - 2018-05-04 12:11:30 --> Total execution time: 0.1390
INFO - 2018-05-04 08:41:36 --> Config Class Initialized
INFO - 2018-05-04 08:41:36 --> Hooks Class Initialized
DEBUG - 2018-05-04 08:41:36 --> UTF-8 Support Enabled
INFO - 2018-05-04 08:41:36 --> Utf8 Class Initialized
INFO - 2018-05-04 08:41:36 --> URI Class Initialized
INFO - 2018-05-04 08:41:36 --> Router Class Initialized
INFO - 2018-05-04 08:41:36 --> Output Class Initialized
INFO - 2018-05-04 08:41:36 --> Security Class Initialized
DEBUG - 2018-05-04 08:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 08:41:36 --> Input Class Initialized
INFO - 2018-05-04 08:41:36 --> Language Class Initialized
INFO - 2018-05-04 08:41:36 --> Loader Class Initialized
INFO - 2018-05-04 08:41:36 --> Helper loaded: common_helper
INFO - 2018-05-04 08:41:36 --> Database Driver Class Initialized
INFO - 2018-05-04 08:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 08:41:37 --> Email Class Initialized
INFO - 2018-05-04 08:41:37 --> Controller Class Initialized
INFO - 2018-05-04 08:41:37 --> Helper loaded: form_helper
INFO - 2018-05-04 08:41:37 --> Form Validation Class Initialized
INFO - 2018-05-04 08:41:37 --> Helper loaded: email_helper
DEBUG - 2018-05-04 08:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 08:41:37 --> Helper loaded: url_helper
INFO - 2018-05-04 08:41:37 --> Model Class Initialized
INFO - 2018-05-04 08:41:37 --> Model Class Initialized
INFO - 2018-05-04 08:41:37 --> Model Class Initialized
INFO - 2018-05-04 12:11:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 12:11:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 12:11:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 12:11:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/addGelery.php
INFO - 2018-05-04 12:11:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 12:11:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 12:11:37 --> Final output sent to browser
DEBUG - 2018-05-04 12:11:37 --> Total execution time: 0.1430
INFO - 2018-05-04 11:34:38 --> Config Class Initialized
INFO - 2018-05-04 11:34:38 --> Hooks Class Initialized
DEBUG - 2018-05-04 11:34:38 --> UTF-8 Support Enabled
INFO - 2018-05-04 11:34:38 --> Utf8 Class Initialized
INFO - 2018-05-04 11:34:38 --> URI Class Initialized
INFO - 2018-05-04 11:34:38 --> Router Class Initialized
INFO - 2018-05-04 11:34:38 --> Output Class Initialized
INFO - 2018-05-04 11:34:38 --> Security Class Initialized
DEBUG - 2018-05-04 11:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 11:34:38 --> Input Class Initialized
INFO - 2018-05-04 11:34:38 --> Language Class Initialized
INFO - 2018-05-04 11:34:38 --> Loader Class Initialized
INFO - 2018-05-04 11:34:38 --> Helper loaded: common_helper
INFO - 2018-05-04 11:34:38 --> Database Driver Class Initialized
INFO - 2018-05-04 11:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 11:34:38 --> Email Class Initialized
INFO - 2018-05-04 11:34:38 --> Controller Class Initialized
INFO - 2018-05-04 11:34:38 --> Helper loaded: form_helper
INFO - 2018-05-04 11:34:38 --> Form Validation Class Initialized
INFO - 2018-05-04 11:34:38 --> Helper loaded: email_helper
DEBUG - 2018-05-04 11:34:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 11:34:38 --> Helper loaded: url_helper
INFO - 2018-05-04 11:34:38 --> Model Class Initialized
INFO - 2018-05-04 11:34:38 --> Model Class Initialized
INFO - 2018-05-04 11:34:38 --> Model Class Initialized
INFO - 2018-05-04 15:04:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 15:04:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 15:04:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 15:04:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-04 15:04:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 15:04:38 --> Final output sent to browser
DEBUG - 2018-05-04 15:04:38 --> Total execution time: 0.2120
INFO - 2018-05-04 11:34:39 --> Config Class Initialized
INFO - 2018-05-04 11:34:39 --> Hooks Class Initialized
DEBUG - 2018-05-04 11:34:39 --> UTF-8 Support Enabled
INFO - 2018-05-04 11:34:39 --> Utf8 Class Initialized
INFO - 2018-05-04 11:34:39 --> URI Class Initialized
INFO - 2018-05-04 11:34:39 --> Router Class Initialized
INFO - 2018-05-04 11:34:39 --> Output Class Initialized
INFO - 2018-05-04 11:34:39 --> Security Class Initialized
DEBUG - 2018-05-04 11:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 11:34:39 --> Input Class Initialized
INFO - 2018-05-04 11:34:39 --> Language Class Initialized
INFO - 2018-05-04 11:34:39 --> Loader Class Initialized
INFO - 2018-05-04 11:34:39 --> Helper loaded: common_helper
INFO - 2018-05-04 11:34:39 --> Database Driver Class Initialized
INFO - 2018-05-04 11:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 11:34:40 --> Email Class Initialized
INFO - 2018-05-04 11:34:40 --> Controller Class Initialized
INFO - 2018-05-04 11:34:40 --> Helper loaded: form_helper
INFO - 2018-05-04 11:34:40 --> Form Validation Class Initialized
INFO - 2018-05-04 11:34:40 --> Helper loaded: email_helper
DEBUG - 2018-05-04 11:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 11:34:40 --> Helper loaded: url_helper
INFO - 2018-05-04 11:34:40 --> Model Class Initialized
INFO - 2018-05-04 11:34:40 --> Model Class Initialized
INFO - 2018-05-04 11:34:40 --> Model Class Initialized
INFO - 2018-05-04 15:04:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 15:04:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 15:04:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-04 15:04:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 15:04:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 15:04:40 --> Final output sent to browser
DEBUG - 2018-05-04 15:04:40 --> Total execution time: 0.1500
INFO - 2018-05-04 11:34:41 --> Config Class Initialized
INFO - 2018-05-04 11:34:41 --> Hooks Class Initialized
DEBUG - 2018-05-04 11:34:41 --> UTF-8 Support Enabled
INFO - 2018-05-04 11:34:41 --> Utf8 Class Initialized
INFO - 2018-05-04 11:34:41 --> URI Class Initialized
INFO - 2018-05-04 11:34:41 --> Router Class Initialized
INFO - 2018-05-04 11:34:41 --> Output Class Initialized
INFO - 2018-05-04 11:34:41 --> Security Class Initialized
DEBUG - 2018-05-04 11:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 11:34:42 --> Input Class Initialized
INFO - 2018-05-04 11:34:42 --> Language Class Initialized
INFO - 2018-05-04 11:34:42 --> Loader Class Initialized
INFO - 2018-05-04 11:34:42 --> Helper loaded: common_helper
INFO - 2018-05-04 11:34:42 --> Database Driver Class Initialized
INFO - 2018-05-04 11:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 11:34:42 --> Email Class Initialized
INFO - 2018-05-04 11:34:42 --> Controller Class Initialized
INFO - 2018-05-04 11:34:42 --> Helper loaded: form_helper
INFO - 2018-05-04 11:34:42 --> Form Validation Class Initialized
INFO - 2018-05-04 11:34:42 --> Helper loaded: email_helper
DEBUG - 2018-05-04 11:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 11:34:42 --> Helper loaded: url_helper
INFO - 2018-05-04 11:34:42 --> Model Class Initialized
INFO - 2018-05-04 11:34:42 --> Model Class Initialized
INFO - 2018-05-04 11:34:42 --> Model Class Initialized
INFO - 2018-05-04 15:04:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 15:04:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 15:04:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 15:04:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 15:04:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 15:04:42 --> Final output sent to browser
DEBUG - 2018-05-04 15:04:42 --> Total execution time: 0.1540
INFO - 2018-05-04 11:34:44 --> Config Class Initialized
INFO - 2018-05-04 11:34:44 --> Hooks Class Initialized
DEBUG - 2018-05-04 11:34:44 --> UTF-8 Support Enabled
INFO - 2018-05-04 11:34:44 --> Utf8 Class Initialized
INFO - 2018-05-04 11:34:44 --> URI Class Initialized
INFO - 2018-05-04 11:34:44 --> Router Class Initialized
INFO - 2018-05-04 11:34:44 --> Output Class Initialized
INFO - 2018-05-04 11:34:44 --> Security Class Initialized
DEBUG - 2018-05-04 11:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 11:34:44 --> Input Class Initialized
INFO - 2018-05-04 11:34:44 --> Language Class Initialized
INFO - 2018-05-04 11:34:44 --> Loader Class Initialized
INFO - 2018-05-04 11:34:44 --> Helper loaded: common_helper
INFO - 2018-05-04 11:34:44 --> Database Driver Class Initialized
INFO - 2018-05-04 11:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 11:34:44 --> Email Class Initialized
INFO - 2018-05-04 11:34:44 --> Controller Class Initialized
INFO - 2018-05-04 11:34:44 --> Helper loaded: form_helper
INFO - 2018-05-04 11:34:44 --> Form Validation Class Initialized
INFO - 2018-05-04 11:34:44 --> Helper loaded: email_helper
DEBUG - 2018-05-04 11:34:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 11:34:44 --> Helper loaded: url_helper
INFO - 2018-05-04 11:34:44 --> Model Class Initialized
INFO - 2018-05-04 11:34:44 --> Model Class Initialized
INFO - 2018-05-04 11:34:44 --> Model Class Initialized
INFO - 2018-05-04 15:04:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 15:04:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 15:04:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 15:04:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 15:04:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 15:04:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 15:04:44 --> Final output sent to browser
DEBUG - 2018-05-04 15:04:44 --> Total execution time: 0.1390
INFO - 2018-05-04 11:36:08 --> Config Class Initialized
INFO - 2018-05-04 11:36:08 --> Hooks Class Initialized
DEBUG - 2018-05-04 11:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-04 11:36:08 --> Utf8 Class Initialized
INFO - 2018-05-04 11:36:08 --> URI Class Initialized
INFO - 2018-05-04 11:36:08 --> Router Class Initialized
INFO - 2018-05-04 11:36:08 --> Output Class Initialized
INFO - 2018-05-04 11:36:08 --> Security Class Initialized
DEBUG - 2018-05-04 11:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 11:36:08 --> Input Class Initialized
INFO - 2018-05-04 11:36:08 --> Language Class Initialized
INFO - 2018-05-04 11:36:08 --> Loader Class Initialized
INFO - 2018-05-04 11:36:08 --> Helper loaded: common_helper
INFO - 2018-05-04 11:36:08 --> Database Driver Class Initialized
INFO - 2018-05-04 11:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 11:36:08 --> Email Class Initialized
INFO - 2018-05-04 11:36:08 --> Controller Class Initialized
INFO - 2018-05-04 11:36:08 --> Helper loaded: form_helper
INFO - 2018-05-04 11:36:08 --> Form Validation Class Initialized
INFO - 2018-05-04 11:36:08 --> Helper loaded: email_helper
DEBUG - 2018-05-04 11:36:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 11:36:08 --> Helper loaded: url_helper
INFO - 2018-05-04 11:36:08 --> Model Class Initialized
INFO - 2018-05-04 11:36:08 --> Model Class Initialized
INFO - 2018-05-04 11:36:08 --> Model Class Initialized
INFO - 2018-05-04 15:06:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 15:06:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 15:06:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 15:06:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 15:06:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 15:06:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 15:06:08 --> Final output sent to browser
DEBUG - 2018-05-04 15:06:08 --> Total execution time: 0.1410
INFO - 2018-05-04 11:36:49 --> Config Class Initialized
INFO - 2018-05-04 11:36:49 --> Hooks Class Initialized
DEBUG - 2018-05-04 11:36:49 --> UTF-8 Support Enabled
INFO - 2018-05-04 11:36:49 --> Utf8 Class Initialized
INFO - 2018-05-04 11:36:49 --> URI Class Initialized
INFO - 2018-05-04 11:36:49 --> Router Class Initialized
INFO - 2018-05-04 11:36:49 --> Output Class Initialized
INFO - 2018-05-04 11:36:49 --> Security Class Initialized
DEBUG - 2018-05-04 11:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 11:36:49 --> Input Class Initialized
INFO - 2018-05-04 11:36:50 --> Language Class Initialized
INFO - 2018-05-04 11:36:50 --> Loader Class Initialized
INFO - 2018-05-04 11:36:50 --> Helper loaded: common_helper
INFO - 2018-05-04 11:36:50 --> Database Driver Class Initialized
INFO - 2018-05-04 11:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 11:36:50 --> Email Class Initialized
INFO - 2018-05-04 11:36:50 --> Controller Class Initialized
INFO - 2018-05-04 11:36:50 --> Helper loaded: form_helper
INFO - 2018-05-04 11:36:50 --> Form Validation Class Initialized
INFO - 2018-05-04 11:36:50 --> Helper loaded: email_helper
DEBUG - 2018-05-04 11:36:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 11:36:50 --> Helper loaded: url_helper
INFO - 2018-05-04 11:36:50 --> Model Class Initialized
INFO - 2018-05-04 11:36:50 --> Model Class Initialized
INFO - 2018-05-04 11:36:50 --> Model Class Initialized
INFO - 2018-05-04 15:06:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 15:06:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 15:06:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 15:06:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 15:06:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 15:06:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 15:06:50 --> Final output sent to browser
DEBUG - 2018-05-04 15:06:50 --> Total execution time: 0.1480
INFO - 2018-05-04 11:37:01 --> Config Class Initialized
INFO - 2018-05-04 11:37:01 --> Hooks Class Initialized
DEBUG - 2018-05-04 11:37:01 --> UTF-8 Support Enabled
INFO - 2018-05-04 11:37:01 --> Utf8 Class Initialized
INFO - 2018-05-04 11:37:01 --> URI Class Initialized
INFO - 2018-05-04 11:37:01 --> Router Class Initialized
INFO - 2018-05-04 11:37:01 --> Output Class Initialized
INFO - 2018-05-04 11:37:01 --> Security Class Initialized
DEBUG - 2018-05-04 11:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 11:37:01 --> Input Class Initialized
INFO - 2018-05-04 11:37:01 --> Language Class Initialized
INFO - 2018-05-04 11:37:01 --> Loader Class Initialized
INFO - 2018-05-04 11:37:01 --> Helper loaded: common_helper
INFO - 2018-05-04 11:37:01 --> Database Driver Class Initialized
INFO - 2018-05-04 11:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 11:37:01 --> Email Class Initialized
INFO - 2018-05-04 11:37:01 --> Controller Class Initialized
INFO - 2018-05-04 11:37:01 --> Helper loaded: form_helper
INFO - 2018-05-04 11:37:01 --> Form Validation Class Initialized
INFO - 2018-05-04 11:37:01 --> Helper loaded: email_helper
DEBUG - 2018-05-04 11:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 11:37:01 --> Helper loaded: url_helper
INFO - 2018-05-04 11:37:01 --> Model Class Initialized
INFO - 2018-05-04 11:37:01 --> Model Class Initialized
INFO - 2018-05-04 11:37:01 --> Model Class Initialized
INFO - 2018-05-04 15:07:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 15:07:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 15:07:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 15:07:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 15:07:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 15:07:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 15:07:01 --> Final output sent to browser
DEBUG - 2018-05-04 15:07:01 --> Total execution time: 0.1510
INFO - 2018-05-04 11:57:36 --> Config Class Initialized
INFO - 2018-05-04 11:57:36 --> Hooks Class Initialized
DEBUG - 2018-05-04 11:57:36 --> UTF-8 Support Enabled
INFO - 2018-05-04 11:57:36 --> Utf8 Class Initialized
INFO - 2018-05-04 11:57:36 --> URI Class Initialized
INFO - 2018-05-04 11:57:36 --> Router Class Initialized
INFO - 2018-05-04 11:57:36 --> Output Class Initialized
INFO - 2018-05-04 11:57:36 --> Security Class Initialized
DEBUG - 2018-05-04 11:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 11:57:36 --> Input Class Initialized
INFO - 2018-05-04 11:57:36 --> Language Class Initialized
INFO - 2018-05-04 11:57:36 --> Loader Class Initialized
INFO - 2018-05-04 11:57:36 --> Helper loaded: common_helper
INFO - 2018-05-04 11:57:36 --> Database Driver Class Initialized
INFO - 2018-05-04 11:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 11:57:36 --> Email Class Initialized
INFO - 2018-05-04 11:57:36 --> Controller Class Initialized
INFO - 2018-05-04 11:57:36 --> Helper loaded: form_helper
INFO - 2018-05-04 11:57:36 --> Form Validation Class Initialized
INFO - 2018-05-04 11:57:36 --> Helper loaded: email_helper
DEBUG - 2018-05-04 11:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 11:57:36 --> Helper loaded: url_helper
INFO - 2018-05-04 11:57:36 --> Model Class Initialized
INFO - 2018-05-04 11:57:36 --> Model Class Initialized
INFO - 2018-05-04 11:57:36 --> Model Class Initialized
INFO - 2018-05-04 15:27:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 15:27:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 15:27:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 15:27:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 15:27:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 15:27:36 --> Final output sent to browser
DEBUG - 2018-05-04 15:27:36 --> Total execution time: 0.1500
INFO - 2018-05-04 11:57:38 --> Config Class Initialized
INFO - 2018-05-04 11:57:38 --> Hooks Class Initialized
DEBUG - 2018-05-04 11:57:38 --> UTF-8 Support Enabled
INFO - 2018-05-04 11:57:38 --> Utf8 Class Initialized
INFO - 2018-05-04 11:57:38 --> URI Class Initialized
INFO - 2018-05-04 11:57:38 --> Router Class Initialized
INFO - 2018-05-04 11:57:38 --> Output Class Initialized
INFO - 2018-05-04 11:57:38 --> Security Class Initialized
DEBUG - 2018-05-04 11:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 11:57:38 --> Input Class Initialized
INFO - 2018-05-04 11:57:38 --> Language Class Initialized
INFO - 2018-05-04 11:57:38 --> Loader Class Initialized
INFO - 2018-05-04 11:57:38 --> Helper loaded: common_helper
INFO - 2018-05-04 11:57:39 --> Database Driver Class Initialized
INFO - 2018-05-04 11:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 11:57:39 --> Email Class Initialized
INFO - 2018-05-04 11:57:39 --> Controller Class Initialized
INFO - 2018-05-04 11:57:39 --> Helper loaded: form_helper
INFO - 2018-05-04 11:57:39 --> Form Validation Class Initialized
INFO - 2018-05-04 11:57:39 --> Helper loaded: email_helper
DEBUG - 2018-05-04 11:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 11:57:39 --> Helper loaded: url_helper
INFO - 2018-05-04 11:57:39 --> Model Class Initialized
INFO - 2018-05-04 11:57:39 --> Model Class Initialized
INFO - 2018-05-04 11:57:39 --> Model Class Initialized
INFO - 2018-05-04 15:27:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 15:27:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 15:27:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 15:27:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 15:27:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 15:27:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 15:27:39 --> Final output sent to browser
DEBUG - 2018-05-04 15:27:39 --> Total execution time: 0.1710
INFO - 2018-05-04 12:03:25 --> Config Class Initialized
INFO - 2018-05-04 12:03:25 --> Hooks Class Initialized
DEBUG - 2018-05-04 12:03:25 --> UTF-8 Support Enabled
INFO - 2018-05-04 12:03:25 --> Utf8 Class Initialized
INFO - 2018-05-04 12:03:25 --> URI Class Initialized
INFO - 2018-05-04 12:03:25 --> Router Class Initialized
INFO - 2018-05-04 12:03:25 --> Output Class Initialized
INFO - 2018-05-04 12:03:25 --> Security Class Initialized
DEBUG - 2018-05-04 12:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 12:03:25 --> Input Class Initialized
INFO - 2018-05-04 12:03:25 --> Language Class Initialized
INFO - 2018-05-04 12:03:25 --> Loader Class Initialized
INFO - 2018-05-04 12:03:25 --> Helper loaded: common_helper
INFO - 2018-05-04 12:03:25 --> Database Driver Class Initialized
INFO - 2018-05-04 12:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 12:03:25 --> Email Class Initialized
INFO - 2018-05-04 12:03:25 --> Controller Class Initialized
INFO - 2018-05-04 12:03:25 --> Helper loaded: form_helper
INFO - 2018-05-04 12:03:25 --> Form Validation Class Initialized
INFO - 2018-05-04 12:03:25 --> Helper loaded: email_helper
DEBUG - 2018-05-04 12:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 12:03:25 --> Helper loaded: url_helper
INFO - 2018-05-04 12:03:25 --> Model Class Initialized
INFO - 2018-05-04 12:03:25 --> Model Class Initialized
INFO - 2018-05-04 12:03:25 --> Model Class Initialized
INFO - 2018-05-04 15:33:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 15:33:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 15:33:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 15:33:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 15:33:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 15:33:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 15:33:25 --> Final output sent to browser
DEBUG - 2018-05-04 15:33:25 --> Total execution time: 0.1560
INFO - 2018-05-04 12:05:05 --> Config Class Initialized
INFO - 2018-05-04 12:05:05 --> Hooks Class Initialized
DEBUG - 2018-05-04 12:05:05 --> UTF-8 Support Enabled
INFO - 2018-05-04 12:05:05 --> Utf8 Class Initialized
INFO - 2018-05-04 12:05:05 --> URI Class Initialized
INFO - 2018-05-04 12:05:05 --> Router Class Initialized
INFO - 2018-05-04 12:05:05 --> Output Class Initialized
INFO - 2018-05-04 12:05:05 --> Security Class Initialized
DEBUG - 2018-05-04 12:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 12:05:05 --> Input Class Initialized
INFO - 2018-05-04 12:05:05 --> Language Class Initialized
INFO - 2018-05-04 12:05:05 --> Loader Class Initialized
INFO - 2018-05-04 12:05:05 --> Helper loaded: common_helper
INFO - 2018-05-04 12:05:05 --> Database Driver Class Initialized
INFO - 2018-05-04 12:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 12:05:05 --> Email Class Initialized
INFO - 2018-05-04 12:05:05 --> Controller Class Initialized
INFO - 2018-05-04 12:05:05 --> Helper loaded: form_helper
INFO - 2018-05-04 12:05:05 --> Form Validation Class Initialized
INFO - 2018-05-04 12:05:05 --> Helper loaded: email_helper
DEBUG - 2018-05-04 12:05:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 12:05:05 --> Helper loaded: url_helper
INFO - 2018-05-04 12:05:05 --> Model Class Initialized
INFO - 2018-05-04 12:05:05 --> Model Class Initialized
INFO - 2018-05-04 12:05:05 --> Model Class Initialized
INFO - 2018-05-04 15:35:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 15:35:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 15:35:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 15:35:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 15:35:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 15:35:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 15:35:05 --> Final output sent to browser
DEBUG - 2018-05-04 15:35:05 --> Total execution time: 0.1520
INFO - 2018-05-04 12:32:02 --> Config Class Initialized
INFO - 2018-05-04 12:32:02 --> Hooks Class Initialized
DEBUG - 2018-05-04 12:32:02 --> UTF-8 Support Enabled
INFO - 2018-05-04 12:32:02 --> Utf8 Class Initialized
INFO - 2018-05-04 12:32:02 --> URI Class Initialized
INFO - 2018-05-04 12:32:02 --> Router Class Initialized
INFO - 2018-05-04 12:32:02 --> Output Class Initialized
INFO - 2018-05-04 12:32:02 --> Security Class Initialized
DEBUG - 2018-05-04 12:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 12:32:02 --> Input Class Initialized
INFO - 2018-05-04 12:32:02 --> Language Class Initialized
INFO - 2018-05-04 12:32:02 --> Loader Class Initialized
INFO - 2018-05-04 12:32:02 --> Helper loaded: common_helper
INFO - 2018-05-04 12:32:02 --> Database Driver Class Initialized
INFO - 2018-05-04 12:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 12:32:02 --> Email Class Initialized
INFO - 2018-05-04 12:32:02 --> Controller Class Initialized
INFO - 2018-05-04 12:32:02 --> Helper loaded: form_helper
INFO - 2018-05-04 12:32:02 --> Form Validation Class Initialized
INFO - 2018-05-04 12:32:02 --> Helper loaded: email_helper
DEBUG - 2018-05-04 12:32:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 12:32:02 --> Helper loaded: url_helper
INFO - 2018-05-04 12:32:02 --> Model Class Initialized
INFO - 2018-05-04 12:32:02 --> Model Class Initialized
INFO - 2018-05-04 12:32:02 --> Model Class Initialized
INFO - 2018-05-04 16:02:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 16:02:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 16:02:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 16:02:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 16:02:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editSongs.php
INFO - 2018-05-04 16:02:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 16:02:02 --> Final output sent to browser
DEBUG - 2018-05-04 16:02:02 --> Total execution time: 0.1490
INFO - 2018-05-04 12:34:15 --> Config Class Initialized
INFO - 2018-05-04 12:34:15 --> Hooks Class Initialized
DEBUG - 2018-05-04 12:34:15 --> UTF-8 Support Enabled
INFO - 2018-05-04 12:34:15 --> Utf8 Class Initialized
INFO - 2018-05-04 12:34:15 --> URI Class Initialized
INFO - 2018-05-04 12:34:15 --> Router Class Initialized
INFO - 2018-05-04 12:34:15 --> Output Class Initialized
INFO - 2018-05-04 12:34:15 --> Security Class Initialized
DEBUG - 2018-05-04 12:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 12:34:15 --> Input Class Initialized
INFO - 2018-05-04 12:34:15 --> Language Class Initialized
INFO - 2018-05-04 12:34:15 --> Loader Class Initialized
INFO - 2018-05-04 12:34:15 --> Helper loaded: common_helper
INFO - 2018-05-04 12:34:15 --> Database Driver Class Initialized
INFO - 2018-05-04 12:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 12:34:15 --> Email Class Initialized
INFO - 2018-05-04 12:34:15 --> Controller Class Initialized
INFO - 2018-05-04 12:34:15 --> Helper loaded: form_helper
INFO - 2018-05-04 12:34:15 --> Form Validation Class Initialized
INFO - 2018-05-04 12:34:15 --> Helper loaded: email_helper
DEBUG - 2018-05-04 12:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 12:34:15 --> Helper loaded: url_helper
INFO - 2018-05-04 12:34:15 --> Model Class Initialized
INFO - 2018-05-04 12:34:15 --> Model Class Initialized
INFO - 2018-05-04 12:34:15 --> Model Class Initialized
INFO - 2018-05-04 16:04:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 16:04:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 16:04:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 16:04:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 16:04:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 16:04:15 --> Final output sent to browser
DEBUG - 2018-05-04 16:04:15 --> Total execution time: 0.1450
INFO - 2018-05-04 12:34:35 --> Config Class Initialized
INFO - 2018-05-04 12:34:35 --> Hooks Class Initialized
DEBUG - 2018-05-04 12:34:35 --> UTF-8 Support Enabled
INFO - 2018-05-04 12:34:35 --> Utf8 Class Initialized
INFO - 2018-05-04 12:34:35 --> URI Class Initialized
INFO - 2018-05-04 12:34:35 --> Router Class Initialized
INFO - 2018-05-04 12:34:35 --> Output Class Initialized
INFO - 2018-05-04 12:34:35 --> Security Class Initialized
DEBUG - 2018-05-04 12:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 12:34:35 --> Input Class Initialized
INFO - 2018-05-04 12:34:35 --> Language Class Initialized
INFO - 2018-05-04 12:34:35 --> Loader Class Initialized
INFO - 2018-05-04 12:34:35 --> Helper loaded: common_helper
INFO - 2018-05-04 12:34:35 --> Database Driver Class Initialized
INFO - 2018-05-04 12:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 12:34:35 --> Email Class Initialized
INFO - 2018-05-04 12:34:35 --> Controller Class Initialized
INFO - 2018-05-04 12:34:35 --> Helper loaded: form_helper
INFO - 2018-05-04 12:34:35 --> Form Validation Class Initialized
INFO - 2018-05-04 12:34:35 --> Helper loaded: email_helper
DEBUG - 2018-05-04 12:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 12:34:35 --> Helper loaded: url_helper
INFO - 2018-05-04 12:34:35 --> Model Class Initialized
INFO - 2018-05-04 12:34:35 --> Model Class Initialized
INFO - 2018-05-04 12:34:35 --> Model Class Initialized
INFO - 2018-05-04 16:04:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 16:04:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 16:04:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 16:04:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 16:04:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 16:04:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 16:04:35 --> Final output sent to browser
DEBUG - 2018-05-04 16:04:35 --> Total execution time: 0.1370
INFO - 2018-05-04 12:35:05 --> Config Class Initialized
INFO - 2018-05-04 12:35:05 --> Hooks Class Initialized
DEBUG - 2018-05-04 12:35:05 --> UTF-8 Support Enabled
INFO - 2018-05-04 12:35:05 --> Utf8 Class Initialized
INFO - 2018-05-04 12:35:05 --> URI Class Initialized
INFO - 2018-05-04 12:35:06 --> Router Class Initialized
INFO - 2018-05-04 12:35:06 --> Output Class Initialized
INFO - 2018-05-04 12:35:06 --> Security Class Initialized
DEBUG - 2018-05-04 12:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 12:35:06 --> Input Class Initialized
INFO - 2018-05-04 12:35:06 --> Language Class Initialized
INFO - 2018-05-04 12:35:06 --> Loader Class Initialized
INFO - 2018-05-04 12:35:06 --> Helper loaded: common_helper
INFO - 2018-05-04 12:35:06 --> Database Driver Class Initialized
INFO - 2018-05-04 12:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 12:35:06 --> Email Class Initialized
INFO - 2018-05-04 12:35:06 --> Controller Class Initialized
INFO - 2018-05-04 12:35:06 --> Helper loaded: form_helper
INFO - 2018-05-04 12:35:06 --> Form Validation Class Initialized
INFO - 2018-05-04 12:35:06 --> Helper loaded: email_helper
DEBUG - 2018-05-04 12:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 12:35:06 --> Helper loaded: url_helper
INFO - 2018-05-04 12:35:06 --> Model Class Initialized
INFO - 2018-05-04 12:35:06 --> Model Class Initialized
INFO - 2018-05-04 12:35:06 --> Model Class Initialized
INFO - 2018-05-04 16:05:06 --> Final output sent to browser
DEBUG - 2018-05-04 16:05:06 --> Total execution time: 0.1960
INFO - 2018-05-04 12:35:07 --> Config Class Initialized
INFO - 2018-05-04 12:35:07 --> Hooks Class Initialized
DEBUG - 2018-05-04 12:35:07 --> UTF-8 Support Enabled
INFO - 2018-05-04 12:35:07 --> Utf8 Class Initialized
INFO - 2018-05-04 12:35:07 --> URI Class Initialized
INFO - 2018-05-04 12:35:07 --> Router Class Initialized
INFO - 2018-05-04 12:35:07 --> Output Class Initialized
INFO - 2018-05-04 12:35:07 --> Security Class Initialized
DEBUG - 2018-05-04 12:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 12:35:07 --> Input Class Initialized
INFO - 2018-05-04 12:35:07 --> Language Class Initialized
INFO - 2018-05-04 12:35:07 --> Loader Class Initialized
INFO - 2018-05-04 12:35:07 --> Helper loaded: common_helper
INFO - 2018-05-04 12:35:07 --> Database Driver Class Initialized
INFO - 2018-05-04 12:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 12:35:07 --> Email Class Initialized
INFO - 2018-05-04 12:35:07 --> Controller Class Initialized
INFO - 2018-05-04 12:35:07 --> Helper loaded: form_helper
INFO - 2018-05-04 12:35:07 --> Form Validation Class Initialized
INFO - 2018-05-04 12:35:07 --> Helper loaded: email_helper
DEBUG - 2018-05-04 12:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 12:35:07 --> Helper loaded: url_helper
INFO - 2018-05-04 12:35:07 --> Model Class Initialized
INFO - 2018-05-04 12:35:07 --> Model Class Initialized
INFO - 2018-05-04 12:35:07 --> Model Class Initialized
INFO - 2018-05-04 16:05:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 16:05:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-04 16:05:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 16:05:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 16:05:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-04 16:05:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 16:05:07 --> Final output sent to browser
DEBUG - 2018-05-04 16:05:07 --> Total execution time: 0.1600
INFO - 2018-05-04 12:54:21 --> Config Class Initialized
INFO - 2018-05-04 12:54:21 --> Hooks Class Initialized
DEBUG - 2018-05-04 12:54:21 --> UTF-8 Support Enabled
INFO - 2018-05-04 12:54:21 --> Utf8 Class Initialized
INFO - 2018-05-04 12:54:21 --> URI Class Initialized
INFO - 2018-05-04 12:54:21 --> Router Class Initialized
INFO - 2018-05-04 12:54:21 --> Output Class Initialized
INFO - 2018-05-04 12:54:21 --> Security Class Initialized
DEBUG - 2018-05-04 12:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 12:54:21 --> Input Class Initialized
INFO - 2018-05-04 12:54:21 --> Language Class Initialized
INFO - 2018-05-04 12:54:21 --> Loader Class Initialized
INFO - 2018-05-04 12:54:21 --> Helper loaded: common_helper
INFO - 2018-05-04 12:54:21 --> Database Driver Class Initialized
INFO - 2018-05-04 12:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 12:54:21 --> Email Class Initialized
INFO - 2018-05-04 12:54:21 --> Controller Class Initialized
INFO - 2018-05-04 12:54:21 --> Helper loaded: form_helper
INFO - 2018-05-04 12:54:21 --> Form Validation Class Initialized
INFO - 2018-05-04 12:54:21 --> Helper loaded: email_helper
DEBUG - 2018-05-04 12:54:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 12:54:21 --> Helper loaded: url_helper
INFO - 2018-05-04 12:54:21 --> Model Class Initialized
INFO - 2018-05-04 12:54:21 --> Model Class Initialized
INFO - 2018-05-04 12:54:21 --> Model Class Initialized
INFO - 2018-05-04 16:24:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 16:24:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 16:24:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 16:24:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-04 16:24:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 16:24:21 --> Final output sent to browser
DEBUG - 2018-05-04 16:24:21 --> Total execution time: 0.1470
INFO - 2018-05-04 12:54:22 --> Config Class Initialized
INFO - 2018-05-04 12:54:22 --> Hooks Class Initialized
DEBUG - 2018-05-04 12:54:22 --> UTF-8 Support Enabled
INFO - 2018-05-04 12:54:22 --> Utf8 Class Initialized
INFO - 2018-05-04 12:54:22 --> URI Class Initialized
INFO - 2018-05-04 12:54:22 --> Router Class Initialized
INFO - 2018-05-04 12:54:22 --> Output Class Initialized
INFO - 2018-05-04 12:54:22 --> Security Class Initialized
DEBUG - 2018-05-04 12:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 12:54:22 --> Input Class Initialized
INFO - 2018-05-04 12:54:22 --> Language Class Initialized
INFO - 2018-05-04 12:54:22 --> Loader Class Initialized
INFO - 2018-05-04 12:54:22 --> Helper loaded: common_helper
INFO - 2018-05-04 12:54:22 --> Database Driver Class Initialized
INFO - 2018-05-04 12:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 12:54:22 --> Email Class Initialized
INFO - 2018-05-04 12:54:22 --> Controller Class Initialized
INFO - 2018-05-04 12:54:22 --> Helper loaded: form_helper
INFO - 2018-05-04 12:54:22 --> Form Validation Class Initialized
INFO - 2018-05-04 12:54:22 --> Helper loaded: email_helper
DEBUG - 2018-05-04 12:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 12:54:22 --> Helper loaded: url_helper
INFO - 2018-05-04 12:54:22 --> Model Class Initialized
INFO - 2018-05-04 12:54:22 --> Model Class Initialized
INFO - 2018-05-04 12:54:22 --> Model Class Initialized
INFO - 2018-05-04 16:24:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 16:24:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 16:24:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-04 16:24:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 16:24:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 16:24:22 --> Final output sent to browser
DEBUG - 2018-05-04 16:24:22 --> Total execution time: 0.1540
INFO - 2018-05-04 12:54:24 --> Config Class Initialized
INFO - 2018-05-04 12:54:24 --> Hooks Class Initialized
DEBUG - 2018-05-04 12:54:24 --> UTF-8 Support Enabled
INFO - 2018-05-04 12:54:24 --> Utf8 Class Initialized
INFO - 2018-05-04 12:54:24 --> URI Class Initialized
INFO - 2018-05-04 12:54:24 --> Router Class Initialized
INFO - 2018-05-04 12:54:24 --> Output Class Initialized
INFO - 2018-05-04 12:54:24 --> Security Class Initialized
DEBUG - 2018-05-04 12:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 12:54:24 --> Input Class Initialized
INFO - 2018-05-04 12:54:24 --> Language Class Initialized
INFO - 2018-05-04 12:54:24 --> Loader Class Initialized
INFO - 2018-05-04 12:54:24 --> Helper loaded: common_helper
INFO - 2018-05-04 12:54:24 --> Database Driver Class Initialized
INFO - 2018-05-04 12:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 12:54:24 --> Email Class Initialized
INFO - 2018-05-04 12:54:24 --> Controller Class Initialized
INFO - 2018-05-04 12:54:24 --> Helper loaded: form_helper
INFO - 2018-05-04 12:54:24 --> Form Validation Class Initialized
INFO - 2018-05-04 12:54:24 --> Helper loaded: email_helper
DEBUG - 2018-05-04 12:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 12:54:24 --> Helper loaded: url_helper
INFO - 2018-05-04 12:54:24 --> Model Class Initialized
INFO - 2018-05-04 12:54:24 --> Model Class Initialized
INFO - 2018-05-04 12:54:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 12:54:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 12:54:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 12:54:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-04 12:54:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 12:54:24 --> Final output sent to browser
DEBUG - 2018-05-04 12:54:24 --> Total execution time: 0.2270
INFO - 2018-05-04 12:54:25 --> Config Class Initialized
INFO - 2018-05-04 12:54:25 --> Hooks Class Initialized
DEBUG - 2018-05-04 12:54:25 --> UTF-8 Support Enabled
INFO - 2018-05-04 12:54:25 --> Utf8 Class Initialized
INFO - 2018-05-04 12:54:25 --> URI Class Initialized
INFO - 2018-05-04 12:54:25 --> Router Class Initialized
INFO - 2018-05-04 12:54:25 --> Output Class Initialized
INFO - 2018-05-04 12:54:25 --> Security Class Initialized
DEBUG - 2018-05-04 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 12:54:25 --> Input Class Initialized
INFO - 2018-05-04 12:54:25 --> Language Class Initialized
INFO - 2018-05-04 12:54:25 --> Loader Class Initialized
INFO - 2018-05-04 12:54:25 --> Helper loaded: common_helper
INFO - 2018-05-04 12:54:25 --> Database Driver Class Initialized
INFO - 2018-05-04 12:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 12:54:25 --> Email Class Initialized
INFO - 2018-05-04 12:54:25 --> Controller Class Initialized
INFO - 2018-05-04 12:54:25 --> Helper loaded: form_helper
INFO - 2018-05-04 12:54:25 --> Form Validation Class Initialized
INFO - 2018-05-04 12:54:25 --> Helper loaded: email_helper
DEBUG - 2018-05-04 12:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 12:54:25 --> Helper loaded: url_helper
INFO - 2018-05-04 12:54:25 --> Model Class Initialized
INFO - 2018-05-04 12:54:25 --> Model Class Initialized
INFO - 2018-05-04 12:54:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 12:54:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 12:54:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 12:54:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/addPromotionBanner.php
INFO - 2018-05-04 12:54:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 12:54:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 12:54:25 --> Final output sent to browser
DEBUG - 2018-05-04 12:54:25 --> Total execution time: 0.1690
INFO - 2018-05-04 14:53:48 --> Config Class Initialized
INFO - 2018-05-04 14:53:48 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:53:48 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:53:48 --> Utf8 Class Initialized
INFO - 2018-05-04 14:53:48 --> URI Class Initialized
INFO - 2018-05-04 14:53:48 --> Router Class Initialized
INFO - 2018-05-04 14:53:48 --> Output Class Initialized
INFO - 2018-05-04 14:53:48 --> Security Class Initialized
DEBUG - 2018-05-04 14:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:53:48 --> Input Class Initialized
INFO - 2018-05-04 14:53:48 --> Language Class Initialized
INFO - 2018-05-04 14:53:48 --> Loader Class Initialized
INFO - 2018-05-04 14:53:48 --> Helper loaded: common_helper
INFO - 2018-05-04 14:53:48 --> Database Driver Class Initialized
INFO - 2018-05-04 14:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 14:53:48 --> Email Class Initialized
INFO - 2018-05-04 14:53:48 --> Controller Class Initialized
INFO - 2018-05-04 14:53:48 --> Helper loaded: form_helper
INFO - 2018-05-04 14:53:48 --> Form Validation Class Initialized
INFO - 2018-05-04 14:53:48 --> Helper loaded: email_helper
DEBUG - 2018-05-04 14:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-04 14:53:48 --> Helper loaded: url_helper
INFO - 2018-05-04 14:53:48 --> Model Class Initialized
INFO - 2018-05-04 14:53:48 --> Model Class Initialized
INFO - 2018-05-04 14:53:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-04 14:53:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-04 14:53:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-04 14:53:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\promotionBanners/promotionBanner.php
INFO - 2018-05-04 14:53:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-04 14:53:48 --> Final output sent to browser
DEBUG - 2018-05-04 14:53:48 --> Total execution time: 0.4030
