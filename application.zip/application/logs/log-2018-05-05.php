<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-05 12:18:51 --> Config Class Initialized
INFO - 2018-05-05 12:18:51 --> Hooks Class Initialized
DEBUG - 2018-05-05 12:18:51 --> UTF-8 Support Enabled
INFO - 2018-05-05 12:18:51 --> Utf8 Class Initialized
INFO - 2018-05-05 12:18:51 --> URI Class Initialized
INFO - 2018-05-05 12:18:51 --> Router Class Initialized
INFO - 2018-05-05 12:18:51 --> Output Class Initialized
INFO - 2018-05-05 12:18:51 --> Security Class Initialized
DEBUG - 2018-05-05 12:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 12:18:51 --> Input Class Initialized
INFO - 2018-05-05 12:18:51 --> Language Class Initialized
INFO - 2018-05-05 12:18:52 --> Loader Class Initialized
INFO - 2018-05-05 12:18:52 --> Helper loaded: common_helper
INFO - 2018-05-05 12:18:53 --> Database Driver Class Initialized
ERROR - 2018-05-05 12:18:53 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-05 12:18:53 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-05 12:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 12:18:54 --> Email Class Initialized
INFO - 2018-05-05 12:18:54 --> Controller Class Initialized
INFO - 2018-05-05 12:18:54 --> Helper loaded: form_helper
INFO - 2018-05-05 12:18:54 --> Form Validation Class Initialized
INFO - 2018-05-05 12:18:54 --> Helper loaded: email_helper
DEBUG - 2018-05-05 12:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 12:18:54 --> Helper loaded: url_helper
INFO - 2018-05-05 12:18:54 --> Model Class Initialized
INFO - 2018-05-05 12:18:54 --> Model Class Initialized
INFO - 2018-05-05 12:18:55 --> Config Class Initialized
INFO - 2018-05-05 12:18:55 --> Hooks Class Initialized
DEBUG - 2018-05-05 12:18:55 --> UTF-8 Support Enabled
INFO - 2018-05-05 12:18:55 --> Utf8 Class Initialized
INFO - 2018-05-05 12:18:55 --> URI Class Initialized
INFO - 2018-05-05 12:18:55 --> Router Class Initialized
INFO - 2018-05-05 12:18:55 --> Output Class Initialized
INFO - 2018-05-05 12:18:55 --> Security Class Initialized
DEBUG - 2018-05-05 12:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 12:18:55 --> Input Class Initialized
INFO - 2018-05-05 12:18:55 --> Language Class Initialized
INFO - 2018-05-05 12:18:55 --> Loader Class Initialized
INFO - 2018-05-05 12:18:55 --> Helper loaded: common_helper
INFO - 2018-05-05 12:18:55 --> Database Driver Class Initialized
ERROR - 2018-05-05 12:18:55 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-05 12:18:55 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-05 12:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 12:18:55 --> Email Class Initialized
INFO - 2018-05-05 12:18:55 --> Controller Class Initialized
INFO - 2018-05-05 12:18:55 --> Helper loaded: form_helper
INFO - 2018-05-05 12:18:55 --> Form Validation Class Initialized
INFO - 2018-05-05 12:18:55 --> Helper loaded: email_helper
DEBUG - 2018-05-05 12:18:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 12:18:55 --> Helper loaded: url_helper
INFO - 2018-05-05 12:18:55 --> Model Class Initialized
INFO - 2018-05-05 12:18:55 --> Model Class Initialized
INFO - 2018-05-05 12:18:55 --> Config Class Initialized
INFO - 2018-05-05 12:18:55 --> Hooks Class Initialized
DEBUG - 2018-05-05 12:18:55 --> UTF-8 Support Enabled
INFO - 2018-05-05 12:18:55 --> Utf8 Class Initialized
INFO - 2018-05-05 12:18:55 --> URI Class Initialized
DEBUG - 2018-05-05 12:18:55 --> No URI present. Default controller set.
INFO - 2018-05-05 12:18:55 --> Router Class Initialized
INFO - 2018-05-05 12:18:55 --> Output Class Initialized
INFO - 2018-05-05 12:18:55 --> Security Class Initialized
DEBUG - 2018-05-05 12:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 12:18:55 --> Input Class Initialized
INFO - 2018-05-05 12:18:55 --> Language Class Initialized
INFO - 2018-05-05 12:18:55 --> Loader Class Initialized
INFO - 2018-05-05 12:18:55 --> Helper loaded: common_helper
INFO - 2018-05-05 12:18:55 --> Database Driver Class Initialized
INFO - 2018-05-05 12:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 12:18:55 --> Email Class Initialized
INFO - 2018-05-05 12:18:55 --> Controller Class Initialized
INFO - 2018-05-05 12:18:55 --> Helper loaded: form_helper
INFO - 2018-05-05 12:18:55 --> Form Validation Class Initialized
INFO - 2018-05-05 12:18:55 --> Helper loaded: email_helper
DEBUG - 2018-05-05 12:18:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 12:18:55 --> Helper loaded: url_helper
INFO - 2018-05-05 12:18:55 --> Model Class Initialized
INFO - 2018-05-05 12:18:55 --> Model Class Initialized
INFO - 2018-05-05 12:18:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\index.php
INFO - 2018-05-05 12:18:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 12:18:55 --> Final output sent to browser
DEBUG - 2018-05-05 12:18:55 --> Total execution time: 0.1875
INFO - 2018-05-05 19:57:53 --> Config Class Initialized
INFO - 2018-05-05 19:57:53 --> Hooks Class Initialized
DEBUG - 2018-05-05 19:57:53 --> UTF-8 Support Enabled
INFO - 2018-05-05 19:57:53 --> Utf8 Class Initialized
INFO - 2018-05-05 19:57:53 --> URI Class Initialized
DEBUG - 2018-05-05 19:57:53 --> No URI present. Default controller set.
INFO - 2018-05-05 19:57:53 --> Router Class Initialized
INFO - 2018-05-05 19:57:53 --> Output Class Initialized
INFO - 2018-05-05 19:57:53 --> Security Class Initialized
DEBUG - 2018-05-05 19:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 19:57:53 --> Input Class Initialized
INFO - 2018-05-05 19:57:53 --> Language Class Initialized
INFO - 2018-05-05 19:57:53 --> Loader Class Initialized
INFO - 2018-05-05 19:57:53 --> Helper loaded: common_helper
INFO - 2018-05-05 19:57:53 --> Database Driver Class Initialized
ERROR - 2018-05-05 19:57:53 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-05 19:57:53 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-05 19:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 19:57:54 --> Email Class Initialized
INFO - 2018-05-05 19:57:54 --> Controller Class Initialized
INFO - 2018-05-05 19:57:54 --> Helper loaded: form_helper
INFO - 2018-05-05 19:57:54 --> Form Validation Class Initialized
INFO - 2018-05-05 19:57:54 --> Helper loaded: email_helper
DEBUG - 2018-05-05 19:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:57:54 --> Helper loaded: url_helper
INFO - 2018-05-05 19:57:54 --> Model Class Initialized
INFO - 2018-05-05 19:57:54 --> Model Class Initialized
DEBUG - 2018-05-05 19:57:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:57:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-05 19:57:54 --> Config Class Initialized
INFO - 2018-05-05 19:57:54 --> Hooks Class Initialized
DEBUG - 2018-05-05 19:57:54 --> UTF-8 Support Enabled
INFO - 2018-05-05 19:57:54 --> Utf8 Class Initialized
INFO - 2018-05-05 19:57:54 --> URI Class Initialized
INFO - 2018-05-05 19:57:54 --> Router Class Initialized
INFO - 2018-05-05 19:57:54 --> Output Class Initialized
INFO - 2018-05-05 19:57:54 --> Security Class Initialized
DEBUG - 2018-05-05 19:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 19:57:54 --> Input Class Initialized
INFO - 2018-05-05 19:57:54 --> Language Class Initialized
INFO - 2018-05-05 19:57:54 --> Loader Class Initialized
INFO - 2018-05-05 19:57:54 --> Helper loaded: common_helper
INFO - 2018-05-05 19:57:54 --> Database Driver Class Initialized
INFO - 2018-05-05 19:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 19:57:54 --> Email Class Initialized
INFO - 2018-05-05 19:57:54 --> Controller Class Initialized
INFO - 2018-05-05 19:57:54 --> Helper loaded: form_helper
INFO - 2018-05-05 19:57:54 --> Form Validation Class Initialized
INFO - 2018-05-05 19:57:54 --> Helper loaded: email_helper
DEBUG - 2018-05-05 19:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:57:54 --> Helper loaded: url_helper
INFO - 2018-05-05 19:57:54 --> Model Class Initialized
INFO - 2018-05-05 19:57:54 --> Model Class Initialized
INFO - 2018-05-05 19:57:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 19:57:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
ERROR - 2018-05-05 19:57:54 --> Undefined variable: categories
ERROR - 2018-05-05 19:57:54 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-05 19:57:54 --> Trying to get property of non-object
ERROR - 2018-05-05 19:57:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-05 19:57:54 --> Undefined variable: articles
ERROR - 2018-05-05 19:57:54 --> Severity: Notice --> Undefined variable: articles C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-05 19:57:54 --> Trying to get property of non-object
ERROR - 2018-05-05 19:57:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-05 19:57:54 --> Undefined variable: subscriptions
ERROR - 2018-05-05 19:57:54 --> Severity: Notice --> Undefined variable: subscriptions C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
ERROR - 2018-05-05 19:57:54 --> Trying to get property of non-object
ERROR - 2018-05-05 19:57:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
INFO - 2018-05-05 19:57:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php
INFO - 2018-05-05 19:57:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 19:57:54 --> Final output sent to browser
DEBUG - 2018-05-05 19:57:54 --> Total execution time: 0.1600
INFO - 2018-05-05 19:57:59 --> Config Class Initialized
INFO - 2018-05-05 19:57:59 --> Hooks Class Initialized
DEBUG - 2018-05-05 19:57:59 --> UTF-8 Support Enabled
INFO - 2018-05-05 19:57:59 --> Utf8 Class Initialized
INFO - 2018-05-05 19:57:59 --> URI Class Initialized
INFO - 2018-05-05 19:57:59 --> Router Class Initialized
INFO - 2018-05-05 19:57:59 --> Output Class Initialized
INFO - 2018-05-05 19:57:59 --> Security Class Initialized
DEBUG - 2018-05-05 19:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 19:57:59 --> Input Class Initialized
INFO - 2018-05-05 19:57:59 --> Language Class Initialized
INFO - 2018-05-05 19:57:59 --> Loader Class Initialized
INFO - 2018-05-05 19:57:59 --> Helper loaded: common_helper
INFO - 2018-05-05 19:57:59 --> Database Driver Class Initialized
INFO - 2018-05-05 19:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 19:57:59 --> Email Class Initialized
INFO - 2018-05-05 19:57:59 --> Controller Class Initialized
INFO - 2018-05-05 19:57:59 --> Helper loaded: form_helper
INFO - 2018-05-05 19:57:59 --> Form Validation Class Initialized
INFO - 2018-05-05 19:57:59 --> Helper loaded: email_helper
DEBUG - 2018-05-05 19:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:57:59 --> Helper loaded: url_helper
INFO - 2018-05-05 19:57:59 --> Model Class Initialized
INFO - 2018-05-05 19:57:59 --> Model Class Initialized
INFO - 2018-05-05 19:57:59 --> Model Class Initialized
INFO - 2018-05-05 19:57:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 19:57:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 19:57:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 19:57:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-05 19:57:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 19:57:59 --> Final output sent to browser
DEBUG - 2018-05-05 19:57:59 --> Total execution time: 0.1440
INFO - 2018-05-05 19:58:02 --> Config Class Initialized
INFO - 2018-05-05 19:58:02 --> Hooks Class Initialized
DEBUG - 2018-05-05 19:58:02 --> UTF-8 Support Enabled
INFO - 2018-05-05 19:58:02 --> Utf8 Class Initialized
INFO - 2018-05-05 19:58:02 --> URI Class Initialized
INFO - 2018-05-05 19:58:02 --> Router Class Initialized
INFO - 2018-05-05 19:58:02 --> Output Class Initialized
INFO - 2018-05-05 19:58:02 --> Security Class Initialized
DEBUG - 2018-05-05 19:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 19:58:02 --> Input Class Initialized
INFO - 2018-05-05 19:58:02 --> Language Class Initialized
INFO - 2018-05-05 19:58:02 --> Loader Class Initialized
INFO - 2018-05-05 19:58:02 --> Helper loaded: common_helper
INFO - 2018-05-05 19:58:02 --> Database Driver Class Initialized
ERROR - 2018-05-05 19:58:02 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-05 19:58:02 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-05 19:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 19:58:02 --> Email Class Initialized
INFO - 2018-05-05 19:58:02 --> Controller Class Initialized
INFO - 2018-05-05 19:58:02 --> Helper loaded: form_helper
INFO - 2018-05-05 19:58:02 --> Form Validation Class Initialized
INFO - 2018-05-05 19:58:02 --> Helper loaded: email_helper
DEBUG - 2018-05-05 19:58:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:58:02 --> Helper loaded: url_helper
INFO - 2018-05-05 19:58:02 --> Model Class Initialized
INFO - 2018-05-05 19:58:02 --> Model Class Initialized
INFO - 2018-05-05 19:58:02 --> Model Class Initialized
INFO - 2018-05-05 19:58:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 19:58:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 19:58:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 19:58:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 19:58:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 19:58:02 --> Final output sent to browser
DEBUG - 2018-05-05 19:58:02 --> Total execution time: 0.1860
INFO - 2018-05-05 19:58:03 --> Config Class Initialized
INFO - 2018-05-05 19:58:03 --> Hooks Class Initialized
DEBUG - 2018-05-05 19:58:03 --> UTF-8 Support Enabled
INFO - 2018-05-05 19:58:03 --> Utf8 Class Initialized
INFO - 2018-05-05 19:58:03 --> URI Class Initialized
INFO - 2018-05-05 19:58:03 --> Router Class Initialized
INFO - 2018-05-05 19:58:03 --> Output Class Initialized
INFO - 2018-05-05 19:58:03 --> Security Class Initialized
DEBUG - 2018-05-05 19:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 19:58:03 --> Input Class Initialized
INFO - 2018-05-05 19:58:03 --> Language Class Initialized
INFO - 2018-05-05 19:58:03 --> Loader Class Initialized
INFO - 2018-05-05 19:58:03 --> Helper loaded: common_helper
INFO - 2018-05-05 19:58:03 --> Database Driver Class Initialized
INFO - 2018-05-05 19:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 19:58:03 --> Email Class Initialized
INFO - 2018-05-05 19:58:03 --> Controller Class Initialized
INFO - 2018-05-05 19:58:03 --> Helper loaded: form_helper
INFO - 2018-05-05 19:58:03 --> Form Validation Class Initialized
INFO - 2018-05-05 19:58:03 --> Helper loaded: email_helper
DEBUG - 2018-05-05 19:58:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:58:03 --> Helper loaded: url_helper
INFO - 2018-05-05 19:58:03 --> Model Class Initialized
INFO - 2018-05-05 19:58:03 --> Model Class Initialized
INFO - 2018-05-05 19:58:03 --> Model Class Initialized
INFO - 2018-05-05 19:58:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 19:58:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 19:58:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 19:58:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 19:58:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 19:58:03 --> Final output sent to browser
DEBUG - 2018-05-05 19:58:03 --> Total execution time: 0.1540
INFO - 2018-05-05 19:58:05 --> Config Class Initialized
INFO - 2018-05-05 19:58:05 --> Hooks Class Initialized
DEBUG - 2018-05-05 19:58:06 --> UTF-8 Support Enabled
INFO - 2018-05-05 19:58:06 --> Utf8 Class Initialized
INFO - 2018-05-05 19:58:06 --> URI Class Initialized
INFO - 2018-05-05 19:58:06 --> Router Class Initialized
INFO - 2018-05-05 19:58:06 --> Output Class Initialized
INFO - 2018-05-05 19:58:06 --> Security Class Initialized
DEBUG - 2018-05-05 19:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 19:58:06 --> Input Class Initialized
INFO - 2018-05-05 19:58:06 --> Language Class Initialized
INFO - 2018-05-05 19:58:06 --> Loader Class Initialized
INFO - 2018-05-05 19:58:06 --> Helper loaded: common_helper
INFO - 2018-05-05 19:58:06 --> Database Driver Class Initialized
ERROR - 2018-05-05 19:58:06 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-05 19:58:06 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-05 19:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 19:58:06 --> Email Class Initialized
INFO - 2018-05-05 19:58:06 --> Controller Class Initialized
INFO - 2018-05-05 19:58:06 --> Helper loaded: form_helper
INFO - 2018-05-05 19:58:06 --> Form Validation Class Initialized
INFO - 2018-05-05 19:58:06 --> Helper loaded: email_helper
DEBUG - 2018-05-05 19:58:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:58:06 --> Helper loaded: url_helper
INFO - 2018-05-05 19:58:06 --> Model Class Initialized
INFO - 2018-05-05 19:58:06 --> Model Class Initialized
INFO - 2018-05-05 19:58:06 --> Model Class Initialized
INFO - 2018-05-05 19:58:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 19:58:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 19:58:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 19:58:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 19:58:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 19:58:06 --> Final output sent to browser
DEBUG - 2018-05-05 19:58:06 --> Total execution time: 0.2430
INFO - 2018-05-05 19:58:06 --> Config Class Initialized
INFO - 2018-05-05 19:58:06 --> Hooks Class Initialized
DEBUG - 2018-05-05 19:58:06 --> UTF-8 Support Enabled
INFO - 2018-05-05 19:58:06 --> Utf8 Class Initialized
INFO - 2018-05-05 19:58:06 --> URI Class Initialized
INFO - 2018-05-05 19:58:06 --> Router Class Initialized
INFO - 2018-05-05 19:58:06 --> Output Class Initialized
INFO - 2018-05-05 19:58:06 --> Security Class Initialized
DEBUG - 2018-05-05 19:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 19:58:06 --> Input Class Initialized
INFO - 2018-05-05 19:58:06 --> Language Class Initialized
INFO - 2018-05-05 19:58:06 --> Loader Class Initialized
INFO - 2018-05-05 19:58:06 --> Helper loaded: common_helper
INFO - 2018-05-05 19:58:06 --> Database Driver Class Initialized
INFO - 2018-05-05 19:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 19:58:06 --> Email Class Initialized
INFO - 2018-05-05 19:58:06 --> Controller Class Initialized
INFO - 2018-05-05 19:58:06 --> Helper loaded: form_helper
INFO - 2018-05-05 19:58:06 --> Form Validation Class Initialized
INFO - 2018-05-05 19:58:06 --> Helper loaded: email_helper
DEBUG - 2018-05-05 19:58:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:58:06 --> Helper loaded: url_helper
INFO - 2018-05-05 19:58:06 --> Model Class Initialized
INFO - 2018-05-05 19:58:06 --> Model Class Initialized
INFO - 2018-05-05 19:58:06 --> Model Class Initialized
INFO - 2018-05-05 19:58:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 19:58:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 19:58:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 19:58:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 19:58:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 19:58:06 --> Final output sent to browser
DEBUG - 2018-05-05 19:58:06 --> Total execution time: 0.1670
INFO - 2018-05-05 19:58:08 --> Config Class Initialized
INFO - 2018-05-05 19:58:08 --> Hooks Class Initialized
DEBUG - 2018-05-05 19:58:08 --> UTF-8 Support Enabled
INFO - 2018-05-05 19:58:08 --> Utf8 Class Initialized
INFO - 2018-05-05 19:58:08 --> URI Class Initialized
INFO - 2018-05-05 19:58:08 --> Router Class Initialized
INFO - 2018-05-05 19:58:08 --> Output Class Initialized
INFO - 2018-05-05 19:58:08 --> Security Class Initialized
DEBUG - 2018-05-05 19:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 19:58:08 --> Input Class Initialized
INFO - 2018-05-05 19:58:08 --> Language Class Initialized
INFO - 2018-05-05 19:58:08 --> Loader Class Initialized
INFO - 2018-05-05 19:58:08 --> Helper loaded: common_helper
INFO - 2018-05-05 19:58:08 --> Database Driver Class Initialized
INFO - 2018-05-05 19:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 19:58:08 --> Email Class Initialized
INFO - 2018-05-05 19:58:08 --> Controller Class Initialized
INFO - 2018-05-05 19:58:08 --> Helper loaded: form_helper
INFO - 2018-05-05 19:58:08 --> Form Validation Class Initialized
INFO - 2018-05-05 19:58:08 --> Helper loaded: email_helper
DEBUG - 2018-05-05 19:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:58:08 --> Helper loaded: url_helper
INFO - 2018-05-05 19:58:08 --> Model Class Initialized
INFO - 2018-05-05 19:58:08 --> Model Class Initialized
INFO - 2018-05-05 19:58:08 --> Model Class Initialized
INFO - 2018-05-05 19:58:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 19:58:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 19:58:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 19:58:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 19:58:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 19:58:08 --> Final output sent to browser
DEBUG - 2018-05-05 19:58:08 --> Total execution time: 0.1370
INFO - 2018-05-05 19:58:10 --> Config Class Initialized
INFO - 2018-05-05 19:58:10 --> Hooks Class Initialized
DEBUG - 2018-05-05 19:58:10 --> UTF-8 Support Enabled
INFO - 2018-05-05 19:58:10 --> Utf8 Class Initialized
INFO - 2018-05-05 19:58:10 --> URI Class Initialized
INFO - 2018-05-05 19:58:10 --> Router Class Initialized
INFO - 2018-05-05 19:58:10 --> Output Class Initialized
INFO - 2018-05-05 19:58:10 --> Security Class Initialized
DEBUG - 2018-05-05 19:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 19:58:10 --> Input Class Initialized
INFO - 2018-05-05 19:58:10 --> Language Class Initialized
INFO - 2018-05-05 19:58:10 --> Loader Class Initialized
INFO - 2018-05-05 19:58:10 --> Helper loaded: common_helper
INFO - 2018-05-05 19:58:10 --> Database Driver Class Initialized
INFO - 2018-05-05 19:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 19:58:10 --> Email Class Initialized
INFO - 2018-05-05 19:58:10 --> Controller Class Initialized
INFO - 2018-05-05 19:58:10 --> Helper loaded: form_helper
INFO - 2018-05-05 19:58:10 --> Form Validation Class Initialized
INFO - 2018-05-05 19:58:10 --> Helper loaded: email_helper
DEBUG - 2018-05-05 19:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:58:10 --> Helper loaded: url_helper
INFO - 2018-05-05 19:58:10 --> Model Class Initialized
INFO - 2018-05-05 19:58:10 --> Model Class Initialized
INFO - 2018-05-05 19:58:10 --> Model Class Initialized
INFO - 2018-05-05 19:58:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 19:58:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 19:58:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 19:58:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-05 19:58:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 19:58:10 --> Final output sent to browser
DEBUG - 2018-05-05 19:58:10 --> Total execution time: 0.1840
INFO - 2018-05-05 19:58:13 --> Config Class Initialized
INFO - 2018-05-05 19:58:13 --> Hooks Class Initialized
DEBUG - 2018-05-05 19:58:13 --> UTF-8 Support Enabled
INFO - 2018-05-05 19:58:13 --> Utf8 Class Initialized
INFO - 2018-05-05 19:58:13 --> URI Class Initialized
INFO - 2018-05-05 19:58:13 --> Router Class Initialized
INFO - 2018-05-05 19:58:13 --> Output Class Initialized
INFO - 2018-05-05 19:58:13 --> Security Class Initialized
DEBUG - 2018-05-05 19:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 19:58:13 --> Input Class Initialized
INFO - 2018-05-05 19:58:13 --> Language Class Initialized
INFO - 2018-05-05 19:58:13 --> Loader Class Initialized
INFO - 2018-05-05 19:58:13 --> Helper loaded: common_helper
INFO - 2018-05-05 19:58:13 --> Database Driver Class Initialized
INFO - 2018-05-05 19:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 19:58:13 --> Email Class Initialized
INFO - 2018-05-05 19:58:13 --> Controller Class Initialized
INFO - 2018-05-05 19:58:13 --> Helper loaded: form_helper
INFO - 2018-05-05 19:58:13 --> Form Validation Class Initialized
INFO - 2018-05-05 19:58:13 --> Helper loaded: email_helper
DEBUG - 2018-05-05 19:58:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:58:13 --> Helper loaded: url_helper
INFO - 2018-05-05 19:58:13 --> Model Class Initialized
INFO - 2018-05-05 19:58:13 --> Model Class Initialized
INFO - 2018-05-05 19:58:13 --> Model Class Initialized
INFO - 2018-05-05 19:58:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 19:58:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 19:58:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 19:58:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 19:58:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 19:58:13 --> Final output sent to browser
DEBUG - 2018-05-05 19:58:13 --> Total execution time: 0.1920
INFO - 2018-05-05 19:58:53 --> Config Class Initialized
INFO - 2018-05-05 19:58:53 --> Hooks Class Initialized
DEBUG - 2018-05-05 19:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-05 19:58:53 --> Utf8 Class Initialized
INFO - 2018-05-05 19:58:53 --> URI Class Initialized
INFO - 2018-05-05 19:58:53 --> Router Class Initialized
INFO - 2018-05-05 19:58:53 --> Output Class Initialized
INFO - 2018-05-05 19:58:53 --> Security Class Initialized
DEBUG - 2018-05-05 19:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 19:58:53 --> Input Class Initialized
INFO - 2018-05-05 19:58:53 --> Language Class Initialized
INFO - 2018-05-05 19:58:53 --> Loader Class Initialized
INFO - 2018-05-05 19:58:53 --> Helper loaded: common_helper
INFO - 2018-05-05 19:58:53 --> Database Driver Class Initialized
ERROR - 2018-05-05 19:58:53 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-05 19:58:53 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-05 19:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 19:58:53 --> Email Class Initialized
INFO - 2018-05-05 19:58:53 --> Controller Class Initialized
INFO - 2018-05-05 19:58:53 --> Helper loaded: form_helper
INFO - 2018-05-05 19:58:53 --> Form Validation Class Initialized
INFO - 2018-05-05 19:58:53 --> Helper loaded: email_helper
DEBUG - 2018-05-05 19:58:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:58:53 --> Helper loaded: url_helper
INFO - 2018-05-05 19:58:53 --> Model Class Initialized
INFO - 2018-05-05 19:58:53 --> Model Class Initialized
INFO - 2018-05-05 19:58:53 --> Model Class Initialized
INFO - 2018-05-05 19:58:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 19:58:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 19:58:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 19:58:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 19:58:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 19:58:53 --> Final output sent to browser
DEBUG - 2018-05-05 19:58:53 --> Total execution time: 0.4420
INFO - 2018-05-05 19:58:53 --> Config Class Initialized
INFO - 2018-05-05 19:58:53 --> Hooks Class Initialized
DEBUG - 2018-05-05 19:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-05 19:58:53 --> Utf8 Class Initialized
INFO - 2018-05-05 19:58:53 --> URI Class Initialized
INFO - 2018-05-05 19:58:53 --> Router Class Initialized
INFO - 2018-05-05 19:58:53 --> Output Class Initialized
INFO - 2018-05-05 19:58:53 --> Security Class Initialized
DEBUG - 2018-05-05 19:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 19:58:53 --> Input Class Initialized
INFO - 2018-05-05 19:58:53 --> Language Class Initialized
INFO - 2018-05-05 19:58:53 --> Loader Class Initialized
INFO - 2018-05-05 19:58:53 --> Helper loaded: common_helper
INFO - 2018-05-05 19:58:53 --> Database Driver Class Initialized
INFO - 2018-05-05 19:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 19:58:53 --> Email Class Initialized
INFO - 2018-05-05 19:58:53 --> Controller Class Initialized
INFO - 2018-05-05 19:58:53 --> Helper loaded: form_helper
INFO - 2018-05-05 19:58:53 --> Form Validation Class Initialized
INFO - 2018-05-05 19:58:53 --> Helper loaded: email_helper
DEBUG - 2018-05-05 19:58:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 19:58:53 --> Helper loaded: url_helper
INFO - 2018-05-05 19:58:53 --> Model Class Initialized
INFO - 2018-05-05 19:58:53 --> Model Class Initialized
INFO - 2018-05-05 19:58:53 --> Model Class Initialized
INFO - 2018-05-05 19:58:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 19:58:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 19:58:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 19:58:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 19:58:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 19:58:53 --> Final output sent to browser
DEBUG - 2018-05-05 19:58:54 --> Total execution time: 0.1650
INFO - 2018-05-05 20:04:27 --> Config Class Initialized
INFO - 2018-05-05 20:04:27 --> Hooks Class Initialized
DEBUG - 2018-05-05 20:04:27 --> UTF-8 Support Enabled
INFO - 2018-05-05 20:04:27 --> Utf8 Class Initialized
INFO - 2018-05-05 20:04:27 --> URI Class Initialized
INFO - 2018-05-05 20:04:27 --> Router Class Initialized
INFO - 2018-05-05 20:04:27 --> Output Class Initialized
INFO - 2018-05-05 20:04:27 --> Security Class Initialized
DEBUG - 2018-05-05 20:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 20:04:27 --> Input Class Initialized
INFO - 2018-05-05 20:04:27 --> Language Class Initialized
INFO - 2018-05-05 20:04:27 --> Loader Class Initialized
INFO - 2018-05-05 20:04:27 --> Helper loaded: common_helper
INFO - 2018-05-05 20:04:27 --> Database Driver Class Initialized
INFO - 2018-05-05 20:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 20:04:27 --> Email Class Initialized
INFO - 2018-05-05 20:04:27 --> Controller Class Initialized
INFO - 2018-05-05 20:04:27 --> Helper loaded: form_helper
INFO - 2018-05-05 20:04:27 --> Form Validation Class Initialized
INFO - 2018-05-05 20:04:27 --> Helper loaded: email_helper
DEBUG - 2018-05-05 20:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 20:04:27 --> Helper loaded: url_helper
INFO - 2018-05-05 20:04:27 --> Model Class Initialized
INFO - 2018-05-05 20:04:27 --> Model Class Initialized
INFO - 2018-05-05 20:04:27 --> Model Class Initialized
INFO - 2018-05-05 20:04:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 20:04:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 20:04:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 20:04:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 20:04:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 20:04:27 --> Final output sent to browser
DEBUG - 2018-05-05 20:04:27 --> Total execution time: 0.1790
INFO - 2018-05-05 20:04:29 --> Config Class Initialized
INFO - 2018-05-05 20:04:29 --> Hooks Class Initialized
DEBUG - 2018-05-05 20:04:29 --> UTF-8 Support Enabled
INFO - 2018-05-05 20:04:29 --> Utf8 Class Initialized
INFO - 2018-05-05 20:04:29 --> URI Class Initialized
INFO - 2018-05-05 20:04:29 --> Router Class Initialized
INFO - 2018-05-05 20:04:29 --> Output Class Initialized
INFO - 2018-05-05 20:04:29 --> Security Class Initialized
DEBUG - 2018-05-05 20:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 20:04:29 --> Input Class Initialized
INFO - 2018-05-05 20:04:29 --> Language Class Initialized
INFO - 2018-05-05 20:04:29 --> Loader Class Initialized
INFO - 2018-05-05 20:04:29 --> Helper loaded: common_helper
INFO - 2018-05-05 20:04:29 --> Database Driver Class Initialized
INFO - 2018-05-05 20:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 20:04:29 --> Email Class Initialized
INFO - 2018-05-05 20:04:29 --> Controller Class Initialized
INFO - 2018-05-05 20:04:29 --> Helper loaded: form_helper
INFO - 2018-05-05 20:04:29 --> Form Validation Class Initialized
INFO - 2018-05-05 20:04:29 --> Helper loaded: email_helper
DEBUG - 2018-05-05 20:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 20:04:29 --> Helper loaded: url_helper
INFO - 2018-05-05 20:04:29 --> Model Class Initialized
INFO - 2018-05-05 20:04:29 --> Model Class Initialized
INFO - 2018-05-05 20:04:29 --> Model Class Initialized
INFO - 2018-05-05 20:04:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 20:04:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 20:04:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 20:04:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 20:04:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addMovie.php
INFO - 2018-05-05 20:04:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 20:04:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 20:04:29 --> Final output sent to browser
DEBUG - 2018-05-05 20:04:29 --> Total execution time: 0.1520
INFO - 2018-05-05 20:55:07 --> Config Class Initialized
INFO - 2018-05-05 20:55:07 --> Hooks Class Initialized
DEBUG - 2018-05-05 20:55:07 --> UTF-8 Support Enabled
INFO - 2018-05-05 20:55:07 --> Utf8 Class Initialized
INFO - 2018-05-05 20:55:07 --> URI Class Initialized
INFO - 2018-05-05 20:55:07 --> Router Class Initialized
INFO - 2018-05-05 20:55:07 --> Output Class Initialized
INFO - 2018-05-05 20:55:07 --> Security Class Initialized
DEBUG - 2018-05-05 20:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 20:55:07 --> Input Class Initialized
INFO - 2018-05-05 20:55:07 --> Language Class Initialized
ERROR - 2018-05-05 20:55:07 --> syntax error, unexpected ';'
ERROR - 2018-05-05 20:55:07 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 33
INFO - 2018-05-05 20:55:16 --> Config Class Initialized
INFO - 2018-05-05 20:55:16 --> Hooks Class Initialized
DEBUG - 2018-05-05 20:55:16 --> UTF-8 Support Enabled
INFO - 2018-05-05 20:55:16 --> Utf8 Class Initialized
INFO - 2018-05-05 20:55:16 --> URI Class Initialized
INFO - 2018-05-05 20:55:16 --> Router Class Initialized
INFO - 2018-05-05 20:55:16 --> Output Class Initialized
INFO - 2018-05-05 20:55:16 --> Security Class Initialized
DEBUG - 2018-05-05 20:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 20:55:16 --> Input Class Initialized
INFO - 2018-05-05 20:55:16 --> Language Class Initialized
ERROR - 2018-05-05 20:55:17 --> syntax error, unexpected 'else' (T_ELSE)
ERROR - 2018-05-05 20:55:17 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 34
INFO - 2018-05-05 20:55:19 --> Config Class Initialized
INFO - 2018-05-05 20:55:19 --> Hooks Class Initialized
DEBUG - 2018-05-05 20:55:19 --> UTF-8 Support Enabled
INFO - 2018-05-05 20:55:19 --> Utf8 Class Initialized
INFO - 2018-05-05 20:55:19 --> URI Class Initialized
INFO - 2018-05-05 20:55:19 --> Router Class Initialized
INFO - 2018-05-05 20:55:19 --> Output Class Initialized
INFO - 2018-05-05 20:55:19 --> Security Class Initialized
DEBUG - 2018-05-05 20:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 20:55:19 --> Input Class Initialized
INFO - 2018-05-05 20:55:19 --> Language Class Initialized
ERROR - 2018-05-05 20:55:19 --> syntax error, unexpected 'else' (T_ELSE)
ERROR - 2018-05-05 20:55:19 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 34
INFO - 2018-05-05 20:55:39 --> Config Class Initialized
INFO - 2018-05-05 20:55:39 --> Hooks Class Initialized
DEBUG - 2018-05-05 20:55:39 --> UTF-8 Support Enabled
INFO - 2018-05-05 20:55:39 --> Utf8 Class Initialized
INFO - 2018-05-05 20:55:39 --> URI Class Initialized
INFO - 2018-05-05 20:55:39 --> Router Class Initialized
INFO - 2018-05-05 20:55:39 --> Output Class Initialized
INFO - 2018-05-05 20:55:39 --> Security Class Initialized
DEBUG - 2018-05-05 20:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 20:55:39 --> Input Class Initialized
INFO - 2018-05-05 20:55:39 --> Language Class Initialized
INFO - 2018-05-05 20:55:39 --> Loader Class Initialized
INFO - 2018-05-05 20:55:39 --> Helper loaded: common_helper
INFO - 2018-05-05 20:55:39 --> Database Driver Class Initialized
INFO - 2018-05-05 20:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 20:55:39 --> Email Class Initialized
INFO - 2018-05-05 20:55:39 --> Controller Class Initialized
INFO - 2018-05-05 20:55:39 --> Helper loaded: form_helper
INFO - 2018-05-05 20:55:39 --> Form Validation Class Initialized
INFO - 2018-05-05 20:55:39 --> Helper loaded: email_helper
DEBUG - 2018-05-05 20:55:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 20:55:39 --> Helper loaded: url_helper
INFO - 2018-05-05 20:55:39 --> Model Class Initialized
INFO - 2018-05-05 20:55:39 --> Model Class Initialized
INFO - 2018-05-05 20:55:39 --> Model Class Initialized
ERROR - 2018-05-05 20:55:39 --> Query error: Unknown column 'order' in 'where clause' - Invalid query: SELECT *
FROM `movies`
WHERE `isDeleted` =0
AND `celebrityId` = 1
AND `order` = 'ASEC'
ORDER BY `movie_id` DESC
ERROR - 2018-05-05 20:55:39 --> Call to a member function result() on boolean
ERROR - 2018-05-05 20:55:39 --> Severity: Error --> Call to a member function result() on boolean C:\xampp\htdocs\Celebrity\admin\application\core\Healthcontroller.php 75
INFO - 2018-05-05 20:55:41 --> Config Class Initialized
INFO - 2018-05-05 20:55:41 --> Hooks Class Initialized
DEBUG - 2018-05-05 20:55:41 --> UTF-8 Support Enabled
INFO - 2018-05-05 20:55:41 --> Utf8 Class Initialized
INFO - 2018-05-05 20:55:41 --> URI Class Initialized
INFO - 2018-05-05 20:55:41 --> Router Class Initialized
INFO - 2018-05-05 20:55:41 --> Output Class Initialized
INFO - 2018-05-05 20:55:41 --> Security Class Initialized
DEBUG - 2018-05-05 20:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 20:55:41 --> Input Class Initialized
INFO - 2018-05-05 20:55:41 --> Language Class Initialized
INFO - 2018-05-05 20:55:41 --> Loader Class Initialized
INFO - 2018-05-05 20:55:41 --> Helper loaded: common_helper
INFO - 2018-05-05 20:55:41 --> Database Driver Class Initialized
INFO - 2018-05-05 20:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 20:55:41 --> Email Class Initialized
INFO - 2018-05-05 20:55:41 --> Controller Class Initialized
INFO - 2018-05-05 20:55:41 --> Helper loaded: form_helper
INFO - 2018-05-05 20:55:41 --> Form Validation Class Initialized
INFO - 2018-05-05 20:55:41 --> Helper loaded: email_helper
DEBUG - 2018-05-05 20:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 20:55:41 --> Helper loaded: url_helper
INFO - 2018-05-05 20:55:41 --> Model Class Initialized
INFO - 2018-05-05 20:55:41 --> Model Class Initialized
INFO - 2018-05-05 20:55:41 --> Model Class Initialized
ERROR - 2018-05-05 20:55:41 --> Query error: Unknown column 'order' in 'where clause' - Invalid query: SELECT *
FROM `movies`
WHERE `isDeleted` =0
AND `celebrityId` = 1
AND `order` = 'ASEC'
ORDER BY `movie_id` DESC
ERROR - 2018-05-05 20:55:41 --> Call to a member function result() on boolean
ERROR - 2018-05-05 20:55:41 --> Severity: Error --> Call to a member function result() on boolean C:\xampp\htdocs\Celebrity\admin\application\core\Healthcontroller.php 75
INFO - 2018-05-05 20:56:00 --> Config Class Initialized
INFO - 2018-05-05 20:56:00 --> Hooks Class Initialized
DEBUG - 2018-05-05 20:56:00 --> UTF-8 Support Enabled
INFO - 2018-05-05 20:56:00 --> Utf8 Class Initialized
INFO - 2018-05-05 20:56:00 --> URI Class Initialized
INFO - 2018-05-05 20:56:00 --> Router Class Initialized
INFO - 2018-05-05 20:56:00 --> Output Class Initialized
INFO - 2018-05-05 20:56:00 --> Security Class Initialized
DEBUG - 2018-05-05 20:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 20:56:00 --> Input Class Initialized
INFO - 2018-05-05 20:56:00 --> Language Class Initialized
INFO - 2018-05-05 20:56:00 --> Loader Class Initialized
INFO - 2018-05-05 20:56:00 --> Helper loaded: common_helper
INFO - 2018-05-05 20:56:00 --> Database Driver Class Initialized
INFO - 2018-05-05 20:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 20:56:00 --> Email Class Initialized
INFO - 2018-05-05 20:56:00 --> Controller Class Initialized
INFO - 2018-05-05 20:56:00 --> Helper loaded: form_helper
INFO - 2018-05-05 20:56:00 --> Form Validation Class Initialized
INFO - 2018-05-05 20:56:00 --> Helper loaded: email_helper
DEBUG - 2018-05-05 20:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 20:56:00 --> Helper loaded: url_helper
INFO - 2018-05-05 20:56:00 --> Model Class Initialized
INFO - 2018-05-05 20:56:00 --> Model Class Initialized
INFO - 2018-05-05 20:56:00 --> Model Class Initialized
ERROR - 2018-05-05 20:56:00 --> Use of undefined constant ASEC - assumed 'ASEC'
ERROR - 2018-05-05 20:56:00 --> Severity: Notice --> Use of undefined constant ASEC - assumed 'ASEC' C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 33
ERROR - 2018-05-05 20:56:00 --> Query error: Unknown column 'order' in 'where clause' - Invalid query: SELECT *
FROM `movies`
WHERE `isDeleted` =0
AND `celebrityId` = 1
AND `order` = 'ASEC'
ORDER BY `movie_id` DESC
ERROR - 2018-05-05 20:56:00 --> Call to a member function result() on boolean
ERROR - 2018-05-05 20:56:00 --> Severity: Error --> Call to a member function result() on boolean C:\xampp\htdocs\Celebrity\admin\application\core\Healthcontroller.php 75
INFO - 2018-05-05 20:58:02 --> Config Class Initialized
INFO - 2018-05-05 20:58:02 --> Hooks Class Initialized
DEBUG - 2018-05-05 20:58:02 --> UTF-8 Support Enabled
INFO - 2018-05-05 20:58:02 --> Utf8 Class Initialized
INFO - 2018-05-05 20:58:02 --> URI Class Initialized
INFO - 2018-05-05 20:58:02 --> Router Class Initialized
INFO - 2018-05-05 20:58:02 --> Output Class Initialized
INFO - 2018-05-05 20:58:02 --> Security Class Initialized
DEBUG - 2018-05-05 20:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 20:58:02 --> Input Class Initialized
INFO - 2018-05-05 20:58:02 --> Language Class Initialized
INFO - 2018-05-05 20:58:02 --> Loader Class Initialized
INFO - 2018-05-05 20:58:02 --> Helper loaded: common_helper
INFO - 2018-05-05 20:58:02 --> Database Driver Class Initialized
ERROR - 2018-05-05 20:58:02 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-05 20:58:02 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-05 20:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 20:58:02 --> Email Class Initialized
INFO - 2018-05-05 20:58:02 --> Controller Class Initialized
INFO - 2018-05-05 20:58:02 --> Helper loaded: form_helper
INFO - 2018-05-05 20:58:02 --> Form Validation Class Initialized
INFO - 2018-05-05 20:58:02 --> Helper loaded: email_helper
DEBUG - 2018-05-05 20:58:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 20:58:02 --> Helper loaded: url_helper
INFO - 2018-05-05 20:58:02 --> Model Class Initialized
INFO - 2018-05-05 20:58:02 --> Model Class Initialized
INFO - 2018-05-05 20:58:02 --> Model Class Initialized
ERROR - 2018-05-05 20:58:02 --> Query error: Unknown column 'order_by' in 'where clause' - Invalid query: SELECT *
FROM `movies`
WHERE `isDeleted` =0
AND `celebrityId` = 1
AND `order_by` = 'ASEC'
ORDER BY `movie_id` DESC
ERROR - 2018-05-05 20:58:02 --> Call to a member function result() on boolean
ERROR - 2018-05-05 20:58:02 --> Severity: Error --> Call to a member function result() on boolean C:\xampp\htdocs\Celebrity\admin\application\core\Healthcontroller.php 75
INFO - 2018-05-05 20:58:04 --> Config Class Initialized
INFO - 2018-05-05 20:58:04 --> Hooks Class Initialized
DEBUG - 2018-05-05 20:58:04 --> UTF-8 Support Enabled
INFO - 2018-05-05 20:58:04 --> Utf8 Class Initialized
INFO - 2018-05-05 20:58:04 --> URI Class Initialized
INFO - 2018-05-05 20:58:04 --> Router Class Initialized
INFO - 2018-05-05 20:58:04 --> Output Class Initialized
INFO - 2018-05-05 20:58:04 --> Security Class Initialized
DEBUG - 2018-05-05 20:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 20:58:04 --> Input Class Initialized
INFO - 2018-05-05 20:58:04 --> Language Class Initialized
INFO - 2018-05-05 20:58:04 --> Loader Class Initialized
INFO - 2018-05-05 20:58:04 --> Helper loaded: common_helper
INFO - 2018-05-05 20:58:04 --> Database Driver Class Initialized
ERROR - 2018-05-05 20:58:05 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-05-05 20:58:05 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\Celebrity\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-05-05 20:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 20:58:05 --> Email Class Initialized
INFO - 2018-05-05 20:58:05 --> Controller Class Initialized
INFO - 2018-05-05 20:58:05 --> Helper loaded: form_helper
INFO - 2018-05-05 20:58:05 --> Form Validation Class Initialized
INFO - 2018-05-05 20:58:05 --> Helper loaded: email_helper
DEBUG - 2018-05-05 20:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 20:58:05 --> Helper loaded: url_helper
INFO - 2018-05-05 20:58:05 --> Model Class Initialized
INFO - 2018-05-05 20:58:05 --> Model Class Initialized
INFO - 2018-05-05 20:58:05 --> Model Class Initialized
ERROR - 2018-05-05 20:58:05 --> Query error: Unknown column 'order_by' in 'where clause' - Invalid query: SELECT *
FROM `movies`
WHERE `isDeleted` =0
AND `celebrityId` = 1
AND `order_by` = 'ASEC'
ORDER BY `movie_id` DESC
ERROR - 2018-05-05 20:58:05 --> Call to a member function result() on boolean
ERROR - 2018-05-05 20:58:05 --> Severity: Error --> Call to a member function result() on boolean C:\xampp\htdocs\Celebrity\admin\application\core\Healthcontroller.php 75
INFO - 2018-05-05 21:01:59 --> Config Class Initialized
INFO - 2018-05-05 21:01:59 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:01:59 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:01:59 --> Utf8 Class Initialized
INFO - 2018-05-05 21:01:59 --> URI Class Initialized
INFO - 2018-05-05 21:01:59 --> Router Class Initialized
INFO - 2018-05-05 21:01:59 --> Output Class Initialized
INFO - 2018-05-05 21:01:59 --> Security Class Initialized
DEBUG - 2018-05-05 21:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:01:59 --> Input Class Initialized
INFO - 2018-05-05 21:01:59 --> Language Class Initialized
ERROR - 2018-05-05 21:01:59 --> syntax error, unexpected ')'
ERROR - 2018-05-05 21:01:59 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 33
INFO - 2018-05-05 21:02:21 --> Config Class Initialized
INFO - 2018-05-05 21:02:21 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:02:21 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:02:21 --> Utf8 Class Initialized
INFO - 2018-05-05 21:02:21 --> URI Class Initialized
INFO - 2018-05-05 21:02:21 --> Router Class Initialized
INFO - 2018-05-05 21:02:21 --> Output Class Initialized
INFO - 2018-05-05 21:02:21 --> Security Class Initialized
DEBUG - 2018-05-05 21:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:02:21 --> Input Class Initialized
INFO - 2018-05-05 21:02:21 --> Language Class Initialized
INFO - 2018-05-05 21:02:21 --> Loader Class Initialized
INFO - 2018-05-05 21:02:21 --> Helper loaded: common_helper
INFO - 2018-05-05 21:02:21 --> Database Driver Class Initialized
INFO - 2018-05-05 21:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:02:21 --> Email Class Initialized
INFO - 2018-05-05 21:02:21 --> Controller Class Initialized
INFO - 2018-05-05 21:02:21 --> Helper loaded: form_helper
INFO - 2018-05-05 21:02:21 --> Form Validation Class Initialized
INFO - 2018-05-05 21:02:21 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:02:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:02:21 --> Helper loaded: url_helper
INFO - 2018-05-05 21:02:21 --> Model Class Initialized
INFO - 2018-05-05 21:02:21 --> Model Class Initialized
INFO - 2018-05-05 21:02:21 --> Model Class Initialized
INFO - 2018-05-05 21:02:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:02:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:02:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:02:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:02:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:02:21 --> Final output sent to browser
DEBUG - 2018-05-05 21:02:21 --> Total execution time: 0.1400
INFO - 2018-05-05 21:03:32 --> Config Class Initialized
INFO - 2018-05-05 21:03:32 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:03:32 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:03:32 --> Utf8 Class Initialized
INFO - 2018-05-05 21:03:32 --> URI Class Initialized
INFO - 2018-05-05 21:03:32 --> Router Class Initialized
INFO - 2018-05-05 21:03:32 --> Output Class Initialized
INFO - 2018-05-05 21:03:32 --> Security Class Initialized
DEBUG - 2018-05-05 21:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:03:32 --> Input Class Initialized
INFO - 2018-05-05 21:03:32 --> Language Class Initialized
INFO - 2018-05-05 21:03:32 --> Loader Class Initialized
INFO - 2018-05-05 21:03:32 --> Helper loaded: common_helper
INFO - 2018-05-05 21:03:32 --> Database Driver Class Initialized
INFO - 2018-05-05 21:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:03:32 --> Email Class Initialized
INFO - 2018-05-05 21:03:32 --> Controller Class Initialized
INFO - 2018-05-05 21:03:32 --> Helper loaded: form_helper
INFO - 2018-05-05 21:03:32 --> Form Validation Class Initialized
INFO - 2018-05-05 21:03:32 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:03:32 --> Helper loaded: url_helper
INFO - 2018-05-05 21:03:32 --> Model Class Initialized
INFO - 2018-05-05 21:03:32 --> Model Class Initialized
INFO - 2018-05-05 21:03:32 --> Model Class Initialized
INFO - 2018-05-05 21:03:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:03:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:03:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:03:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:03:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:03:32 --> Final output sent to browser
DEBUG - 2018-05-05 21:03:32 --> Total execution time: 0.2370
INFO - 2018-05-05 21:04:58 --> Config Class Initialized
INFO - 2018-05-05 21:04:58 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:04:58 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:04:58 --> Utf8 Class Initialized
INFO - 2018-05-05 21:04:58 --> URI Class Initialized
INFO - 2018-05-05 21:04:58 --> Router Class Initialized
INFO - 2018-05-05 21:04:58 --> Output Class Initialized
INFO - 2018-05-05 21:04:58 --> Security Class Initialized
DEBUG - 2018-05-05 21:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:04:58 --> Input Class Initialized
INFO - 2018-05-05 21:04:58 --> Language Class Initialized
ERROR - 2018-05-05 21:04:58 --> syntax error, unexpected '=>' (T_DOUBLE_ARROW)
ERROR - 2018-05-05 21:04:58 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 38
INFO - 2018-05-05 21:05:21 --> Config Class Initialized
INFO - 2018-05-05 21:05:21 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:05:21 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:05:21 --> Utf8 Class Initialized
INFO - 2018-05-05 21:05:21 --> URI Class Initialized
INFO - 2018-05-05 21:05:21 --> Router Class Initialized
INFO - 2018-05-05 21:05:21 --> Output Class Initialized
INFO - 2018-05-05 21:05:21 --> Security Class Initialized
DEBUG - 2018-05-05 21:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:05:21 --> Input Class Initialized
INFO - 2018-05-05 21:05:21 --> Language Class Initialized
ERROR - 2018-05-05 21:05:21 --> syntax error, unexpected '=>' (T_DOUBLE_ARROW)
ERROR - 2018-05-05 21:05:21 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\Celebrity\admin\application\controllers\Movie.php 38
INFO - 2018-05-05 21:05:42 --> Config Class Initialized
INFO - 2018-05-05 21:05:42 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:05:42 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:05:42 --> Utf8 Class Initialized
INFO - 2018-05-05 21:05:42 --> URI Class Initialized
INFO - 2018-05-05 21:05:42 --> Router Class Initialized
INFO - 2018-05-05 21:05:42 --> Output Class Initialized
INFO - 2018-05-05 21:05:42 --> Security Class Initialized
DEBUG - 2018-05-05 21:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:05:42 --> Input Class Initialized
INFO - 2018-05-05 21:05:42 --> Language Class Initialized
INFO - 2018-05-05 21:05:42 --> Loader Class Initialized
INFO - 2018-05-05 21:05:42 --> Helper loaded: common_helper
INFO - 2018-05-05 21:05:42 --> Database Driver Class Initialized
INFO - 2018-05-05 21:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:05:42 --> Email Class Initialized
INFO - 2018-05-05 21:05:42 --> Controller Class Initialized
INFO - 2018-05-05 21:05:42 --> Helper loaded: form_helper
INFO - 2018-05-05 21:05:42 --> Form Validation Class Initialized
INFO - 2018-05-05 21:05:42 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:05:42 --> Helper loaded: url_helper
INFO - 2018-05-05 21:05:42 --> Model Class Initialized
INFO - 2018-05-05 21:05:42 --> Model Class Initialized
INFO - 2018-05-05 21:05:42 --> Model Class Initialized
ERROR - 2018-05-05 21:05:42 --> explode() expects parameter 2 to be string, array given
ERROR - 2018-05-05 21:05:42 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\Celebrity\admin\system\database\DB_query_builder.php 1191
ERROR - 2018-05-05 21:05:42 --> Invalid argument supplied for foreach()
ERROR - 2018-05-05 21:05:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Celebrity\admin\system\database\DB_query_builder.php 1191
INFO - 2018-05-05 21:05:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:05:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:05:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:05:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:05:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:05:42 --> Final output sent to browser
DEBUG - 2018-05-05 21:05:42 --> Total execution time: 0.1990
INFO - 2018-05-05 21:05:42 --> Config Class Initialized
INFO - 2018-05-05 21:05:42 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:05:42 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:05:42 --> Utf8 Class Initialized
INFO - 2018-05-05 21:05:42 --> URI Class Initialized
INFO - 2018-05-05 21:05:42 --> Router Class Initialized
INFO - 2018-05-05 21:05:42 --> Output Class Initialized
INFO - 2018-05-05 21:05:42 --> Security Class Initialized
DEBUG - 2018-05-05 21:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:05:42 --> Input Class Initialized
INFO - 2018-05-05 21:05:42 --> Language Class Initialized
INFO - 2018-05-05 21:05:42 --> Loader Class Initialized
INFO - 2018-05-05 21:05:42 --> Helper loaded: common_helper
INFO - 2018-05-05 21:05:42 --> Database Driver Class Initialized
INFO - 2018-05-05 21:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:05:42 --> Email Class Initialized
INFO - 2018-05-05 21:05:42 --> Controller Class Initialized
INFO - 2018-05-05 21:05:42 --> Helper loaded: form_helper
INFO - 2018-05-05 21:05:42 --> Form Validation Class Initialized
INFO - 2018-05-05 21:05:42 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:05:42 --> Helper loaded: url_helper
INFO - 2018-05-05 21:05:42 --> Model Class Initialized
INFO - 2018-05-05 21:05:42 --> Model Class Initialized
INFO - 2018-05-05 21:05:42 --> Model Class Initialized
ERROR - 2018-05-05 21:05:42 --> explode() expects parameter 2 to be string, array given
ERROR - 2018-05-05 21:05:42 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\Celebrity\admin\system\database\DB_query_builder.php 1191
ERROR - 2018-05-05 21:05:42 --> Invalid argument supplied for foreach()
ERROR - 2018-05-05 21:05:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Celebrity\admin\system\database\DB_query_builder.php 1191
INFO - 2018-05-05 21:05:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:05:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:05:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:05:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:05:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:05:42 --> Final output sent to browser
DEBUG - 2018-05-05 21:05:42 --> Total execution time: 0.1530
INFO - 2018-05-05 21:14:27 --> Config Class Initialized
INFO - 2018-05-05 21:14:27 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:14:27 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:14:27 --> Utf8 Class Initialized
INFO - 2018-05-05 21:14:27 --> URI Class Initialized
INFO - 2018-05-05 21:14:27 --> Router Class Initialized
INFO - 2018-05-05 21:14:27 --> Output Class Initialized
INFO - 2018-05-05 21:14:27 --> Security Class Initialized
DEBUG - 2018-05-05 21:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:14:27 --> Input Class Initialized
INFO - 2018-05-05 21:14:27 --> Language Class Initialized
INFO - 2018-05-05 21:14:27 --> Loader Class Initialized
INFO - 2018-05-05 21:14:27 --> Helper loaded: common_helper
INFO - 2018-05-05 21:14:27 --> Database Driver Class Initialized
INFO - 2018-05-05 21:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:14:27 --> Email Class Initialized
INFO - 2018-05-05 21:14:27 --> Controller Class Initialized
INFO - 2018-05-05 21:14:27 --> Helper loaded: form_helper
INFO - 2018-05-05 21:14:27 --> Form Validation Class Initialized
INFO - 2018-05-05 21:14:27 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:14:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:14:27 --> Helper loaded: url_helper
INFO - 2018-05-05 21:14:27 --> Model Class Initialized
INFO - 2018-05-05 21:14:27 --> Model Class Initialized
INFO - 2018-05-05 21:14:27 --> Model Class Initialized
INFO - 2018-05-05 21:14:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:14:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:14:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:14:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:14:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:14:27 --> Final output sent to browser
DEBUG - 2018-05-05 21:14:27 --> Total execution time: 0.1640
INFO - 2018-05-05 21:14:33 --> Config Class Initialized
INFO - 2018-05-05 21:14:33 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:14:33 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:14:33 --> Utf8 Class Initialized
INFO - 2018-05-05 21:14:33 --> URI Class Initialized
INFO - 2018-05-05 21:14:33 --> Router Class Initialized
INFO - 2018-05-05 21:14:33 --> Output Class Initialized
INFO - 2018-05-05 21:14:33 --> Security Class Initialized
DEBUG - 2018-05-05 21:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:14:33 --> Input Class Initialized
INFO - 2018-05-05 21:14:33 --> Language Class Initialized
INFO - 2018-05-05 21:14:33 --> Loader Class Initialized
INFO - 2018-05-05 21:14:33 --> Helper loaded: common_helper
INFO - 2018-05-05 21:14:33 --> Database Driver Class Initialized
INFO - 2018-05-05 21:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:14:33 --> Email Class Initialized
INFO - 2018-05-05 21:14:33 --> Controller Class Initialized
INFO - 2018-05-05 21:14:33 --> Helper loaded: form_helper
INFO - 2018-05-05 21:14:33 --> Form Validation Class Initialized
INFO - 2018-05-05 21:14:33 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:14:33 --> Helper loaded: url_helper
INFO - 2018-05-05 21:14:33 --> Model Class Initialized
INFO - 2018-05-05 21:14:33 --> Model Class Initialized
INFO - 2018-05-05 21:14:33 --> Model Class Initialized
INFO - 2018-05-05 21:14:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:14:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:14:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:14:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:14:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:14:33 --> Final output sent to browser
DEBUG - 2018-05-05 21:14:33 --> Total execution time: 0.1660
INFO - 2018-05-05 21:16:33 --> Config Class Initialized
INFO - 2018-05-05 21:16:33 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:16:33 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:16:33 --> Utf8 Class Initialized
INFO - 2018-05-05 21:16:33 --> URI Class Initialized
INFO - 2018-05-05 21:16:33 --> Router Class Initialized
INFO - 2018-05-05 21:16:33 --> Output Class Initialized
INFO - 2018-05-05 21:16:33 --> Security Class Initialized
DEBUG - 2018-05-05 21:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:16:33 --> Input Class Initialized
INFO - 2018-05-05 21:16:33 --> Language Class Initialized
INFO - 2018-05-05 21:16:33 --> Loader Class Initialized
INFO - 2018-05-05 21:16:33 --> Helper loaded: common_helper
INFO - 2018-05-05 21:16:33 --> Database Driver Class Initialized
INFO - 2018-05-05 21:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:16:33 --> Email Class Initialized
INFO - 2018-05-05 21:16:33 --> Controller Class Initialized
INFO - 2018-05-05 21:16:33 --> Helper loaded: form_helper
INFO - 2018-05-05 21:16:33 --> Form Validation Class Initialized
INFO - 2018-05-05 21:16:33 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:16:33 --> Helper loaded: url_helper
INFO - 2018-05-05 21:16:33 --> Model Class Initialized
INFO - 2018-05-05 21:16:33 --> Model Class Initialized
INFO - 2018-05-05 21:16:33 --> Model Class Initialized
ERROR - 2018-05-05 21:16:33 --> Undefined variable: id
ERROR - 2018-05-05 21:16:33 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Celebrity\admin\application\models\Commonmodel.php 75
INFO - 2018-05-05 21:17:23 --> Config Class Initialized
INFO - 2018-05-05 21:17:23 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:17:23 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:17:23 --> Utf8 Class Initialized
INFO - 2018-05-05 21:17:23 --> URI Class Initialized
INFO - 2018-05-05 21:17:23 --> Router Class Initialized
INFO - 2018-05-05 21:17:23 --> Output Class Initialized
INFO - 2018-05-05 21:17:23 --> Security Class Initialized
DEBUG - 2018-05-05 21:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:17:23 --> Input Class Initialized
INFO - 2018-05-05 21:17:23 --> Language Class Initialized
INFO - 2018-05-05 21:17:23 --> Loader Class Initialized
INFO - 2018-05-05 21:17:23 --> Helper loaded: common_helper
INFO - 2018-05-05 21:17:23 --> Database Driver Class Initialized
INFO - 2018-05-05 21:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:17:23 --> Email Class Initialized
INFO - 2018-05-05 21:17:23 --> Controller Class Initialized
INFO - 2018-05-05 21:17:23 --> Helper loaded: form_helper
INFO - 2018-05-05 21:17:23 --> Form Validation Class Initialized
INFO - 2018-05-05 21:17:23 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:17:23 --> Helper loaded: url_helper
INFO - 2018-05-05 21:17:23 --> Model Class Initialized
INFO - 2018-05-05 21:17:23 --> Model Class Initialized
INFO - 2018-05-05 21:17:23 --> Model Class Initialized
ERROR - 2018-05-05 21:17:23 --> Undefined variable: id
ERROR - 2018-05-05 21:17:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Celebrity\admin\application\models\Commonmodel.php 75
INFO - 2018-05-05 21:18:24 --> Config Class Initialized
INFO - 2018-05-05 21:18:24 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:18:24 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:18:24 --> Utf8 Class Initialized
INFO - 2018-05-05 21:18:24 --> URI Class Initialized
INFO - 2018-05-05 21:18:24 --> Router Class Initialized
INFO - 2018-05-05 21:18:24 --> Output Class Initialized
INFO - 2018-05-05 21:18:24 --> Security Class Initialized
DEBUG - 2018-05-05 21:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:18:24 --> Input Class Initialized
INFO - 2018-05-05 21:18:24 --> Language Class Initialized
INFO - 2018-05-05 21:18:24 --> Loader Class Initialized
INFO - 2018-05-05 21:18:24 --> Helper loaded: common_helper
INFO - 2018-05-05 21:18:24 --> Database Driver Class Initialized
INFO - 2018-05-05 21:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:18:24 --> Email Class Initialized
INFO - 2018-05-05 21:18:24 --> Controller Class Initialized
INFO - 2018-05-05 21:18:24 --> Helper loaded: form_helper
INFO - 2018-05-05 21:18:24 --> Form Validation Class Initialized
INFO - 2018-05-05 21:18:24 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:18:24 --> Helper loaded: url_helper
INFO - 2018-05-05 21:18:24 --> Model Class Initialized
INFO - 2018-05-05 21:18:24 --> Model Class Initialized
INFO - 2018-05-05 21:18:24 --> Model Class Initialized
ERROR - 2018-05-05 21:18:24 --> Undefined variable: id
ERROR - 2018-05-05 21:18:24 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Celebrity\admin\application\models\Commonmodel.php 75
INFO - 2018-05-05 21:19:12 --> Config Class Initialized
INFO - 2018-05-05 21:19:12 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:19:12 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:19:12 --> Utf8 Class Initialized
INFO - 2018-05-05 21:19:12 --> URI Class Initialized
INFO - 2018-05-05 21:19:12 --> Router Class Initialized
INFO - 2018-05-05 21:19:12 --> Output Class Initialized
INFO - 2018-05-05 21:19:12 --> Security Class Initialized
DEBUG - 2018-05-05 21:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:19:12 --> Input Class Initialized
INFO - 2018-05-05 21:19:12 --> Language Class Initialized
INFO - 2018-05-05 21:19:12 --> Loader Class Initialized
INFO - 2018-05-05 21:19:12 --> Helper loaded: common_helper
INFO - 2018-05-05 21:19:12 --> Database Driver Class Initialized
INFO - 2018-05-05 21:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:19:12 --> Email Class Initialized
INFO - 2018-05-05 21:19:12 --> Controller Class Initialized
INFO - 2018-05-05 21:19:12 --> Helper loaded: form_helper
INFO - 2018-05-05 21:19:12 --> Form Validation Class Initialized
INFO - 2018-05-05 21:19:12 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:19:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:19:12 --> Helper loaded: url_helper
INFO - 2018-05-05 21:19:12 --> Model Class Initialized
INFO - 2018-05-05 21:19:12 --> Model Class Initialized
INFO - 2018-05-05 21:19:12 --> Model Class Initialized
INFO - 2018-05-05 21:19:25 --> Config Class Initialized
INFO - 2018-05-05 21:19:25 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:19:25 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:19:25 --> Utf8 Class Initialized
INFO - 2018-05-05 21:19:25 --> URI Class Initialized
INFO - 2018-05-05 21:19:25 --> Router Class Initialized
INFO - 2018-05-05 21:19:25 --> Output Class Initialized
INFO - 2018-05-05 21:19:25 --> Security Class Initialized
DEBUG - 2018-05-05 21:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:19:25 --> Input Class Initialized
INFO - 2018-05-05 21:19:25 --> Language Class Initialized
INFO - 2018-05-05 21:19:25 --> Loader Class Initialized
INFO - 2018-05-05 21:19:25 --> Helper loaded: common_helper
INFO - 2018-05-05 21:19:25 --> Database Driver Class Initialized
INFO - 2018-05-05 21:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:19:25 --> Email Class Initialized
INFO - 2018-05-05 21:19:25 --> Controller Class Initialized
INFO - 2018-05-05 21:19:25 --> Helper loaded: form_helper
INFO - 2018-05-05 21:19:25 --> Form Validation Class Initialized
INFO - 2018-05-05 21:19:25 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:19:25 --> Helper loaded: url_helper
INFO - 2018-05-05 21:19:25 --> Model Class Initialized
INFO - 2018-05-05 21:19:25 --> Model Class Initialized
INFO - 2018-05-05 21:19:25 --> Model Class Initialized
INFO - 2018-05-05 21:19:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:19:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:19:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:19:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:19:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:19:25 --> Final output sent to browser
DEBUG - 2018-05-05 21:19:25 --> Total execution time: 0.1360
INFO - 2018-05-05 21:19:29 --> Config Class Initialized
INFO - 2018-05-05 21:19:29 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:19:29 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:19:29 --> Utf8 Class Initialized
INFO - 2018-05-05 21:19:29 --> URI Class Initialized
INFO - 2018-05-05 21:19:29 --> Router Class Initialized
INFO - 2018-05-05 21:19:29 --> Output Class Initialized
INFO - 2018-05-05 21:19:29 --> Security Class Initialized
DEBUG - 2018-05-05 21:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:19:29 --> Input Class Initialized
INFO - 2018-05-05 21:19:29 --> Language Class Initialized
INFO - 2018-05-05 21:19:29 --> Loader Class Initialized
INFO - 2018-05-05 21:19:29 --> Helper loaded: common_helper
INFO - 2018-05-05 21:19:29 --> Database Driver Class Initialized
INFO - 2018-05-05 21:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:19:29 --> Email Class Initialized
INFO - 2018-05-05 21:19:29 --> Controller Class Initialized
INFO - 2018-05-05 21:19:29 --> Helper loaded: form_helper
INFO - 2018-05-05 21:19:29 --> Form Validation Class Initialized
INFO - 2018-05-05 21:19:29 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:19:29 --> Helper loaded: url_helper
INFO - 2018-05-05 21:19:29 --> Model Class Initialized
INFO - 2018-05-05 21:19:29 --> Model Class Initialized
INFO - 2018-05-05 21:19:29 --> Model Class Initialized
INFO - 2018-05-05 21:19:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:19:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:19:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 21:19:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:19:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:19:29 --> Final output sent to browser
DEBUG - 2018-05-05 21:19:29 --> Total execution time: 0.1950
INFO - 2018-05-05 21:19:35 --> Config Class Initialized
INFO - 2018-05-05 21:19:35 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:19:35 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:19:35 --> Utf8 Class Initialized
INFO - 2018-05-05 21:19:35 --> URI Class Initialized
INFO - 2018-05-05 21:19:35 --> Router Class Initialized
INFO - 2018-05-05 21:19:35 --> Output Class Initialized
INFO - 2018-05-05 21:19:35 --> Security Class Initialized
DEBUG - 2018-05-05 21:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:19:35 --> Input Class Initialized
INFO - 2018-05-05 21:19:35 --> Language Class Initialized
INFO - 2018-05-05 21:19:35 --> Loader Class Initialized
INFO - 2018-05-05 21:19:35 --> Helper loaded: common_helper
INFO - 2018-05-05 21:19:35 --> Database Driver Class Initialized
INFO - 2018-05-05 21:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:19:35 --> Email Class Initialized
INFO - 2018-05-05 21:19:35 --> Controller Class Initialized
INFO - 2018-05-05 21:19:35 --> Helper loaded: form_helper
INFO - 2018-05-05 21:19:35 --> Form Validation Class Initialized
INFO - 2018-05-05 21:19:35 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:19:35 --> Helper loaded: url_helper
INFO - 2018-05-05 21:19:35 --> Model Class Initialized
INFO - 2018-05-05 21:19:35 --> Model Class Initialized
INFO - 2018-05-05 21:19:35 --> Model Class Initialized
INFO - 2018-05-05 21:19:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:19:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:19:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:19:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-05 21:19:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:19:35 --> Final output sent to browser
DEBUG - 2018-05-05 21:19:35 --> Total execution time: 0.1380
INFO - 2018-05-05 21:19:37 --> Config Class Initialized
INFO - 2018-05-05 21:19:37 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:19:37 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:19:37 --> Utf8 Class Initialized
INFO - 2018-05-05 21:19:37 --> URI Class Initialized
INFO - 2018-05-05 21:19:37 --> Router Class Initialized
INFO - 2018-05-05 21:19:37 --> Output Class Initialized
INFO - 2018-05-05 21:19:37 --> Security Class Initialized
DEBUG - 2018-05-05 21:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:19:37 --> Input Class Initialized
INFO - 2018-05-05 21:19:37 --> Language Class Initialized
INFO - 2018-05-05 21:19:37 --> Loader Class Initialized
INFO - 2018-05-05 21:19:37 --> Helper loaded: common_helper
INFO - 2018-05-05 21:19:37 --> Database Driver Class Initialized
INFO - 2018-05-05 21:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:19:37 --> Email Class Initialized
INFO - 2018-05-05 21:19:37 --> Controller Class Initialized
INFO - 2018-05-05 21:19:37 --> Helper loaded: form_helper
INFO - 2018-05-05 21:19:37 --> Form Validation Class Initialized
INFO - 2018-05-05 21:19:37 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:19:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:19:37 --> Helper loaded: url_helper
INFO - 2018-05-05 21:19:37 --> Model Class Initialized
INFO - 2018-05-05 21:19:37 --> Model Class Initialized
INFO - 2018-05-05 21:19:37 --> Model Class Initialized
INFO - 2018-05-05 21:19:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:19:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:19:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 21:19:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:19:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:19:37 --> Final output sent to browser
DEBUG - 2018-05-05 21:19:37 --> Total execution time: 0.1470
INFO - 2018-05-05 21:19:40 --> Config Class Initialized
INFO - 2018-05-05 21:19:40 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:19:40 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:19:40 --> Utf8 Class Initialized
INFO - 2018-05-05 21:19:40 --> URI Class Initialized
INFO - 2018-05-05 21:19:40 --> Router Class Initialized
INFO - 2018-05-05 21:19:40 --> Output Class Initialized
INFO - 2018-05-05 21:19:40 --> Security Class Initialized
DEBUG - 2018-05-05 21:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:19:40 --> Input Class Initialized
INFO - 2018-05-05 21:19:40 --> Language Class Initialized
INFO - 2018-05-05 21:19:40 --> Loader Class Initialized
INFO - 2018-05-05 21:19:40 --> Helper loaded: common_helper
INFO - 2018-05-05 21:19:40 --> Database Driver Class Initialized
INFO - 2018-05-05 21:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:19:40 --> Email Class Initialized
INFO - 2018-05-05 21:19:40 --> Controller Class Initialized
INFO - 2018-05-05 21:19:40 --> Helper loaded: form_helper
INFO - 2018-05-05 21:19:40 --> Form Validation Class Initialized
INFO - 2018-05-05 21:19:40 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:19:40 --> Helper loaded: url_helper
INFO - 2018-05-05 21:19:40 --> Model Class Initialized
INFO - 2018-05-05 21:19:40 --> Model Class Initialized
INFO - 2018-05-05 21:19:40 --> Model Class Initialized
INFO - 2018-05-05 21:19:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:19:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:19:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:19:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:19:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:19:40 --> Final output sent to browser
DEBUG - 2018-05-05 21:19:40 --> Total execution time: 0.1340
INFO - 2018-05-05 21:19:44 --> Config Class Initialized
INFO - 2018-05-05 21:19:44 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:19:44 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:19:44 --> Utf8 Class Initialized
INFO - 2018-05-05 21:19:44 --> URI Class Initialized
INFO - 2018-05-05 21:19:44 --> Router Class Initialized
INFO - 2018-05-05 21:19:44 --> Output Class Initialized
INFO - 2018-05-05 21:19:44 --> Security Class Initialized
DEBUG - 2018-05-05 21:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:19:44 --> Input Class Initialized
INFO - 2018-05-05 21:19:44 --> Language Class Initialized
INFO - 2018-05-05 21:19:44 --> Loader Class Initialized
INFO - 2018-05-05 21:19:44 --> Helper loaded: common_helper
INFO - 2018-05-05 21:19:44 --> Database Driver Class Initialized
INFO - 2018-05-05 21:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:19:44 --> Email Class Initialized
INFO - 2018-05-05 21:19:44 --> Controller Class Initialized
INFO - 2018-05-05 21:19:44 --> Helper loaded: form_helper
INFO - 2018-05-05 21:19:44 --> Form Validation Class Initialized
INFO - 2018-05-05 21:19:44 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:19:44 --> Helper loaded: url_helper
INFO - 2018-05-05 21:19:44 --> Model Class Initialized
INFO - 2018-05-05 21:19:44 --> Model Class Initialized
INFO - 2018-05-05 21:19:44 --> Model Class Initialized
INFO - 2018-05-05 21:19:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:19:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:19:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 21:19:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:19:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:19:44 --> Final output sent to browser
DEBUG - 2018-05-05 21:19:44 --> Total execution time: 0.1840
INFO - 2018-05-05 21:25:53 --> Config Class Initialized
INFO - 2018-05-05 21:25:53 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:25:53 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:25:53 --> Utf8 Class Initialized
INFO - 2018-05-05 21:25:53 --> URI Class Initialized
INFO - 2018-05-05 21:25:53 --> Router Class Initialized
INFO - 2018-05-05 21:25:53 --> Output Class Initialized
INFO - 2018-05-05 21:25:53 --> Security Class Initialized
DEBUG - 2018-05-05 21:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:25:53 --> Input Class Initialized
INFO - 2018-05-05 21:25:53 --> Language Class Initialized
INFO - 2018-05-05 21:25:53 --> Loader Class Initialized
INFO - 2018-05-05 21:25:53 --> Helper loaded: common_helper
INFO - 2018-05-05 21:25:53 --> Database Driver Class Initialized
INFO - 2018-05-05 21:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:25:53 --> Email Class Initialized
INFO - 2018-05-05 21:25:53 --> Controller Class Initialized
INFO - 2018-05-05 21:25:53 --> Helper loaded: form_helper
INFO - 2018-05-05 21:25:53 --> Form Validation Class Initialized
INFO - 2018-05-05 21:25:53 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:25:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:25:53 --> Helper loaded: url_helper
INFO - 2018-05-05 21:25:53 --> Model Class Initialized
INFO - 2018-05-05 21:25:53 --> Model Class Initialized
INFO - 2018-05-05 21:25:53 --> Model Class Initialized
INFO - 2018-05-05 21:25:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:25:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:25:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 21:25:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:25:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:25:53 --> Final output sent to browser
DEBUG - 2018-05-05 21:25:53 --> Total execution time: 0.1280
INFO - 2018-05-05 21:25:55 --> Config Class Initialized
INFO - 2018-05-05 21:25:55 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:25:55 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:25:55 --> Utf8 Class Initialized
INFO - 2018-05-05 21:25:55 --> URI Class Initialized
INFO - 2018-05-05 21:25:55 --> Router Class Initialized
INFO - 2018-05-05 21:25:55 --> Output Class Initialized
INFO - 2018-05-05 21:25:55 --> Security Class Initialized
DEBUG - 2018-05-05 21:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:25:55 --> Input Class Initialized
INFO - 2018-05-05 21:25:55 --> Language Class Initialized
INFO - 2018-05-05 21:25:55 --> Loader Class Initialized
INFO - 2018-05-05 21:25:55 --> Helper loaded: common_helper
INFO - 2018-05-05 21:25:55 --> Database Driver Class Initialized
INFO - 2018-05-05 21:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:25:55 --> Email Class Initialized
INFO - 2018-05-05 21:25:55 --> Controller Class Initialized
INFO - 2018-05-05 21:25:55 --> Helper loaded: form_helper
INFO - 2018-05-05 21:25:55 --> Form Validation Class Initialized
INFO - 2018-05-05 21:25:55 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:25:55 --> Helper loaded: url_helper
INFO - 2018-05-05 21:25:55 --> Model Class Initialized
INFO - 2018-05-05 21:25:55 --> Model Class Initialized
INFO - 2018-05-05 21:25:55 --> Model Class Initialized
INFO - 2018-05-05 21:25:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:25:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:25:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:25:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:25:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:25:55 --> Final output sent to browser
DEBUG - 2018-05-05 21:25:55 --> Total execution time: 0.1410
INFO - 2018-05-05 21:25:58 --> Config Class Initialized
INFO - 2018-05-05 21:25:58 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:25:58 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:25:58 --> Utf8 Class Initialized
INFO - 2018-05-05 21:25:58 --> URI Class Initialized
INFO - 2018-05-05 21:25:58 --> Router Class Initialized
INFO - 2018-05-05 21:25:58 --> Output Class Initialized
INFO - 2018-05-05 21:25:58 --> Security Class Initialized
DEBUG - 2018-05-05 21:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:25:58 --> Input Class Initialized
INFO - 2018-05-05 21:25:58 --> Language Class Initialized
INFO - 2018-05-05 21:25:58 --> Loader Class Initialized
INFO - 2018-05-05 21:25:58 --> Helper loaded: common_helper
INFO - 2018-05-05 21:25:58 --> Database Driver Class Initialized
INFO - 2018-05-05 21:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:25:58 --> Email Class Initialized
INFO - 2018-05-05 21:25:58 --> Controller Class Initialized
INFO - 2018-05-05 21:25:58 --> Helper loaded: form_helper
INFO - 2018-05-05 21:25:58 --> Form Validation Class Initialized
INFO - 2018-05-05 21:25:58 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:25:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:25:58 --> Helper loaded: url_helper
INFO - 2018-05-05 21:25:58 --> Model Class Initialized
INFO - 2018-05-05 21:25:58 --> Model Class Initialized
INFO - 2018-05-05 21:25:58 --> Model Class Initialized
INFO - 2018-05-05 21:25:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:25:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:25:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:25:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:25:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addMovie.php
INFO - 2018-05-05 21:25:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:25:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:25:58 --> Final output sent to browser
DEBUG - 2018-05-05 21:25:58 --> Total execution time: 0.1340
INFO - 2018-05-05 21:26:03 --> Config Class Initialized
INFO - 2018-05-05 21:26:03 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:26:03 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:26:03 --> Utf8 Class Initialized
INFO - 2018-05-05 21:26:03 --> URI Class Initialized
INFO - 2018-05-05 21:26:03 --> Router Class Initialized
INFO - 2018-05-05 21:26:03 --> Output Class Initialized
INFO - 2018-05-05 21:26:03 --> Security Class Initialized
DEBUG - 2018-05-05 21:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:26:03 --> Input Class Initialized
INFO - 2018-05-05 21:26:03 --> Language Class Initialized
INFO - 2018-05-05 21:26:03 --> Loader Class Initialized
INFO - 2018-05-05 21:26:03 --> Helper loaded: common_helper
INFO - 2018-05-05 21:26:03 --> Database Driver Class Initialized
INFO - 2018-05-05 21:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:26:03 --> Email Class Initialized
INFO - 2018-05-05 21:26:03 --> Controller Class Initialized
INFO - 2018-05-05 21:26:03 --> Helper loaded: form_helper
INFO - 2018-05-05 21:26:03 --> Form Validation Class Initialized
INFO - 2018-05-05 21:26:03 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:26:03 --> Helper loaded: url_helper
INFO - 2018-05-05 21:26:03 --> Model Class Initialized
INFO - 2018-05-05 21:26:03 --> Model Class Initialized
INFO - 2018-05-05 21:26:03 --> Model Class Initialized
INFO - 2018-05-05 21:26:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:26:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:26:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:26:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:26:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:26:03 --> Final output sent to browser
DEBUG - 2018-05-05 21:26:03 --> Total execution time: 0.1880
INFO - 2018-05-05 21:26:05 --> Config Class Initialized
INFO - 2018-05-05 21:26:05 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:26:05 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:26:05 --> Utf8 Class Initialized
INFO - 2018-05-05 21:26:05 --> URI Class Initialized
INFO - 2018-05-05 21:26:05 --> Router Class Initialized
INFO - 2018-05-05 21:26:05 --> Output Class Initialized
INFO - 2018-05-05 21:26:05 --> Security Class Initialized
DEBUG - 2018-05-05 21:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:26:05 --> Input Class Initialized
INFO - 2018-05-05 21:26:05 --> Language Class Initialized
INFO - 2018-05-05 21:26:05 --> Loader Class Initialized
INFO - 2018-05-05 21:26:05 --> Helper loaded: common_helper
INFO - 2018-05-05 21:26:05 --> Database Driver Class Initialized
INFO - 2018-05-05 21:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:26:05 --> Email Class Initialized
INFO - 2018-05-05 21:26:05 --> Controller Class Initialized
INFO - 2018-05-05 21:26:05 --> Helper loaded: form_helper
INFO - 2018-05-05 21:26:05 --> Form Validation Class Initialized
INFO - 2018-05-05 21:26:05 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:26:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:26:05 --> Helper loaded: url_helper
INFO - 2018-05-05 21:26:05 --> Model Class Initialized
INFO - 2018-05-05 21:26:05 --> Model Class Initialized
INFO - 2018-05-05 21:26:05 --> Model Class Initialized
INFO - 2018-05-05 21:26:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:26:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:26:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:26:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:26:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 21:26:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:26:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:26:05 --> Final output sent to browser
DEBUG - 2018-05-05 21:26:05 --> Total execution time: 0.2170
INFO - 2018-05-05 21:26:43 --> Config Class Initialized
INFO - 2018-05-05 21:26:43 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:26:43 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:26:43 --> Utf8 Class Initialized
INFO - 2018-05-05 21:26:43 --> URI Class Initialized
INFO - 2018-05-05 21:26:44 --> Router Class Initialized
INFO - 2018-05-05 21:26:44 --> Output Class Initialized
INFO - 2018-05-05 21:26:44 --> Security Class Initialized
DEBUG - 2018-05-05 21:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:26:44 --> Input Class Initialized
INFO - 2018-05-05 21:26:44 --> Language Class Initialized
INFO - 2018-05-05 21:26:44 --> Loader Class Initialized
INFO - 2018-05-05 21:26:44 --> Helper loaded: common_helper
INFO - 2018-05-05 21:26:44 --> Database Driver Class Initialized
INFO - 2018-05-05 21:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:26:44 --> Email Class Initialized
INFO - 2018-05-05 21:26:44 --> Controller Class Initialized
INFO - 2018-05-05 21:26:44 --> Helper loaded: form_helper
INFO - 2018-05-05 21:26:44 --> Form Validation Class Initialized
INFO - 2018-05-05 21:26:44 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:26:44 --> Helper loaded: url_helper
INFO - 2018-05-05 21:26:44 --> Model Class Initialized
INFO - 2018-05-05 21:26:44 --> Model Class Initialized
INFO - 2018-05-05 21:26:44 --> Model Class Initialized
INFO - 2018-05-05 21:26:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:26:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:26:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:26:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:26:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 21:26:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:26:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:26:44 --> Final output sent to browser
DEBUG - 2018-05-05 21:26:44 --> Total execution time: 0.1430
INFO - 2018-05-05 21:26:49 --> Config Class Initialized
INFO - 2018-05-05 21:26:49 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:26:49 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:26:49 --> Utf8 Class Initialized
INFO - 2018-05-05 21:26:49 --> URI Class Initialized
INFO - 2018-05-05 21:26:49 --> Router Class Initialized
INFO - 2018-05-05 21:26:49 --> Output Class Initialized
INFO - 2018-05-05 21:26:49 --> Security Class Initialized
DEBUG - 2018-05-05 21:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:26:49 --> Input Class Initialized
INFO - 2018-05-05 21:26:49 --> Language Class Initialized
INFO - 2018-05-05 21:26:49 --> Loader Class Initialized
INFO - 2018-05-05 21:26:49 --> Helper loaded: common_helper
INFO - 2018-05-05 21:26:49 --> Database Driver Class Initialized
INFO - 2018-05-05 21:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:26:49 --> Email Class Initialized
INFO - 2018-05-05 21:26:49 --> Controller Class Initialized
INFO - 2018-05-05 21:26:49 --> Helper loaded: form_helper
INFO - 2018-05-05 21:26:49 --> Form Validation Class Initialized
INFO - 2018-05-05 21:26:49 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:26:49 --> Helper loaded: url_helper
INFO - 2018-05-05 21:26:49 --> Model Class Initialized
INFO - 2018-05-05 21:26:49 --> Model Class Initialized
INFO - 2018-05-05 21:26:49 --> Model Class Initialized
INFO - 2018-05-05 21:26:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:26:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:26:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:26:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:26:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 21:26:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:26:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:26:49 --> Final output sent to browser
DEBUG - 2018-05-05 21:26:49 --> Total execution time: 0.1700
INFO - 2018-05-05 21:27:43 --> Config Class Initialized
INFO - 2018-05-05 21:27:43 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:27:43 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:27:43 --> Utf8 Class Initialized
INFO - 2018-05-05 21:27:43 --> URI Class Initialized
INFO - 2018-05-05 21:27:43 --> Router Class Initialized
INFO - 2018-05-05 21:27:43 --> Output Class Initialized
INFO - 2018-05-05 21:27:43 --> Security Class Initialized
DEBUG - 2018-05-05 21:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:27:43 --> Input Class Initialized
INFO - 2018-05-05 21:27:43 --> Language Class Initialized
INFO - 2018-05-05 21:27:43 --> Loader Class Initialized
INFO - 2018-05-05 21:27:43 --> Helper loaded: common_helper
INFO - 2018-05-05 21:27:43 --> Database Driver Class Initialized
INFO - 2018-05-05 21:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:27:43 --> Email Class Initialized
INFO - 2018-05-05 21:27:43 --> Controller Class Initialized
INFO - 2018-05-05 21:27:43 --> Helper loaded: form_helper
INFO - 2018-05-05 21:27:43 --> Form Validation Class Initialized
INFO - 2018-05-05 21:27:43 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:27:43 --> Helper loaded: url_helper
INFO - 2018-05-05 21:27:43 --> Model Class Initialized
INFO - 2018-05-05 21:27:43 --> Model Class Initialized
INFO - 2018-05-05 21:27:43 --> Model Class Initialized
INFO - 2018-05-05 21:27:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:27:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:27:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:27:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:27:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 21:27:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:27:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:27:43 --> Final output sent to browser
DEBUG - 2018-05-05 21:27:43 --> Total execution time: 0.1460
INFO - 2018-05-05 21:31:08 --> Config Class Initialized
INFO - 2018-05-05 21:31:08 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:31:08 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:31:08 --> Utf8 Class Initialized
INFO - 2018-05-05 21:31:08 --> URI Class Initialized
INFO - 2018-05-05 21:31:08 --> Router Class Initialized
INFO - 2018-05-05 21:31:08 --> Output Class Initialized
INFO - 2018-05-05 21:31:08 --> Security Class Initialized
DEBUG - 2018-05-05 21:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:31:08 --> Input Class Initialized
INFO - 2018-05-05 21:31:08 --> Language Class Initialized
INFO - 2018-05-05 21:31:08 --> Loader Class Initialized
INFO - 2018-05-05 21:31:08 --> Helper loaded: common_helper
INFO - 2018-05-05 21:31:08 --> Database Driver Class Initialized
INFO - 2018-05-05 21:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:31:08 --> Email Class Initialized
INFO - 2018-05-05 21:31:08 --> Controller Class Initialized
INFO - 2018-05-05 21:31:08 --> Helper loaded: form_helper
INFO - 2018-05-05 21:31:08 --> Form Validation Class Initialized
INFO - 2018-05-05 21:31:08 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:31:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:31:08 --> Helper loaded: url_helper
INFO - 2018-05-05 21:31:08 --> Model Class Initialized
INFO - 2018-05-05 21:31:08 --> Model Class Initialized
INFO - 2018-05-05 21:31:08 --> Model Class Initialized
INFO - 2018-05-05 21:31:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:31:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:31:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:31:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:31:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 21:31:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:31:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:31:08 --> Final output sent to browser
DEBUG - 2018-05-05 21:31:08 --> Total execution time: 0.1400
INFO - 2018-05-05 21:31:14 --> Config Class Initialized
INFO - 2018-05-05 21:31:14 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:31:14 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:31:14 --> Utf8 Class Initialized
INFO - 2018-05-05 21:31:14 --> URI Class Initialized
INFO - 2018-05-05 21:31:14 --> Router Class Initialized
INFO - 2018-05-05 21:31:14 --> Output Class Initialized
INFO - 2018-05-05 21:31:14 --> Security Class Initialized
DEBUG - 2018-05-05 21:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:31:14 --> Input Class Initialized
INFO - 2018-05-05 21:31:14 --> Language Class Initialized
INFO - 2018-05-05 21:31:14 --> Loader Class Initialized
INFO - 2018-05-05 21:31:14 --> Helper loaded: common_helper
INFO - 2018-05-05 21:31:14 --> Database Driver Class Initialized
INFO - 2018-05-05 21:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:31:14 --> Email Class Initialized
INFO - 2018-05-05 21:31:14 --> Controller Class Initialized
INFO - 2018-05-05 21:31:14 --> Helper loaded: form_helper
INFO - 2018-05-05 21:31:14 --> Form Validation Class Initialized
INFO - 2018-05-05 21:31:14 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:31:14 --> Helper loaded: url_helper
INFO - 2018-05-05 21:31:14 --> Model Class Initialized
INFO - 2018-05-05 21:31:14 --> Model Class Initialized
INFO - 2018-05-05 21:31:14 --> Model Class Initialized
DEBUG - 2018-05-05 21:31:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:31:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-05 21:31:14 --> Query error: Duplicate entry '6' for key 'movie_display_order' - Invalid query: UPDATE `movies` SET `celebrityId` = '2', `movie_title` = 'jai Lava Kusa', `about_movie` = 'Jai Lava Kusa is a Telugu movie of action-drama genre written and directed by K. S. Ravindra. The movie features Jr. NTR, Raashi Khanna and Nivetha Thomas in the lead roles. This film marks the Telugu debut of Hindi film and television actor Ronit Roy, who will play the film\'s villain. The movie is produced by Jr. NTR\'s brother Nandamuri Kalyan Ram under his banner N. T. R. Arts. The soundtrack is composed by Devi Sri Prasad. Chota K. Naidu is the film\'s cinematographer. The songs and background score was scored by Devi Sri Prasad, and the audio was released on September 3 2017 on Lahari Music.', `movie_director` = 'K. S. Ravindra', `movie_genre` = 'Action', `movie_stars` = 'Jr. NTR, Posani Krishna Murali, Pradeep Rawat, Nivetha Thomas, Hamsa Nandini, Abhimanyu Singh', `release_date` = '17-09-21 12:00:00', `movie_link` = '=1SFGU6tkGZw', `movie_display_order` = '6', `updatedTime` = '18-05-05 09:31:14'
WHERE `movie_id` = '2'
INFO - 2018-05-05 21:31:14 --> Config Class Initialized
INFO - 2018-05-05 21:31:14 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:31:14 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:31:14 --> Utf8 Class Initialized
INFO - 2018-05-05 21:31:14 --> URI Class Initialized
INFO - 2018-05-05 21:31:14 --> Router Class Initialized
INFO - 2018-05-05 21:31:14 --> Output Class Initialized
INFO - 2018-05-05 21:31:14 --> Security Class Initialized
DEBUG - 2018-05-05 21:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:31:14 --> Input Class Initialized
INFO - 2018-05-05 21:31:14 --> Language Class Initialized
INFO - 2018-05-05 21:31:14 --> Loader Class Initialized
INFO - 2018-05-05 21:31:14 --> Helper loaded: common_helper
INFO - 2018-05-05 21:31:14 --> Database Driver Class Initialized
INFO - 2018-05-05 21:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:31:14 --> Email Class Initialized
INFO - 2018-05-05 21:31:14 --> Controller Class Initialized
INFO - 2018-05-05 21:31:14 --> Helper loaded: form_helper
INFO - 2018-05-05 21:31:14 --> Form Validation Class Initialized
INFO - 2018-05-05 21:31:14 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:31:14 --> Helper loaded: url_helper
INFO - 2018-05-05 21:31:14 --> Model Class Initialized
INFO - 2018-05-05 21:31:14 --> Model Class Initialized
INFO - 2018-05-05 21:31:14 --> Model Class Initialized
INFO - 2018-05-05 21:31:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:31:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:31:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:31:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:31:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 21:31:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:31:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:31:14 --> Final output sent to browser
DEBUG - 2018-05-05 21:31:14 --> Total execution time: 0.1590
INFO - 2018-05-05 21:36:40 --> Config Class Initialized
INFO - 2018-05-05 21:36:40 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:36:40 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:36:40 --> Utf8 Class Initialized
INFO - 2018-05-05 21:36:40 --> URI Class Initialized
INFO - 2018-05-05 21:36:40 --> Router Class Initialized
INFO - 2018-05-05 21:36:40 --> Output Class Initialized
INFO - 2018-05-05 21:36:40 --> Security Class Initialized
DEBUG - 2018-05-05 21:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:36:40 --> Input Class Initialized
INFO - 2018-05-05 21:36:40 --> Language Class Initialized
INFO - 2018-05-05 21:36:40 --> Loader Class Initialized
INFO - 2018-05-05 21:36:40 --> Helper loaded: common_helper
INFO - 2018-05-05 21:36:40 --> Database Driver Class Initialized
INFO - 2018-05-05 21:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:36:40 --> Email Class Initialized
INFO - 2018-05-05 21:36:40 --> Controller Class Initialized
INFO - 2018-05-05 21:36:40 --> Helper loaded: form_helper
INFO - 2018-05-05 21:36:40 --> Form Validation Class Initialized
INFO - 2018-05-05 21:36:40 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:36:40 --> Helper loaded: url_helper
INFO - 2018-05-05 21:36:40 --> Model Class Initialized
INFO - 2018-05-05 21:36:40 --> Model Class Initialized
INFO - 2018-05-05 21:36:40 --> Model Class Initialized
INFO - 2018-05-05 21:36:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:36:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:36:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:36:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:36:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 21:36:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:36:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:36:41 --> Final output sent to browser
DEBUG - 2018-05-05 21:36:41 --> Total execution time: 0.1390
INFO - 2018-05-05 21:36:42 --> Config Class Initialized
INFO - 2018-05-05 21:36:42 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:36:42 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:36:42 --> Utf8 Class Initialized
INFO - 2018-05-05 21:36:42 --> URI Class Initialized
INFO - 2018-05-05 21:36:42 --> Router Class Initialized
INFO - 2018-05-05 21:36:42 --> Output Class Initialized
INFO - 2018-05-05 21:36:42 --> Security Class Initialized
DEBUG - 2018-05-05 21:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:36:42 --> Input Class Initialized
INFO - 2018-05-05 21:36:42 --> Language Class Initialized
INFO - 2018-05-05 21:36:42 --> Loader Class Initialized
INFO - 2018-05-05 21:36:42 --> Helper loaded: common_helper
INFO - 2018-05-05 21:36:42 --> Database Driver Class Initialized
INFO - 2018-05-05 21:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:36:42 --> Email Class Initialized
INFO - 2018-05-05 21:36:42 --> Controller Class Initialized
INFO - 2018-05-05 21:36:42 --> Helper loaded: form_helper
INFO - 2018-05-05 21:36:42 --> Form Validation Class Initialized
INFO - 2018-05-05 21:36:42 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:36:42 --> Helper loaded: url_helper
INFO - 2018-05-05 21:36:42 --> Model Class Initialized
INFO - 2018-05-05 21:36:42 --> Model Class Initialized
INFO - 2018-05-05 21:36:42 --> Model Class Initialized
INFO - 2018-05-05 21:36:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:36:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:36:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:36:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:36:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 21:36:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:36:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:36:42 --> Final output sent to browser
DEBUG - 2018-05-05 21:36:42 --> Total execution time: 0.1520
INFO - 2018-05-05 21:36:44 --> Config Class Initialized
INFO - 2018-05-05 21:36:44 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:36:44 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:36:44 --> Utf8 Class Initialized
INFO - 2018-05-05 21:36:44 --> URI Class Initialized
INFO - 2018-05-05 21:36:44 --> Router Class Initialized
INFO - 2018-05-05 21:36:44 --> Output Class Initialized
INFO - 2018-05-05 21:36:44 --> Security Class Initialized
DEBUG - 2018-05-05 21:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:36:44 --> Input Class Initialized
INFO - 2018-05-05 21:36:44 --> Language Class Initialized
INFO - 2018-05-05 21:36:44 --> Loader Class Initialized
INFO - 2018-05-05 21:36:44 --> Helper loaded: common_helper
INFO - 2018-05-05 21:36:44 --> Database Driver Class Initialized
INFO - 2018-05-05 21:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:36:44 --> Email Class Initialized
INFO - 2018-05-05 21:36:44 --> Controller Class Initialized
INFO - 2018-05-05 21:36:44 --> Helper loaded: form_helper
INFO - 2018-05-05 21:36:44 --> Form Validation Class Initialized
INFO - 2018-05-05 21:36:44 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:36:44 --> Helper loaded: url_helper
INFO - 2018-05-05 21:36:44 --> Model Class Initialized
INFO - 2018-05-05 21:36:44 --> Model Class Initialized
INFO - 2018-05-05 21:36:44 --> Model Class Initialized
INFO - 2018-05-05 21:36:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:36:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:36:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:36:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:36:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:36:44 --> Final output sent to browser
DEBUG - 2018-05-05 21:36:44 --> Total execution time: 0.1380
INFO - 2018-05-05 21:36:45 --> Config Class Initialized
INFO - 2018-05-05 21:36:45 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:36:45 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:36:45 --> Utf8 Class Initialized
INFO - 2018-05-05 21:36:45 --> URI Class Initialized
INFO - 2018-05-05 21:36:45 --> Router Class Initialized
INFO - 2018-05-05 21:36:45 --> Output Class Initialized
INFO - 2018-05-05 21:36:45 --> Security Class Initialized
DEBUG - 2018-05-05 21:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:36:45 --> Input Class Initialized
INFO - 2018-05-05 21:36:45 --> Language Class Initialized
INFO - 2018-05-05 21:36:45 --> Loader Class Initialized
INFO - 2018-05-05 21:36:45 --> Helper loaded: common_helper
INFO - 2018-05-05 21:36:45 --> Database Driver Class Initialized
INFO - 2018-05-05 21:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:36:45 --> Email Class Initialized
INFO - 2018-05-05 21:36:45 --> Controller Class Initialized
INFO - 2018-05-05 21:36:45 --> Helper loaded: form_helper
INFO - 2018-05-05 21:36:45 --> Form Validation Class Initialized
INFO - 2018-05-05 21:36:45 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:36:45 --> Helper loaded: url_helper
INFO - 2018-05-05 21:36:45 --> Model Class Initialized
INFO - 2018-05-05 21:36:45 --> Model Class Initialized
INFO - 2018-05-05 21:36:45 --> Model Class Initialized
INFO - 2018-05-05 21:36:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:36:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:36:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 21:36:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:36:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:36:45 --> Final output sent to browser
DEBUG - 2018-05-05 21:36:45 --> Total execution time: 0.1530
INFO - 2018-05-05 21:36:47 --> Config Class Initialized
INFO - 2018-05-05 21:36:47 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:36:47 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:36:47 --> Utf8 Class Initialized
INFO - 2018-05-05 21:36:47 --> URI Class Initialized
INFO - 2018-05-05 21:36:47 --> Router Class Initialized
INFO - 2018-05-05 21:36:47 --> Output Class Initialized
INFO - 2018-05-05 21:36:47 --> Security Class Initialized
DEBUG - 2018-05-05 21:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:36:47 --> Input Class Initialized
INFO - 2018-05-05 21:36:47 --> Language Class Initialized
INFO - 2018-05-05 21:36:47 --> Loader Class Initialized
INFO - 2018-05-05 21:36:47 --> Helper loaded: common_helper
INFO - 2018-05-05 21:36:47 --> Database Driver Class Initialized
INFO - 2018-05-05 21:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:36:47 --> Email Class Initialized
INFO - 2018-05-05 21:36:47 --> Controller Class Initialized
INFO - 2018-05-05 21:36:47 --> Helper loaded: form_helper
INFO - 2018-05-05 21:36:47 --> Form Validation Class Initialized
INFO - 2018-05-05 21:36:47 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:36:47 --> Helper loaded: url_helper
INFO - 2018-05-05 21:36:48 --> Model Class Initialized
INFO - 2018-05-05 21:36:48 --> Model Class Initialized
INFO - 2018-05-05 21:36:48 --> Model Class Initialized
INFO - 2018-05-05 21:36:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:36:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:36:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:36:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:36:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:36:48 --> Final output sent to browser
DEBUG - 2018-05-05 21:36:48 --> Total execution time: 0.1600
INFO - 2018-05-05 21:36:49 --> Config Class Initialized
INFO - 2018-05-05 21:36:49 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:36:49 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:36:49 --> Utf8 Class Initialized
INFO - 2018-05-05 21:36:49 --> URI Class Initialized
INFO - 2018-05-05 21:36:49 --> Router Class Initialized
INFO - 2018-05-05 21:36:49 --> Output Class Initialized
INFO - 2018-05-05 21:36:49 --> Security Class Initialized
DEBUG - 2018-05-05 21:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:36:49 --> Input Class Initialized
INFO - 2018-05-05 21:36:49 --> Language Class Initialized
INFO - 2018-05-05 21:36:49 --> Loader Class Initialized
INFO - 2018-05-05 21:36:49 --> Helper loaded: common_helper
INFO - 2018-05-05 21:36:49 --> Database Driver Class Initialized
INFO - 2018-05-05 21:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:36:49 --> Email Class Initialized
INFO - 2018-05-05 21:36:49 --> Controller Class Initialized
INFO - 2018-05-05 21:36:49 --> Helper loaded: form_helper
INFO - 2018-05-05 21:36:49 --> Form Validation Class Initialized
INFO - 2018-05-05 21:36:49 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:36:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:36:49 --> Helper loaded: url_helper
INFO - 2018-05-05 21:36:49 --> Model Class Initialized
INFO - 2018-05-05 21:36:49 --> Model Class Initialized
INFO - 2018-05-05 21:36:49 --> Model Class Initialized
INFO - 2018-05-05 21:36:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:36:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:36:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 21:36:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:36:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:36:49 --> Final output sent to browser
DEBUG - 2018-05-05 21:36:49 --> Total execution time: 0.1460
INFO - 2018-05-05 21:36:50 --> Config Class Initialized
INFO - 2018-05-05 21:36:50 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:36:50 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:36:50 --> Utf8 Class Initialized
INFO - 2018-05-05 21:36:50 --> URI Class Initialized
INFO - 2018-05-05 21:36:50 --> Router Class Initialized
INFO - 2018-05-05 21:36:50 --> Output Class Initialized
INFO - 2018-05-05 21:36:50 --> Security Class Initialized
DEBUG - 2018-05-05 21:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:36:50 --> Input Class Initialized
INFO - 2018-05-05 21:36:50 --> Language Class Initialized
INFO - 2018-05-05 21:36:50 --> Loader Class Initialized
INFO - 2018-05-05 21:36:50 --> Helper loaded: common_helper
INFO - 2018-05-05 21:36:50 --> Database Driver Class Initialized
INFO - 2018-05-05 21:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:36:50 --> Email Class Initialized
INFO - 2018-05-05 21:36:50 --> Controller Class Initialized
INFO - 2018-05-05 21:36:50 --> Helper loaded: form_helper
INFO - 2018-05-05 21:36:50 --> Form Validation Class Initialized
INFO - 2018-05-05 21:36:50 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:36:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:36:50 --> Helper loaded: url_helper
INFO - 2018-05-05 21:36:50 --> Model Class Initialized
INFO - 2018-05-05 21:36:50 --> Model Class Initialized
INFO - 2018-05-05 21:36:50 --> Model Class Initialized
INFO - 2018-05-05 21:36:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:36:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:36:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:36:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-05 21:36:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:36:50 --> Final output sent to browser
DEBUG - 2018-05-05 21:36:50 --> Total execution time: 0.1370
INFO - 2018-05-05 21:36:52 --> Config Class Initialized
INFO - 2018-05-05 21:36:52 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:36:52 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:36:52 --> Utf8 Class Initialized
INFO - 2018-05-05 21:36:52 --> URI Class Initialized
INFO - 2018-05-05 21:36:52 --> Router Class Initialized
INFO - 2018-05-05 21:36:52 --> Output Class Initialized
INFO - 2018-05-05 21:36:52 --> Security Class Initialized
DEBUG - 2018-05-05 21:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:36:52 --> Input Class Initialized
INFO - 2018-05-05 21:36:52 --> Language Class Initialized
INFO - 2018-05-05 21:36:52 --> Loader Class Initialized
INFO - 2018-05-05 21:36:52 --> Helper loaded: common_helper
INFO - 2018-05-05 21:36:52 --> Database Driver Class Initialized
INFO - 2018-05-05 21:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:36:52 --> Email Class Initialized
INFO - 2018-05-05 21:36:52 --> Controller Class Initialized
INFO - 2018-05-05 21:36:52 --> Helper loaded: form_helper
INFO - 2018-05-05 21:36:52 --> Form Validation Class Initialized
INFO - 2018-05-05 21:36:52 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:36:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:36:52 --> Helper loaded: url_helper
INFO - 2018-05-05 21:36:52 --> Model Class Initialized
INFO - 2018-05-05 21:36:52 --> Model Class Initialized
INFO - 2018-05-05 21:36:52 --> Model Class Initialized
INFO - 2018-05-05 21:36:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:36:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:36:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 21:36:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:36:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:36:52 --> Final output sent to browser
DEBUG - 2018-05-05 21:36:52 --> Total execution time: 0.1570
INFO - 2018-05-05 21:36:54 --> Config Class Initialized
INFO - 2018-05-05 21:36:54 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:36:54 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:36:54 --> Utf8 Class Initialized
INFO - 2018-05-05 21:36:54 --> URI Class Initialized
INFO - 2018-05-05 21:36:54 --> Router Class Initialized
INFO - 2018-05-05 21:36:54 --> Output Class Initialized
INFO - 2018-05-05 21:36:54 --> Security Class Initialized
DEBUG - 2018-05-05 21:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:36:54 --> Input Class Initialized
INFO - 2018-05-05 21:36:54 --> Language Class Initialized
INFO - 2018-05-05 21:36:54 --> Loader Class Initialized
INFO - 2018-05-05 21:36:54 --> Helper loaded: common_helper
INFO - 2018-05-05 21:36:54 --> Database Driver Class Initialized
INFO - 2018-05-05 21:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:36:54 --> Email Class Initialized
INFO - 2018-05-05 21:36:54 --> Controller Class Initialized
INFO - 2018-05-05 21:36:54 --> Helper loaded: form_helper
INFO - 2018-05-05 21:36:54 --> Form Validation Class Initialized
INFO - 2018-05-05 21:36:54 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:36:54 --> Helper loaded: url_helper
INFO - 2018-05-05 21:36:54 --> Model Class Initialized
INFO - 2018-05-05 21:36:54 --> Model Class Initialized
INFO - 2018-05-05 21:36:54 --> Model Class Initialized
INFO - 2018-05-05 21:36:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:36:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:36:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:36:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:36:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:36:54 --> Final output sent to browser
DEBUG - 2018-05-05 21:36:54 --> Total execution time: 0.1390
INFO - 2018-05-05 21:37:31 --> Config Class Initialized
INFO - 2018-05-05 21:37:31 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:37:31 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:37:31 --> Utf8 Class Initialized
INFO - 2018-05-05 21:37:31 --> URI Class Initialized
INFO - 2018-05-05 21:37:31 --> Router Class Initialized
INFO - 2018-05-05 21:37:31 --> Output Class Initialized
INFO - 2018-05-05 21:37:31 --> Security Class Initialized
DEBUG - 2018-05-05 21:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:37:31 --> Input Class Initialized
INFO - 2018-05-05 21:37:31 --> Language Class Initialized
INFO - 2018-05-05 21:37:31 --> Loader Class Initialized
INFO - 2018-05-05 21:37:31 --> Helper loaded: common_helper
INFO - 2018-05-05 21:37:31 --> Database Driver Class Initialized
INFO - 2018-05-05 21:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:37:31 --> Email Class Initialized
INFO - 2018-05-05 21:37:31 --> Controller Class Initialized
INFO - 2018-05-05 21:37:31 --> Helper loaded: form_helper
INFO - 2018-05-05 21:37:31 --> Form Validation Class Initialized
INFO - 2018-05-05 21:37:31 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:37:31 --> Helper loaded: url_helper
INFO - 2018-05-05 21:37:31 --> Model Class Initialized
INFO - 2018-05-05 21:37:31 --> Model Class Initialized
INFO - 2018-05-05 21:37:31 --> Model Class Initialized
INFO - 2018-05-05 21:37:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:37:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:37:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:37:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:37:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 21:37:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:37:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:37:31 --> Final output sent to browser
DEBUG - 2018-05-05 21:37:31 --> Total execution time: 0.1370
INFO - 2018-05-05 21:37:36 --> Config Class Initialized
INFO - 2018-05-05 21:37:36 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:37:36 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:37:36 --> Utf8 Class Initialized
INFO - 2018-05-05 21:37:36 --> URI Class Initialized
INFO - 2018-05-05 21:37:36 --> Router Class Initialized
INFO - 2018-05-05 21:37:36 --> Output Class Initialized
INFO - 2018-05-05 21:37:36 --> Security Class Initialized
DEBUG - 2018-05-05 21:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:37:36 --> Input Class Initialized
INFO - 2018-05-05 21:37:36 --> Language Class Initialized
INFO - 2018-05-05 21:37:36 --> Loader Class Initialized
INFO - 2018-05-05 21:37:36 --> Helper loaded: common_helper
INFO - 2018-05-05 21:37:36 --> Database Driver Class Initialized
INFO - 2018-05-05 21:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:37:36 --> Email Class Initialized
INFO - 2018-05-05 21:37:36 --> Controller Class Initialized
INFO - 2018-05-05 21:37:36 --> Helper loaded: form_helper
INFO - 2018-05-05 21:37:36 --> Form Validation Class Initialized
INFO - 2018-05-05 21:37:36 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:37:36 --> Helper loaded: url_helper
INFO - 2018-05-05 21:37:36 --> Model Class Initialized
INFO - 2018-05-05 21:37:36 --> Model Class Initialized
INFO - 2018-05-05 21:37:36 --> Model Class Initialized
DEBUG - 2018-05-05 21:37:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:37:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-05 21:37:36 --> Config Class Initialized
INFO - 2018-05-05 21:37:36 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:37:36 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:37:36 --> Utf8 Class Initialized
INFO - 2018-05-05 21:37:36 --> URI Class Initialized
INFO - 2018-05-05 21:37:36 --> Router Class Initialized
INFO - 2018-05-05 21:37:36 --> Output Class Initialized
INFO - 2018-05-05 21:37:36 --> Security Class Initialized
DEBUG - 2018-05-05 21:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:37:36 --> Input Class Initialized
INFO - 2018-05-05 21:37:36 --> Language Class Initialized
INFO - 2018-05-05 21:37:36 --> Loader Class Initialized
INFO - 2018-05-05 21:37:36 --> Helper loaded: common_helper
INFO - 2018-05-05 21:37:36 --> Database Driver Class Initialized
INFO - 2018-05-05 21:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:37:36 --> Email Class Initialized
INFO - 2018-05-05 21:37:36 --> Controller Class Initialized
INFO - 2018-05-05 21:37:36 --> Helper loaded: form_helper
INFO - 2018-05-05 21:37:36 --> Form Validation Class Initialized
INFO - 2018-05-05 21:37:36 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:37:37 --> Helper loaded: url_helper
INFO - 2018-05-05 21:37:37 --> Model Class Initialized
INFO - 2018-05-05 21:37:37 --> Model Class Initialized
INFO - 2018-05-05 21:37:37 --> Model Class Initialized
INFO - 2018-05-05 21:37:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:37:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:37:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:37:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:37:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:37:37 --> Final output sent to browser
DEBUG - 2018-05-05 21:37:37 --> Total execution time: 0.1550
INFO - 2018-05-05 21:40:52 --> Config Class Initialized
INFO - 2018-05-05 21:40:52 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:40:52 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:40:52 --> Utf8 Class Initialized
INFO - 2018-05-05 21:40:52 --> URI Class Initialized
INFO - 2018-05-05 21:40:52 --> Router Class Initialized
INFO - 2018-05-05 21:40:52 --> Output Class Initialized
INFO - 2018-05-05 21:40:52 --> Security Class Initialized
DEBUG - 2018-05-05 21:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:40:52 --> Input Class Initialized
INFO - 2018-05-05 21:40:52 --> Language Class Initialized
INFO - 2018-05-05 21:40:52 --> Loader Class Initialized
INFO - 2018-05-05 21:40:52 --> Helper loaded: common_helper
INFO - 2018-05-05 21:40:52 --> Database Driver Class Initialized
INFO - 2018-05-05 21:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:40:52 --> Email Class Initialized
INFO - 2018-05-05 21:40:52 --> Controller Class Initialized
INFO - 2018-05-05 21:40:52 --> Helper loaded: form_helper
INFO - 2018-05-05 21:40:52 --> Form Validation Class Initialized
INFO - 2018-05-05 21:40:52 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:40:52 --> Helper loaded: url_helper
INFO - 2018-05-05 21:40:52 --> Model Class Initialized
INFO - 2018-05-05 21:40:52 --> Model Class Initialized
INFO - 2018-05-05 21:40:52 --> Model Class Initialized
INFO - 2018-05-05 21:40:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:40:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:40:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:40:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:40:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 21:40:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:40:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:40:52 --> Final output sent to browser
DEBUG - 2018-05-05 21:40:52 --> Total execution time: 0.1840
INFO - 2018-05-05 21:40:54 --> Config Class Initialized
INFO - 2018-05-05 21:40:54 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:40:54 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:40:54 --> Utf8 Class Initialized
INFO - 2018-05-05 21:40:54 --> URI Class Initialized
INFO - 2018-05-05 21:40:54 --> Router Class Initialized
INFO - 2018-05-05 21:40:54 --> Output Class Initialized
INFO - 2018-05-05 21:40:54 --> Security Class Initialized
DEBUG - 2018-05-05 21:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:40:54 --> Input Class Initialized
INFO - 2018-05-05 21:40:54 --> Language Class Initialized
INFO - 2018-05-05 21:40:54 --> Loader Class Initialized
INFO - 2018-05-05 21:40:54 --> Helper loaded: common_helper
INFO - 2018-05-05 21:40:54 --> Database Driver Class Initialized
INFO - 2018-05-05 21:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:40:54 --> Email Class Initialized
INFO - 2018-05-05 21:40:54 --> Controller Class Initialized
INFO - 2018-05-05 21:40:54 --> Helper loaded: form_helper
INFO - 2018-05-05 21:40:54 --> Form Validation Class Initialized
INFO - 2018-05-05 21:40:54 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:40:54 --> Helper loaded: url_helper
INFO - 2018-05-05 21:40:54 --> Model Class Initialized
INFO - 2018-05-05 21:40:54 --> Model Class Initialized
INFO - 2018-05-05 21:40:54 --> Model Class Initialized
INFO - 2018-05-05 21:40:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:40:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:40:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:40:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:40:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:40:54 --> Final output sent to browser
DEBUG - 2018-05-05 21:40:54 --> Total execution time: 0.1430
INFO - 2018-05-05 21:40:55 --> Config Class Initialized
INFO - 2018-05-05 21:40:55 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:40:55 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:40:55 --> Utf8 Class Initialized
INFO - 2018-05-05 21:40:55 --> URI Class Initialized
INFO - 2018-05-05 21:40:55 --> Router Class Initialized
INFO - 2018-05-05 21:40:55 --> Output Class Initialized
INFO - 2018-05-05 21:40:55 --> Security Class Initialized
DEBUG - 2018-05-05 21:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:40:55 --> Input Class Initialized
INFO - 2018-05-05 21:40:56 --> Language Class Initialized
INFO - 2018-05-05 21:40:56 --> Loader Class Initialized
INFO - 2018-05-05 21:40:56 --> Helper loaded: common_helper
INFO - 2018-05-05 21:40:56 --> Database Driver Class Initialized
INFO - 2018-05-05 21:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:40:56 --> Email Class Initialized
INFO - 2018-05-05 21:40:56 --> Controller Class Initialized
INFO - 2018-05-05 21:40:56 --> Helper loaded: form_helper
INFO - 2018-05-05 21:40:56 --> Form Validation Class Initialized
INFO - 2018-05-05 21:40:56 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:40:56 --> Helper loaded: url_helper
INFO - 2018-05-05 21:40:56 --> Model Class Initialized
INFO - 2018-05-05 21:40:56 --> Model Class Initialized
INFO - 2018-05-05 21:40:56 --> Model Class Initialized
INFO - 2018-05-05 21:40:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:40:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:40:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:40:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:40:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 21:40:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:40:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:40:56 --> Final output sent to browser
DEBUG - 2018-05-05 21:40:56 --> Total execution time: 0.1420
INFO - 2018-05-05 21:42:01 --> Config Class Initialized
INFO - 2018-05-05 21:42:01 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:42:01 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:42:01 --> Utf8 Class Initialized
INFO - 2018-05-05 21:42:01 --> URI Class Initialized
INFO - 2018-05-05 21:42:01 --> Router Class Initialized
INFO - 2018-05-05 21:42:01 --> Output Class Initialized
INFO - 2018-05-05 21:42:01 --> Security Class Initialized
DEBUG - 2018-05-05 21:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:42:01 --> Input Class Initialized
INFO - 2018-05-05 21:42:01 --> Language Class Initialized
INFO - 2018-05-05 21:42:01 --> Loader Class Initialized
INFO - 2018-05-05 21:42:01 --> Helper loaded: common_helper
INFO - 2018-05-05 21:42:01 --> Database Driver Class Initialized
INFO - 2018-05-05 21:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:42:01 --> Email Class Initialized
INFO - 2018-05-05 21:42:01 --> Controller Class Initialized
INFO - 2018-05-05 21:42:01 --> Helper loaded: form_helper
INFO - 2018-05-05 21:42:01 --> Form Validation Class Initialized
INFO - 2018-05-05 21:42:01 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:42:01 --> Helper loaded: url_helper
INFO - 2018-05-05 21:42:01 --> Model Class Initialized
INFO - 2018-05-05 21:42:01 --> Model Class Initialized
INFO - 2018-05-05 21:42:01 --> Model Class Initialized
INFO - 2018-05-05 21:42:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:42:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 21:42:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:42:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:42:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 21:42:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:42:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:42:01 --> Final output sent to browser
DEBUG - 2018-05-05 21:42:01 --> Total execution time: 0.1550
INFO - 2018-05-05 21:42:04 --> Config Class Initialized
INFO - 2018-05-05 21:42:04 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:42:04 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:42:04 --> Utf8 Class Initialized
INFO - 2018-05-05 21:42:04 --> URI Class Initialized
INFO - 2018-05-05 21:42:04 --> Router Class Initialized
INFO - 2018-05-05 21:42:04 --> Output Class Initialized
INFO - 2018-05-05 21:42:04 --> Security Class Initialized
DEBUG - 2018-05-05 21:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:42:04 --> Input Class Initialized
INFO - 2018-05-05 21:42:04 --> Language Class Initialized
INFO - 2018-05-05 21:42:04 --> Loader Class Initialized
INFO - 2018-05-05 21:42:04 --> Helper loaded: common_helper
INFO - 2018-05-05 21:42:04 --> Database Driver Class Initialized
INFO - 2018-05-05 21:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:42:04 --> Email Class Initialized
INFO - 2018-05-05 21:42:04 --> Controller Class Initialized
INFO - 2018-05-05 21:42:04 --> Helper loaded: form_helper
INFO - 2018-05-05 21:42:04 --> Form Validation Class Initialized
INFO - 2018-05-05 21:42:04 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:42:04 --> Helper loaded: url_helper
INFO - 2018-05-05 21:42:04 --> Model Class Initialized
INFO - 2018-05-05 21:42:04 --> Model Class Initialized
INFO - 2018-05-05 21:42:04 --> Model Class Initialized
INFO - 2018-05-05 21:42:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:42:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:42:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:42:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:42:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:42:04 --> Final output sent to browser
DEBUG - 2018-05-05 21:42:04 --> Total execution time: 0.1450
INFO - 2018-05-05 21:42:15 --> Config Class Initialized
INFO - 2018-05-05 21:42:15 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:42:15 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:42:15 --> Utf8 Class Initialized
INFO - 2018-05-05 21:42:15 --> URI Class Initialized
INFO - 2018-05-05 21:42:15 --> Router Class Initialized
INFO - 2018-05-05 21:42:15 --> Output Class Initialized
INFO - 2018-05-05 21:42:15 --> Security Class Initialized
DEBUG - 2018-05-05 21:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:42:15 --> Input Class Initialized
INFO - 2018-05-05 21:42:15 --> Language Class Initialized
INFO - 2018-05-05 21:42:15 --> Loader Class Initialized
INFO - 2018-05-05 21:42:15 --> Helper loaded: common_helper
INFO - 2018-05-05 21:42:15 --> Database Driver Class Initialized
INFO - 2018-05-05 21:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:42:15 --> Email Class Initialized
INFO - 2018-05-05 21:42:15 --> Controller Class Initialized
INFO - 2018-05-05 21:42:15 --> Helper loaded: form_helper
INFO - 2018-05-05 21:42:15 --> Form Validation Class Initialized
INFO - 2018-05-05 21:42:15 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:42:15 --> Helper loaded: url_helper
INFO - 2018-05-05 21:42:15 --> Model Class Initialized
INFO - 2018-05-05 21:42:15 --> Model Class Initialized
INFO - 2018-05-05 21:42:15 --> Model Class Initialized
INFO - 2018-05-05 21:42:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:42:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:42:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 21:42:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:42:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:42:15 --> Final output sent to browser
DEBUG - 2018-05-05 21:42:15 --> Total execution time: 0.1870
INFO - 2018-05-05 21:42:16 --> Config Class Initialized
INFO - 2018-05-05 21:42:16 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:42:16 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:42:16 --> Utf8 Class Initialized
INFO - 2018-05-05 21:42:16 --> URI Class Initialized
INFO - 2018-05-05 21:42:16 --> Router Class Initialized
INFO - 2018-05-05 21:42:16 --> Output Class Initialized
INFO - 2018-05-05 21:42:16 --> Security Class Initialized
DEBUG - 2018-05-05 21:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:42:16 --> Input Class Initialized
INFO - 2018-05-05 21:42:17 --> Language Class Initialized
INFO - 2018-05-05 21:42:17 --> Loader Class Initialized
INFO - 2018-05-05 21:42:17 --> Helper loaded: common_helper
INFO - 2018-05-05 21:42:17 --> Database Driver Class Initialized
INFO - 2018-05-05 21:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:42:17 --> Email Class Initialized
INFO - 2018-05-05 21:42:17 --> Controller Class Initialized
INFO - 2018-05-05 21:42:17 --> Helper loaded: form_helper
INFO - 2018-05-05 21:42:17 --> Form Validation Class Initialized
INFO - 2018-05-05 21:42:17 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:42:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:42:17 --> Helper loaded: url_helper
INFO - 2018-05-05 21:42:17 --> Model Class Initialized
INFO - 2018-05-05 21:42:17 --> Model Class Initialized
INFO - 2018-05-05 21:42:17 --> Model Class Initialized
INFO - 2018-05-05 21:42:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:42:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:42:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:42:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-05 21:42:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:42:17 --> Final output sent to browser
DEBUG - 2018-05-05 21:42:17 --> Total execution time: 0.1500
INFO - 2018-05-05 21:42:19 --> Config Class Initialized
INFO - 2018-05-05 21:42:19 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:42:19 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:42:19 --> Utf8 Class Initialized
INFO - 2018-05-05 21:42:19 --> URI Class Initialized
INFO - 2018-05-05 21:42:19 --> Router Class Initialized
INFO - 2018-05-05 21:42:19 --> Output Class Initialized
INFO - 2018-05-05 21:42:19 --> Security Class Initialized
DEBUG - 2018-05-05 21:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:42:19 --> Input Class Initialized
INFO - 2018-05-05 21:42:19 --> Language Class Initialized
INFO - 2018-05-05 21:42:19 --> Loader Class Initialized
INFO - 2018-05-05 21:42:19 --> Helper loaded: common_helper
INFO - 2018-05-05 21:42:19 --> Database Driver Class Initialized
INFO - 2018-05-05 21:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:42:19 --> Email Class Initialized
INFO - 2018-05-05 21:42:19 --> Controller Class Initialized
INFO - 2018-05-05 21:42:19 --> Helper loaded: form_helper
INFO - 2018-05-05 21:42:19 --> Form Validation Class Initialized
INFO - 2018-05-05 21:42:19 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:42:19 --> Helper loaded: url_helper
INFO - 2018-05-05 21:42:19 --> Model Class Initialized
INFO - 2018-05-05 21:42:19 --> Model Class Initialized
INFO - 2018-05-05 21:42:19 --> Model Class Initialized
INFO - 2018-05-05 21:42:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:42:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:42:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 21:42:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:42:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:42:19 --> Final output sent to browser
DEBUG - 2018-05-05 21:42:19 --> Total execution time: 0.1360
INFO - 2018-05-05 21:42:26 --> Config Class Initialized
INFO - 2018-05-05 21:42:26 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:42:26 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:42:26 --> Utf8 Class Initialized
INFO - 2018-05-05 21:42:26 --> URI Class Initialized
INFO - 2018-05-05 21:42:26 --> Router Class Initialized
INFO - 2018-05-05 21:42:26 --> Output Class Initialized
INFO - 2018-05-05 21:42:26 --> Security Class Initialized
DEBUG - 2018-05-05 21:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:42:26 --> Input Class Initialized
INFO - 2018-05-05 21:42:26 --> Language Class Initialized
INFO - 2018-05-05 21:42:26 --> Loader Class Initialized
INFO - 2018-05-05 21:42:26 --> Helper loaded: common_helper
INFO - 2018-05-05 21:42:26 --> Database Driver Class Initialized
INFO - 2018-05-05 21:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:42:26 --> Email Class Initialized
INFO - 2018-05-05 21:42:26 --> Controller Class Initialized
INFO - 2018-05-05 21:42:26 --> Helper loaded: form_helper
INFO - 2018-05-05 21:42:26 --> Form Validation Class Initialized
INFO - 2018-05-05 21:42:26 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:42:26 --> Helper loaded: url_helper
INFO - 2018-05-05 21:42:26 --> Model Class Initialized
INFO - 2018-05-05 21:42:26 --> Model Class Initialized
INFO - 2018-05-05 21:42:26 --> Model Class Initialized
INFO - 2018-05-05 21:42:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:42:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:42:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 21:42:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:42:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:42:26 --> Final output sent to browser
DEBUG - 2018-05-05 21:42:26 --> Total execution time: 0.2080
INFO - 2018-05-05 21:44:58 --> Config Class Initialized
INFO - 2018-05-05 21:44:58 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:44:58 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:44:58 --> Utf8 Class Initialized
INFO - 2018-05-05 21:44:58 --> URI Class Initialized
INFO - 2018-05-05 21:44:58 --> Router Class Initialized
INFO - 2018-05-05 21:44:58 --> Output Class Initialized
INFO - 2018-05-05 21:44:58 --> Security Class Initialized
DEBUG - 2018-05-05 21:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:44:58 --> Input Class Initialized
INFO - 2018-05-05 21:44:58 --> Language Class Initialized
INFO - 2018-05-05 21:44:58 --> Loader Class Initialized
INFO - 2018-05-05 21:44:58 --> Helper loaded: common_helper
INFO - 2018-05-05 21:44:58 --> Database Driver Class Initialized
INFO - 2018-05-05 21:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:44:58 --> Email Class Initialized
INFO - 2018-05-05 21:44:58 --> Controller Class Initialized
INFO - 2018-05-05 21:44:58 --> Helper loaded: form_helper
INFO - 2018-05-05 21:44:58 --> Form Validation Class Initialized
INFO - 2018-05-05 21:44:58 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:44:58 --> Helper loaded: url_helper
INFO - 2018-05-05 21:44:58 --> Model Class Initialized
INFO - 2018-05-05 21:44:58 --> Model Class Initialized
INFO - 2018-05-05 21:44:58 --> Model Class Initialized
INFO - 2018-05-05 21:44:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:44:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:44:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:44:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:44:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:44:58 --> Final output sent to browser
DEBUG - 2018-05-05 21:44:58 --> Total execution time: 0.1770
INFO - 2018-05-05 21:45:02 --> Config Class Initialized
INFO - 2018-05-05 21:45:02 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:45:02 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:45:02 --> Utf8 Class Initialized
INFO - 2018-05-05 21:45:02 --> URI Class Initialized
INFO - 2018-05-05 21:45:02 --> Router Class Initialized
INFO - 2018-05-05 21:45:02 --> Output Class Initialized
INFO - 2018-05-05 21:45:02 --> Security Class Initialized
DEBUG - 2018-05-05 21:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:45:02 --> Input Class Initialized
INFO - 2018-05-05 21:45:02 --> Language Class Initialized
INFO - 2018-05-05 21:45:02 --> Loader Class Initialized
INFO - 2018-05-05 21:45:02 --> Helper loaded: common_helper
INFO - 2018-05-05 21:45:02 --> Database Driver Class Initialized
INFO - 2018-05-05 21:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:45:02 --> Email Class Initialized
INFO - 2018-05-05 21:45:02 --> Controller Class Initialized
INFO - 2018-05-05 21:45:02 --> Helper loaded: form_helper
INFO - 2018-05-05 21:45:02 --> Form Validation Class Initialized
INFO - 2018-05-05 21:45:02 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:45:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:45:02 --> Helper loaded: url_helper
INFO - 2018-05-05 21:45:02 --> Model Class Initialized
INFO - 2018-05-05 21:45:02 --> Model Class Initialized
INFO - 2018-05-05 21:45:02 --> Model Class Initialized
INFO - 2018-05-05 21:45:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:45:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:45:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 21:45:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:45:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:45:02 --> Final output sent to browser
DEBUG - 2018-05-05 21:45:02 --> Total execution time: 0.1660
INFO - 2018-05-05 21:47:31 --> Config Class Initialized
INFO - 2018-05-05 21:47:31 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:47:31 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:47:31 --> Utf8 Class Initialized
INFO - 2018-05-05 21:47:31 --> URI Class Initialized
INFO - 2018-05-05 21:47:31 --> Router Class Initialized
INFO - 2018-05-05 21:47:31 --> Output Class Initialized
INFO - 2018-05-05 21:47:31 --> Security Class Initialized
DEBUG - 2018-05-05 21:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:47:31 --> Input Class Initialized
INFO - 2018-05-05 21:47:31 --> Language Class Initialized
INFO - 2018-05-05 21:47:31 --> Loader Class Initialized
INFO - 2018-05-05 21:47:31 --> Helper loaded: common_helper
INFO - 2018-05-05 21:47:31 --> Database Driver Class Initialized
INFO - 2018-05-05 21:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:47:31 --> Email Class Initialized
INFO - 2018-05-05 21:47:31 --> Controller Class Initialized
INFO - 2018-05-05 21:47:31 --> Helper loaded: form_helper
INFO - 2018-05-05 21:47:31 --> Form Validation Class Initialized
INFO - 2018-05-05 21:47:31 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:47:31 --> Helper loaded: url_helper
INFO - 2018-05-05 21:47:31 --> Model Class Initialized
INFO - 2018-05-05 21:47:31 --> Model Class Initialized
INFO - 2018-05-05 21:47:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:47:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:47:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:47:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\timeline/timeline.php
INFO - 2018-05-05 21:47:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:47:31 --> Final output sent to browser
DEBUG - 2018-05-05 21:47:31 --> Total execution time: 0.2140
INFO - 2018-05-05 21:47:33 --> Config Class Initialized
INFO - 2018-05-05 21:47:33 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:47:33 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:47:33 --> Utf8 Class Initialized
INFO - 2018-05-05 21:47:33 --> URI Class Initialized
INFO - 2018-05-05 21:47:33 --> Router Class Initialized
INFO - 2018-05-05 21:47:33 --> Output Class Initialized
INFO - 2018-05-05 21:47:33 --> Security Class Initialized
DEBUG - 2018-05-05 21:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:47:33 --> Input Class Initialized
INFO - 2018-05-05 21:47:33 --> Language Class Initialized
INFO - 2018-05-05 21:47:33 --> Loader Class Initialized
INFO - 2018-05-05 21:47:33 --> Helper loaded: common_helper
INFO - 2018-05-05 21:47:33 --> Database Driver Class Initialized
INFO - 2018-05-05 21:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:47:33 --> Email Class Initialized
INFO - 2018-05-05 21:47:33 --> Controller Class Initialized
INFO - 2018-05-05 21:47:33 --> Helper loaded: form_helper
INFO - 2018-05-05 21:47:33 --> Form Validation Class Initialized
INFO - 2018-05-05 21:47:33 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:47:33 --> Helper loaded: url_helper
INFO - 2018-05-05 21:47:33 --> Model Class Initialized
INFO - 2018-05-05 21:47:33 --> Model Class Initialized
INFO - 2018-05-05 21:47:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:47:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:47:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:47:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\timeline/addTimeline.php
INFO - 2018-05-05 21:47:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:47:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:47:33 --> Final output sent to browser
DEBUG - 2018-05-05 21:47:33 --> Total execution time: 0.1860
INFO - 2018-05-05 21:48:56 --> Config Class Initialized
INFO - 2018-05-05 21:48:56 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:48:56 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:48:56 --> Utf8 Class Initialized
INFO - 2018-05-05 21:48:56 --> URI Class Initialized
INFO - 2018-05-05 21:48:56 --> Router Class Initialized
INFO - 2018-05-05 21:48:56 --> Output Class Initialized
INFO - 2018-05-05 21:48:56 --> Security Class Initialized
DEBUG - 2018-05-05 21:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:48:56 --> Input Class Initialized
INFO - 2018-05-05 21:48:56 --> Language Class Initialized
INFO - 2018-05-05 21:48:56 --> Loader Class Initialized
INFO - 2018-05-05 21:48:56 --> Helper loaded: common_helper
INFO - 2018-05-05 21:48:56 --> Database Driver Class Initialized
INFO - 2018-05-05 21:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:48:56 --> Email Class Initialized
INFO - 2018-05-05 21:48:56 --> Controller Class Initialized
INFO - 2018-05-05 21:48:56 --> Helper loaded: form_helper
INFO - 2018-05-05 21:48:56 --> Form Validation Class Initialized
INFO - 2018-05-05 21:48:56 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:48:56 --> Helper loaded: url_helper
INFO - 2018-05-05 21:48:56 --> Model Class Initialized
INFO - 2018-05-05 21:48:56 --> Model Class Initialized
INFO - 2018-05-05 21:48:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:48:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:48:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:48:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\timeline/timeline.php
INFO - 2018-05-05 21:48:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:48:56 --> Final output sent to browser
DEBUG - 2018-05-05 21:48:56 --> Total execution time: 0.1790
INFO - 2018-05-05 21:48:59 --> Config Class Initialized
INFO - 2018-05-05 21:48:59 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:48:59 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:48:59 --> Utf8 Class Initialized
INFO - 2018-05-05 21:48:59 --> URI Class Initialized
INFO - 2018-05-05 21:48:59 --> Router Class Initialized
INFO - 2018-05-05 21:48:59 --> Output Class Initialized
INFO - 2018-05-05 21:48:59 --> Security Class Initialized
DEBUG - 2018-05-05 21:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:48:59 --> Input Class Initialized
INFO - 2018-05-05 21:48:59 --> Language Class Initialized
INFO - 2018-05-05 21:48:59 --> Loader Class Initialized
INFO - 2018-05-05 21:48:59 --> Helper loaded: common_helper
INFO - 2018-05-05 21:48:59 --> Database Driver Class Initialized
INFO - 2018-05-05 21:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:48:59 --> Email Class Initialized
INFO - 2018-05-05 21:48:59 --> Controller Class Initialized
INFO - 2018-05-05 21:48:59 --> Helper loaded: form_helper
INFO - 2018-05-05 21:48:59 --> Form Validation Class Initialized
INFO - 2018-05-05 21:48:59 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:48:59 --> Helper loaded: url_helper
INFO - 2018-05-05 21:48:59 --> Model Class Initialized
INFO - 2018-05-05 21:48:59 --> Model Class Initialized
INFO - 2018-05-05 21:48:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:48:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:48:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:48:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\timeline/editTimeline.php
INFO - 2018-05-05 21:48:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:48:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:48:59 --> Final output sent to browser
DEBUG - 2018-05-05 21:48:59 --> Total execution time: 0.1330
INFO - 2018-05-05 21:49:01 --> Config Class Initialized
INFO - 2018-05-05 21:49:01 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:49:01 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:49:01 --> Utf8 Class Initialized
INFO - 2018-05-05 21:49:01 --> URI Class Initialized
INFO - 2018-05-05 21:49:01 --> Router Class Initialized
INFO - 2018-05-05 21:49:01 --> Output Class Initialized
INFO - 2018-05-05 21:49:01 --> Security Class Initialized
DEBUG - 2018-05-05 21:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:49:01 --> Input Class Initialized
INFO - 2018-05-05 21:49:01 --> Language Class Initialized
INFO - 2018-05-05 21:49:01 --> Loader Class Initialized
INFO - 2018-05-05 21:49:01 --> Helper loaded: common_helper
INFO - 2018-05-05 21:49:01 --> Database Driver Class Initialized
INFO - 2018-05-05 21:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:49:01 --> Email Class Initialized
INFO - 2018-05-05 21:49:01 --> Controller Class Initialized
INFO - 2018-05-05 21:49:01 --> Helper loaded: form_helper
INFO - 2018-05-05 21:49:01 --> Form Validation Class Initialized
INFO - 2018-05-05 21:49:01 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:49:01 --> Helper loaded: url_helper
INFO - 2018-05-05 21:49:01 --> Model Class Initialized
INFO - 2018-05-05 21:49:01 --> Model Class Initialized
INFO - 2018-05-05 21:49:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:49:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:49:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:49:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\timeline/timeline.php
INFO - 2018-05-05 21:49:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:49:01 --> Final output sent to browser
DEBUG - 2018-05-05 21:49:01 --> Total execution time: 0.2120
INFO - 2018-05-05 21:49:03 --> Config Class Initialized
INFO - 2018-05-05 21:49:03 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:49:03 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:49:03 --> Utf8 Class Initialized
INFO - 2018-05-05 21:49:03 --> URI Class Initialized
INFO - 2018-05-05 21:49:03 --> Router Class Initialized
INFO - 2018-05-05 21:49:03 --> Output Class Initialized
INFO - 2018-05-05 21:49:03 --> Security Class Initialized
DEBUG - 2018-05-05 21:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:49:03 --> Input Class Initialized
INFO - 2018-05-05 21:49:03 --> Language Class Initialized
INFO - 2018-05-05 21:49:03 --> Loader Class Initialized
INFO - 2018-05-05 21:49:03 --> Helper loaded: common_helper
INFO - 2018-05-05 21:49:03 --> Database Driver Class Initialized
INFO - 2018-05-05 21:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:49:03 --> Email Class Initialized
INFO - 2018-05-05 21:49:03 --> Controller Class Initialized
INFO - 2018-05-05 21:49:03 --> Helper loaded: form_helper
INFO - 2018-05-05 21:49:03 --> Form Validation Class Initialized
INFO - 2018-05-05 21:49:03 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:49:03 --> Helper loaded: url_helper
INFO - 2018-05-05 21:49:03 --> Model Class Initialized
INFO - 2018-05-05 21:49:03 --> Model Class Initialized
INFO - 2018-05-05 21:49:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:49:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:49:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:49:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\timeline/editTimeline.php
INFO - 2018-05-05 21:49:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:49:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:49:03 --> Final output sent to browser
DEBUG - 2018-05-05 21:49:03 --> Total execution time: 0.1300
INFO - 2018-05-05 21:50:13 --> Config Class Initialized
INFO - 2018-05-05 21:50:13 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:50:13 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:50:13 --> Utf8 Class Initialized
INFO - 2018-05-05 21:50:13 --> URI Class Initialized
INFO - 2018-05-05 21:50:13 --> Router Class Initialized
INFO - 2018-05-05 21:50:13 --> Output Class Initialized
INFO - 2018-05-05 21:50:13 --> Security Class Initialized
DEBUG - 2018-05-05 21:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:50:13 --> Input Class Initialized
INFO - 2018-05-05 21:50:13 --> Language Class Initialized
INFO - 2018-05-05 21:50:13 --> Loader Class Initialized
INFO - 2018-05-05 21:50:13 --> Helper loaded: common_helper
INFO - 2018-05-05 21:50:13 --> Database Driver Class Initialized
INFO - 2018-05-05 21:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:50:13 --> Email Class Initialized
INFO - 2018-05-05 21:50:13 --> Controller Class Initialized
INFO - 2018-05-05 21:50:13 --> Helper loaded: form_helper
INFO - 2018-05-05 21:50:13 --> Form Validation Class Initialized
INFO - 2018-05-05 21:50:13 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:50:13 --> Helper loaded: url_helper
INFO - 2018-05-05 21:50:13 --> Model Class Initialized
INFO - 2018-05-05 21:50:13 --> Model Class Initialized
INFO - 2018-05-05 21:50:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:50:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:50:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:50:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\timeline/timeline.php
INFO - 2018-05-05 21:50:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:50:13 --> Final output sent to browser
DEBUG - 2018-05-05 21:50:13 --> Total execution time: 0.1730
INFO - 2018-05-05 21:50:18 --> Config Class Initialized
INFO - 2018-05-05 21:50:18 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:50:18 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:50:18 --> Utf8 Class Initialized
INFO - 2018-05-05 21:50:18 --> URI Class Initialized
INFO - 2018-05-05 21:50:18 --> Router Class Initialized
INFO - 2018-05-05 21:50:18 --> Output Class Initialized
INFO - 2018-05-05 21:50:18 --> Security Class Initialized
DEBUG - 2018-05-05 21:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:50:18 --> Input Class Initialized
INFO - 2018-05-05 21:50:18 --> Language Class Initialized
INFO - 2018-05-05 21:50:18 --> Loader Class Initialized
INFO - 2018-05-05 21:50:18 --> Helper loaded: common_helper
INFO - 2018-05-05 21:50:18 --> Database Driver Class Initialized
INFO - 2018-05-05 21:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:50:19 --> Email Class Initialized
INFO - 2018-05-05 21:50:19 --> Controller Class Initialized
INFO - 2018-05-05 21:50:19 --> Helper loaded: form_helper
INFO - 2018-05-05 21:50:19 --> Form Validation Class Initialized
INFO - 2018-05-05 21:50:19 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:50:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:50:19 --> Helper loaded: url_helper
INFO - 2018-05-05 21:50:19 --> Model Class Initialized
INFO - 2018-05-05 21:50:19 --> Model Class Initialized
INFO - 2018-05-05 21:50:19 --> Model Class Initialized
INFO - 2018-05-05 21:50:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:50:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:50:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 21:50:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:50:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:50:19 --> Final output sent to browser
DEBUG - 2018-05-05 21:50:19 --> Total execution time: 0.2230
INFO - 2018-05-05 21:50:20 --> Config Class Initialized
INFO - 2018-05-05 21:50:20 --> Hooks Class Initialized
DEBUG - 2018-05-05 21:50:20 --> UTF-8 Support Enabled
INFO - 2018-05-05 21:50:20 --> Utf8 Class Initialized
INFO - 2018-05-05 21:50:20 --> URI Class Initialized
INFO - 2018-05-05 21:50:20 --> Router Class Initialized
INFO - 2018-05-05 21:50:20 --> Output Class Initialized
INFO - 2018-05-05 21:50:20 --> Security Class Initialized
DEBUG - 2018-05-05 21:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 21:50:20 --> Input Class Initialized
INFO - 2018-05-05 21:50:20 --> Language Class Initialized
INFO - 2018-05-05 21:50:20 --> Loader Class Initialized
INFO - 2018-05-05 21:50:20 --> Helper loaded: common_helper
INFO - 2018-05-05 21:50:20 --> Database Driver Class Initialized
INFO - 2018-05-05 21:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 21:50:20 --> Email Class Initialized
INFO - 2018-05-05 21:50:20 --> Controller Class Initialized
INFO - 2018-05-05 21:50:20 --> Helper loaded: form_helper
INFO - 2018-05-05 21:50:20 --> Form Validation Class Initialized
INFO - 2018-05-05 21:50:20 --> Helper loaded: email_helper
DEBUG - 2018-05-05 21:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 21:50:20 --> Helper loaded: url_helper
INFO - 2018-05-05 21:50:20 --> Model Class Initialized
INFO - 2018-05-05 21:50:20 --> Model Class Initialized
INFO - 2018-05-05 21:50:20 --> Model Class Initialized
INFO - 2018-05-05 21:50:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 21:50:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 21:50:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 21:50:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 21:50:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 21:50:20 --> Final output sent to browser
DEBUG - 2018-05-05 21:50:20 --> Total execution time: 0.1520
INFO - 2018-05-05 22:30:43 --> Config Class Initialized
INFO - 2018-05-05 22:30:43 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:30:43 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:30:43 --> Utf8 Class Initialized
INFO - 2018-05-05 22:30:43 --> URI Class Initialized
INFO - 2018-05-05 22:30:43 --> Router Class Initialized
INFO - 2018-05-05 22:30:43 --> Output Class Initialized
INFO - 2018-05-05 22:30:43 --> Security Class Initialized
DEBUG - 2018-05-05 22:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:30:43 --> Input Class Initialized
INFO - 2018-05-05 22:30:43 --> Language Class Initialized
INFO - 2018-05-05 22:30:43 --> Loader Class Initialized
INFO - 2018-05-05 22:30:43 --> Helper loaded: common_helper
INFO - 2018-05-05 22:30:43 --> Database Driver Class Initialized
INFO - 2018-05-05 22:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:30:43 --> Email Class Initialized
INFO - 2018-05-05 22:30:43 --> Controller Class Initialized
INFO - 2018-05-05 22:30:43 --> Helper loaded: form_helper
INFO - 2018-05-05 22:30:43 --> Form Validation Class Initialized
INFO - 2018-05-05 22:30:43 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:30:43 --> Helper loaded: url_helper
INFO - 2018-05-05 22:30:43 --> Model Class Initialized
INFO - 2018-05-05 22:30:43 --> Model Class Initialized
INFO - 2018-05-05 22:30:43 --> Model Class Initialized
INFO - 2018-05-05 22:30:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 22:30:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 22:30:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 22:30:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:30:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 22:30:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:30:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 22:30:43 --> Final output sent to browser
DEBUG - 2018-05-05 22:30:43 --> Total execution time: 0.1750
INFO - 2018-05-05 22:30:45 --> Config Class Initialized
INFO - 2018-05-05 22:30:45 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:30:45 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:30:45 --> Utf8 Class Initialized
INFO - 2018-05-05 22:30:45 --> URI Class Initialized
INFO - 2018-05-05 22:30:45 --> Router Class Initialized
INFO - 2018-05-05 22:30:45 --> Output Class Initialized
INFO - 2018-05-05 22:30:45 --> Security Class Initialized
DEBUG - 2018-05-05 22:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:30:45 --> Input Class Initialized
INFO - 2018-05-05 22:30:45 --> Language Class Initialized
INFO - 2018-05-05 22:30:46 --> Loader Class Initialized
INFO - 2018-05-05 22:30:46 --> Helper loaded: common_helper
INFO - 2018-05-05 22:30:46 --> Database Driver Class Initialized
INFO - 2018-05-05 22:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:30:46 --> Email Class Initialized
INFO - 2018-05-05 22:30:46 --> Controller Class Initialized
INFO - 2018-05-05 22:30:46 --> Helper loaded: form_helper
INFO - 2018-05-05 22:30:46 --> Form Validation Class Initialized
INFO - 2018-05-05 22:30:46 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:30:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:30:46 --> Helper loaded: url_helper
INFO - 2018-05-05 22:30:46 --> Model Class Initialized
INFO - 2018-05-05 22:30:46 --> Model Class Initialized
INFO - 2018-05-05 22:30:46 --> Model Class Initialized
DEBUG - 2018-05-05 22:30:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:30:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-05 22:30:46 --> Config Class Initialized
INFO - 2018-05-05 22:30:46 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:30:46 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:30:46 --> Utf8 Class Initialized
INFO - 2018-05-05 22:30:46 --> URI Class Initialized
INFO - 2018-05-05 22:30:46 --> Router Class Initialized
INFO - 2018-05-05 22:30:46 --> Output Class Initialized
INFO - 2018-05-05 22:30:46 --> Security Class Initialized
DEBUG - 2018-05-05 22:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:30:46 --> Input Class Initialized
INFO - 2018-05-05 22:30:46 --> Language Class Initialized
INFO - 2018-05-05 22:30:46 --> Loader Class Initialized
INFO - 2018-05-05 22:30:46 --> Helper loaded: common_helper
INFO - 2018-05-05 22:30:46 --> Database Driver Class Initialized
INFO - 2018-05-05 22:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:30:46 --> Email Class Initialized
INFO - 2018-05-05 22:30:46 --> Controller Class Initialized
INFO - 2018-05-05 22:30:46 --> Helper loaded: form_helper
INFO - 2018-05-05 22:30:46 --> Form Validation Class Initialized
INFO - 2018-05-05 22:30:46 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:30:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:30:46 --> Helper loaded: url_helper
INFO - 2018-05-05 22:30:46 --> Model Class Initialized
INFO - 2018-05-05 22:30:46 --> Model Class Initialized
INFO - 2018-05-05 22:30:46 --> Model Class Initialized
INFO - 2018-05-05 22:30:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 22:30:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 22:30:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:30:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 22:30:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 22:30:46 --> Final output sent to browser
DEBUG - 2018-05-05 22:30:46 --> Total execution time: 0.1330
INFO - 2018-05-05 22:31:54 --> Config Class Initialized
INFO - 2018-05-05 22:31:54 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:31:54 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:31:54 --> Utf8 Class Initialized
INFO - 2018-05-05 22:31:54 --> URI Class Initialized
INFO - 2018-05-05 22:31:54 --> Router Class Initialized
INFO - 2018-05-05 22:31:54 --> Output Class Initialized
INFO - 2018-05-05 22:31:54 --> Security Class Initialized
DEBUG - 2018-05-05 22:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:31:54 --> Input Class Initialized
INFO - 2018-05-05 22:31:54 --> Language Class Initialized
INFO - 2018-05-05 22:31:54 --> Loader Class Initialized
INFO - 2018-05-05 22:31:54 --> Helper loaded: common_helper
INFO - 2018-05-05 22:31:54 --> Database Driver Class Initialized
INFO - 2018-05-05 22:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:31:54 --> Email Class Initialized
INFO - 2018-05-05 22:31:54 --> Controller Class Initialized
INFO - 2018-05-05 22:31:55 --> Helper loaded: form_helper
INFO - 2018-05-05 22:31:55 --> Form Validation Class Initialized
INFO - 2018-05-05 22:31:55 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:31:55 --> Helper loaded: url_helper
INFO - 2018-05-05 22:31:55 --> Model Class Initialized
INFO - 2018-05-05 22:31:55 --> Model Class Initialized
INFO - 2018-05-05 22:31:55 --> Model Class Initialized
INFO - 2018-05-05 22:31:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 22:31:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 22:31:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:31:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 22:31:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 22:31:55 --> Final output sent to browser
DEBUG - 2018-05-05 22:31:55 --> Total execution time: 0.1350
INFO - 2018-05-05 22:31:59 --> Config Class Initialized
INFO - 2018-05-05 22:31:59 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:31:59 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:31:59 --> Utf8 Class Initialized
INFO - 2018-05-05 22:31:59 --> URI Class Initialized
INFO - 2018-05-05 22:31:59 --> Router Class Initialized
INFO - 2018-05-05 22:31:59 --> Output Class Initialized
INFO - 2018-05-05 22:32:00 --> Security Class Initialized
DEBUG - 2018-05-05 22:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:32:00 --> Input Class Initialized
INFO - 2018-05-05 22:32:00 --> Language Class Initialized
INFO - 2018-05-05 22:32:00 --> Loader Class Initialized
INFO - 2018-05-05 22:32:00 --> Helper loaded: common_helper
INFO - 2018-05-05 22:32:00 --> Database Driver Class Initialized
INFO - 2018-05-05 22:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:32:00 --> Email Class Initialized
INFO - 2018-05-05 22:32:00 --> Controller Class Initialized
INFO - 2018-05-05 22:32:00 --> Helper loaded: form_helper
INFO - 2018-05-05 22:32:00 --> Form Validation Class Initialized
INFO - 2018-05-05 22:32:00 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:32:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:32:00 --> Helper loaded: url_helper
INFO - 2018-05-05 22:32:00 --> Model Class Initialized
INFO - 2018-05-05 22:32:00 --> Model Class Initialized
INFO - 2018-05-05 22:32:00 --> Model Class Initialized
INFO - 2018-05-05 22:32:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 22:32:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 22:32:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 22:32:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:32:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addMovie.php
INFO - 2018-05-05 22:32:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:32:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 22:32:00 --> Final output sent to browser
DEBUG - 2018-05-05 22:32:00 --> Total execution time: 0.1340
INFO - 2018-05-05 22:32:01 --> Config Class Initialized
INFO - 2018-05-05 22:32:01 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:32:01 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:32:01 --> Utf8 Class Initialized
INFO - 2018-05-05 22:32:01 --> URI Class Initialized
INFO - 2018-05-05 22:32:01 --> Router Class Initialized
INFO - 2018-05-05 22:32:01 --> Output Class Initialized
INFO - 2018-05-05 22:32:01 --> Security Class Initialized
DEBUG - 2018-05-05 22:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:32:01 --> Input Class Initialized
INFO - 2018-05-05 22:32:01 --> Language Class Initialized
INFO - 2018-05-05 22:32:01 --> Loader Class Initialized
INFO - 2018-05-05 22:32:01 --> Helper loaded: common_helper
INFO - 2018-05-05 22:32:01 --> Database Driver Class Initialized
INFO - 2018-05-05 22:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:32:01 --> Email Class Initialized
INFO - 2018-05-05 22:32:01 --> Controller Class Initialized
INFO - 2018-05-05 22:32:01 --> Helper loaded: form_helper
INFO - 2018-05-05 22:32:01 --> Form Validation Class Initialized
INFO - 2018-05-05 22:32:01 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:32:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:32:01 --> Helper loaded: url_helper
INFO - 2018-05-05 22:32:01 --> Model Class Initialized
INFO - 2018-05-05 22:32:01 --> Model Class Initialized
INFO - 2018-05-05 22:32:01 --> Model Class Initialized
INFO - 2018-05-05 22:32:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 22:32:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 22:32:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:32:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 22:32:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 22:32:01 --> Final output sent to browser
DEBUG - 2018-05-05 22:32:01 --> Total execution time: 0.1440
INFO - 2018-05-05 22:35:56 --> Config Class Initialized
INFO - 2018-05-05 22:35:56 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:35:56 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:35:56 --> Utf8 Class Initialized
INFO - 2018-05-05 22:35:56 --> URI Class Initialized
INFO - 2018-05-05 22:35:56 --> Router Class Initialized
INFO - 2018-05-05 22:35:56 --> Output Class Initialized
INFO - 2018-05-05 22:35:56 --> Security Class Initialized
DEBUG - 2018-05-05 22:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:35:56 --> Input Class Initialized
INFO - 2018-05-05 22:35:56 --> Language Class Initialized
INFO - 2018-05-05 22:35:56 --> Loader Class Initialized
INFO - 2018-05-05 22:35:56 --> Helper loaded: common_helper
INFO - 2018-05-05 22:35:56 --> Database Driver Class Initialized
INFO - 2018-05-05 22:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:35:56 --> Email Class Initialized
INFO - 2018-05-05 22:35:56 --> Controller Class Initialized
INFO - 2018-05-05 22:35:56 --> Helper loaded: form_helper
INFO - 2018-05-05 22:35:56 --> Form Validation Class Initialized
INFO - 2018-05-05 22:35:56 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:35:56 --> Helper loaded: url_helper
INFO - 2018-05-05 22:35:56 --> Model Class Initialized
INFO - 2018-05-05 22:35:56 --> Model Class Initialized
INFO - 2018-05-05 22:35:56 --> Model Class Initialized
INFO - 2018-05-05 22:35:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 22:35:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 22:35:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 22:35:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:35:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addMovie.php
INFO - 2018-05-05 22:35:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:35:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 22:35:56 --> Final output sent to browser
DEBUG - 2018-05-05 22:35:56 --> Total execution time: 0.1380
INFO - 2018-05-05 22:35:58 --> Config Class Initialized
INFO - 2018-05-05 22:35:58 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:35:58 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:35:58 --> Utf8 Class Initialized
INFO - 2018-05-05 22:35:58 --> URI Class Initialized
INFO - 2018-05-05 22:35:58 --> Router Class Initialized
INFO - 2018-05-05 22:35:58 --> Output Class Initialized
INFO - 2018-05-05 22:35:58 --> Security Class Initialized
DEBUG - 2018-05-05 22:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:35:58 --> Input Class Initialized
INFO - 2018-05-05 22:35:58 --> Language Class Initialized
INFO - 2018-05-05 22:35:58 --> Loader Class Initialized
INFO - 2018-05-05 22:35:58 --> Helper loaded: common_helper
INFO - 2018-05-05 22:35:58 --> Database Driver Class Initialized
INFO - 2018-05-05 22:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:35:58 --> Email Class Initialized
INFO - 2018-05-05 22:35:58 --> Controller Class Initialized
INFO - 2018-05-05 22:35:58 --> Helper loaded: form_helper
INFO - 2018-05-05 22:35:58 --> Form Validation Class Initialized
INFO - 2018-05-05 22:35:58 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:35:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:35:58 --> Helper loaded: url_helper
INFO - 2018-05-05 22:35:58 --> Model Class Initialized
INFO - 2018-05-05 22:35:58 --> Model Class Initialized
INFO - 2018-05-05 22:35:58 --> Model Class Initialized
INFO - 2018-05-05 22:35:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 22:35:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 22:35:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:35:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 22:35:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 22:35:58 --> Final output sent to browser
DEBUG - 2018-05-05 22:35:58 --> Total execution time: 0.1470
INFO - 2018-05-05 22:36:40 --> Config Class Initialized
INFO - 2018-05-05 22:36:40 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:36:40 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:36:40 --> Utf8 Class Initialized
INFO - 2018-05-05 22:36:40 --> URI Class Initialized
INFO - 2018-05-05 22:36:40 --> Router Class Initialized
INFO - 2018-05-05 22:36:40 --> Output Class Initialized
INFO - 2018-05-05 22:36:40 --> Security Class Initialized
DEBUG - 2018-05-05 22:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:36:40 --> Input Class Initialized
INFO - 2018-05-05 22:36:40 --> Language Class Initialized
INFO - 2018-05-05 22:36:40 --> Loader Class Initialized
INFO - 2018-05-05 22:36:40 --> Helper loaded: common_helper
INFO - 2018-05-05 22:36:40 --> Database Driver Class Initialized
INFO - 2018-05-05 22:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:36:40 --> Email Class Initialized
INFO - 2018-05-05 22:36:40 --> Controller Class Initialized
INFO - 2018-05-05 22:36:40 --> Helper loaded: form_helper
INFO - 2018-05-05 22:36:40 --> Form Validation Class Initialized
INFO - 2018-05-05 22:36:40 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:36:40 --> Helper loaded: url_helper
INFO - 2018-05-05 22:36:40 --> Model Class Initialized
INFO - 2018-05-05 22:36:40 --> Model Class Initialized
INFO - 2018-05-05 22:36:40 --> Model Class Initialized
INFO - 2018-05-05 22:36:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 22:36:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 22:36:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 22:36:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:36:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editMovie.php
INFO - 2018-05-05 22:36:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:36:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 22:36:40 --> Final output sent to browser
DEBUG - 2018-05-05 22:36:40 --> Total execution time: 0.1610
INFO - 2018-05-05 22:36:40 --> Config Class Initialized
INFO - 2018-05-05 22:36:40 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:36:40 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:36:40 --> Utf8 Class Initialized
INFO - 2018-05-05 22:36:40 --> URI Class Initialized
INFO - 2018-05-05 22:36:40 --> Router Class Initialized
INFO - 2018-05-05 22:36:40 --> Output Class Initialized
INFO - 2018-05-05 22:36:40 --> Security Class Initialized
DEBUG - 2018-05-05 22:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:36:40 --> Input Class Initialized
INFO - 2018-05-05 22:36:40 --> Language Class Initialized
INFO - 2018-05-05 22:36:40 --> Loader Class Initialized
INFO - 2018-05-05 22:36:40 --> Helper loaded: common_helper
INFO - 2018-05-05 22:36:40 --> Database Driver Class Initialized
INFO - 2018-05-05 22:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:36:41 --> Email Class Initialized
INFO - 2018-05-05 22:36:41 --> Controller Class Initialized
INFO - 2018-05-05 22:36:41 --> Helper loaded: form_helper
INFO - 2018-05-05 22:36:41 --> Form Validation Class Initialized
INFO - 2018-05-05 22:36:41 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:36:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:36:41 --> Helper loaded: url_helper
INFO - 2018-05-05 22:36:41 --> Model Class Initialized
INFO - 2018-05-05 22:36:41 --> Model Class Initialized
INFO - 2018-05-05 22:36:41 --> Model Class Initialized
INFO - 2018-05-05 22:36:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 22:36:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 22:36:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:36:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 22:36:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 22:36:41 --> Final output sent to browser
DEBUG - 2018-05-05 22:36:41 --> Total execution time: 0.1800
INFO - 2018-05-05 22:36:58 --> Config Class Initialized
INFO - 2018-05-05 22:36:58 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:36:58 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:36:58 --> Utf8 Class Initialized
INFO - 2018-05-05 22:36:58 --> URI Class Initialized
INFO - 2018-05-05 22:36:58 --> Router Class Initialized
INFO - 2018-05-05 22:36:58 --> Output Class Initialized
INFO - 2018-05-05 22:36:58 --> Security Class Initialized
DEBUG - 2018-05-05 22:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:36:58 --> Input Class Initialized
INFO - 2018-05-05 22:36:58 --> Language Class Initialized
INFO - 2018-05-05 22:36:58 --> Loader Class Initialized
INFO - 2018-05-05 22:36:58 --> Helper loaded: common_helper
INFO - 2018-05-05 22:36:58 --> Database Driver Class Initialized
INFO - 2018-05-05 22:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:36:58 --> Email Class Initialized
INFO - 2018-05-05 22:36:58 --> Controller Class Initialized
INFO - 2018-05-05 22:36:58 --> Helper loaded: form_helper
INFO - 2018-05-05 22:36:58 --> Form Validation Class Initialized
INFO - 2018-05-05 22:36:58 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:36:58 --> Helper loaded: url_helper
INFO - 2018-05-05 22:36:58 --> Model Class Initialized
INFO - 2018-05-05 22:36:58 --> Model Class Initialized
INFO - 2018-05-05 22:36:58 --> Model Class Initialized
INFO - 2018-05-05 22:36:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 22:36:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-05 22:36:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 22:36:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:36:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/addMovie.php
INFO - 2018-05-05 22:36:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:36:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 22:36:58 --> Final output sent to browser
DEBUG - 2018-05-05 22:36:58 --> Total execution time: 0.1360
INFO - 2018-05-05 22:37:00 --> Config Class Initialized
INFO - 2018-05-05 22:37:00 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:37:00 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:37:00 --> Utf8 Class Initialized
INFO - 2018-05-05 22:37:00 --> URI Class Initialized
INFO - 2018-05-05 22:37:00 --> Router Class Initialized
INFO - 2018-05-05 22:37:00 --> Output Class Initialized
INFO - 2018-05-05 22:37:00 --> Security Class Initialized
DEBUG - 2018-05-05 22:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:37:00 --> Input Class Initialized
INFO - 2018-05-05 22:37:00 --> Language Class Initialized
INFO - 2018-05-05 22:37:00 --> Loader Class Initialized
INFO - 2018-05-05 22:37:00 --> Helper loaded: common_helper
INFO - 2018-05-05 22:37:00 --> Database Driver Class Initialized
INFO - 2018-05-05 22:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:37:00 --> Email Class Initialized
INFO - 2018-05-05 22:37:00 --> Controller Class Initialized
INFO - 2018-05-05 22:37:00 --> Helper loaded: form_helper
INFO - 2018-05-05 22:37:00 --> Form Validation Class Initialized
INFO - 2018-05-05 22:37:00 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:37:00 --> Helper loaded: url_helper
INFO - 2018-05-05 22:37:00 --> Model Class Initialized
INFO - 2018-05-05 22:37:00 --> Model Class Initialized
INFO - 2018-05-05 22:37:00 --> Model Class Initialized
INFO - 2018-05-05 22:37:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 22:37:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 22:37:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:37:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-05 22:37:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 22:37:00 --> Final output sent to browser
DEBUG - 2018-05-05 22:37:00 --> Total execution time: 0.1900
INFO - 2018-05-05 22:39:15 --> Config Class Initialized
INFO - 2018-05-05 22:39:15 --> Hooks Class Initialized
DEBUG - 2018-05-05 22:39:15 --> UTF-8 Support Enabled
INFO - 2018-05-05 22:39:15 --> Utf8 Class Initialized
INFO - 2018-05-05 22:39:15 --> URI Class Initialized
INFO - 2018-05-05 22:39:15 --> Router Class Initialized
INFO - 2018-05-05 22:39:15 --> Output Class Initialized
INFO - 2018-05-05 22:39:15 --> Security Class Initialized
DEBUG - 2018-05-05 22:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-05 22:39:15 --> Input Class Initialized
INFO - 2018-05-05 22:39:15 --> Language Class Initialized
INFO - 2018-05-05 22:39:15 --> Loader Class Initialized
INFO - 2018-05-05 22:39:15 --> Helper loaded: common_helper
INFO - 2018-05-05 22:39:15 --> Database Driver Class Initialized
INFO - 2018-05-05 22:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-05 22:39:15 --> Email Class Initialized
INFO - 2018-05-05 22:39:15 --> Controller Class Initialized
INFO - 2018-05-05 22:39:15 --> Helper loaded: form_helper
INFO - 2018-05-05 22:39:15 --> Form Validation Class Initialized
INFO - 2018-05-05 22:39:15 --> Helper loaded: email_helper
DEBUG - 2018-05-05 22:39:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-05 22:39:15 --> Helper loaded: url_helper
INFO - 2018-05-05 22:39:15 --> Model Class Initialized
INFO - 2018-05-05 22:39:15 --> Model Class Initialized
INFO - 2018-05-05 22:39:15 --> Model Class Initialized
INFO - 2018-05-05 22:39:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-05 22:39:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-05 22:39:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-05 22:39:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-05 22:39:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-05 22:39:15 --> Final output sent to browser
DEBUG - 2018-05-05 22:39:15 --> Total execution time: 0.1410
