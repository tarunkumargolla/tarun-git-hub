<?php

Class Chatmodel extends CI_Model
{

    var $CI;

    protected $_timestamps = TRUE;
    
    function __construct()
    {
        parent::__construct();

        $this->CI =& get_instance();
        $this->CI->load->database(); 
        $this->CI->load->helper('url');
    }
	
 
  function deleteValues($table,$where)
  {
	  $this->db->where($where);
      $this->db->delete($table); 
	  return true;
  }
 function checkmemberExists($table,$where,$id)
  {
	  $this->db->where($where);
	  $this->db->where('ID!=',$id);
      $this->db->from($table); 
	  $query=$this->db->get();
	  $result=$query->result();
	  return $result;
	  
  }
  function getNewsTitle($id){
		$this->db->select('news_title');
		$this->db->where('news_id',$id);
        $query = $this->db->get(TBL_NEWS); 
		$results = $query->row();
		if($results){
			return $results->news_title;
		}else{
			return "" ;
		}
		
	}

 }