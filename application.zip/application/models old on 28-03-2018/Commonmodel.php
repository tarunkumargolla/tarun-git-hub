<?php

Class Commonmodel extends CI_Model
{

    var $CI;

    protected $_timestamps = TRUE;
    
    function __construct()
    {
        parent::__construct();

        $this->CI =& get_instance();
        $this->CI->load->database(); 
        $this->CI->load->helper('url');
    }
	
 
 function checkUserExists($table,$where,$id)
  {
	  $this->db->where($where);
	  $this->db->where('userId!=',$id);
      $this->db->from($table); 
	  $query=$this->db->get();
	  $result=$query->result();
	  return $result;
	  
  }
  function checkArticleExists($table,$where,$id)
  {
	  $this->db->where($where);
	  $this->db->where('articleTypeID!=',$id);
      $this->db->from($table); 
	  $query=$this->db->get();
	  $result=$query->result();
	  return $result;
	  
  }
  function checkCategoryExists($table,$where,$id)
  {
	  $this->db->where($where);
	  $this->db->where('cat_id!=',$id);
      $this->db->from($table); 
	  $query=$this->db->get();
	  $result=$query->result();
	  return $result;
	  
  }
  function checkSubscriptionExists($table,$where,$id)
  {
	  $this->db->where($where);
	  $this->db->where('bm_type_ref_id!=',$id);
      $this->db->from($table); 
	  $query=$this->db->get();
	  $result=$query->result();
	  return $result;
	  
  } 
  function checkNewsExists($table,$where,$id)
  {
	  $this->db->where($where);
	  $this->db->where('news_id!=',$id);
      $this->db->from($table); 
	  $query=$this->db->get();
	  $result=$query->result();
	  return $result;
	  
  }

 }