<?php

Class Paramsmodel extends CI_model
{

    var $CI;

    protected $_table_name = TBL_PARAMS;
    protected $_order_by = 'param_id desc';
    protected $_timestamps = TRUE;
    
    function __construct()
    {
        parent::__construct();

        $this->CI =& get_instance();
        $this->CI->load->database(); 
        $this->CI->load->helper('url');
    }
	
	function getParams()
	{
		$this->db->select('*');
		$query = $this->db->get(TBL_PARAMS);
		return $query->result();
	}
	
	
}