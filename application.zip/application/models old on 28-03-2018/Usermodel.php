<?php

Class Usermodel extends CI_Model
{

    var $CI;

    protected $_table_name = TBL_USERS; 
    protected $_order_by = 'userId desc';
    protected $_timestamps = TRUE;
    
    function __construct()
    {
        parent::__construct();

        $this->CI =& get_instance();
        $this->CI->load->database(); 
        $this->CI->load->helper('url');
    }
    
  
	function login($Phone_or_Name,$password)
    {
      
        $this->db->select('userId,name,phoneNumber,bloodGroup,is_phoneNumber_visible,noti_enable');
		$this->db->where('isActive', 1);
		$this->db->where('password', md5($password)); 
		$this->db->where("(phoneNumber = '$Phone_or_Name' OR name = '$Phone_or_Name')");
		$this->db->limit(1);
        $query = $this->db->get(TBL_USERS);
	  if (!$query)
		{
		     $this->throwException($query);
		}else{
		
			$user = $query->row_array();
			if ($user){
				return $user;
			}else{
				return false;
			}
	   }
    }
	
	function getUserProfile($userId)
	{
		$this->db->select('userId,name,gender,countryCode,phoneNumber,address,profilePicture,bloodGroup,is_phoneNumber_visible,noti_enable,age');
		$this->db->where('isActive', 1);
		$this->db->where('userId', $userId); 
		$this->db->limit(1);
        $query = $this->db->get(TBL_USERS);
		
    	 if (!$query)
		 {
		    $this->throwException($query);
		 }else{
		   $user = $query->row_array();
			 if ($user){
				return $user;
			 }else{
				return false;
          }
	   }
	}
	
	
	public function user_exists($phone_number,$email_address)
	{
      $query = $this->db->query("SELECT userId,phoneNumber,emailAddress FROM ".TBL_USERS." WHERE phoneNumber='".$phone_number."' OR emailAddress='".$email_address."' ");
		if (!$query)
		{
          $this->throwException($query);
		}else{
			$row = $query->row();
			if($row){
             return $row;
			}else{
				 return FALSE;
			}
		}
        
	}
	
	
   public function saveRecoveryEmailData($userid,$token,$purpose)
   {
	    //we create a new date that is 3 days in the future
	    $expireDateFormat = mktime(date("H"), date("i"), date("s"), date("m")  , date("d")+3, date("Y"));
	    $expirationDate = date("Y-m-d H:i:s",$expireDateFormat);
	    $data = array(
			'userID'=>$userid,
			'purpose'=>$purpose,
			'token'=>$token,
			'isactive'=>1,
			'expirationDate'=>$expirationDate
	     );
	    $query = $this->db->insert(TBL_RECOVERY_PASSWORDS,$data);
	      if (!$query)
	      {
		    $this->throwException($query);
	      }
	     else
	     { 
		    return $this->db->insert_id();
	     }
    }
	
	
   public function getUserDataByToken($token,$purpose)
   {
	  $query = $this->db->get_where(TBL_RECOVERY_PASSWORDS, array('token' => $token,'isactive'=>1,'purpose'=>$purpose));
		if (!$query)
		 {
           $this->throwException($query);
		 }
		else
		{ 
		  return $query->row();
		}
   }
   
    //deactive the random code after successful
	//password updated
  public function deactivateResetPassword($userId,$purpose)
  {
      $data = array('isactive'=>0);
	  $this->db->where(array('userID'=>$userId,'isactive'=>1,'purpose'=>$purpose));
	  $query = $this->db->update(TBL_RECOVERY_PASSWORDS,$data);
		if (!$query)
		{
		  $this->throwException($query);
		}
		else
		{
		  return $query;
		}

    }
	
	function getUserPassword($userId)
	{
		$this->db->select('password');
		$this->db->from(TBL_USERS);
		$this->db->where('userId',$userId);
		$query = $this->db->get();
		if (!$query)
		{
		   $this->throwException($query);
		}else{
		  $results = $query->row();
		  $result = $results->password;
		  return $result; 
		}
	}
	
   
	function getBloodGroupName($id)
   {
        $this->db->select('bloodGroup');
		$this->db->from(TBL_BLOODGROUPS);
		$this->db->where(TBL_BLOODGROUPS.'.id',$id);
		  $query = $this->db->get();
		    if (!$query)
		      {
			    $this->throwException($query);
		      }
		    else
              {
                return $query->row();
          }
	   
    }
	 function getdata(){
     $this->db->select('*');
     $query = $this->db->get('users');
     return $query->result_array();
  }
	
}








