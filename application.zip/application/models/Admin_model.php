<?php

Class Admin_model extends Healthmodel
{

    var $CI;

    protected $_table_name = TBL_USERS;
    protected $_order_by = 'user_id desc';
    protected $_timestamps = TRUE;
    
    function __construct()
    {
        parent::__construct();

        $this->CI =& get_instance();
        $this->CI->load->database(); 
        $this->CI->load->helper('url');
    }
   function login($Email_or_Phone,$password)
    {
	    $this->db->select('userId,name,emailAddress,phoneNumber,isActive,roleId');
		$this->db->where('isActive', 1);
		$this->db->where('isDeleted', 0);
		$this->db->where('roleId', 1);
		$this->db->where("(phoneNumber = '$Email_or_Phone' OR name = '$Email_or_Phone')");
		$this->db->where('password',md5($password));
		$this->db->limit(1);
        $query = $this->db->get(TBL_USERS);//print_r($this->db->last_query());die();
		if (!$query)
		{
		     $this->throwException($query);
		}else{
			$user = $query->row();
			//$pwd = decrypt($user->password);
			
			if ($user){
				return $user;
			}else{
				return false;
			}
	   }
    }
	function adminlogin($Email_or_Phone,$password,$celebrityId)
    {
        $this->db->select('userId,name,emailAddress,phoneNumber,isActive,roleId,celebrityId');
		$this->db->where('isActive', 1);
		$this->db->where('isDeleted', 0);
		$this->db->where('roleId', 2);
		$this->db->where("(phoneNumber = '$Email_or_Phone' OR name = '$Email_or_Phone')");
		$this->db->where('password', md5($password));
		$this->db->where('celebrityId', $celebrityId); 
		$this->db->limit(1);
        $query = $this->db->get(TBL_USERS);
		if (!$query)
		{
		     $this->throwException($query);
		}else{
			$user = $query->row();
			//$pwd = decrypt($user->password);
			
			if ($user){
				return $user;
			}else{
				return false;
			}
	   }
    }
	
}