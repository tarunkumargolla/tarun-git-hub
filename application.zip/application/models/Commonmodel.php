<?php

Class Commonmodel extends CI_Model
{

    var $CI;

    protected $_timestamps = TRUE;
    
    function __construct()
    {
        parent::__construct();

        $this->CI =& get_instance();
        $this->CI->load->database(); 
        $this->CI->load->helper('url');
    }
	
 
 function checkUserExists($table,$where,$id)
  {
	  $this->db->where($where);
	  $this->db->where('userId!=',$id);
      $this->db->from($table); 
	  $query=$this->db->get();
	  $result=$query->result();
	  return $result;
	  
  }
  
 /* function checkAdminExists($table,$where,$id)
  {
	  $this->db->where($where);
	  $this->db->where('adminId!=',$id);
      $this->db->from($table); 
	  $query=$this->db->get();
	  $result=$query->result();
	  return $result;
	  
  } */
  function checkArticleExists($table,$where,$id)
  {
	  $this->db->where($where);
	  $this->db->where('articleTypeID!=',$id);
      $this->db->from($table); 
	  $query=$this->db->get();
	  $result=$query->result();
	  return $result;
	  
  }
  function checkCategoryExists($table,$where,$id)
  {
	  $this->db->where($where);
	  $this->db->where('cat_id!=',$id);
      $this->db->from($table); 
	  $query=$this->db->get();
	  $result=$query->result();
	  return $result;
	  
  }
  function checkSubscriptionExists($table,$where,$id)
  {
	  $this->db->where($where);
	  $this->db->where('bm_type_ref_id!=',$id);
      $this->db->from($table); 
	  $query=$this->db->get();
	  $result=$query->result();
	  return $result;
	  
  } 
  function movieOrder($table,$where)
	{
		$this->db->select('*');
		$this->db->where($where);
		  $this->db->order_by('movie_display_order','asec');
        $query = $this->db->get($table);
		$results = $query->result();
	    return $results;
	}
  function checkNewsExists($table,$where,$id)
  {
	  $this->db->where($where);
	  $this->db->where('news_id!=',$id);
      $this->db->from($table); 
	  $query=$this->db->get();
	  $result=$query->result();
	  return $result;
	  
  }
  function celAppType($apptype){
	  $query='SELECT * FROM `celebritys` WHERE 
     `c_app_type` like "%,'.$apptype.',%" OR `c_app_type` like "'.$apptype.',%" OR  `c_app_type`  like "%,'.$apptype.'" OR `c_app_type`  like "%'.$apptype.'%" and c_is_active=1 and c_is_deleted=0';
    $result = $this->db->query($query)->result();
	if($result){
		return $result;
	}
	else{
		return false;
	}
  }
  /* function imageTitles($celebrityId){
	  $sql ="SELECT `news_title`, `news_id` FROM `news` WHERE `isDeleted` =0 AND `news_article_type` IN (3,4) AND `celebrityId` = $celebrityId ORDER BY `news`.`celebrityId` ASC";
	  $result = $this->db->query($sql)->result();
	  if($result){
		  return $result;
	  }
	  else{
		 return false; 
	  }
  }
  function videoTitles($celebrityId){
	  $sql ="SELECT `news_title`, `news_id` FROM `news` WHERE `isDeleted` =0 AND `news_article_type` IN (2,1) AND `celebrityId` = $celebrityId";
	  $result = $this->db->query($sql)->result();
	  if($result){
		  return $result;
	  }
	  else{
		 return false; 
	  }
  } */
  
 }