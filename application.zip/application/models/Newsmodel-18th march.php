<?php

Class NewsModel extends CI_Model
{

    var $CI;

    protected $_table_name = TBL_NEWS; 
    protected $_order_by = 'news_id desc';
    protected $_timestamps = TRUE;
    
    function __construct()
    {
        parent::__construct();

        $this->CI =& get_instance();
        $this->CI->load->database(); 
        $this->CI->load->helper('url');
    }
	
    public function getNewsDetails($id)
	{
		$this->db->select(TBL_NEWS.'.*,'.TBL_ARTICLES_REF.'.articleType,');
	$this->db->from(TBL_NEWS);
   // $this->db->join(TBL_CATEGORIES, TBL_CATEGORIES.'.cat_id='.TBL_NEWS.'.news_category_id ','inner');
    $this->db->join(TBL_ARTICLES_REF, TBL_ARTICLES_REF.'.articleTypeID='.TBL_NEWS.'.news_article_type ','inner');
   // $this->db->join(TBL_NEWS_SOURCES, TBL_NEWS_SOURCES.'.newsID='.TBL_NEWS.'.news_id ','inner');
	$this->db->where(TBL_NEWS.'.news_id ',$id);
	$this->db->order_by('news_id', 'DESC');
	$query = $this->db->get();
	   if(!$query)
	    {
		  $this->throwException($query);
	    }
	  else
	   { 
       $result=$query->row();
       $result->videos="";
	   $result->images="";
	   $result->coverPageDetails="";
	   $result->pollDetails="";
	   $result->pollBackGround="";
	   if($result){
            $type=$result->news_article_type;
            if($type==2 || $type == 5 || $type == 16){
                  $videos=$this->getNewsVideos($id);
                  $result->videos=$videos;
				   
             }else if($type == "14"){
			      $embedData=$this->getEmbedPage($id);
                  $result->embedData=$embedData;
			 }else if($type == "12" || $type == "13"){
				$coverPageDetails=$this->getCoverPageDetails($id);
				$result->coverPageDetails=$coverPageDetails;
			}else if($type == "11"){
				$images=$this->getNewsImages($id);
				$result->pollBackGround=$images;
				$pollDetails=$this->getPollsDetails($id);
				$result->pollDetails=$pollDetails;
			}else{
				$images=$this->getNewsImages($id);
				$result->images=$images;
			}
			return $result;
	   }
	   else{
		   return false;
	   }
	   }
	}
	function getPollsDetails($id){
		$this->db->select('*');
		$this->db->from(TBL_NEWS_POLLS);
		$this->db->where('npNewsId',$id);
		$this->db->where('npIsActive',1);
		$this->db->where('npIsDeleted',0);
		$query=$this->db->get();
		$result=$query->row();
		if($result){
			if($result){
				$pollsImages=array();
				
					$newsId=$result->npNewsId;
				    $npPollsId=$result->npPollsId;
				$sql="select poleImageId,image from news_polls_images where newsPoleId =$npPollsId and  newsId = $newsId and isActive = 1";
				$pollsImages=$this->db->query($sql)->result();
				$result->pollsImages= $pollsImages;
				
			}
			return $result;
		}else{
			return false;
		}
	}
	function getNewsImages($id){
		$this->db->select('*');
		$this->db->from(TBL_NEWS_IMAGES);
		$this->db->where('niNewsID',$id);
		$this->db->where('niIsDeleted',0);
		$query=$this->db->get();
		$res=$query->result();
		if($res){
			return $res;
		}else{
			return false;
		}
	}
function getNewsVideos($id){
		$this->db->select('*');
		$this->db->from(TBL_NEWS_VIDEOS);
		$this->db->where('nvNewsID',$id);
		$this->db->where('nvIsDeleted',0);
		$query=$this->db->get();
		$res=$query->result();//print_r($res);die();
		if($res){
			return $res;
		}else{
			return false;
		}
	}
	function getEmbedPage($newsID)
	{
		$result = array();
		$this->db->select(TBL_NEWS_EMBED_PAGES.'.*');
	    $this->db->from(TBL_NEWS_EMBED_PAGES);
	    $this->db->where(TBL_NEWS_EMBED_PAGES.'.neIsActive', 1);
	    $this->db->where(TBL_NEWS_EMBED_PAGES.'.neIsDeleted', 0);
	    $this->db->where(TBL_NEWS_EMBED_PAGES.'.neNewsID', $newsID);
	    $query = $this->db->get();
		
		if (!$query)
		{
			$this->throwException($query);
		}else{
			$result=$query->row();
			
		}
		return $result;
	}
	function getCoverPageDetails($newsID)
	{
		$result = array();
		$this->db->select(TBL_NEWS_COVER_PAGES.'.*');
	    $this->db->from(TBL_NEWS_COVER_PAGES);
	    $this->db->where(TBL_NEWS_COVER_PAGES.'.ncIsActive', 1);
	    $this->db->where(TBL_NEWS_COVER_PAGES.'.ncIsDeleted', 0);
	    $this->db->where(TBL_NEWS_COVER_PAGES.'.ncNewsId', $newsID);
	    $query = $this->db->get();
		
		if (!$query)
		{
			$this->throwException($query);
		}else{
			$result=$query->row();
			
		}
		return $result;
	}
	
	
	
}