<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0777);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/
define("APP_FOLDER","Celebrity/admin");
define("FRONT_FOLDER","Celebrity");
define("ROOT",$_SERVER['DOCUMENT_ROOT']."/".APP_FOLDER);
define("SITEURL2","http://".$_SERVER['SERVER_NAME']."/".APP_FOLDER."/index.php");
define("SITEURL","http://".$_SERVER['SERVER_NAME']."/".APP_FOLDER."/index.php");
define("ASITEURL","http://".$_SERVER['SERVER_NAME']."/".APP_FOLDER);
define("FSITEURL","http://".$_SERVER['SERVER_NAME']."/".FRONT_FOLDER);

define('SUPERADMIN_ROLL', "2");
define('USER_ROLL', "1");

define('SEND_PUSH_NOTI_URL', FSITEURL."/Webservices/News/sendNoti");  
define('ASSETS_URL', ASITEURL."/assets/");
define('CSS_URL', ASSETS_URL."css/");
define('JS_URL', ASSETS_URL."js/");
define('IMG_URL', ASSETS_URL."images/");
define('FONT_URL', ASSETS_URL."fonts/");
define('CATAGORIES_IMAGE_PATH', FSITEURL."/uploads/categories/");
define('SOURCE_IMAGE_PATH', FSITEURL."/uploads/sourceimages/");
define('NEWS_IMAGE_PATH', FSITEURL."/uploads/news/");
define('CHAT_MEMBER_IMAGE_PATH', FSITEURL."/uploads/chatMembers/");
define('DELETE_IMAGE_URL',SITEURL."/News/deleteImage");
define('DELETE_BAR_VALUE_URL',FSITEURL."/Chats/deleteBarGraphValue"); 
define('CELEBRITY_IMAGE_PATH',FSITEURL."/uploads/celebrity/"); 

//neww
define('USER_MANAGEMENT_URL',SITEURL."/users/index"); 
define('ADD_USERS_URL',SITEURL."/users/addUser");
define('DELETE_USER_URL',SITEURL."/users/deleteUser");

define('ARTICLES_URL',SITEURL."/Articles/index"); 
define('ADD_ARTICLES_URL',SITEURL."/Articles/addArticle");
define('DELETE_ARTICLE_URL',SITEURL."/Articles/deleteArticle");


define('CHAT_MEMBERS',SITEURL."/Stats/"); 
define('ADD_CHAT_MEMBERS_URL',SITEURL."/Stats/addMember"); 
define('ADD_CHAT_VALUES_URL',SITEURL."/Stats/addValues"); 
define('ADD_BAR_CHAT_VALUES_URL',SITEURL."/Stats/saveBarGraphValues"); 
define('ADD_LINE_CHAT_VALUES_URL',SITEURL."/Stats/saveLineGraphValues"); 
define('ADD_PIE_CHAT_VALUES_URL',SITEURL."/Stats/savePieGraphValues"); 
define('DELETE_MEMBER_URL',SITEURL."/Stats/deleteMember"); 

define('CATEGORIES_URL',SITEURL."/categories/index"); 
define('ADD_CATEGORIES_URL',SITEURL."/Categories/addCategory");
define('DELETE_CATEGORY_URL',SITEURL."/Categories/deleteCategory");

define('SUBSCRIPTIONS_URL',SITEURL."/subscriptions/index"); 
define('ADD_SUBSCRIPTIONS_URL',SITEURL."/subscriptions/addSubscription");
define('DELETE_SUBSCRIPTIONS_URL',SITEURL."/subscriptions/deleteSubscription");

define('NEWS_URL',SITEURL."/News/index");
define('ADD_NEWS_URL',SITEURL."/News/addNews");
define('EDIT_NEWS_URL',SITEURL."/News/editNews");
define('DELETE_NEWS_URL',SITEURL."/News/deleteNews/");


define('SETTINGS',SITEURL."/Settings/index");
define('EXPORT_USER_DATA',SITEURL."/Users/download_excel");
define('ADD_SETTINGS_URL',SITEURL."/Settings/addSettings");

//tables
define("TBL_SETTINGS","settings");
define("TBL_USERS","users");
define("TBL_RECOVERY_PASSWORDS","recovery_otp");
define("TBL_PARAMS","params");
define("TBL_CATEGORIES","categories");
define("TBL_ARTICLES_REF","article_types_ref");
define("TBL_SUBSCRIPTION_REF","bookmarks_type_ref");
define("TBL_NEWS","news");
define("TBL_NEWS_SOURCES","news_sources");
define("TBL_NEWS_VIDEOS","news_videos");
define("TBL_NEWS_IMAGES","news_images");
define("TBL_CHAT_MEMBERS","news_chats_members");
define("TBL_CHAT_TYPES","chats_type_ref");
define("TBL_BAR_GRAPH_VALUES","bar_graph_values");
define("TBL_PIE_GRAPH_VALUES","pie_chat_values");
define("TBL_LINE_GRAPH_VALUES","line_graph_values");
define("TBL_APPS","app");
define("TBL_APP_TYPE","app_type");
define("TBL_CELEBRITY","celebritys");
define("TBL_ADMINS","admins");
define("TBL_WISHES","wishes");
define("TBL_AWARDS","awards");
define("TBL_TIMELINE","timeline");
define('TBL_SPEECHES','speeches');
define('TBL_TIMELINE_ARTICLE_TYPES','timeline_article_types');
define("TBL_OPENION_POLLS","openion_polls");
define("TBL_USER_POLLING_RESULTS","user_polling_results");
define('TBL_TUTORIAL',"tutorials");

define("TBL_NEWS_EMBED_PAGES","news_embedpages");
define("TBL_NEWS_COVER_PAGES","news_coverpages");
define("TBL_NEWS_POLLS","news_polls");
define("TBL_NEWS_POLLS_IMAGES","news_polls_images");
define("TBL_FCM_TOKENS","fcm_tokens");
define("TBL_ADVERTISEMENTS","advertisments");

define('ADMIN_URL',SITEURL."/Admins/index");
define("ADMIN_LOGOUT_URL",SITEURL.'/Admins/logout');
define('ADD_ADMINS_URL',SITEURL."/Admins/addAdmin");
define('CELEBRITY_ADMIN_DASHBOARD_URL',SITEURL.'/Admins/dashboard');
define('ADMIN_PROFILE_URL',SITEURL.'/Admins/profile');
define('UPDATE_ADMIN_PROFILE_URL',SITEURL.'/Admins/updateProfile');
define('ADMIN_CHANGEPASSWORD_URL',SITEURL.'/Admins/changepassword');
define('UPDATE_ADMIN_PASSWORD_URL',SITEURL.'/Admins/updatePassword');


define('EVENTS_MANAGEMENT_URL',SITEURL."/events");
define('ADD_EVENTS_URL',SITEURL."/events/addEvents");
define('DELETE_EVENT_URL',SITEURL."/events/deleteEvent");
define('LOGIN_URL',SITEURL."(:any)/admin/index");
define('AGENT_LOGIN_URL',SITEURL."/agent/index");
define('DASHBOARD_URL',SITEURL."/dashboard");
define("LOGOUT_URL",SITEURL.'/admin/logout');
define("PROFILE_URL",SITEURL.'/profile');
define("UPDATE_PROFILE_URL",SITEURL.'/admin/updateProfile');
define("CHANGEPASSWORD_URL",SITEURL.'/changepassword');
define("UPDATE_PASSWORD_URL",SITEURL.'/admin/updatePassword');
define('AGENT_DASHBOARD_URL',SITEURL."/agent/dashboard");
define("AGENT_LOGOUT_URL",SITEURL.'/agent/logout');
define("AGENT_PROFILE_URL",SITEURL.'/agent/profile');
define("AGENT_UPDATE_PROFILE_URL",SITEURL.'/agent/updateProfile');
define("AGENT_CHANGEPASSWORD_URL",SITEURL.'/agent/changepassword');
define("AGENT_UPDATE_PASSWORD_URL",SITEURL.'/agent/updatePassword');
define("FORGOT_PASSWORD_URL",SITEURL.'/agent/forgotPassword');
define("RESET_PASSWORD_URL",SITEURL.'/agent/resetPassword');
define("AGENT_RESET_PASSWORD_URL",SITEURL.'/agent/changeForgotPassword');


define('IMAGE_URL',SITEURL.'/Galery/images');
define('IMAGE_DATA_URL',SITEURL.'/Galery/imagesData');
define('VIDEO_URL',SITEURL.'/Galery/videos');
define('VIDEO_DATA_URL',SITEURL.'/Galery/videosData');
define('DELETE_FOLDER_IMAGE_URL',SITEURL."/Galery/deleteImage/");
define('DELETE_FOLDER_VIDEO_URL',SITEURL."/Galery/deleteVideo/");
define('NEWS_VIDEO_PATH',FSITEURL."/uploads/videos/");


define('AWARDS_URL',SITEURL.'/Awards/index');
define('ADD_AWARDS_URL',SITEURL.'/Awards/addAwards');
define('EDIT_AWARDS_URL',SITEURL.'/Awards/editAwards');
define('DELETE_AWARDS_URL',SITEURL.'/Awards/deleteAwards');

/* define('TBL_MOVIES','movies');
define('MOVIE_URL',SITEURL.'/Movie/index');
define('ADD_MOVIE_URL',SITEURL.'/Movie/addMovie');
define('EDIT_MOVIE_URL',SITEURL.'/Movie/editMovie');
define('DELETE_MOVIES_URL',SITEURL.'/Movie/deleteMovie');
define('MOVIE_DETAILS_URL',SITEURL.'/Movie/movieDetails');
define('MOVIE_IMAGES_LIST_URL',SITEURL.'/Movie/movieImageList');
define('MOVIE_IMAGE_DATA_URL',SITEURL.'/Movie/movieImagesData');
define('ABOUT_MOVIE_URL',SITEURL.'/Movie/aboutMovie');
define('MOVIE_SONGS_URL',SITEURL.'/Movie/movieSongs');
define('MOVIE_TRILLER_URL',SITEURL.'/Movie/movieTrailer');
define('FULL_MOVIE_URL',SITEURL.'/Movie/fullMovie'); */

define('TBL_MOVIES','movies');
define('MOVIE_URL',SITEURL.'/Movie/index');
define('ADD_MOVIE_URL',SITEURL.'/Movie/addMovie');
define('EDIT_MOVIE_URL',SITEURL.'/Movie/editMovie');
define('DELETE_MOVIES_URL',SITEURL.'/Movie/deleteMovie');
define('MOVIE_DETAILS_URL',SITEURL.'/Movie/movieDetails');
define('MOVIE_IMAGES_LIST_URL',SITEURL.'/Movie/movieImageList');
define('MOVIE_IMAGE_DATA_URL',SITEURL.'/Movie/movieImagesData');
define('ABOUT_MOVIE_URL',SITEURL.'/Movie/aboutMovie');
define('MOVIE_SONGS_URL',SITEURL.'/Movie/movieSongs');
define('MOVIE_TRAILER_URL',SITEURL.'/Movie/movieTrailer');
define('TBL_MOVIE_TRAILER','movie_trailers');
define('TBL_MOVIE_SONGS','movie_songs');
define('ADD_TRAILER_URL',SITEURL.'/Movie/addTrailer');
define('EDIT_TRAILER_URL',SITEURL.'/Movie/editTrailer');
define('DELETE_TRAILER_URL',SITEURL.'/Movie/deleteTrailer/');
define('ADD_SONGS_URL',SITEURL.'/Movie/addSongs');
define('EDIT_SONGS_URL',SITEURL.'/Movie/editSongs');
define('DELETE_SONG_URL',SITEURL.'/Movie/deleteSong/');
define('FULL_MOVIE_URL',SITEURL.'/Movie/fullMovie');
define('ADD_GALLERY_IMAGES_URL',SITEURL.'/Movie/addGeleryImages/');
define('EDIT_GALLERY_IMAGES_URL',SITEURL.'/Movie/editGeleryImages/');
define('DELETE_GALLERY_IMAGES_URL',SITEURL.'/Movie/deleteGeleryImages/');
define('TBL_MOVIE_IMAGE','movie_images');

define('DELETE_MOVIE_FOLDER_IMAGE_URL',SITEURL.'/Movie/deleteImage');

define('ADD_CELEBRITY_URL',SITEURL.'/Celebrity/addCelebrity');
define('EDIT_CELEBRITY_URL',SITEURL.'/Celebrity/editCelebrity');
define('CELEBRITY_URL',SITEURL.'/Celebrity/index');
define('CELEBRITY_PAGE_URL',SITEURL.'/Celebrity/celebrityPage/');
define('DELETE_CELEBRITY_URL',SITEURL.'/Celebrity/deleteCelebrity');

define('WISHES_URL',SITEURL.'/Wishes/index');
define('ADD_WISHES_URL',SITEURL.'/Wishes/addWishes');
define('EDIT_WISHES_URL',SITEURL.'/Wishes/editWishes');
define('DELETE_WISHES_URL',SITEURL.'/Wishes/deleteWishes');

define('TUTORIAL_URL',SITEURL.'/Tutorial/index');
define('ADD_TUTORIAL_URL',SITEURL.'/Tutorial/addTutorial');
define('EDIT_TUTORIAL_URL',SITEURL.'/Tutorial/editTutorial');
define('DELETE_TUTORIAL_URL',SITEURL.'/Tutorial/deleteTutorial');


define('OPENION_POLLS_URL',SITEURL.'/Openion/index');
define('ADD_OPENION_POLLS_URL',SITEURL.'/Openion/addOpenion');
define('EDIT_OPENION_POLLS_URL',SITEURL.'/Openion/editOpenion');
define('DELETE_OPENION_POLLS_URL',SITEURL.'/Openion/deleteOpenion');

define('SPEECHES_URL',SITEURL.'/Speeches/index');
define('ADD_SPEECHES_URL',SITEURL.'/Speeches/addSpeech');
define('EDIT_SPEECHES_URL',SITEURL.'/Speeches/editSpeech');
define('DELETE_SPEECHES_URL',SITEURL.'/Speeches/deleteSpeech');


define('FOUNDATION_URL',SITEURL.'/Foundations/index');
define('ADD_FOUNDATION_URL',SITEURL.'/Foundations/addFoundation');
define('EDIT_FOUNDATION_URL',SITEURL.'/Foundations/editFoundation');
define('DELETE_FOUNDATION_URL',SITEURL.'/Foundations/deleteFoundation');
define('TBL_FOUNDATIONS','foundation_news');

define('EVENTS_URL',SITEURL.'/Events/index');
define('ADD_EVENT_URL',SITEURL.'/Events/addEvent');
define('EDIT_EVENT_URL',SITEURL.'/Events/editEvent');
define('DELETE_EVENTS_URL',SITEURL.'/Events/deleteEvent');
define('TBL_EVENTS','events');

define('SOCIAL_SERVICE_URL',SITEURL.'/SocialService/index');
define('ADD_SOCIAL_SERVICE_URL',SITEURL.'/SocialService/addSocialService');
define('EDIT_SOCIAL_SERVICE_URL',SITEURL.'/SocialService/editSocialService');
define('DELETE_SOCIAL_SERVICE_URL',SITEURL.'/SocialService/deleteSocialService');
define('TBL_SOCIAL_SERVICE','social_services');

define('TIMELINE_POST_URL',SITEURL.'/Timeline/index');
define('ADD_TIMELINE_POST_URL',SITEURL.'/Timeline/addTimeline');
define('EDIT_TIMELINE_POST_URL',SITEURL.'/Timeline/editTimeline');
define('DELETE_TIMELINE_POST_URL',SITEURL.'/Timeline/deleteTimeline');
define('TBL_TIMELINE_POST', 'timeline_post_image_or_videos');
define('TBL_ADMIN_TIMELINE_POST', 'admin_timeline_posts');
define('DELETE_TIMELINE_IMAGES_URL',SITEURL.'/Timeline/deleteTimelineImages');
define('TIMELINE_IMAGES_POST_URL',SITEURL.'/Timeline/timelineImages');


define('PROMOTION_BANNERS_URL',SITEURL.'/PromotionBanners/index');
define('ADD_PROMOTION_BANNERS_URL',SITEURL.'/PromotionBanners/addPromotionBanner');
define('EDIT_PROMOTION_BANNERS_URL',SITEURL.'/PromotionBanners/editPromotionBanner');
define('DELETE_PROMOTION_BANNERS_URL',SITEURL.'/PromotionBanners/deletePromotionBanner');
define('TBL_PROMOTION_BANNERS','promotion_banners');

define('TBL_VIDEOS','videos');
define('VIDEOS_URL',SITEURL.'/Video/index');
define('ADD_VIDEO_URL',SITEURL.'/Video/addVideo/');
define('EDIT_VIDEO_URL',SITEURL.'/Video/editVideo/');
define('DELETE_VIDEO_URL',SITEURL.'/Video/deleteVideo/');
define('TBL_GALLERY','gallery_images');
define('ADD_GALLERY_URL',SITEURL.'/Galery/addGalery/');
define('EDIT_GALLERY_URL',SITEURL.'/Galery/editGalery/');
define('GALLERY_IMAGE_DATA_URL',SITEURL.'/Galery/galleryImagesData');
define('DELETE_GALLERY_URL',SITEURL.'/Galery/deleteGalery');

define('TBL_SOCIAL_SERVICE_IMAGES','social_service_images');
define('TBL_FOUNDATION_IMAGES','foundation_images');
define('TBL_AWARDS_IMAGES','awards_images');

define('ADDS_URL',SITEURL.'/Adds/index');
define('ADD_ADD_URL',SITEURL.'/Adds/addAdd');
define('EDIT_ADD_URL',SITEURL.'/Adds/editAdd'); 
define('DELETE_ADD_URL',SITEURL.'/Adds/deleteAdd');
define('ADD_IMAGE_PATH',FSITEURL.'/uploads/adds');


define('SUPERADMIN_LOGIN_URL',SITEURL);


//old
define('FOPEN_READ',							'rb');
define('FOPEN_READ_WRITE',						'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE',		'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE',	'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE',					'ab');
define('FOPEN_READ_WRITE_CREATE',				'a+b');
define('FOPEN_WRITE_CREATE_STRICT',				'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT',		'x+b');

define("RECORDS_EXISTS","Records Exists");
define("NO_RECORDS_EXISTS","No Records Exists");
define("USER_REGISTRATION_SUCCESS",'Registration Success');
define("USER_REGISTRATION_FAILED",'Registration failed');
define("PHONE_NUMBER_ALREADY_EXISTS","This phone Number already exists.");
define("PHONE_NUMBER_OR_EMAIL_ALREADY_EXISTS","This phone number or email already exists.");
define("LOGIN_SUCCESS","Login success");
define("EMAIL_OR_PHONE_AND_PASSWORD_NOT_MATCH","Failed to authenticate name or phone number,passwords are invalid.");
define("PHONE_AND_PASSWORD_NOT_MATCH","Failed to authenticate phone number,passwords are invalid.");
define('PLEASE_PROVIDE_VALID_ADDRESS','Please provide valid address.');
define('PROFILE_UPDATED_SUCCESSFULLY','Profile updated successfully.');
define('UPDATE_SUCCESSFULLY','Updated successfully.');
define('UPDATE_FAILED','Updated failed.');
define('ADDING_FAILED','Adding failed.');
define('INVALID_OTP','Invalid OTP.');
define('CURRENT_PASSWORD_NOT_MATCH','Please provide valid current password.');
define('PLEASE_TRY_DIFFRRENT_PASSWORD','Please try different password to update.');
define('PASSWORD_UPDATE_SUCCESS','Password Successfully Updated.');
define('PLEASE_CHECK_YOUR_MAIL_FOR_OTP','Please Check Your Mail For OTP.');
define('APP_LAT_LON','Please provide apploading lat lons');
define('PROVIDE_USERID','User id must be specified');
define('PROVIDE_USERID_DONARID','User Id and donar Id must be specified');
define('PROVIDE_EVENTID','Event Id must be specified');

define('AUTHENTICATION_SUCCESS','Authentication Successfully Completed.');
define('AUTHENTICATION_FAILED','Authentication failed.');
define('INVALID_DEVICEID','Invalid deviceId .');  
define('LOGOUT_SUCCESS','Your Logout success.');
define('SUCCESS','Success.');
define('FAILED','Failed.');



/* End of file constants.php */
/* Location: ./application/config/constants.php */