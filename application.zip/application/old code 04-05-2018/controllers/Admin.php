<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header("access-control-allow-origin: *");
class Admin extends Healthcontroller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
		$this->load->model('Admin_model'); 

	}
	
	/*************
	**************
	This method will useful to login as a super admin.
	@param : Email_OR_phone
	@param : password
	return boolen
	**************
	*************/
	function index()
	{
		try{
				$this->load->helper('url');
				$data=array(); 
				 if($this->session->userdata('Role_Id')){
					redirect(DASHBOARD_URL,'refresh'); 
				} 
				if (!empty($_POST)) 
				{  
			        $this->session->unset_userdata('agent_id');
                    $this->load->library('form_validation');
					$this->form_validation->set_rules('Email_OR_phone','Email or Phone Number','trim|required');
					$this->form_validation->set_rules('password','Password','trim|required');
					if($this->form_validation->run()!=false)
					{
						$remember = trim($this->input->post('remember'));
						$this->session->set_userdata('remember',$remember);
						
						$Email_OR_phone = trim($this->input->post('Email_OR_phone'));
						$password       = trim($this->input->post('password'));
						$result = $this->Admin_model->login($Email_OR_phone, $password);
						if($result) 
						{
							$session_remember=$this->session->userdata('remember');
							if(!empty( $session_remember) && $session_remember==1){
								
							  $cookie1= array('name'   => 'admin_Name', 'value'  => $Email_OR_phone, 'expire' => '630720000','path'=>'/'  );
							  $cookie2= array('name'   => 'admin_password', 'value'  => $password, 'expire' => '630720000', 'path'=>'/' );
							  $cookie3= array('name'   => 'admin_remember', 'value'  => $session_remember, 'expire' => '630720000', 'path'=>'/' );
							    $this->input->set_cookie($cookie1);
							    $this->input->set_cookie($cookie2);
							    $this->input->set_cookie($cookie3);
						     }else {   
							  $cookie1= array('name'   => 'admin_Name', 'value'  => '','expire' => time()-3600, );
							  $cookie2= array('name'   => 'admin_password','value'  => '','expire' => time()-3600, );
							  $cookie3= array('name'   => 'admin_remember','value'  => '','expire' => time()-3600,);
								$this->input->set_cookie($cookie1);
								$this->input->set_cookie($cookie2);
								$this->input->set_cookie($cookie3);
						    }
							
							$this->setuser_sessiondata($result); 
							$data['successMessage'] = LOGIN_SUCCESS;
							
							redirect(DASHBOARD_URL,'refresh'); 
						} 
						else 
						{ 
								 $this->session->set_flashdata('Fmessage', EMAIL_OR_PHONE_AND_PASSWORD_NOT_MATCH); 
                                redirect(SITEURL);	
						}
					}
					else {
						$data['errorMessage']=validation_errors();
					}
					
				}
				
				
		 }catch (Exception $exception)
		 {
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		 } 	
		
		
	//	$this->load->view('header');
		$this->load->view('index',$data);
		//$this->load->view('scripts');
		$this->load->view('footer');

	}
	
	function dashboard(){
		try{
			$Role_Id=$this->session->userdata('Role_Id');

			if( empty($Role_Id))
			{
				redirect(LOGOUT_URL,'refresh');
			}
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		$where = array('isActive'=>1,'isDeleted'=>0,'roleId'=>1);
        $usersCount = $this->getAllRecords(TBL_USERS,$where,'count(*) as users_count'); 
		$data['usersCount'] = $usersCount[0];
         //  START 
		$where = array();
        $appTypes = $this->getAllRecords(TBL_APP_TYPE,$where,'count(*) as noOfApps'); 
		$data['noOfapps'] = $appTypes[0]; 
		
		$where = array();
        $appTypes = $this->getAllRecords(TBL_APP_TYPE,$where,'*'); 
		$data['apptypes'] = $appTypes; 
		//  END 
        // debug($data);
        $this->load->view('header');
		$this->load->view('dashboard',$data);
		$this->load->view('footer');
	}
	
	
	/*******************
	********************
	This method is useful to 
	logout the user.
	********************
	********************/
	function logout(){
		    $this->session->unset_userdata('userId');
		    $this->session->unset_userdata('Name');
		    $this->session->unset_userdata('emailAddress');
		    $this->session->unset_userdata('Role_Id');
		    $this->session->unset_userdata('loggedIn');
		    $this->session->unset_userdata('isSessionIn');
          //  $this->session->sess_destroy();
            redirect(SITEURL);
		}
	
	/*******************
	********************
	This method is useful to set the login user details into session
	********************
	********************/
	function setuser_sessiondata($result){ 
		if($result)
		   {
		        $userId = $result->userId;
			   	$Name = $result->name;
			   	$email_address = $result->emailAddress;
				$Role_Id=$result->roleId;
			   	$newdata = array('userId'  => $userId,
			   	                 'Name'  => $Name,
			   	                 'emailAddress' => $email_address,
								 'Role_Id' => $Role_Id,
			   	                 'loggedIn' => TRUE,
								 'isSessionIn' => 1
			   			   );
						   
			   	$this->session->set_userdata($newdata);
			}
	}
	
	

	function profile(){
           $Role_Id=$this->session->userdata('Role_Id');
		   $userId=$this->session->userdata('userId');
		 if(empty($userId))
		{
			redirect(LOGOUT_URL,'refresh');
		}
		
		 
		 if( empty($Role_Id))
		{
			redirect(LOGOUT_URL,'refresh');
		}
		
		$where = array('userId' => $userId,'roleID'=>$Role_Id);
		$details=$this->getSingleRecord(TBL_USERS,$where);
		$data['details']=$details;
        $this->load->view('header');
		$this->load->view('profile',$data);
		$this->load->view('scripts');
		$this->load->view('footer');
		
		}
		
	function updateProfile()
	 {
		
		 $userId = trim($this->input->post('id'));
		 $name = trim($this->input->post('name'));
		 $emailAddress = trim($this->input->post('emailAddress'));
		 $phoneNumber = trim($this->input->post('phoneNumber'));
		
		 if(!empty($name))        { $data['name']= $name;                      }
		 if(!empty($emailAddress)){ $data['emailAddress']= $emailAddress;          }
		 if(!empty($phoneNumber)) { $data['phoneNumber']= $phoneNumber;            }
		
         $data['updatedTime'] = date("Y-m-d H:i:s");
		 $where = array('userId'=>$userId);
		 $result=$this->insertOrUpdate(TBL_USERS,$where,$data);
		 if($result>0){
               $this->session->set_flashdata('Smessage', 'Your Profile Updated successfully'); 
               redirect(ADMIN_URL);
			
			    }else{
			   $this->session->set_flashdata('Fmessage', 'Error occured'); 
               redirect(PROFILE_URL);
				   
			    }
				
	 }
	 function changepassword()
	 {
		  $userId=$this->session->userdata('userId');
		  $where = array('userId' => $userId);
		  $details=$this->getSingleRecord(TBL_USERS,$where);
		  $data['details']=$details;
		  
		  $where = array('isDeleted' => 0,'isActive'=>1);
		  $this->load->view('header');
		  $this->load->view('changepassword',$data);
		  $this->load->view('scripts');
		  $this->load->view('footer');

	}
	 function updatePassword()

	{
		
		 $this->load->library('form_validation');
		 $this->form_validation->set_rules('password','Password','trim|required|min_length[6]|max_length[20]');
		 $this->form_validation->set_rules('cpassword','Confirm Password','trim|required|matches[password]');
	     if($this->form_validation->run()!=false)
		 {
		 $userId=$this->session->userdata('userId');
		 $update_password=trim($this->input->post('password'));
		 $where = array('userId' => $userId);
		 $new_password = trim($this->input->post('password'));
				 $confirm_password = trim($this->input->post('cpassword'));
				 if(!empty($new_password)){ $superadmin_data['password']=md5($new_password);    }
				 $superadmin_data['updatedTime'] = date("Y-m-d H:i:s");
				 $where = array('userId'=>$userId);
				 $result=$this->insertOrUpdate(TBL_USERS,$where,$superadmin_data);
				
				 if($result>0){
                  $this->session->set_flashdata('Smessage', PASSWORD_UPDATE_SUCCESS); 
                  redirect(ADMIN_URL);
						}else{
					 $this->session->set_flashdata('Fmessage', 'Error occured'); 
                     redirect(CHANGEPASSWORD_URL);
						}
			 }
			
		else
		{
            $this->session->set_flashdata('Fmessage', validation_errors()); 
                     redirect(CHANGEPASSWORD_URL);
			
		}
		echo json_encode($message); die();
		 
	}
	
	
	
}