<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header("access-control-allow-origin: *");
class Awards extends Healthcontroller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
        $this->load->model('Commonmodel'); 
	}
	
	function index(){
		try{
			$Role_Id=$this->session->userdata('Role_Id');
			$celebrityId = $this->uri->segment(3);
			if( empty($Role_Id) && empty($agentId) )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(LOGOUT_URL,'refresh');
				}
			}
			
			if($Role_Id == 1){
			$where = array('a_is_deleted'=>0,'celebrityId'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('a_is_deleted'=>0,'celebrityId'=>$celebrityId);
			}
            $awards = $this->getAllRecords(TBL_AWARDS,$where,'*');//print_r($awards);die();
			if($Role_Id == 1){
			$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			}
			$celebrity = $this->getSingleRecord(TBL_CELEBRITY,$where,'*');
			if(empty($celebrity)){
			redirect(CELEBRITY_URL);
		}
		    $data['awards']= $awards ;
			$data['cele_Name']=@$celebrity->c_name;
			$data['celebrityId']=@$celebrityId;
			
			$this->load->view('header');
		    $this->load->view('awards/awards',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		
	}
	function addAwards() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
             $celebrityId = $this->uri->segment(3);
            $data['celebrityId'] = $celebrityId;
            
            if ($this->input->post('addAwards')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('awards_title', 'Awards Title', 'trim|required');
                $this->form_validation->set_rules('awards_content', 'Awards Content', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $awards_title = trim($this->input->post('awards_title'));
                    $awards_content = trim($this->input->post('awards_content'));
					if($celebrityId){
						$Idata['celebrityId'] = $celebrityId;
					}
					else{
                   $Idata['celebrityId'] =$this->session->userdata('celebrityId');}

                    $Idata['a_title'] = $awards_title;
                    $Idata['a_content'] = $awards_content;
                    $Idata['a_created_time'] = date('y-m-d h:i:s');
					$Idata['a_thumb_image'] = "";
					$Idata['a_video'] = "";
					$where = array();
					$result = $this->insertOrUpdate(TBL_AWARDS,$where,$Idata);
					$last_id = $this->db->insert_id();
					if($result){
                                    /*  if (!empty($_FILES['thumb_image']['name'])) {
                                        $target_path = '../uploads/awards/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['thumb_image']['name']);
                                        $filename = basename($_FILES['thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['thumb_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $Idata['a_thumb_image'] = $picname2;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_AWARDS_URL.'/'.$celebrityId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_AWARDS_URL.'/'.$celebrityId);
                                        }} */
                                    if (!empty($_FILES['awards_image']['name'])) {
                                       $imageName = @$_FILES['awards_image']['name'];
					                    if ($imageName) {
											$i = 0;
											$imageData = array();
											$fileTypes = array('jpeg', 'png', 'jpg', 'gif');
											foreach ($imageName as $name) {
												$target_path = '../uploads/awards/';
												if (!empty($name)) {
													$response['file_name'] = basename($name);
													$filename = basename($name);
													$rand = rand();
													$file_extension = pathinfo($name);
													$picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
													$target_path = $target_path . $picname1;
													if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
														$movefile = move_uploaded_file($_FILES['awards_image']['tmp_name'][$i], $target_path);
														if ($movefile) {
													$upimgData['a_image'] = $picname1;
													$upimgData['a_award_id'] = $last_id;
													$upimgData['a_created_time'] = date('Y-m-d H:i:s');
													$where = array();
													$res = $this->insertOrUpdate(TBL_AWARDS_IMAGES, $where, $upimgData);
														}
														else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_AWARDS_URL.'/'.$celebrityId);
											}
													}
													else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_AWARDS_URL.'/'.$celebrityId);
                                                     }
												}
												$i++;
										}}
												if($res){
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(AWARDS_URL.'/'.$celebrityId);
												       }
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(ADD_AWARDS_URL.'/'.$celebrityId);
											}
                                            }
										$Tdata['t_post_type'] = 12;
										$Tdata['t_post_id'] = $last_id;
									    $Tdata['t_celebrity_id'] = $celebrityId;
										$where = array();
										$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
                                    }
									else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(ADD_AWARDS_URL.'/'.$celebrityId);
											}
			                    }else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_AWARDS_URL);
                }
            }
            $this->load->view('header');
            $this->load->view('awards/addAwards',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		function editAwards() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
            if ($this->input->post('editAwards')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_awards_title', 'Awards Title', 'trim|required');
                $this->form_validation->set_rules('edit_awards_content', 'Awards Content', 'trim|required');
                if ($this->form_validation->run() != false) {
                     
					$aImgId = $this->input->post('imageId');
                    $awards_title = trim($this->input->post('edit_awards_title'));
					$awards_id = trim($this->input->post('edit_awards_id'));
                    $awards_content = trim($this->input->post('edit_awards_content'));
					$celebrityId = $this->uri->segment(3);
					if($celebrityId){
						$Idata['celebrityId'] = $celebrityId;
					}
					else{
                   $Idata['celebrityId'] =$this->session->userdata('celebrityId');}

                    $Idata['a_title'] = $awards_title;
                    $Idata['a_content'] = $awards_content;
                    $Idata['a_created_time'] = date('y-m-d h:i:s');
					$Idata['a_thumb_image'] = "";
					$Idata['a_video'] = "";
					$where = array('a_id'=>$awards_id);
					$result = $this->insertOrUpdate(TBL_AWARDS,$where,$Idata);//print_r($result);die();
					if($result){
                                    /*  if (!empty($_FILES['thumb_image']['name'])) {
                                        $target_path = '../uploads/awards/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['thumb_image']['name']);
                                        $filename = basename($_FILES['thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['thumb_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $Idata['a_thumb_image'] = $picname2;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_AWARDS_URL.'/'.$celebrityId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_AWARDS_URL.'/'.$celebrityId);
                                        }} */
                                       $imageName = @$_FILES['edit_awards_image']['name'];
					                    if ($imageName || empty($imageName)) {
											$i = 0;
											$imageData = array();
											$fileTypes = array('jpeg', 'png', 'jpg', 'gif');
											foreach ($imageName as $name) {
												$target_path = '../uploads/awards/';
												if (!empty($name)) {
													$response['file_name'] = basename($name);
													$filename = basename($name);
													$rand = rand();
													$file_extension = pathinfo($name);
													$picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
													$target_path = $target_path . $picname1;
													if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
														$movefile = move_uploaded_file($_FILES['edit_awards_image']['tmp_name'][$i], $target_path);
														if ($movefile) {
													$upimgData['a_image'] = $picname1;
													 $upimgData['a_award_id'] = $awards_id;
													$upimgData['a_updated_time'] = date('Y-m-d H:i:s');
													$where = array('a_award_id'=>$awards_id,'a_img_id'=>$aImgId[$i]);
													$haveRecord = $this->getAllRecords(TBL_AWARDS_IMAGES, $where,'*');
													if($haveRecord){
													$where = array('a_img_id'=>$aImgId[$i]);
													$res = $this->insertOrUpdate(TBL_AWARDS_IMAGES, $where, $upimgData);//print_r($this->db->last_query());die();
													}
													else{
														$where = array();
													$res = $this->insertOrUpdate(TBL_AWARDS_IMAGES, $where, $upimgData);//print_r($this->db->last_query());die();
													}
														}
														else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_AWARDS_URL.'/'.$celebrityId.'/'.$awards_id);
											}
													}
													else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_AWARDS_URL.'/'.$celebrityId.'/'.$awards_id);
                                                     }
												}
												$i++;
										}}
											$this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(AWARDS_URL.'/'.$celebrityId.'/'.$awards_id);
                                    }
									else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(EDIT_AWARDS_URL.'/'.$celebrityId.'/'.$awards_id);
											}
			                    }else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_AWARDS_URL.'/'.$celebrityId.'/'.$awards_id);
                }
            }
			$id = $this->uri->segment(4);
			$where = array('a_id'=>$id);
			$data['details'] = $this->getSingleRecord(TBL_AWARDS,$where,'*');
			$where = array('a_award_id'=>$id);
			$data['imageDetails'] = $this->getAllRecords(TBL_AWARDS_IMAGES,$where,'*');
			$celebrityId = $this->uri->segment(3);
            $data['celebrityId'] = $celebrityId;
            $this->load->view('header');
            $this->load->view('awards/editAwards',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function deleteAwards() {
        if ($this->input->is_ajax_request()) {
			$id = $this->input->post('id');
			$data['a_is_deleted'] = 1;
			$where = array('a_id'=>$id);
			$deleteAwards = $this->insertOrUpdate(TBL_AWARDS,$where,$data);
            if($deleteAwards){
               $this->session->set_flashdata('Smessage', SUCCESS);
            } else {
             $this->session->set_flashdata('Fmessage', FAILED);
            }
            die();
        }
    }
}