<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */
// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Celebrity extends Healthcontroller {

    public function __construct() {

        parent::__construct();
        $this->load->model('Newsmodel');
        $this->load->model('Commonmodel', 'Commonmodel');

        date_default_timezone_set('Asia/Kolkata');
    }
	
	function index() {
        try {
            $Role_Id = $this->session->userdata('Role_Id');
			$apptype = $this->uri->segment(3);
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			if($Role_Id == 1){
               $celebrity = $this->Commonmodel->celAppType($apptype);
			}else{
                $celebrityId = $this->session->userdata('celebrityId');
				$where = array('c_is_deleted' => 0,'c_id'=>$celebrityId);
				$celebrity = $this->getAllRecords(TBL_CELEBRITY, $where, '*');
            }
			
            $data['celebrity'] = $celebrity;
            $this->load->view('header');
            $this->load->view('Celebrity/celebrity', $data);
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function celebrityPage(){
		$id = $this->uri->segment(3);
		$where = array('c_id'=>$id);
		$Name = $this->getSingleRecord(TBL_CELEBRITY,$where,'c_id,c_name');
		if(empty($Name)){
			redirect(DASHBOARD_URL);
		}
		$data['celebrityName'] = $Name;
		 $this->load->view('header');
		 $this->load->view('Celebrity/celebrityPage',$data);
		 $this->load->view('scripts');
		 $this->load->view('footer');
	}
	function addCelebrity(){
		try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$where = array();
			$data['appTypes'] = $this->getAllRecords(TBL_APP_TYPE,$where,'*');
                if ($this->input->post('addCelebrity')) {
                $this->load->library('form_validation');
				$this->form_validation->set_rules('apptype[]', 'App Type', 'trim|required');
                $this->form_validation->set_rules('name', 'Celebrity Name', 'trim|required');
                $this->form_validation->set_rules('num', 'Celedrity Number', 'trim|required');
				$this->form_validation->set_rules('address', 'Celebrity Address', 'trim|required');
                $this->form_validation->set_rules('gender', 'Celedrity Gender', 'trim|required');
			   //$this->form_validation->set_rules('lang[]', 'Celebrity Language', 'trim|required');
               // $this->form_validation->set_rules('hobbies', 'Celedrity Hobbies', 'trim|required');
				$this->form_validation->set_rules('email', 'Celebrity Email', 'trim|required');
                $this->form_validation->set_rules('pass', 'Celedrity Password', 'trim|required');
                if ($this->form_validation->run() != false) {
                    
					$appType = $this->input->post('apptype[]');
					$type = "";
					if($appType){
						foreach($appType as $sOption){
							if(empty($type)){
							$type = $sOption;
							}
							else{
								$type.= ",".$sOption;
							}
						}
					}
                    $name = trim($this->input->post('name'));
                    $where = array('c_name' => $name);
                     $Exists=$this->getAllRecords(TBL_CELEBRITY,$where,"*");
                      if($Exists && count($Exists)>0){
                      $this->session->set_flashdata('Fmessage',"Celebrity  already existed with this Name." );
                      redirect(ADD_CELEBRITY_URL);
                      } 
                    $phone = trim($this->input->post('num'));
					$address = trim($this->input->post('address'));
					$gender = trim($this->input->post('gender'));
					$languages = $this->input->post('lang');
					if($languages){
					 $language="";
						foreach ($languages as $sOption)
						{
							if(empty($language)){
							$language.= $sOption;}
							else
								{$language.=",".$sOption;
								}
						}
					}
					$hobbies = $this->input->post('hobbies');
					$avards = trim($this->input->post('avards'));
					if($avards){$Idata['c_is_awards_available']=$avards;}
					$foundations = trim($this->input->post('foundations'));
					if($foundations){$Idata['c_is_foundations_available']=$foundations;}
					$email = trim($this->input->post('email'));
					$password = trim($this->input->post('pass'));
					$password = encrypt($password);
                    $Idata['c_app_type'] = $type;
                    $Idata['c_name'] = $name;
					$Idata['c_address'] = $address;
					$Idata['c_phone'] =$phone;
					$Idata['c_gender'] = $gender;
                    $Idata['c_language'] = $language;
					$Idata['c_hobbies'] = $hobbies;
					$Idata['c_email'] = $email;
					$Idata['c_password'] = $password;
					$Idata['c_created_time'] = date("y-m-d H:i:s ");
                        $isPremiun = 0;                   
												if (!empty($_FILES['image']['name'])) {
													$fileTypes = array('jpg','png','gif');
											   $target_path = '../uploads/celebrity/';
													$response['file_name'] = basename($_FILES['image']['name']);
													$filename = basename($_FILES['image']['name']);
													$rand = rand();
													$file_extension = pathinfo($_FILES['image']['name']);
													$picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
													$target_path = $target_path . $picname1;
													if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
														$movefile = move_uploaded_file($_FILES['image']['tmp_name'], $target_path);
														if ($movefile) {
															$Idata['c_image'] = $picname1;
														}
													}
													else {
														  $this->session->set_flashdata('Fmessage', "File formate is not supported");
														  redirect($url);
														}
					$where = array();
                    $result = $this->insertOrUpdate(TBL_CELEBRITY, $where, $Idata);
                    $last_id = $this->db->insert_id();
					if($result){
						 $this->session->set_flashdata('Smessage', SUCCESS);
                        redirect(CELEBRITY_URL);
					}
					else{
						$this->session->set_flashdata('Fmessage', "Faild");
                        redirect(CELEBRITY_URL);
					}
					}
      
				}	
                   else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_CELEBRITY_URL);
                       }				
				}
            $this->load->view('header');
            $this->load->view('Celebrity/addcelebrity',$data);
			$this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
	}
		function editCelebrity(){
		try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$id = $this->uri->segment(3);
                if ($this->input->post('editCelebrity')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('editapptype[]', 'App Type', 'trim|required');
                $this->form_validation->set_rules('editname', 'Celebrity Name', 'trim|required');
                $this->form_validation->set_rules('editnum', 'Celedrity Number', 'trim|required');
				$this->form_validation->set_rules('editaddress', 'Celebrity Address', 'trim|required');
                $this->form_validation->set_rules('editgender', 'Celedrity Gender', 'trim|required');
				$this->form_validation->set_rules('editlang[]', 'Celebrity Language', 'trim|required');
                $this->form_validation->set_rules('edithobbies', 'Celedrity Hobbies', 'trim|required');
				$this->form_validation->set_rules('editemail', 'Celebrity Email', 'trim|required');
                if ($this->form_validation->run() != false) {
                    $celId = trim($this->input->post('cel_id'));
                    $name = trim($this->input->post('editname'));
                    $phone = trim($this->input->post('editnum'));
					$address = trim($this->input->post('editaddress'));
					$gender = trim($this->input->post('editgender'));
					$languages = $this->input->post('editlang');
					if($languages){
					 $language="";
						foreach ($languages as $sOption)
						{
							if(empty($language)){
							$language.= $sOption;}
							else
								{$language.=",".$sOption;
								}
						}
					}
					$hobbies = $this->input->post('edithobbies');
					$avards = trim($this->input->post('editavards'));
					if($avards){$Idata['c_is_awards_available']=$avards;}
					$foundations = trim($this->input->post('editfoundations'));
					if($foundations){$Idata['c_is_foundations_available']=$foundations;}
					$email = trim($this->input->post('editemail'));
					/* $password = trim($this->input->post('editpassword'));
					$password = encrypt($password);
					if($password){
						$Idata['c_password'] = $password;
					} */
					$appType = $this->input->post('editapptype[]');
					$type = "";
					if($appType){
					foreach($appType as $sOption){
					if(empty($type)){
					$type = $sOption;
					}
					else{
					$type.= ",".$sOption;
					}
					}
					}
					$Idata['c_app_type'] = $type;

                    $Idata['c_name'] = $name;
					$Idata['c_address'] = $address;
					$Idata['c_phone'] =$phone;
					$Idata['c_gender'] = $gender;
                    $Idata['c_language'] = $language;
					$Idata['c_hobbies'] = $hobbies;
					$Idata['c_email'] = $email;
					$Idata['c_updated_time'] = date("y-m-d H:i:s ");
                        $isPremiun = 0;                   
												if (!empty($_FILES['editimage']['name'])) {
													$fileTypes = array('jpg','png','gif');
											   $target_path = '../uploads/celebrity/';
													$response['file_name'] = basename($_FILES['editimage']['name']);
													$filename = basename($_FILES['editimage']['name']);
													$rand = rand();
													$file_extension = pathinfo($_FILES['editimage']['name']);
													$picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
													$target_path = $target_path . $picname1;
													if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
														$movefile = move_uploaded_file($_FILES['editimage']['tmp_name'], $target_path);
														if ($movefile) {
															$Idata['c_image'] = $picname1;
														}
													}
													else {
														  $this->session->set_flashdata('Fmessage', "File formate is not supported");
														  redirect($url);
														}
												}
					$where = array('c_id'=>$celId);
					$haveRecord = $this->getSingleRecord(TBL_CELEBRITY,$where,'*');
					if($haveRecord){
					$where = array('c_id'=>$celId);
                    $result = $this->insertOrUpdate(TBL_CELEBRITY, $where, $Idata);}
					else{
					$where = array();
                    $result = $this->insertOrUpdate(TBL_CELEBRITY, $where, $Idata);}
                    $last_id = $this->db->insert_id();
					if($result){
						 $this->session->set_flashdata('Smessage', SUCCESS);
                        redirect(CELEBRITY_URL);
					}
					else{
						$this->session->set_flashdata('Fmessage', "Faild");
                        redirect(CELEBRITY_URL);
					}
      
				}	
                   else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_CELEBRITY_URL);
                       }				
				}
				$where =array('c_id'=>$id);
				$celebrity = $this->getSingleRecord(TBL_CELEBRITY,$where,'*');
				$where = array();
			    $data['appTypes'] = $this->getAllRecords(TBL_APP_TYPE,$where,'*');
				$data['celebrity']=$celebrity;
            $this->load->view('header');
            $this->load->view('Celebrity/editcelebrity',$data);
			$this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
	}
	function deleteCelebrity() {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $where = array('c_id' => $id);
            $data['c_is_deleted'] = 1;

            $success = $this->insertOrUpdate(TBL_CELEBRITY, $where, $data);
            if ($success) {
                echo json_encode(array('status' => 1, 'message' => SUCCESS));
            } else {
                echo json_encode(array('status' => 0));
            }
            die();
        }
    }
}