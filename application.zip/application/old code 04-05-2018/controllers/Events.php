<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header("access-control-allow-origin: *");
class Events extends Healthcontroller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
        $this->load->model('Commonmodel'); 
	}
	
	function index(){
		try{
			$Role_Id=$this->session->userdata('Role_Id');
			$celebrityId = $this->uri->segment(3);
			if( empty($Role_Id) && empty($agentId) )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(LOGOUT_URL,'refresh');
				}
			}
			
			if($Role_Id == 1){
			$where = array('e_is_deleted'=>0,'e_celebrity_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('e_is_deleted'=>0,'e_celebrity_id'=>$celebrityId);
			}
            $events = $this->getAllRecords(TBL_EVENTS,$where,'*','e_id');
			if($Role_Id == 1){
			$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			}
			$celebrity = $this->getSingleRecord(TBL_CELEBRITY,$where,'*');
			if(empty($celebrity)){
			redirect(DASHBOARD_URL);
		        }
		    $data['events']= $events ;
			$data['cele_Name']=@$celebrity->c_name;
			$data['celebrityId']=@$celebrityId;
			
			$this->load->view('header');
		    $this->load->view('events/event',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		
	}
	function addEvent() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
             $celebrityId = $this->uri->segment(3);
            $data['celebrityId'] = $celebrityId;
            if ($this->input->post('addEvent')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('event_title', 'Events Title', 'trim|required');
                $this->form_validation->set_rules('event_content', 'Events Content', 'trim|required');
				$this->form_validation->set_rules('event_place', 'Events Place', 'trim|required');
				$this->form_validation->set_rules('event_start_date', 'Events Start Date', 'trim|required');
				$this->form_validation->set_rules('event_end_date', 'Events End Date', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $event_title = trim($this->input->post('event_title'));
                    $event_content = trim($this->input->post('event_content'));
					$event_place = trim($this->input->post('event_place'));
					$event_start_date = trim($this->input->post('event_start_date'));
					$event_end_date = trim($this->input->post('event_end_date'));
					 if(strtotime($event_end_date) <  strtotime($event_start_date)){
			          $error_message =array('status'=>0,'message'=>"End time must be greater than start time. ");
		              echo json_encode($error_message);die();
		              }
					if($celebrityId){
						$Idata['e_celebrity_id'] = $celebrityId;
					}
					else{
                   $Idata['e_celebrity_id'] =$this->session->userdata('celebrityId');}

                    $Idata['e_title'] = $event_title;
                    $Idata['e_content'] = $event_content;
					$Idata['e_place'] = $event_place;
					$Idata['e_start_date'] = date('y-m-d h:i:s',strtotime($event_start_date));
					$Idata['e_end_date'] = date('y-m-d h:i:s',strtotime($event_end_date));
                        $isPremiun = 0;
                    $Idata['e_created_time'] = date('y-m-d h:i:s');
					$Idata['e_image'] = "";//debug($Idata);
                                     if (!empty($_FILES['event_image']['name'])) {
                                        $target_path = '../uploads/events/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['event_image']['name']);
                                        $filename = basename($_FILES['event_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['event_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['event_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $Idata['e_image'] = $picname;
										  $where = array();
												$result = $this->insertOrUpdate(TBL_EVENTS, $where, $Idata);
												$last_id = $this->db->insert_id();
												if($result){
													$Tdata['t_post_type'] = '11';
													$Tdata['t_post_id'] = $last_id;
													$Tdata['t_celebrity_id'] = $celebrityId;
													$where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(EVENTS_URL.'/'.$celebrityId);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(ADD_EVENT_URL.'/'.$celebrityId);
											}
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_EVENT_URL.'/'.$celebrityId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_EVENT_URL.'/'.$celebrityId);
                                        }
                                }
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_EVENT_URL);
                }
            }
            $this->load->view('header');
            $this->load->view('events/addEvent',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		function editEvent() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }

            $event_id= $this->uri->segment(4);
			$celebrityId = $this->uri->segment(3);
            $where = array('e_id'=>$event_id);
			$details = $this->getSingleRecord(TBL_EVENTS, $where, '*');
			$data['details'] = $details;
            $data['celebrityId'] = $celebrityId;
			
            if ($this->input->post('editEvent')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_event_title', 'Events Title', 'trim|required');
                $this->form_validation->set_rules('edit_event_content', 'Events Content', 'trim|required');
				$this->form_validation->set_rules('edit_event_place', 'Events Place', 'trim|required');
				$this->form_validation->set_rules('edit_event_start_date', 'Events Start Date', 'trim|required');
				$this->form_validation->set_rules('edit_event_end_date', 'Events End Date', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $event_title = trim($this->input->post('edit_event_title'));
					$event_id = trim($this->input->post('edit_foundation_id'));
                    $event_content = trim($this->input->post('edit_event_content'));
					$event_place = trim($this->input->post('edit_event_place'));
					$event_start_date = trim($this->input->post('edit_event_start_date'));
					$event_end_date = trim($this->input->post('edit_event_end_date'));
					 if(strtotime($event_end_date) <= strtotime($event_start_date)){
			          $error_message =array('status'=>0,'message'=>"End time must be greater than start time. ");
		              echo json_encode($error_message);die();
		              }
					if($celebrityId){
						$Idata['e_celebrity_id'] = $celebrityId;
					}
					else{
                   $Idata['e_celebrity_id'] =$this->session->userdata('celebrityId');}

                    $Idata['e_title'] = $event_title;
                    $Idata['e_content'] = $event_content;
					$Idata['e_place'] = $event_place;
					$Idata['e_start_date'] = date('y-m-d h:i:s',strtotime($event_start_date));
					$Idata['e_end_date'] = date('y-m-d h:i:s',strtotime($event_end_date));
					$Idata['e_updated_time'] = date('y-m-d H:i:s');
                        $isPremiun = 0;
                                    if (!empty($_FILES['edit_event_image']['name'])) {
                                        $target_path = '../uploads/events/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_event_image']['name']);
                                        $filename = basename($_FILES['edit_event_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_event_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_event_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $Idata['e_image'] = $picname;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_EVENT_URL.'/'.$celebrityId.'/'.$event_id);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_EVENT_URL.'/'.$celebrityId.'/'.$event_id);
                                        }}
												$where = array('e_id'=>$event_id);
												$haveRecord = $this->getSingleRecord(TBL_EVENTS,$where,'*');
												if($haveRecord){
												$where = array('e_id'=>$event_id);
												$result = $this->insertOrUpdate(TBL_EVENTS, $where, $Idata);}
												else{
												$where = array();
												$result = $this->insertOrUpdate(TBL_EVENTS, $where, $Idata);
												}
												$last_id = $this->db->insert_id();
												if($result){
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(EVENTS_URL.'/'.$celebrityId.'/'.$event_id);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(EDIT_EVENT_URL.'/'.$celebrityId.'/'.$event_id);
											}
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_EVENT_URL.'/'.$celebrityId.'/'.$event_id);
                }
            }
			
            $this->load->view('header');
            $this->load->view('events/editEvent',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function deleteEvent() {
        if ($this->input->is_ajax_request()) {
			$event_id = $this->input->post('id');
			$data['e_is_deleted'] = 1;
			$where = array('e_id'=>$event_id);
			$deleteEvent = $this->insertOrUpdate(TBL_EVENTS,$where,$data);
            if($deleteEvent){
               $this->session->set_flashdata('Smessage', SUCCESS);
            } else {
             $this->session->set_flashdata('Fmessage', FAILED);
            }
            die();
        }
    }
}