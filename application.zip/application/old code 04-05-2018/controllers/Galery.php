<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */
// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Galery extends Healthcontroller {

    public function __construct() {

        parent::__construct();
        $this->load->model('Newsmodel');
        $this->load->model('Commonmodel', 'Commonmodel');

        date_default_timezone_set('Asia/Kolkata');
    }
	//START
	  function images() {
		  $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$celebrityId = $this->uri->segment(3);
		if($celebrityId){
			$imageTitles = $this->Commonmodel->imageTitles($celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$imageTitles = $this->Commonmodel->imageTitles($celebrityId);
			}
		$data['titles'] =$imageTitles;
		if($Role_Id==1){
			$where = array('gallery_is_deleted' => 0,'gallery_celebrity_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('gallery_is_deleted'=>0,'gallery_celebrity_id'=>$celebrityId);
			}
            $gallery = $this->getAllRecords(TBL_GALLERY, $where, '*');
            $data['galleryTitles'] = $gallery;
		if($celebrityId){
			$videoTitles = $this->Commonmodel->videoTitles($celebrityId);
		}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$videoTitles = $this->Commonmodel->videoTitles($celebrityId);
			}
		$data['videotitles'] =$videoTitles;
		$data['celebrityId'] = $celebrityId;
        $this->load->view('header');
		$this->load->view('galery/image',$data);
		$this->load->view('footer');
		
	}  
	function addGalery(){
		try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
            if ($this->input->post('addGaleryImages')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('gallery_title', 'Gallery_Title', 'trim|required');
                if ($this->form_validation->run() != false) {
					if($this->session->userdata('celebrityId')){
						$gallery_Celebrity =$this->session->userdata('celebrityId');
					}
					else{
                    $gallery_Celebrity = $this->uri->segment(3);}
                    $gallery_title = trim($this->input->post('gallery_title'));
                    $where = array('gallery_title' => $gallery_title,'gallery_celebrity_id'=>$gallery_Celebrity,'gallery_is_deleted' => 0);
                     $Exists=$this->getAllRecords(TBL_GALLERY,$where,"*");
                      if($Exists && count($Exists)>0){
                      $this->session->set_flashdata('Fmessage',"Gallery already existed with this title." );
                      redirect(ADD_GALLERY_URL.$gallery_Celebrity);
                      } 
					  $Idata['gallery_title'] = $gallery_title;
					  $gallery_title = str_ireplace(" ","_",$gallery_title);
                     $myNewFolderPath ='../uploads/gallery/'.$gallery_title;
					 mkdir($myNewFolderPath);
                    $Idata['gallery_celebrity_id'] = $gallery_Celebrity;
                    $Idata['gallery_created_time'] = date('y-m-d h:i:s');
                    $where = array();
                    $result = $this->insertOrUpdate(TBL_GALLERY, $where, $Idata);
                    $last_id = $this->db->insert_id();
					if($result){
						if ($_FILES) {
                            
                            //for images 
                            $imageName = "";
                            $imageName = @$_FILES['gallery_image']['name'];
                           
										if ($imageName) {
											$i = 0;
											$imageData = array();
											$fileTypes = array('jpg','png','gif');
											foreach ($imageName as $name) {
												if (!empty($name)) {
													$target_path = $myNewFolderPath.'/';
													$response['file_name'] = basename($name);
													$filename = basename($name);
													$rand = rand();
													$file_extension = pathinfo($name);
													$picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
													$target_path = $target_path . $picname1;
													if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
														$movefile = move_uploaded_file($_FILES['gallery_image']['tmp_name'][$i], $target_path);
														if ($movefile) {
															$imageData[$i] = $picname1;
															
														}
													}
													else {
														  $this->session->set_flashdata('Fmessage', "File formate is not supported");
														  redirect($url);
														}
												}
												$i++;
												}
					                         }  
                            }
								$this->session->set_flashdata('Smessage', SUCCESS);
								redirect(IMAGE_URL.'/'.$gallery_Celebrity);
					}
					} 
					else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_GALERY_URL);
                       }
			}
			
			$celebrityId=$this->uri->segment(3);
			$data['celebrityId'] = $celebrityId;
		$this->load->view('header');
        $this->load->view('galery/addGelery',$data);
        $this->load->view('scripts');
        $this->load->view('footer');
		 } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
	}
		function editGalery(){
		try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');
              $gallery_id = $this->uri->segment(3);
			  $where = array('gallery_id'=>$gallery_id);
			  $data['details'] = $this->getSingleRecord(TBL_GALLERY,$where,'*');
			  $celebrityId = $this->uri->segment(4);
			  $data['celebrityId'] = $celebrityId;
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
            if ($this->input->post('editGaleryImages')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_gallery_title', 'Gallery_Title', 'trim|required');
                if ($this->form_validation->run() != false) {
					if($this->session->userdata('celebrityId')){
						$gallery_Celebrity =$this->session->userdata('celebrityId');
					}
					else{
                    $gallery_Celebrity = $this->uri->segment(4);}
					$gallery_id = $this->uri->segment(3);
                    $gallery_title = trim($this->input->post('edit_gallery_title'));
					$Idata['gallery_title'] = $gallery_title;
                   /* $where = array('gallery_title' => $gallery_title);
                      $Exists=$this->getAllRecords(TBL_GALLERY,$where,"*");
                      if($Exists && count($Exists)>0){
                      $this->session->set_flashdata('Fmessage',"Gallery already existed with this title." );
                      redirect(EDIT_GALERY_URL.$gallery_Celebrity);
                      }  */
					  $gallery_title = str_ireplace(" ","_",$gallery_title);
                     $myNewFolderPath ='../uploads/gallery/'.$gallery_title;
					 mkdir($myNewFolderPath);
                    $Idata['gallery_celebrity_id'] = $gallery_Celebrity;
                    $Idata['gallery_updated_time'] = date('y-m-d h:i:s');
                    $where = array('gallery_id'=>$gallery_id);
                    $result = $this->insertOrUpdate(TBL_GALLERY, $where, $Idata);
                    $last_id = $this->db->insert_id();
					if($result){
						if ($_FILES) {
                            
                            //for images 
                            $imageName = "";
                            $imageName = @$_FILES['edit_gallery_image']['name'];
                           
										if ($imageName) {
											$i = 0;
											$imageData = array();
											$fileTypes = array('jpg','png','gif');
											foreach ($imageName as $name) {
												if (!empty($name)) {
													$target_path = $myNewFolderPath.'/';
													$response['file_name'] = basename($name);
													$filename = basename($name);
													$rand = rand();
													$file_extension = pathinfo($name);
													$picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
													$target_path = $target_path . $picname1;
													if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
														$movefile = move_uploaded_file($_FILES['edit_gallery_image']['tmp_name'][$i], $target_path);
														if ($movefile) {
															$imageData[$i] = $picname1;
															
														}
													}
													else {
														  $this->session->set_flashdata('Fmessage', "File formate is not supported");
														  redirect($url);
														}
												}
												$i++;
												}
					                         }  
                            }
								$this->session->set_flashdata('Smessage', SUCCESS);
								redirect(IMAGE_URL.'/'.$gallery_Celebrity);
					}
					} 
					else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_GALLERY_URL);
                       }
			}
			
		$this->load->view('header');
        $this->load->view('galery/editGelery',$data);
        $this->load->view('scripts');
        $this->load->view('footer');
		 } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
	}
	function deleteGalery(){
		if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
			 $title = $this->input->post('title');
			 $gallerytitle = str_ireplace(" ","_",$title);
			 $dirname = '../uploads/gallery/'.$gallerytitle;
		     foreach(glob($dirname."/*",GLOB_BRACE) as $movieImage){
			 unlink($movieImage);
			}
			rmdir($dirname);
			$data['gallery_is_deleted'] = 1;
			$where = array('gallery_id'=>$id);
			$result = $this->insertOrUpdate(TBL_GALLERY,$where,$data);
			if($result == 1){
               $this->session->set_flashdata('Smessage', "Gallery Delete Successfully");
			}else {
             $this->session->set_flashdata('Fmessage', "Failed ");
            }
            die();
        }
	}
	function imagesData(){
		$celebrityId = $this->uri->segment(3);
		$newsId = $this->uri->segment(4);
		$where = array('news_id'=>$newsId);
		$news = $this->getSingleRecord(TBL_NEWS,$where,'*');
		$data['newsDetails'] = $news;
		$where = array('niNewsID'=>$newsId,'niIsDeleted'=>0);
		$data['newsImages'] = $this->getAllRecords(TBL_NEWS_IMAGES,$where,'*');
		$data['celebrityId'] =$celebrityId;
	    $this->load->view('header');
		$this->load->view('galery/imagedata',$data);
		$this->load->view('footer');
	}
	function galleryImagesData(){
		$celebrityId = $this->uri->segment(3);
		$galleryId = $this->uri->segment(4);
		$where = array('gallery_id'=>$galleryId);
		$gtitle = $this->getSingleRecord(TBL_GALLERY,$where,'gallery_title');
		$data['galleryTitle'] = $gtitle;
		$data['celebrityId'] =$celebrityId;
	    $this->load->view('header');
		$this->load->view('galery/galleryImageData',$data);
		$this->load->view('footer');
	}
	function videosData(){
		$id = $this->uri->segment(4);
		$data['celebrityId'] = $this->uri->segment(3);
		$where = array('news_id'=>$id);
		$news = $this->getSingleRecord(TBL_NEWS,$where,'*');
		$data['newsDetails'] = $news;
		$where = array('nvNewsID'=>$id,'nvIsDeleted'=>0);
		$result = $this->getAllRecords(TBL_NEWS_VIDEOS,$where,'*');
		$data['videoDetails'] = $result;
	    $this->load->view('header');
		$this->load->view('galery/videodata',$data);
		$this->load->view('footer');
	}
	// END
	function deleteImage() {
        if ($this->input->is_ajax_request()) {
			$imagePath = $this->input->post('path');
			if(unlink($imagePath)){
               $this->session->set_flashdata('Smessage', "Image Delete Successfully");
            } else {
             $this->session->set_flashdata('Fmessage', "Failed");
            }
            die();
        }
    }
    function deleteVideo() {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
			$data['nvIsDeleted'] = 1;
			$where = array('nvVideoID'=>$id);
			$result = $this->insertOrUpdate(TBL_NEWS_VIDEOS,$where,$data);
			if($result){
               $this->session->set_flashdata('Smessage', "Video Delete Successfully");
			}else {
             $this->session->set_flashdata('Fmessage', "Failed");
            }
            die();
        }
    
}
}