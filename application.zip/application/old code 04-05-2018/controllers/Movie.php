<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */
// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Movie extends Healthcontroller {

    public function __construct() {

        parent::__construct();
        $this->load->model('Newsmodel');
        $this->load->model('Commonmodel', 'Commonmodel');

        date_default_timezone_set('Asia/Kolkata');
    }
	function index() {
        try {
            $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$celebrityId = $this->uri->segment(3);
			 if($Role_Id==1){
			$where = array('isDeleted' => 0,'celebrityId'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('isDeleted'=>0,'celebrityId'=>$celebrityId);
			}
            $movies = $this->getAllRecords(TBL_MOVIES, $where, '*', 'movie_id');
            $data['movies'] = $movies;
			if($Role_Id==1){
			$where = array('c_is_deleted' => 0,'c_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			}
        $celebrity = $this->getSingleRecord(TBL_CELEBRITY, $where, '*');
		if(empty($celebrity)){
			redirect(CELEBRITY_URL);
		}
         $data['name'] = $celebrity->c_name;
		$data['celebrityId'] = $celebrity->c_id;
            $this->load->view('header');
            $this->load->view('movies/movies',$data);
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
		
    }
	function addMovie(){
		
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			   $celebrityId = $this->uri->segment(3);
                if ($this->input->post('addMovies')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('movie_title', 'movies Title', 'trim|required');
                $this->form_validation->set_rules('about_movie', 'About Movie', 'trim|required');
                $this->form_validation->set_rules('movie_dir', 'Movie Directer', 'trim|required');
                $this->form_validation->set_rules('movie_stars', 'movies Stars', 'trim|required');
                $this->form_validation->set_rules('movie_genre', 'Movie Genre', 'trim|required');
                $this->form_validation->set_rules('movie_rel_date', 'Movie Release Date', 'trim|required');
                $this->form_validation->set_rules('movie_link', 'Movie Link', 'trim|required');
				//$this->form_validation->set_rules('image_option', 'Image Option', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $movie_title = trim($this->input->post('movie_title'));
                    $where = array('movie_title' => $movie_title,'isDeleted'=>0);
                     $Exists=$this->getAllRecords(TBL_MOVIES,$where,"*");
                      if($Exists && count($Exists)>0){
                      $this->session->set_flashdata('Fmessage',"News already existed with this title." );
                      redirect(ADD_MOVIE_URL);
                      } 
                    $about_movie = trim($this->input->post('about_movie'));
					$movie_dir = trim($this->input->post('movie_dir'));
					$movie_stars = trim($this->input->post('movie_stars'));
					$movie_genre = trim($this->input->post('movie_genre'));
					$movie_rel_date = trim($this->input->post('movie_rel_date'));
					$movie_link = trim($this->input->post('movie_link'));
					if($celebrityId){
						 $Idata['celebrityId'] = $celebrityId;
					}
					else{
						 $Idata['celebrityId'] = $this->session->userdata('celebrityId');
					}
					$imageFolder = trim($this->input->post('imageFolder'));
                    $Idata['movie_title'] = $movie_title;
                    $Idata['about_movie'] = $about_movie;
					$Idata['movie_director'] = $movie_dir;
                    $Idata['movie_genre'] = $movie_genre;
					$Idata['movie_stars'] = $movie_stars;
                    $Idata['release_date'] = date('y-m-d h:i:s',strtotime($movie_rel_date));
                    $Idata['movie_link'] = $movie_link;
                    //$Idata['isTrendingNews'] = $is_trending_news;
                        $isPremiun = 0;
                    $Idata['createdTime'] = date('y-m-d h:i:s');
					if ($_FILES['thumb_image']['name']) {

                                    if (!empty($_FILES['thumb_image']['name'])) {
                                        $target_path = '../uploads/movies/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['thumb_image']['name']);
                                        $filename = basename($_FILES['thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['thumb_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['thumb_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['movie_thumbnail'] = $picname;
                                            }
											
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect($url);
                                        }
                                    }
                                }
								$where = array();
                    $result = $this->insertOrUpdate(TBL_MOVIES, $where, $Idata);
                    $last_id = $this->db->insert_id();

                    if ($result) {
					        $Tdata['t_post_type'] = 'M';
							$Tdata['t_post_id'] = $last_id;
							$Tdata['t_celebrity_id'] = $celebrityId;
							$where = array();
							$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
						
                          $this->session->set_flashdata('Smessage', SUCCESS);
                        redirect(ADD_TRAILER_URL.'/'.$last_id);
                            }
                    } 
					else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_MOVIE_URL.'/'.$celebrityId);
                       }
				}				
            $data['celebrityId'] = $celebrityId;
            $this->load->view('header');
		    $this->load->view('movies/addMovie',$data);
		    $this->load->view('scripts');
		    $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function editMovie(){
		
		try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			
			$movieId = $this->uri->segment(3);
			$celebrityId = $this->uri->segment(4);
                if ($this->input->post('editMovies')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('editmovie_title', 'movies Title', 'trim|required');
                $this->form_validation->set_rules('editabout_movie', 'About Movie', 'trim|required');
                $this->form_validation->set_rules('editmovie_dir', 'Movie Directer', 'trim|required');
                $this->form_validation->set_rules('editmovie_stars', 'movies Stars', 'trim|required');
                $this->form_validation->set_rules('editmovie_genre', 'Movie Genre', 'trim|required');
                $this->form_validation->set_rules('editmovie_rel_date', 'Movie Release Date', 'trim|required');
                $this->form_validation->set_rules('editmovie_link', 'Movie Link', 'trim|required');
				//$this->form_validation->set_rules('image_option', 'Image Option', 'trim|required');
                if ($this->form_validation->run() != false) {
                     $id = trim($this->input->post('editmovie_id'));
                    $movie_title = trim($this->input->post('editmovie_title'));
                    $about_movie = trim($this->input->post('editabout_movie'));
					$movie_dir = trim($this->input->post('editmovie_dir'));
					$movie_stars = trim($this->input->post('editmovie_stars'));
					$movie_genre = trim($this->input->post('editmovie_genre'));
					$movie_rel_date = trim($this->input->post('editmovie_rel_date'));
					$movie_triller_link = trim($this->input->post('editmovie_triller_link'));
					$movie_link = trim($this->input->post('editmovie_link'));
					$songs_links = $this->input->post('editsongs_link[]');
					$songs_id = $this->input->post('editsongs_Id[]');
					$imageFolder = trim($this->input->post('editimageFolder'));
					if($celebrityId){
						 $Idata['celebrityId'] = $celebrityId;
					}
					elseif($Role_Id == 2){
						 $Idata['celebrityId'] = $this->session->userdata('celebrityId');
					}
                    $Idata['movie_title'] = $movie_title;
                    $Idata['about_movie'] = $about_movie;
					$Idata['movie_director'] = $movie_dir;
                    $Idata['movie_genre'] = $movie_genre;
					$Idata['movie_stars'] = $movie_stars;
                    $Idata['release_date'] = date('y-m-d h:i:s',strtotime($movie_rel_date));
                    $Idata['movie_link'] = $movie_link;
                    //$Idata['isTrendingNews'] = $is_trending_news;
                        $isPremiun = 0;
                    $Idata['updatedTime'] = date('y-m-d h:i:s');
					// START
					if ($_FILES['edit_thumb_image']['name']) {

                                    if (!empty($_FILES['edit_thumb_image']['name'])) {
                                        $target_path = '../uploads/movies/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_thumb_image']['name']);
                                        $filename = basename($_FILES['edit_thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_thumb_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_thumb_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['movie_thumbnail'] = $picname;
                                            }
											
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect($url);
                                        }
                                    }
                                }
								// END
                    $where = array('movie_id'=>$id);
                    $result = $this->insertOrUpdate(TBL_MOVIES, $where, $Idata);
                    $last_id = $this->db->insert_id();

                    if ($result) {
                        $this->session->set_flashdata('Smessage', SUCCESS);
                        redirect(MOVIE_URL.'/'.$celebrityId);
                            }
							else{
							$this->session->set_flashdata('Fmessage', FAILED);
                            redirect(EDIT_MOVIE_URL.'/'.$movieId.'/'.$celebrityId);	
							}
                    } 
					else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_MOVIE_URL.'/'.$movieId.'/'.$celebrityId);
                       }
				}		

		    $where = array('movie_id'=>$movieId);
			$data['details'] =$this->getSingleRecord(TBL_MOVIES,$where,'*');	
			$where = array('s_movieId'=>$movieId);
			$data['songs'] =$this->getAllRecords(TBL_MOVIE_SONGS,$where,'*');
			$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			$data['celebritys'] =$this->getSingleRecord(TBL_CELEBRITY,$where,'*');
            $this->load->view('header');
		    $this->load->view('movies/editMovie',$data);
		    $this->load->view('scripts');
		    $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function addTrailer(){
		try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
		   $id = $this->uri->segment(3);
		    if ($this->input->post('addTrailer')) {
				$this->load->library('form_validation');
                $this->form_validation->set_rules('movie_trailer[]', 'Movie Trailer', 'trim|required');
                $this->form_validation->set_rules('trailer_title[]', 'Movie Trailer title', 'trim|required');
				 if ($this->form_validation->run() != false) {
                    $movie_trailer = $this->input->post('movie_trailer[]');
					$trailer_title = $this->input->post('trailer_title[]');
					$imageName = @$_FILES['thumb_image']['name'];
					 if ($imageName) {
            $i = 0;
            $imageData = array();
            $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
            foreach ($imageName as $name) {
                $target_path = '../uploads/movies/';
                if (!empty($name)) {
                    $response['file_name'] = basename($name);
                    $filename = basename($name);
                    $rand = rand();
                    $file_extension = pathinfo($name);
                    $picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
                    $target_path = $target_path . $picname1;
                    if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                        $movefile = move_uploaded_file($_FILES['thumb_image']['tmp_name'][$i], $target_path);
                        if ($movefile) {
							 $upimgData['mv_trailer'] = $movie_trailer[$i];
                    $upimgData['mv_t_thumbnail'] = $picname1;
                    $upimgData['mv_movie_id'] = $id;
                    $upimgData['mv_t_created_time'] = date('Y-m-d H:i:s');
                    $upimgData['mv_t_title'] = $trailer_title[$i];

                    $where = array();
                    $result = $this->insertOrUpdate(TBL_MOVIE_TRAILER, $where, $upimgData);
                        }
                    }
                }
                $i++;
            }
			if($result){
						 $this->session->set_flashdata('Smessage', " Successfully");
						 redirect(ADD_SONGS_URL.'/'.$id);
					}
					else{
						$this->session->set_flashdata('Fmessage', " Not Successfully");
						 redirect(ADD_TRAILER_URL.'/'.$id);
					}
            
			}
			}
			else{
				 $this->session->set_flashdata('Fmessage', validation_errors());
                 redirect(ADD_TRAILER_URL.'/'.$id);
			}
			}
		   $data['id'] = $id;
		   $this->load->view('header');
		   $this->load->view('movies/addTrailer',$data);
		   $this->load->view('footer');
		}catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
	}
function editTrailer(){
		try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
		   $id = $this->uri->segment(3);
		   $where = array('mv_movie_id'=>$id,'mv_t_is_deleted'=>0);
		   $data['Details'] = $this->getAllRecords(TBL_MOVIE_TRAILER,$where,'*');
		    if ($this->input->post('editTrailer')) {
				$where = array('movie_id'=>$id);
		         $celebrityid = $this->getSingleRecord(TBL_MOVIES,$where,'celebrityId');
				$this->load->library('form_validation');
                $this->form_validation->set_rules('edit_movie_trailer[]', 'Movie Trailer', 'trim|required');
				 if ($this->form_validation->run() != false) {
					 $movie_id = $this->input->post('movieid');
                    $movie_trailer = $this->input->post('edit_movie_trailer[]');
                    $edit_trailer_title = $this->input->post('edit_trailer_title[]');
					$trailer_id = $this->input->post('trailer_id[]');
					$imageName = @$_FILES['edit_thumb_image']['name'];
					 if ($imageName) {
            $i = 0;
            $imageData = array();
            $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
            foreach ($imageName as $name) {
				$picname1="";
                $target_path = '../uploads/movies/';
				    $Data['mv_trailer'] = $movie_trailer[$i];
                    $Data['mv_movie_id'] = $id;
                    $Data['mv_t_updated_time'] = date('Y-m-d H:i:s');
                    $Data['mv_t_title'] = $edit_trailer_title[$i];
                if (!empty($name)) {
                    $response['file_name'] = basename($name);
                    $filename = basename($name);
                    $rand = rand();
                    $file_extension = pathinfo($name);
                    $picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
                    $target_path = $target_path . $picname1;
                    if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                        $movefile = move_uploaded_file($_FILES['edit_thumb_image']['tmp_name'][$i], $target_path);
                        if ($movefile) {
					$upimgData['mv_t_thumbnail'] = $picname1;
					$upimgData['mv_t_title'] = $edit_trailer_title[$i];
					$upimgData['mv_trailer'] = $movie_trailer[$i];
                    $upimgData['mv_movie_id'] = $id;
                    $upimgData['mv_t_updated_time'] = date('Y-m-d H:i:s');
                     $where = array('mv_movie_id'=>$id,'mv_t_id'=>$trailer_id[$i]);
		            $haveRecord = $this->getAllRecords(TBL_MOVIE_TRAILER,$where,'*');
					if($haveRecord){
                    $where = array('mv_t_id'=>$trailer_id[$i]);
                    $result = $this->insertOrUpdate(TBL_MOVIE_TRAILER, $where, $upimgData);}
					else{
						$where = array();
                        $result = $this->insertOrUpdate(TBL_MOVIE_TRAILER, $where, $upimgData);
					}
					}}
				}
				    $where = array('mv_t_id'=>$trailer_id[$i]);
                    $result = $this->insertOrUpdate(TBL_MOVIE_TRAILER, $where, $Data);
                $i++;
            }
			$this->session->set_flashdata('Smessage', " Successfully");
						 redirect(MOVIE_URL.'/'.$celebrityid->celebrityId);
			}
					else{
						$this->session->set_flashdata('Fmessage', " Not Successfully");
						 redirect(EDIT_TRAILER_URL.'/'.$id);
					}
			}
			else{
				 $this->session->set_flashdata('Fmessage', validation_errors());
                 redirect(EDIT_TRAILER_URL.'/'.$id);
			}
			}
		   $data['id'] = $id;
		   $this->load->view('header');
		   $this->load->view('movies/editTrailer',$data);
		   $this->load->view('footer');
		}catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
	}
	function deleteTrailer() {
		if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $where = array('mv_t_id' => $id);
            $data['mv_t_is_deleted'] = 1;
            $success = $this->insertOrUpdate(TBL_MOVIE_TRAILER,$where,$data);
            if ($success ==1) {
                 $this->session->set_flashdata('Smessage', "Delete Successfully");
            } else {
                $this->session->set_flashdata('Fmessage', "Failed");
            }
            
		}
	}
	function addSongs(){
		try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
		   $id = $this->uri->segment(3);
		    if ($this->input->post('addSongs')) {
				$this->load->library('form_validation');
                $this->form_validation->set_rules('movie_song_title[]', 'Movie Song Title', 'trim|required');
				$this->form_validation->set_rules('movie_songs[]', 'Movie Songs', 'trim|required');
				 if ($this->form_validation->run() != false) {
                    $movie_song_title = $this->input->post('movie_song_title[]');
					$movie_songs = $this->input->post('movie_songs[]');
					 if ($movie_song_title) {
						 $i=0;
            foreach ($movie_song_title as $title) {//print_r($name);die();
                if (!empty($title)) {
					$upimgData['s_song_name'] = $title;
                    $upimgData['s_movieId'] = $id;
					$upimgData['s_song'] = $movie_songs[$i];
                    $upimgData['s_createdTime'] = date('Y-m-d H:i:s');
                     
                    $where = array();
                    $result = $this->insertOrUpdate(TBL_MOVIE_SONGS, $where, $upimgData);
                        
						}
						$i++;
                    }
			if($result){
						 $this->session->set_flashdata('Smessage', " Successfully");
						 redirect(ADD_GALLERY_IMAGES_URL.$id);
					}
					else{
						$this->session->set_flashdata('Fmessage', " Not Successfully");
						 redirect(ADD_SONGS_URL.'/'.$id);
					}
		}
            
			}
			else{
				 $this->session->set_flashdata('Fmessage', validation_errors());
                 redirect(ADD_SONGS_URL.'/'.$id);
			}
			}
		   $data['id'] = $id;
		   $this->load->view('header');
		   $this->load->view('movies/addSongs',$data);
		   $this->load->view('footer');
		}catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
	}
	function editSongs(){
		try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
		   $id = $this->uri->segment(3);
		   $where = array('s_movieId'=>$id,'s_isDeleted'=>0);
		   $data['songDetails'] = $this->getAllRecords(TBL_MOVIE_SONGS,$where,'*');
		    if ($this->input->post('editSongs')) {
				$where = array('movie_id'=>$id);
		         $celebrityid = $this->getSingleRecord(TBL_MOVIES,$where,'celebrityId');
				$this->load->library('form_validation');
                $this->form_validation->set_rules('edit_movie_song_title[]', 'Movie Song Title', 'trim|required');
				$this->form_validation->set_rules('edit_movie_songs[]', 'Movie Songs', 'trim|required');
				 if ($this->form_validation->run() != false) {
                    $movie_song_title = $this->input->post('edit_movie_song_title[]');
					$movie_songs = $this->input->post('edit_movie_songs[]');
					$movie_song_id = $this->input->post('edit_movie_song_id[]');
					 if ($movie_song_title) {
						 $i=0;
                 foreach ($movie_song_title as $title) {//print_r($name);die();
                if (!empty($title)) {
					$upimgData['s_song_name'] = $title;
                    $upimgData['s_movieId'] = $id;
					$upimgData['s_song'] = $movie_songs[$i];
                    $upimgData['s_createdTime'] = date('Y-m-d H:i:s');
                    $where = array('s_movieId'=>$id,'s_id'=>$movie_song_id[$i]);
		            $haveRecord = $this->getAllRecords(TBL_MOVIE_SONGS,$where,'*');
					if($haveRecord){
                    $where = array('s_id'=>$movie_song_id[$i]);
                    $result = $this->insertOrUpdate(TBL_MOVIE_SONGS, $where, $upimgData);}
					else{
						$where = array();
                        $result = $this->insertOrUpdate(TBL_MOVIE_SONGS, $where, $upimgData);
					}
						}
						$i++;
                    }
			if($result){
						 $this->session->set_flashdata('Smessage', " Successfully");
						 redirect(MOVIE_URL.'/'.$celebrityid->celebrityId);
					}
					else{
						$this->session->set_flashdata('Fmessage', " Not Successfully");
						 redirect(EDIT_SONGS_URL.'/'.$id);
					}
		}
            
			}
			else{
				 $this->session->set_flashdata('Fmessage', validation_errors());
                 redirect(EDIT_SONGS_URL.'/'.$id);
			}
			}
		   $data['id'] = $id;
		   $this->load->view('header');
		   $this->load->view('movies/editSongs',$data);
		   $this->load->view('footer');
		}catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
	}
	function deleteSong() {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $where = array('s_id' => $id);
            $data['s_isDeleted'] = 1;
            $success = $this->insertOrUpdate(TBL_MOVIE_SONGS,$where,$data);
            if ($success ==1) {
                 $this->session->set_flashdata('Smessage', "Delete Successfully");
            } else {
                $this->session->set_flashdata('Fmessage', "Failed");
            }
            
		}
	}
		function movieDetails(){
			$data['id'] =$this->uri->segment(3);
			$this->load->view('header');
		   $this->load->view('movies/movieDetails',$data);
		   $this->load->view('footer');
		}
	 function movieImageList() {
		 $id = $this->uri->segment(3);
		 $where = array('mvi_id'=>$id,'mvi_is_deleted'=>0);
         $mImageTitles = $this->getAllRecords(TBL_MOVIE_IMAGE,$where,'mvi_title,mvi_img_id,mvi_id');
		 $data['mvi_titles'] = $mImageTitles;
		$data['id'] =$id;
        $this->load->view('header');
		$this->load->view('movies/movieImageDetails',$data);
		$this->load->view('footer');
	} 
	function aboutMovie() {
		 $id =$this->uri->segment(3);
		 $where =array('movie_id'=>$id);
		$details = $this->getAllRecords(TBL_MOVIES,$where,'*');
        $data['details'] = $details;
		$data['id'] =$id;
		$data['title'] =$this->uri->segment(4);
        $this->load->view('header');
		$this->load->view('movies/aboutMovie',$data);
		$this->load->view('footer');
	} 
	function movieImagesData(){
		$id =$this->uri->segment(3);
		$where =array('mvi_img_id'=>$id);
		$details = $this->getSingleRecord(TBL_MOVIE_IMAGE,$where,'*');
		$title = str_ireplace("%20"," ",$details->mvi_title);
		$data['title'] =$title;
		$data['id'] = $details->mvi_id;
	    $this->load->view('header');
		$this->load->view('movies/imagedata',$data);
		$this->load->view('footer');
	}
	function movieSongs(){
		$id =$this->uri->segment(3);
		$where =array('s_movieId'=>$id);
		$details = $this->getAllRecords(TBL_MOVIE_SONGS,$where,'*');
        $data['songs'] = $details;
		$data['id'] =$id;
	    $this->load->view('header');
		$this->load->view('movies/songsLink',$data);
		$this->load->view('footer');
	}
	function movieTrailer(){
		$id =$this->uri->segment(3);
		$where =array('mv_movie_id'=>$id);
		$details = $this->getAllRecords(TBL_MOVIE_TRAILER,$where,'*');
        $data['trailer'] = $details;
		$data['id'] =$id;
	    $this->load->view('header');
		$this->load->view('movies/trailerLink',$data);
		$this->load->view('footer');
	}
	function fullMovie(){
		$id =$this->uri->segment(3);
		$where =array('movie_id'=>$id);
		$details = $this->getSingleRecord(TBL_MOVIES,$where,'movie_link');
        $data['movie'] = $details;
		$data['id'] =$id;
	    $this->load->view('header');
		$this->load->view('movies/fullMovieLink',$data);
		$this->load->view('footer');
	}
	function addGeleryImages(){
		try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
            if ($this->input->post('addGaleryImagesMore') || $this->input->post('addGaleryImages')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('mvi_title', 'Movie Image Title', 'trim|required');
                if ($this->form_validation->run() != false) {
                    $movieId = $this->uri->segment(3);
					$where = array('movie_id'=>$movieId);
					$moviename = $this->getSingleRecord(TBL_MOVIES,$where,'movie_title');
					$movieTitle = $moviename->movie_title;
					$mvi_title = trim($this->input->post('mvi_title'));
					$mvi_title = $mvi_title.'-'.$movieTitle;
					$Idata['mvi_title'] = $mvi_title;
                    $where = array('mvi_title' => $mvi_title,'mvi_id'=>$movieId);
                     $Exists=$this->getAllRecords(TBL_MOVIE_IMAGE,$where,"*");
                      if($Exists && count($Exists)>0){
                      $this->session->set_flashdata('Fmessage',"movie folder already existed with this title." );
                      redirect(ADD_GALERY_IMAGES_URL.$movieId);
                      } 
					  $mvi_title = str_ireplace(' ','_',$mvi_title);
                     $myNewFolderPath ='../uploads/movies/'.$mvi_title;
					 mkdir($myNewFolderPath);
                     $celebrityId = $this->uri->segment(4);
					$Idata['mvi_id'] = $movieId;
                    $Idata['mvi_created_time'] = date('y-m-d h:i:s');
                    $where = array();
                    $result = $this->insertOrUpdate(TBL_MOVIE_IMAGE, $where, $Idata);
                    $last_id = $this->db->insert_id();
					if($result){
						if ($_FILES) {
                            
                            //for images 
                            $imageName = "";
                            $imageName = @$_FILES['movie_image']['name'];
                           
										if ($imageName) {
											$i = 0;
											$imageData = array();
											$fileTypes = array('jpg','png','gif');
											foreach ($imageName as $name) {
													$target_path = $myNewFolderPath.'/';
												if (!empty($name)) {
													$response['file_name'] = basename($name);
													$filename = basename($name);
													$rand = rand();
													$file_extension = pathinfo($name);
													$picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
													$target_path = $target_path . $picname1;
													if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
														$movefile = move_uploaded_file($_FILES['movie_image']['tmp_name'][$i], $target_path);
														if ($movefile) {
															$imageData[$i] = $picname1;
															
														}
													}
													else {
														  $this->session->set_flashdata('Fmessage', "File formate is not supported");
														  redirect($url);
														}
												}
												$i++;
												}
												
					}  
                            }
							if($this->input->post('addGaleryImagesMore')){
								$this->session->set_flashdata('Smessage', SUCCESS);
								redirect(ADD_GALLERY_IMAGES_URL.'/'.$movieId);
							}else{
								$this->session->set_flashdata('Smessage', SUCCESS);
								redirect(MOVIE_URL.'/'.$celebrityId);
							}
					}
					} 
					else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_GALLERY_IMAGES_URL);
                       }
			}
			$movieId = $this->uri->segment(3);
			$where = array('movie_id'=>$movieId);
			$celebrityId = $this->getSingleRecord(TBL_MOVIES,$where,'*');
			if(empty($celebrityId)){
				redirect(CELEBRITY_URL);
			}
			$data['celebrityId'] = $celebrityId->celebrityId;
			$data['movieId'] = $movieId;
		$this->load->view('header');
        $this->load->view('movies/addGeleryImages',$data);
        $this->load->view('scripts');
        $this->load->view('footer');
		 } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		function editGeleryImages(){
		try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
            if ($this->input->post('editGaleryImages')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_mvi_title', 'Movie Image Title', 'trim|required');
                if ($this->form_validation->run() != false) {
					$id = $this->uri->segment(3);
					$celebrityId = $this->uri->segment(4);
					$mviImgId = $this->uri->segment(5);
					$mvi_title = trim($this->input->post('edit_mvi_title'));
					  $Idata['mvi_title'] = $mvi_title;
					 $mvi_title = str_ireplace(' ','_',$mvi_title);
                     $myNewFolderPath ='../uploads/movies/'.$mvi_title;
					 mkdir($myNewFolderPath);
					$Idata['mvi_id'] = $id;
                    $Idata['mvi_updated_time'] = date('y-m-d h:i:s');
                    $where = array('mvi_img_id'=>$mviImgId);
                    $result = $this->insertOrUpdate(TBL_MOVIE_IMAGE, $where, $Idata);
                    $last_id = $this->db->insert_id();
					if($result){
						if ($_FILES) {
                            
                            //for images 
                            $imageName = "";
                            $imageName = @$_FILES['edit_movie_image']['name'];
                           
										if ($imageName) {
											$i = 0;
											$imageData = array();
											$fileTypes = array('jpg','png','gif');
											foreach ($imageName as $name) {
													$target_path = $myNewFolderPath.'/';
												if (!empty($name)) {
													$response['file_name'] = basename($name);
													$filename = basename($name);
													$rand = rand();
													$file_extension = pathinfo($name);
													$picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
													$target_path = $target_path . $picname1;
													if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
														$movefile = move_uploaded_file($_FILES['edit_movie_image']['tmp_name'][$i], $target_path);
														if ($movefile) {
															$imageData[$i] = $picname1;
															
														}
													}
													else {
														  $this->session->set_flashdata('Fmessage', "File formate is not supported");
														  redirect($url);
														}
												}
												$i++;
												}
												
					}  
                            }
								$this->session->set_flashdata('Smessage', SUCCESS);
								redirect(MOVIE_IMAGES_LIST_URL.'/'.$id);
					}
					} 
					else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_GALLERY_IMAGES_URL.'/'.$id);
                       }
			}
			$id = $this->uri->segment(3);
			$where = array('mvi_img_id'=>$id);
			$details = $this->getSingleRecord(TBL_MOVIE_IMAGE,$where,'*');
			 $data['details'] = $details;
			 $movieId = $details->mvi_id;
			$where = array('movie_id'=>$movieId);
			$celebrityId = $this->getSingleRecord(TBL_MOVIES,$where,'*');
			if(empty($celebrityId)){
				redirect(CELEBRITY_URL);
			}
			$data['celebrityId'] = $celebrityId->celebrityId;
		$this->load->view('header');
        $this->load->view('movies/editGeleryImages',$data);
        $this->load->view('scripts');
        $this->load->view('footer');
		 } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function deleteMovie() {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $where = array('movie_id' => $id);
			//$celebrityId = $this->getSingleRecord(TBL_MOVIES,$where,'celebrityId');
            $data['isDeleted'] = 1;
            $success = $this->insertOrUpdate(TBL_MOVIES,$where,$data);
			$where = array('movieId'=>$id);
			$result = $this->insertOrUpdate(TBL_MOVIE_IMAGE,$where,$data);
            if ($success ==1) {
                 $this->session->set_flashdata('Smessage', "Delete Successfully");
				// redirect(MOVIE_URL.'/'.$celebrityId->celebrityId);
            } else {
                $this->session->set_flashdata('Fmessage', "Delete Not Successfully");
				//redirect(MOVIE_URL.'/'.$celebrityId->celebrityId);
            }
            
		}
	}
	function deleteGeleryImages(){
		if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
			$data['mvi_is_deleted'] = 1;
            $where = array('mvi_img_id' => $id);
			 $title = $this->input->post('title');
			 $gallerytitle = str_ireplace(" ","_",$title);
			 $dirname = '../uploads/movies/'.$gallerytitle;
		    foreach(glob($dirname."/*",GLOB_BRACE) as $movieImage){
			 unlink($movieImage);
			 }
			rmdir($dirname);
            $success = $this->insertOrUpdate(TBL_MOVIE_IMAGE,$where,$data);
            if ($success ==1) {
                 $this->session->set_flashdata('Smessage', "Delete Successfully");
				 
            } else {
                $this->session->set_flashdata('Fmessage', "Delete Not Successfully");
            }
            
		}
	}
	 function deleteImage() {
        if ($this->input->is_ajax_request()) {
            $imagePath = $this->input->post('path');
            if(file_exists($imagePath)){
            unlink($imagePath);
               $this->session->set_flashdata('Smessage', "Image Delete Successfully");
            } else {
             $this->session->set_flashdata('Fmessage', "Image Delete Failed");
            }
            die();
        }
    } 

}