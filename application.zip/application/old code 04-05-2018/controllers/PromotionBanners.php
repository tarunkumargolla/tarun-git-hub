<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header("access-control-allow-origin: *");
class PromotionBanners extends Healthcontroller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
        $this->load->model('Commonmodel'); 
	}
	
	function index(){
		try{
			$Role_Id=$this->session->userdata('Role_Id');
			if( empty($Role_Id) && empty($agentId) )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(LOGOUT_URL,'refresh');
				}
			}
			$celebrityId = $this->uri->segment(3);
			$data['celebrityId'] = $celebrityId;
			if($Role_Id == 1){
			$where = array('promotion_is_deleted'=>0,'promotion_celebrity_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('promotion_is_deleted'=>0,'promotion_celebrity_id'=>$celebrityId);
			}
            $promotionBanners = $this->getAllRecords(TBL_PROMOTION_BANNERS,$where,'*');
			if($Role_Id == 1){
			$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			}
			$celebrity = $this->getSingleRecord(TBL_CELEBRITY,$where,'*');
			if(empty($celebrity)){
			redirect(DASHBOARD_URL);
		        }
		    $data['promotionBanners']= $promotionBanners ;
			$data['cele_Name']=@$celebrity->c_name;
			$data['celebrityId']=@$celebrityId;
			$this->load->view('header');
		    $this->load->view('promotionBanners/promotionBanner',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		
	}
	function addPromotionBanner() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$celebrityId = $this->uri->segment(3);
			$data['celebrityId'] = $celebrityId;
            if ($this->input->post('addPromotionBanner')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('type', 'Article Type', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $promotionBanners_title = trim($this->input->post('promotionBanners_title'));
                    $promotionBanners_content = trim($this->input->post('promotionBanners_content'));
					$promotionBanners_order = trim($this->input->post('promotionBanners_order'));
					$type = $this->input->post('type');
					$promotionBanners_videoUrl = trim($this->input->post('promotionBanners_videoUrl'));
                    $Idata['promotion_title'] = $promotionBanners_title;
					if($celebrityId){
                    $Idata['promotion_celebrity_id'] = $celebrityId;}
					else{
						$celebrityId = $this->session->userdata('celebrityId');
						$Idata['promotion_celebrity_id'] = $celebrityId;
					}
					$Idata['promotion_type'] = $type;
					$Idata['promotion_content'] = $promotionBanners_content;
					$Idata['promotion_display_order'] = $promotionBanners_order;
                    $Idata['promotion_createdTime'] = date('y-m-d h:i:s');
					             if($type == 25 || $type == 26){
									  $Idata['promotion_image'] = "";
									$tPostData['createdTime'] = date('Y-m-d h:i:s');
                                     if (!empty($_FILES['promotion_thumb_image']['name'])) {
                                        $target_path = '../uploads/promotionBanners/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['promotion_thumb_image']['name']);
                                        $filename = basename($_FILES['promotion_thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['promotion_thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['promotion_thumb_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $Idata['promotion_thumb_image'] = $picname2;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_PROMOTION_BANNERS_URL);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported it will take only image files");
                                            redirect(ADD_PROMOTION_BANNERS_URL);
                                        }}
										if(!empty($promotionBanners_videoUrl)){
											$Idata['promotion_video_code'] = $promotionBanners_videoUrl;
										}
                                    if (!empty($_FILES['promotionBanners_video']['name'])) {
                                        $target_path = '../uploads/promotionBanners/';
                                        $fileTypes = array('mp4');
                                        $response['file_name'] = basename($_FILES['promotionBanners_video']['name']);
                                        $filename = basename($_FILES['promotionBanners_video']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['promotionBanners_video']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['promotionBanners_video']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['promotion_video_file'] = $picname;
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_PROMOTION_BANNERS_URL);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported it will take only viedo files");
                                            redirect(ADD_PROMOTION_BANNERS_URL);
                                        }
                                    }
                                }
								if($type == 24){
									$Idata['promotion_video_file'] = "";
									$Idata['promotion_thumb_image'] = "";
									$Idata['promotion_video_code'] = "";
                                    if (!empty($_FILES['promotionBanners_image']['name'])) {
                                        $target_path = '../uploads/promotionBanners/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['promotionBanners_image']['name']);
                                        $filename = basename($_FILES['promotionBanners_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['promotionBanners_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['promotionBanners_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['promotion_image'] = $picname;//print_r($Idata);die();
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_PROMOTION_BANNERS_URL);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported it will take only image files");
                                            redirect(ADD_PROMOTION_BANNERS_URL);
                                        }
                                }
								}
								$where1 = array();
								$result = $this->insertOrUpdate(TBL_PROMOTION_BANNERS, $where1, $Idata);
								$last_id = $this->db->insert_id();
								if($result){
									$Tdata['t_post_type'] = $type;
									$Tdata['t_post_id'] = $last_id;
									$Tdata['t_celebrity_id'] = $celebrityId;
									$where = array();
									$Tresult = $this->insertOrUpdate(TBL_PROMOTION_BANNERS,$where,$Tdata); 
								 $this->session->set_flashdata('Smessage', SUCCESS);
                                 redirect(PROMOTION_BANNERS_URL.'/'.$promotionBanners_celebrity);
								}
								else {
                                $this->session->set_flashdata('Fmessage', FAILED);
                                redirect(ADD_PROMOTION_BANNERS_URL);
								}
					         }
							 else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_PROMOTION_BANNERS_URL);
                }
		}
            $this->load->view('header');
            $this->load->view('promotionBanners/addPromotionBanner',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		function editPromotionBanner() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$id = $this->uri->segment(3);
			$celebrityId = $this->uri->segment(4);
			$where = array('promotion_id'=>$id);
			$data['Details'] = $this->getSingleRecord(TBL_PROMOTION_BANNERS,$where,'*'); 
			$where = array('c_is_deleted'=>0);
			$data['celebritys'] = $this->getAllRecords(TBL_CELEBRITY,$where,'*');
            if ($this->input->post('editPromotionBanner')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('type', 'Article Type', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $promotionBanners_title = trim($this->input->post('edit_promotionBanners_title'));
                    $promotionBanners_content = trim($this->input->post('edit_promotionBanners_content'));
					$promotionBanners_order = trim($this->input->post('edit_promotionBanners_order'));
					$type = $this->input->post('type');
					$promotionBanners_videoUrl = trim($this->input->post('edit_promotionBanners_videoUrl'));
                    $Idata['promotion_title'] = $promotionBanners_title;
					if($celebrityId){
                    $Idata['promotion_celebrity_id'] = $celebrityId;}
					else{
						$celebrityId = $this->session_>userdata('celebrityId');
						$Idata['promotion_celebrity_id'] = $celebrityId;
					}
					$Idata['promotion_type'] = $type;
					$Idata['promotion_content'] = $promotionBanners_content;
					$Idata['promotion_display_order'] = $promotionBanners_order;
                    $Idata['promotion_updatedTime'] = date('y-m-d h:i:s');
					             if($type == 25 || $type == 26){
									  $Idata['promotion_image'] = "";
									$tPostData['createdTime'] = date('Y-m-d h:i:s');
                                     if (!empty($_FILES['edit_promotion_thumb_image']['name'])) {
                                        $target_path = '../uploads/promotionBanners/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_promotion_thumb_image']['name']);
                                        $filename = basename($_FILES['edit_promotion_thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_promotion_thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_promotion_thumb_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $Idata['promotion_thumb_image'] = $picname2;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_PROMOTION_BANNERS_URL.'/'.$id);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported it will take only image files");
                                            redirect(EDIT_PROMOTION_BANNERS_URL.'/'.$id);
                                        }}
										if(!empty($promotionBanners_videoUrl)){
											$Idata['promotion_video_code'] = $promotionBanners_videoUrl;
										}
                                    if (!empty($_FILES['edit_promotionBanners_video']['name'])) {
                                        $target_path = '../uploads/promotionBanners/';
                                        $fileTypes = array('mp4');
                                        $response['file_name'] = basename($_FILES['edit_promotionBanners_video']['name']);
                                        $filename = basename($_FILES['promotionBanners_video']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_promotionBanners_video']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_promotionBanners_video']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['promotion_video_file'] = $picname;
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_PROMOTION_BANNERS_URL.'/'.$id);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported it will take only viedo files");
                                            redirect(EDIT_PROMOTION_BANNERS_URL.'/'.$id);
                                        }
                                    }
                                }
								if($type == 24){
									$Idata['promotion_video_file'] = "";
									$Idata['promotion_thumb_image'] = "";
									$Idata['promotion_video_code'] = "";
                                    if (!empty($_FILES['edit_promotionBanners_image']['name'])) {
                                        $target_path = '../uploads/promotionBanners/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_promotionBanners_image']['name']);
                                        $filename = basename($_FILES['edit_promotionBanners_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_promotionBanners_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_promotionBanners_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['promotion_image'] = $picname;//print_r($Idata);die();
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_PROMOTION_BANNERS_URL.'/'.$id);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported it will take only image files");
                                            redirect(EDIT_PROMOTION_BANNERS_URL.'/'.$id);
                                        }
                                }
								}
								$where = array('promotion_id'=>$id);debug($Idata);
								$result = $this->insertOrUpdate(TBL_PROMOTION_BANNERS, $where, $Idata);
								if($result){
								 $this->session->set_flashdata('Smessage', SUCCESS);
                                 redirect(PROMOTION_BANNERS_URL.'/'.$celebrityId);
								}
								else {
                                $this->session->set_flashdata('Fmessage', FAILED);
                                redirect(EDIT_PROMOTION_BANNERS_URL.'/'.$id);
								}
					         }
							 else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_PROMOTION_BANNERS_URL.'/'.$id);
                }
		}
            $this->load->view('header');
            $this->load->view('promotionBanners/editPromotionBanner',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function deletePromotionBanner() {
        if ($this->input->is_ajax_request()) {
			$id = $this->input->post('id');
			 $data['promotion_is_deleted'] = 1;
			$where = array('promotion_id'=>$id);
			$deletepromotionBanners = $this->insertOrUpdate(TBL_PROMOTION_BANNERS,$where,$data);
            if($deletepromotionBanners == 1){
               $this->session->set_flashdata('Smessage', SUCCESS);
            } else {
             $this->session->set_flashdata('Fmessage', FAILED);
            }
            die();
        }
    }
}