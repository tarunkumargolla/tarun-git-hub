<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header("access-control-allow-origin: *");
class Timeline extends Healthcontroller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
        $this->load->model('Commonmodel'); 
	}
	
	function index(){
		try{
			$Role_Id=$this->session->userdata('Role_Id');
			if( empty($Role_Id) && empty($agentId) )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(LOGOUT_URL,'refresh');
				}
			}
			$celebrityId = $this->uri->segment(3);
			$where = array('isDeleted'=>0);
            $timelinePosts = $this->getAllRecords(TBL_TIMELINE_POST,$where,'*');
			if($Role_Id == 1){
			$where = array('a_t_is_deleted'=>0,'a_t_celebrity_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('a_t_is_deleted'=>0,'a_t_celebrity_id'=>$celebrityId);
			}
			$data['adminTimelinePosts'] = $this->getAllRecords(TBL_ADMIN_TIMELINE_POST,$where,'*');
			if($Role_Id == 1){
			$where = array('c_is_deleted'=>0);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			}
			$celebrity = $this->getSingleRecord(TBL_CELEBRITY,$where,'*');
			if(empty($celebrity)){
			redirect(CELEBRITY_URL);
		        }
		    $data['timelinePosts']= $timelinePosts ;
			$data['cele_Name']=@$celebrity->c_name;
			$data['celebrityId']=@$celebrityId;
			
			$this->load->view('header');
		    $this->load->view('timeline/timeline',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		
	}
	function timelineImages(){
		try{
			$Role_Id=$this->session->userdata('Role_Id');
			if( empty($Role_Id) && empty($agentId) )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(LOGOUT_URL,'refresh');
				}
			}
			$id = $this->uri->segment(3);
			     $where = array('isDeleted'=>0,'timeline_postId'=>$id);
            $data['timelinePosts'] = $this->getAllRecords(TBL_TIMELINE_POST,$where,'*');
			if($Role_Id == 1){
			$where = array('c_is_deleted'=>0);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			}
			$celebrity = $this->getSingleRecord(TBL_CELEBRITY,$where,'*');
			$data['cele_Name']=@$celebrity->c_name;
			//debug($data);
			$this->load->view('header');
		    $this->load->view('timeline/timelineImages',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		
	}
	function addTimeline() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$where = array('c_is_deleted'=>0);
             $celebritys = $this->getAllRecords(TBL_CELEBRITY,$where,'*');
            $data['celebritys'] = $celebritys;
            if ($this->input->post('addTimeline')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('timeline_title', 'Timeline Title', 'trim|required');
                $this->form_validation->set_rules('type', 'Article Type', 'trim|required');
			    $this->form_validation->set_rules('celebrity', 'Timeline Celebrity', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $timeline_title = trim($this->input->post('timeline_title'));
                    $timeline_content = trim($this->input->post('timeline_content'));
					$type = $this->input->post('type');
					$timeline_celebrity = $this->input->post('celebrity');
					$timeline_videoUrl = trim($this->input->post('timeline_videoUrl'));
                    $Idata['a_t_title'] = $timeline_title;
					if($timeline_celebrity){
                    $Idata['a_t_celebrity_id'] = $timeline_celebrity;}
					else{
						$timeline_celebrity = $this->session_>userdata('celebrityId');
						$Idata['a_t_celebrity_id'] = $timeline_celebrity;
					}
					$Idata['a_t_article_type'] = $type;
					$Idata['a_t_content'] = $timeline_content;
                        $isPremiun = 0;
                    $Idata['a_t_created_time'] = date('y-m-d h:i:s');
					$where = array();
					$result = $this->insertOrUpdate(TBL_ADMIN_TIMELINE_POST, $where, $Idata);
					$last_id = $this->db->insert_id();
					/* save into timeline table */
					$Tdata['t_post_type'] = $type;
					$Tdata['t_post_id'] = $last_id;
					$Tdata['t_celebrity_id'] = $timeline_celebrity;
					$where = array();
					$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
					/* end */
					if($result){
					             if($type == 7 || $type == 9){
									 $tPostData['timeline_postId'] = $last_id;
									$tPostData['createdTime'] = date('Y-m-d h:i:s');
                                     if (!empty($_FILES['thumb_image']['name'])) {
                                        $target_path = '../uploads/timeline/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['thumb_image']['name']);
                                        $filename = basename($_FILES['thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['thumb_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $tPostData['thumb_image'] = $picname2;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_TIMELINE_POST_URL);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported it will take only image files");
                                            redirect(ADD_TIMELINE_POST_URL);
                                        }}
										if(!empty($timeline_videoUrl)){
											$tPostData['video_url'] = $timeline_videoUrl;
										}
                                    if (!empty($_FILES['timeline_video']['name'])) {
                                        $target_path = '../uploads/timeline/';
                                        $fileTypes = array('mp4');
                                        $response['file_name'] = basename($_FILES['timeline_video']['name']);
                                        $filename = basename($_FILES['timeline_video']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['timeline_video']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['timeline_video']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $tPostData['video'] = $picname;
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_TIMELINE_POST_URL);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported it will take only viedo files");
                                            redirect(ADD_TIMELINE_POST_URL);
                                        }
                                    }
									$where1 = array();
								$timelineResult = $this->insertOrUpdate(TBL_TIMELINE_POST, $where1, $tPostData);
								if($timelineResult){
									                /* $Tdata['t_post_type'] = $type;
													$Tdata['t_post_id'] = $last_id;
													$Tdata['t_celebrity_id'] = $timeline_celebrity;
													$where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata); */
								 $this->session->set_flashdata('Smessage', SUCCESS);
                                 redirect(TIMELINE_POST_URL.'/'.$timeline_celebrity);
								}
								else {
                                $this->session->set_flashdata('Fmessage', FAILED);
                                redirect(ADD_TIMELINE_POST_URL);
								}
                                }
								if($type == 8 || $type == 10){
									$tPostData['timeline_postId'] = $last_id;
									$tPostData['createdTime'] = date('Y-m-d h:i:s');
									$tPostData['video'] = "";
									$tPostData['thumb_image'] = "";
										$imageName = $_FILES['timeline_image']['name'];//print_r($imageName);die();
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                         if ($imageName) {
												$i = 0;
												$imageData = array();
												$fileTypes = $fileTypes;
												foreach ($imageName as $name) {
													if (!empty($name)) {
														$target_path = '../uploads/timeline/';
														$response['file_name'] = basename($name);
														$filename = basename($name);
														$rand = rand();
														$file_extension = pathinfo($name);
														$picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
														$target_path = $target_path . $picname1;
														if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
															$movefile = move_uploaded_file($_FILES['timeline_image']['tmp_name'][$i], $target_path);
															if ($movefile) {
																$imageData[$i] = $picname1;
															}
														}
													}
													$i++;
												}
												if ($imageData) {
													foreach ($imageData as $imgD) {
														$tPostData['image'] = $imgD;
														$where1 = array();
								                    $Result = $this->insertOrUpdate(TBL_TIMELINE_POST, $where1, $tPostData);
													}
													if($Result){
														$this->session->set_flashdata('Smessage', SUCCESS);
														redirect(TIMELINE_POST_URL.'/'.$timeline_celebrity);
												 }
												 else {
													$this->session->set_flashdata('Fmessage', FAILED);
													redirect(ADD_TIMELINE_POST_URL);
													}
												}
											}
                                    if (!empty($_FILES['timeline_gif']['name'])) {
                                        $target_path = '../uploads/timeline/';
                                        $fileTypes = array('gif');
                                        $response['file_name'] = basename($_FILES['timeline_gif']['name']);
                                        $filename = basename($_FILES['timeline_gif']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['timeline_gif']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['timeline_gif']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $tPostData['image'] = $picname;//print_r($Idata);die();
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_TIMELINE_POST_URL);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported it will take only gif files");
                                            redirect(ADD_TIMELINE_POST_URL);
                                        }
										$where1 = array();
								$timelineResult1 = $this->insertOrUpdate(TBL_TIMELINE_POST, $where1, $tPostData);
								if($timelineResult1){
									                /* $Tdata['t_post_type'] = $type;
													$Tdata['t_post_id'] = $timelineResult1;
													$Tdata['t_celebrity_id'] = $timeline_celebrity;
													$where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata); */
								 $this->session->set_flashdata('Smessage', SUCCESS);
                                 redirect(TIMELINE_POST_URL.'/'.$timeline_celebrity);
								}
								else {
                                $this->session->set_flashdata('Fmessage', FAILED);
                                redirect(ADD_TIMELINE_POST_URL);
								}
                                }
								}
								                        $Tdata['t_post_type'] = $type;
														$Tdata['t_post_id'] = $last_id;
														$Tdata['t_celebrity_id'] = $timeline_celebrity;
														$where = array();
														$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata); 
					         }
							 else {
                                $this->session->set_flashdata('Fmessage', FAILED);
                                redirect(ADD_TIMELINE_POST_URL);
								}
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_TIMELINE_POST_URL);
                }
            }
            $this->load->view('header');
            $this->load->view('timeline/addTimeline',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		function editTimeline() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$id = $this->uri->segment(3);
			$where = array('timeline_postId'=>$id,'isDeleted'=>0);
			$data['timelineDetails'] = $this->getAllRecords(TBL_TIMELINE_POST,$where,'*');
			$where = array('a_t_id'=>$id);
			$data['tAdminDetails'] = $this->getSingleRecord(TBL_ADMIN_TIMELINE_POST,$where,'*');
			$celebrityId = $data['tAdminDetails']->a_t_celebrity_id;
			$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
             $celebritys = $this->getAllRecords(TBL_CELEBRITY,$where,'*');
            $data['celebritys'] = $celebritys;
            if ($this->input->post('editTimeline')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_timeline_title', 'Timeline Title', 'trim|required');
                //$this->form_validation->set_rules('type', 'Article Type', 'trim|required');
			    $this->form_validation->set_rules('edit_celebrity', 'Timeline Celebrity', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $timeline_title = trim($this->input->post('edit_timeline_title'));
                    $timeline_content = trim($this->input->post('edit_timeline_content'));
					$type = $this->input->post('type');
					$timeline_celebrity = $this->input->post('edit_celebrity');
					$timeline_videoUrl = trim($this->input->post('edit_timeline_videoUrl'));
					$aTimelineId = $this->uri->segment(3);
					$tId = $this->input->post('tid');
                    $Idata['a_t_title'] = $timeline_title;
					if($timeline_celebrity){
                    $Idata['a_t_celebrity_id'] = $timeline_celebrity;}
					else{
						$timeline_celebrity = $this->session_>userdata('celebrityId');
						$Idata['a_t_celebrity_id'] = $timeline_celebrity;
					}
					//$Idata['a_t_article_type'] = $type;
					$Idata['a_t_content'] = $timeline_content;
                        $isPremiun = 0;
                    $Idata['a_t_created_time'] = date('y-m-d h:i:s');
					$id = $this->input->post('atId');
					$where = array('a_t_id'=>$id);
					$result = $this->insertOrUpdate(TBL_ADMIN_TIMELINE_POST, $where, $Idata);
					if($result){
					             if($type == 7 || $type == 9){
									 $tPostData['timeline_postId'] = $aTimelineId;
									$tPostData['updatedTime'] = date('Y-m-d h:i:s');
                                     if (!empty($_FILES['edit_thumb_image']['name'])) {
                                        $target_path = '../uploads/timeline/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_thumb_image']['name']);
                                        $filename = basename($_FILES['edit_thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_thumb_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $tPostData['thumb_image'] = $picname2;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_TIMELINE_POST_URL.'/'.$aTimelineId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported it will take only image files");
                                            redirect(EDIT_TIMELINE_POST_URL.'/'.$aTimelineId);
                                        }}
										if(!empty($timeline_videoUrl)){
											$tPostData['video_url'] = $timeline_videoUrl;
										}
                                    if (!empty($_FILES['edit_timeline_video']['name'])) {
                                        $target_path = '../uploads/timeline/';
                                        $fileTypes = array('mp4');
                                        $response['file_name'] = basename($_FILES['edit_timeline_video']['name']);
                                        $filename = basename($_FILES['edit_timeline_video']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_timeline_video']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_timeline_video']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $tPostData['video'] = $picname;//print_r($Idata);die();
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_TIMELINE_POST_URL.'/'.$aTimelineId);
											}
                                        } else {debug($_FILES);
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported it will take only viedo files");
                                            redirect(EDIT_TIMELINE_POST_URL.'/'.$aTimelineId);
                                        }
                                    }
									$where1 = array('id'=>$tId);//debug($Idata);
								    $timelineResult = $this->insertOrUpdate(TBL_TIMELINE_POST, $where1, $tPostData);
								if($timelineResult){
								 $this->session->set_flashdata('Smessage', SUCCESS);
                                 redirect(TIMELINE_POST_URL.'/'.$timeline_celebrity);
								}
								else {
                                $this->session->set_flashdata('Fmessage', FAILED);
                                redirect(EDIT_TIMELINE_POST_URL.'/'.$aTimelineId);
								}
                                }
								if($type == 8 || $type == 10){
									$tPostData['timeline_postId'] = $aTimelineId;
									$tPostData['updatedTime'] = date('Y-m-d h:i:s');
									$tPostData['video'] = "";
									$tPostData['thumb_image'] = "";
										$imageName = $_FILES['edit_timeline_image']['name'];//print_r($imageName);die();
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                         if ($imageName) {
												$i = 0;
												$imageData = array();
												$fileTypes = $fileTypes;
												foreach ($imageName as $name) {
													if (!empty($name)) {
														$target_path = '../uploads/timeline/';
														$response['file_name'] = basename($name);
														$filename = basename($name);
														$rand = rand();
														$file_extension = pathinfo($name);
														$picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
														$target_path = $target_path . $picname1;
														if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
															$movefile = move_uploaded_file($_FILES['edit_timeline_image']['tmp_name'][$i], $target_path);
															if ($movefile) {
																$tPostData['image'] = $picname1;
																$where1 = array('id'=>$tId[$i],'timeline_postId'=>$aTimelineId);
														 $haveRecord = $this->getAllRecords(TBL_TIMELINE_POST, $where1,'*');//debug($haveRecord);
														 if($haveRecord){
														$where1 = array('id'=>$tId[$i]);
														$Result = $this->insertOrUpdate(TBL_TIMELINE_POST, $where1, $tPostData);
														 }
														 else{
															 $where1 = array();
														   $Result = $this->insertOrUpdate(TBL_TIMELINE_POST, $where1, $tPostData);
														 }
															}
														}
													}
													$i++;
												}
												/* if ($imageData) {
													$i=0;
													foreach ($imageData as $imgD) {
														$tPostData['image'] = $imgD;
														 $where1 = array('id'=>$tId[$i],'timeline_postId'=>$aTimelineId);
														 $haveRecord = $this->getAllRecords(TBL_TIMELINE_POST, $where1,'*');//debug($haveRecord);
														 if($haveRecord){
														$where1 = array('id'=>$tId[$i]);
														$Result = $this->insertOrUpdate(TBL_TIMELINE_POST, $where1, $tPostData);
														 }
														 else{
															 $where1 = array();
														   $Result = $this->insertOrUpdate(TBL_TIMELINE_POST, $where1, $tPostData);
														 }
														 $i++;
													} */
													if($Result){
														$this->session->set_flashdata('Smessage', SUCCESS);
													 redirect(TIMELINE_POST_URL.'/'.$timeline_celebrity);
												 }
												 else {
													$this->session->set_flashdata('Fmessage', FAILED);
													redirect(EDIT_TIMELINE_POST_URL.'/'.$aTimelineId);
													}
												//}
										 }
                                    if (!empty($_FILES['edit_timeline_gif']['name'])) {
                                        $target_path1 = '../uploads/timeline/';
                                        $fileTypes = array('gif');
                                        $response['file_name'] = basename($_FILES['edit_timeline_gif']['name']);
                                        $filename = basename($_FILES['edit_timeline_gif']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_timeline_gif']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path1 = $target_path1 . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_timeline_gif']['tmp_name'], $target_path1);
                                            if ($movefile) {
                                                $tPostData['image'] = $picname;//print_r($Idata);die();
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_TIMELINE_POST_URL.'/'.$aTimelineId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported it will take only gif files");
                                            redirect(EDIT_TIMELINE_POST_URL.'/'.$aTimelineId);
                                        }
										$where1 = array('id'=>$tId);
								$timelineResult = $this->insertOrUpdate(TBL_TIMELINE_POST, $where1, $tPostData);
								if($timelineResult){
								 $this->session->set_flashdata('Smessage', SUCCESS);
                                 redirect(TIMELINE_POST_URL.'/'.$timeline_celebrity);
								}
								else {
                                $this->session->set_flashdata('Fmessage', FAILED.'/'.$aTimelineId);
                                redirect(EDIT_TIMELINE_POST_URL.'/'.$aTimelineId);
								}
                                }
								 $this->session->set_flashdata('Smessage', SUCCESS);
                                 redirect(TIMELINE_POST_URL.'/'.$timeline_celebrity);
								}
					         }
							 else {
                                $this->session->set_flashdata('Fmessage', FAILED);
                                redirect(EDIT_TIMELINE_POST_URL.'/'.$aTimelineId);
								}
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_TIMELINE_POST_URL.'/'.$aTimelineId);
                }
            }
            $this->load->view('header');
            $this->load->view('timeline/editTimeline',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function deleteTimeline() {
        if ($this->input->is_ajax_request()) {
			$id = $this->input->post('id');
			/* $tdata['isDeleted'] = 1;
			$where = array('id'=>$id);
			$deleteTimeline = $this->insertOrUpdate(TBL_TIMELINE_POST,$where,$tdata); */
			$data['a_t_is_deleted'] = 1;
			$where = array('a_t_id'=>$id);
			$deleteAdminTimeline = $this->insertOrUpdate(TBL_ADMIN_TIMELINE_POST,$where,$data);
            if($deleteAdminTimeline){
               $this->session->set_flashdata('Smessage', SUCCESS);
            } else {
             $this->session->set_flashdata('Fmessage', FAILED);
            }
            die();
        }
    }
	function deleteTimelineImages() {
        if ($this->input->is_ajax_request()) {
			$id = $this->input->post('id');
			$tdata['isDeleted'] = 1;
			$where = array('id'=>$id);
			$deleteTimeline = $this->insertOrUpdate(TBL_TIMELINE_POST,$where,$tdata);
            if($deleteTimeline){
               $this->session->set_flashdata('Smessage', SUCCESS);
            } else {
             $this->session->set_flashdata('Fmessage', FAILED);
            }
            die();
        }
    }
}