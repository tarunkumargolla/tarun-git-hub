<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */
// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Tutorial extends Healthcontroller {

    public function __construct() {

        parent::__construct();
        $this->load->model('Newsmodel');
        $this->load->model('Commonmodel', 'Commonmodel');

        date_default_timezone_set('Asia/Kolkata');
    }
	  
	  function index() {
		  $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$celebrityId = $this->uri->segment(3);
		if($Role_Id==1){
			$where = array('isDeleted' => 0,'appId'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('isDeleted'=>0,'appId'=>$celebrityId);
			}
		$tutorials = $this->getAllRecords(TBL_TUTORIAL,$where,'*');
		$data['tutorials'] =$tutorials;
		$data['celebrityId'] = $celebrityId;
        $this->load->view('header');
		$this->load->view('tutorial/tutorial',$data);
		$this->load->view('footer');
		
	}  
	function addTutorial() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
            $celebrityId = $this->uri->segment(3); 
            $data['celebrityId'] = $celebrityId;
			$id= $this->uri->segment(4);
			if($id){
				$where = array('id'=>$id);
				$data['tutorial'] = $this->getSingleRecord(TBL_TUTORIAL,$where,'*');
			}
            if ($this->input->post('addTutorial')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('tutorial_title', 'Tutorial Title', 'trim|required');
                $this->form_validation->set_rules('tutorial_content', 'Tutorial Content', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $tutorial_title = trim($this->input->post('tutorial_title'));
                    $tutorial_content = trim($this->input->post('tutorial_content'));
					if($celebrityId){
						$Idata['appId'] = $celebrityId;
					}else{
						$Idata['appId'] =$this->session->userdata('celebrityId');}
						$Idata['title'] = $tutorial_title;
						$Idata['description'] = $tutorial_content;
						$isPremiun = 0;
						$Idata['createdTime'] = date('y-m-d h:i:s');
                                if ($_FILES['tutorial_image']['name']) {

                                    if (!empty($_FILES['tutorial_image']['name'])) {
                                        $target_path = '../uploads/tutorial/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['tutorial_image']['name']);
                                        $filename = basename($_FILES['tutorial_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['tutorial_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['tutorial_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['image'] = $picname;
                                            }
											else {
											        if($id){
                                                    $this->session->set_flashdata('Fmessage', "File not Moved");
													redirect(ADD_TUTORIAL_URL.'/'.$celebrityId.'/'.$id);}
													else{
												    $this->session->set_flashdata('Fmessage', "File not Moved");
													redirect(ADD_TUTORIAL_URL.'/'.$celebrityId);}
											}
                                        } else {
											        if($id){
                                                    $this->session->set_flashdata('Fmessage', "File formate is not supported");
													redirect(ADD_TUTORIAL_URL.'/'.$celebrityId.'/'.$id);}
													else{
												    $this->session->set_flashdata('Fmessage', "File formate is not supported");
													redirect(ADD_TUTORIAL_URL.'/'.$celebrityId);}
                                        }
                                    }
                                }
								                if($id){
												$where = array('id'=>$id);
												$result = $this->insertOrUpdate(TBL_TUTORIAL, $where, $Idata);
												}else{
											    $where = array();
												$result = $this->insertOrUpdate(TBL_TUTORIAL, $where, $Idata);
												}
												$last_id = $this->db->insert_id();
												if($result){
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(TUTORIAL_URL.'/'.$celebrityId);
												}
												else {
													if($id){
                                                    $this->session->set_flashdata('Fmessage', FAILED);
													redirect(ADD_TUTORIAL_URL.'/'.$celebrityId.'/'.$id);}
													else{
												    $this->session->set_flashdata('Fmessage', FAILED);
													redirect(ADD_TUTORIAL_URL.'/'.$celebrityId);}
											}
								 } else {
					 if($id){
                    $this->session->set_flashdata('Fmessage',validation_errors());
					redirect(ADD_TUTORIAL_URL.'/'.$celebrityId.'/'.$id);}
					else{
					$this->session->set_flashdata('Fmessage', validation_errors());
					redirect(ADD_TUTORIAL_URL.'/'.$celebrityId);}
					
                }
            }
            $this->load->view('header');
            $this->load->view('tutorial/addTutorial',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        }catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		/* function editWishes() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }

            $id= $this->uri->segment(4);
			$celebrityId = $this->uri->segment(3);
            $where = array('wishes_id'=>$id);
			$details = $this->getSingleRecord(TBL_TUTORIAL, $where, '*');
			$data['details'] = $details;
            $data['celebrityId'] = $celebrityId;
			
            if ($this->input->post('editWishes')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_wishes_title', 'Wishes Title', 'trim|required');
                $this->form_validation->set_rules('edit_wishes_content', 'Wishes Content', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $wishes_title = trim($this->input->post('edit_wishes_title'));
					$wishes_id = trim($this->input->post('edit_wishes_id'));
                   
                    $wishes_content = trim($this->input->post('edit_wishes_content'));
					if($celebrityId){
						$Idata['celebrityId'] = $celebrityId;
					}
					else{
                   $Idata['celebrityId'] =$this->session->userdata('edit_celebrityId');}

                    $Idata['wishes_name'] = $wishes_title;
                    $Idata['wishes_content'] = $wishes_content;
                        $isPremiun = 0;

                                    if (!empty($_FILES['edit_wishes_image']['name'])) {
                                        $target_path = '../uploads/wishes/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_wishes_image']['name']);
                                        $filename = basename($_FILES['edit_wishes_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_wishes_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_wishes_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['wishes_image'] = $picname;
												 }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_WISHES_URL);
											}
										} else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_WISHES_URL);
                                        }
									}	
												$where = array('wishes_id'=>$wishes_id);
												$haveRecord = $this->getSingleRecord(TBL_TUTORIAL,$where,'*');
												if($haveRecord){
												$where = array('wishes_id'=>$wishes_id);
												$result = $this->insertOrUpdate(TBL_TUTORIAL, $where, $Idata);}
												else{
												$where = array();
												$result = $this->insertOrUpdate(TBL_TUTORIAL, $where, $Idata);
												}
												$last_id = $this->db->insert_id();
												if($result){
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(WISHES_URL.'/'.$celebrityId);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(EDIT_WISHES_URL);
											}
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_WISHES_URL);
                }
            }
			
            $this->load->view('header');
            $this->load->view('Wishes/editWishes',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    } */
	function deleteTutorial() {
        if ($this->input->is_ajax_request()) {
			$id = $this->input->post('id');
			$data['isDeleted'] = 1;
			$where = array('id'=>$id);
			$deleteWishes = $this->insertOrUpdate(TBL_TUTORIAL,$where,$data);
            if($deleteWishes){
               $this->session->set_flashdata('Smessage', SUCCESS);
            } else {
             $this->session->set_flashdata('Fmessage', FAILED);
            }
            die();
        }
    }
}