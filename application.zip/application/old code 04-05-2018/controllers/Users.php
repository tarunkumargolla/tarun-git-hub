<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 * @author		Sharath
 */
class Users extends Healthcontroller 
{
	public function __construct() {
	
		parent::__construct();
		$this->load->model('Usermodel','user');
		$this->load->helpers('common.php');
		$this->load->model('Commonmodel','Commonmodel');
        date_default_timezone_set('Asia/Kolkata');
		 $this->load->helper('download');
	}
	
	
	function index(){
		try{
			$Role_Id=$this->session->userdata('Role_Id');
			
			if( empty($Role_Id) && empty($agentId) )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(LOGOUT_URL,'refresh');
				}
			}
			$where = array('isDeleted'=>0,'roleId'=>3);
            $users = $this->getAllRecords(TBL_USERS,$where,'*');
			$where = array('c_is_deleted'=>0);
            $data['celebritys'] = $this->getAllRecords(TBL_CELEBRITY,$where,'c_name,c_id');
		    $data['users']= $users ;
			$this->load->view('header');
		    $this->load->view('users/users',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		
	}
	function addUser(){
		 try{
			 $data=array();
			 //neww
			$Role_Id=$this->session->userdata('Role_Id');
			
			
			if( empty($Role_Id)  )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(LOGOUT_URL,'refresh');
				}
				
			}
			//end
			$id=$this->uri->segment(3);
			if($id){
				$details=$this->getSingleRecord(TBL_USERS,$where=array('userId'=>$id),'*');
				$data['details']=$details;
				
			}
			
		    
				if( $this->input->post( 'addUser' ) ){
					$this->load->library('form_validation');
					$this->form_validation->set_rules('name','Name','trim|required|min_length[3]');
					$this->form_validation->set_rules('phoneNumber','Phone Number','trim|required|min_length[10]|max_length[10]');
					$this->form_validation->set_rules('emailAddress','Email Address','trim|required');
				   if($this->form_validation->run()!=false)
					{ $phoneNumber=$this->input->post('phoneNumber');
					if(empty($id)){
						  $where=array('phoneNumber'=>$phoneNumber,'isDeleted'=>0); 
						  $checkExists=$this->getSingleRecord(TBL_USERS,$where,'*');
					}else{
						 $where=array('phoneNumber'=>$phoneNumber,'isDeleted'=>0); 
						  $checkExists=$this->Commonmodel->checkUserExists(TBL_USERS,$where,$id);
					}
						  if($checkExists){
								 $this->session->set_flashdata('Fmessage',"User already existed with this Phone Number." ); 
								  if($id)
								   redirect(ADD_USERS_URL.'/'.$id);
								  else
									redirect(ADD_USERS_URL);
						  }
					
						
						$inputdata['name'] = $this->input->post('name');
				        $inputdata['phoneNumber'] = $this->input->post('phoneNumber');
				        $inputdata['emailAddress'] = $this->input->post('emailAddress');
						$inputdata['password'] = md5($this->input->post('password'));
						$inputdata['user_type'] = $this->input->post('celeb');
				        $inputdata['isActive'] = 1;
				        $inputdata['isDeleted'] = 0;
						//$inputdata['uniqueCode'] = generateRandUniqueCode(10);
						//print_r($inputdata);die();
						if($id){
							$inputdata['updatedTime'] = date('y-m-d h:i:s');
                            $where=array('userId'=>$id);
						}else{
							 $inputdata['createdTime'] = date('y-m-d h:i:s');
							 $where=array();
						}
                        $result=$this->insertOrUpdate(TBL_USERS,$where,$inputdata);	
                        if($result){
							$this->session->set_flashdata('Smessage',SUCCESS ); 
					        redirect(USER_MANAGEMENT_URL);
						}else{
							$this->session->set_flashdata('Fmessage',FAILED ); 
					          if($id)
							   redirect(ADD_USERS_URL.'/'.$id);
							  else
								redirect(ADD_USERS_URL);
						}					
					}
					  else
					{
					  $this->session->set_flashdata('Fmessage', validation_errors()); 
					  if($id) {redirect(ADD_USERS_URL.'/'.$id);
					  }else{redirect(ADD_USERS_URL);}
						
						  
					}
				}
				$where = array();
				$data['celebritys'] =$this->getAllRecords(TBL_CELEBRITY,$where,'*');
		    $this->load->view('header');
		    $this->load->view('users/addUser',$data);
		    $this->load->view('scripts');
			$this->load->view('footer');
		 }
			catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	 
	function deleteUser()
	{
		if($this->input->is_ajax_request())
		{
			$id = $this->input->post('id');
			$where = array('userId'=>$id);
			$data['isDeleted'] = 1;
			$data['updatedTime']= date('y-m-d h:i:s');
			$success = $this->insertOrUpdate(TBL_USERS,$where,$data);
			if($success)
			{
				echo json_encode(array('status'=>1,'message'=>SUCCESS));
			}
			else
			{
				echo json_encode(array('status'=>0));
			}
			die();
		}
	}
	
	 function download_excel(){
        $this->load->library('excel');
        $this->excel->setActiveSheetIndex(0);
                //name the worksheet
                $this->excel->getActiveSheet()->setTitle('Countries');
                //set cell A1 content with some text
                $this->excel->getActiveSheet()->setCellValue('A1', 'Users Excel Sheet');
                $this->excel->getActiveSheet()->setCellValue('A2', 'S.No.');
                $this->excel->getActiveSheet()->setCellValue('B2', 'Name');
                $this->excel->getActiveSheet()->setCellValue('C2', 'Name');
                $this->excel->getActiveSheet()->setCellValue('D2', 'Mobile');
                //merge cell A1 until C1
                $this->excel->getActiveSheet()->mergeCells('A1:D1');
                //set aligment to center for that merged cell (A1 to C1)
                $this->excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                //make the font become bold
                $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
                $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(16);
                $this->excel->getActiveSheet()->getStyle('A1')->getFill()->getStartColor()->setARGB('#333');
              
 			  for($col = ord('A'); $col <= ord('C'); $col++){ 
	               $this->excel->getActiveSheet()->getColumnDimension(chr($col))->setAutoSize(true);
                 //change the font size
                $this->excel->getActiveSheet()->getStyle(chr($col))->getFont()->setSize(12);
                 
                $this->excel->getActiveSheet()->getStyle(chr($col))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                   }
				 $this->db->select('userId,name,emailAddress,phoneNumber');
				 $this->db->where('isActive',1);
                $rs = $this->db->get('users');
				
                $exceldata="";
          foreach ($rs->result_array() as $row){
                $exceldata[] = $row;
        }
                //Fill data 
                $this->excel->getActiveSheet()->fromArray($exceldata, null, 'A4');
                 
                $this->excel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $this->excel->getActiveSheet()->getStyle('B4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $this->excel->getActiveSheet()->getStyle('C4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                 
                $filename='UsersData.xls'; //save our workbook as this file name
                header('Content-Type: application/vnd.ms-excel'); //mime type
                header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
                header('Cache-Control: max-age=0'); //no cache
 
                //save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
                //if you want to save it as .XLSX Excel 2007 format
                $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
                //force user to download the Excel file without writing it to server's HD
                $objWriter->save('php://output');
     }

	
	
   }