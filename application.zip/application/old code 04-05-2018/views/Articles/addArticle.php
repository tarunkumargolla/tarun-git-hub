<!DOCTYPE html>
<html>
  <?php $this->load->view('sideMenu');?>
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>Articles</h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li>Add Articles</li>
			   <?php 
			  $Role_Id=$this->session->userdata('Role_Id');
			  $dashboardUrl=DASHBOARD_URL;
			 ?>
              <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="clearfix"></div>
          <div class="col-md-12">
            <div class="card">
              <div class="row"><br>
                <div class="col-lg-8 m-t-25">
                  <div class="well bs-component">
               <?php if($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php  echo $this->session->flashdata('Smessage');?></div><?php } ?>
                <?php  if($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage');?></div><?php } ?>
                    <?php if(@$details->articleTypeID){
						$action=ADD_ARTICLES_URL.'/'.@$details->articleTypeID;
					}else{
						$action=ADD_ARTICLES_URL;
					}?>
					
					<form class="form-horizontal" method="post" action="<?php echo $action; ?>">
                      <fieldset>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Article Type</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="name"   name="name" value="<?php if(@$details->articleType) echo @$details->articleType;?>" type="text"  placeholder="Article Type" required>
                          </div>
                        </div>
                        <input type="hidden" name="id" value="<?php if(@$details->articleTypeID) echo @$details->articleTypeID;?>">
                        <div class="form-group">
                          <label class="col-lg-2 control-label">&nbsp;</label>
                          <div class="col-lg-8"><input type="submit" name="AddArticle" value="submit" class="btn btn-danger" ></input></div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
                
              </div>
            </div>
			<div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Javascripts-->
	<script>
	jQuery('#name').keyup(function () {
        var start = this.selectionStart,
        end = this.selectionEnd;		
        this.value = this.value.replace(/[^a-zA-Z0-9  \s]/g,'');
	    this.setSelectionRange(start, end); 
        });
	</script>
   
  </body>
</html>