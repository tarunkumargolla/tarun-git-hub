  <?php $this->load->view('sideMenu');
        $this->load->view('scripts');?>
 <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1> </h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li>Articles</li>
              <li><a href="<?php echo DASHBOARD_URL; ?>">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="clearfix"></div>
		  
          <div class="col-md-12">
		   
			<h1 class="table_title">Articles DATA</h1>
			<div class="title_separator"></div>
			<?php if($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php  echo $this->session->flashdata('Smessage');?></div><?php } ?>
            <?php  if($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage');?></div><?php } ?>
                   
			<div>
			<a class="btn btn-info color_btn" href="<?php echo ADD_ARTICLES_URL; ?>">ADD</a>
			
			</div>
            <div class="main_table" >
              <div class="table-responsive">
               <br><br>
               <table id="myTable" class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" width="100%" > 
                  <thead>
                    <tr class="title_head">
                      <th width="5%" class="text-center">S.No</th>
                      <th width="15%" class="text-center">Article</th>
                      <th width="15%" class="text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
				  <?php if($articles){
					  $i=1;
					  foreach($articles as $article){    ?>
				
                    <tr>
                      <td><?php echo $i; ?></td>
                      <td><?php  echo $article->articleType ?></td>
                     <td class="text-center"><a href="<?php echo ADD_ARTICLES_URL.'/'.$article->articleTypeID; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
					 &nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0)"><i class="fa fa-trash-o" aria-hidden="true" onclick="deleteArticle(<?php echo $article->articleTypeID; ?>);"></i></a>
					 </td>
                    </tr>
					<?php $i++;  }  } ?>
                    
                  </tbody>
                </table>
				
              </div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            </div>
			<div class="clearfix"></div>
			
          </div>
        </div>
      </div>
	 