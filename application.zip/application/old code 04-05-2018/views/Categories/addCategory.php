<!DOCTYPE html>
<html>
  <?php $this->load->view('sideMenu');?>
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>Event</h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li>Add Event</li>
               <?php 
			  $Role_Id=$this->session->userdata('Role_Id');
			  $agentId=$this->session->userdata('agent_id');
			  if(empty($Role_Id) && $agentId){
				   $dashboardUrl=AGENT_DASHBOARD_URL;
			  }else{
				 $dashboardUrl=DASHBOARD_URL;
			  }
			  ?>
              <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="clearfix"></div>
          <div class="col-md-12">
            <div class="card">
              <div class="row"><br>
                <div class="col-lg-8 m-t-25">
                  <div class="well bs-component">
               <?php if($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php  echo $this->session->flashdata('Smessage');?></div><?php } ?>
                <?php  if($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage');?></div><?php } ?>
                    <?php if(@$details->cat_id){ 
						$action=ADD_CATEGORIES_URL.'/'.@$details->cat_id;
					}else{
						$action=ADD_CATEGORIES_URL;
					}?>
					
					<form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data">
                      <fieldset>
                         <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Category Name</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="name"   name="cat_name" value="<?php if(@$details->cat_name) echo @$details->cat_name;?>" type="text"  placeholder="Name" required>
                          </div>
                        </div>
						
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Category Image</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="cat_Image"  name="cat_image" value="<?php if(@$details->cat_image) echo @$details->cat_image;?>" type="file" <?php if(@$details->cat_image) { echo "";}else{ echo "required"; } ?>>
                          </div>
                        </div>
						 <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Color Code</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="name"   name="colour_code" value="<?php if(@$details->cat_colour_code) echo @$details->cat_colour_code;?>" type="text"  placeholder="Color code" required>
                          </div>
                        </div>
						
						  
                        <input type="hidden" name="id" value="<?php if(@$details->cat_id) echo @$details->cat_id;?>">
                        <div class="form-group">
                          <label class="col-lg-2 control-label">&nbsp;</label>
                          <div class="col-lg-8"><input type="submit" name="addCategory" value="submit" class="btn btn-danger" ></input></div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
                
              </div>
            </div>
			<div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Javascripts-->
    <script>
	jQuery('#name').keyup(function () {
        var start = this.selectionStart,
        end = this.selectionEnd;		
        this.value = this.value.replace(/[^a-zA-Z0-9  \s]/g,'');
	    this.setSelectionRange(start, end); 
        });
	</script>
  </body>
</html>