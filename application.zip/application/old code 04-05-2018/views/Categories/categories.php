  <?php $this->load->view('sideMenu');$this->load->view('scripts');?>
 <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1> </h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li>Categories</li>
               <?php 
			  $Role_Id=$this->session->userdata('Role_Id');
			  $agentId=$this->session->userdata('agent_id');
			  if(empty($Role_Id) && $agentId){
				   $dashboardUrl=AGENT_DASHBOARD_URL;
			  }else{
				 $dashboardUrl=DASHBOARD_URL;
			  }
			  ?>
              <li><a href="<?php echo $dashboardUrl; ?>">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="clearfix"></div>
          <div class="col-md-12">
		   
			<h1 class="table_title">Categories DATA</h1>
			<div class="title_separator"></div>
			<div>
			<a class="btn btn-info color_btn" href="<?php echo ADD_CATEGORIES_URL; ?>">ADD</a>
			
			</div>
            <div class="main_table">
              <div class="table-responsive">
                <br><br>
               <table id="myTable" class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" width="100%" > 
                  <thead>
                    <tr class="title_head">
                      <th width="5%" class="text-center">S.No</th>
                      <th width="15%" class="text-center"> Category Name</th>
                      <th width="10%" class="text-center">Category Image</th>
                      <th width="10%" class="text-center">Colour code</th>
                      <th width="15%" class="text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
				  <?php if($catrgories){
					  $i=1;
					  foreach($catrgories as $catrgory){    ?>
				
                    <tr>
                      <td><?php echo $i; ?></td>
                      <td><?php  echo $catrgory->cat_name ?></td>
					  <td><img src="<?php  echo CATAGORIES_IMAGE_PATH.$catrgory->cat_image ?>" height="50px" width="50px"></td>
					  <td><?php  echo $catrgory->cat_colour_code ?></td>
                      <td class="text-center"><a href="<?php echo ADD_CATEGORIES_URL.'/'.$catrgory->cat_id; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
					 &nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0)"><i class="fa fa-trash-o" aria-hidden="true" onclick="deleteCategory(<?php echo $catrgory->cat_id; ?>);"></i></a>
					 </td>
                    </tr>
					<?php $i++;  }  } ?>
                    
                  </tbody>
                </table>
              </div>
            </div><br><br><br><br>
			<div class="clearfix"></div>
			<!--<a class="btn btn-info color_btn" href="#">ADD</a>
			<a class="btn btn-info color_btn bg_color2" href="#">SAVE</a>
			<a class="btn btn-info color_btn bg_color3" href="#">BACk</a>-->
          </div>
        </div>
      </div>