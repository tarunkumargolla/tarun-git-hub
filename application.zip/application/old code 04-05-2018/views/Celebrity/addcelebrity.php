<!DOCTYPE html>
<html>
    <style>
        .animated {
            -webkit-animation-duration: 10s;animation-duration: 10s;
            -webkit-animation-fill-mode: both;animation-fill-mode: both;
        }
        @-webkit-keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        @keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        .fadeOut {
            -webkit-animation-name: fadeOut;
            animation-name: fadeOut;
        }
    </style>
    <?php $this->load->view('sideMenu');
    $this->load->view('scripts'); ?>
    <div class="content-wrapper">
        <div class="page-title">
            <div>
                <h1>Celebrity</h1>
            </div>
            <div>
                <ul class="breadcrumb">
                    <li>Add Celebrity</li>
                    <?php
                    $Role_Id = $this->session->userdata('Role_Id');
                    $dashboardUrl = DASHBOARD_URL;
                    ?>
                    <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="clearfix"></div>
            <div class="col-md-12">
                <div class="card">
                    <div class="row"><br>
                        <div class="col-lg-8 m-t-25">
                            <div class="well bs-component">
                                <?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
                                <?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
<?php $action = ADD_CELEBRITY_URL; ?>
                                <form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data" >
                                    <div id="Error"></div>
                                    <fieldset>
									
									<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> App Type</label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="apptype" name="apptype[]" multiple>
												<option value="">Select App Type </option>
												<?php foreach($appTypes as $apptype){?>
												<option value="<?php echo $apptype->id;?>"><?php echo $apptype->type;?></option>
												<?php } ?>
												</select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Celebrity Name</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="name"   name="name" value="" type="text"  placeholder="Celebrity Name" required>
                                            </div>
                                        </div>
                                            <div class="form-group" id="image">
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="imagename">Image</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="image"  name="image" value="" type="file"   required>
                                                </div>
                                            </div>
										     <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Phone</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" type="text"name="num"id="num" required maxlength="10" pattern="[6789][0-9]{9}" placeholder="Enter your mobile number [6789][0-9]{9}" />
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Address</label>
                                            <div class="col-lg-8">
                                                <textarea class="form-control" name="address"id="address" required  placeholder="Enter your Address" /></textarea>
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Gender</label>
                                            <div class="col-lg-8">
                                                <input  type="radio"name="gender"id="gender" value="Male"  required />Male &nbsp;
												<input  type="radio"name="gender"id="gender" value="FeMale"  />Female
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Language</label>
											<span class="required">  </span>
                                            <div class="col-lg-8">
                                                <select  class="form-control login_field select2" name="lang[]"id="lang" required multiple >
												<option value=""autofocus>select</option>
												<option value="Telugu">Telugu</option>
												<option value="English">English</option>
												<option value="Hindi">Hindi</option>
												<option value="Tamil">Tamil</option>
											</select>
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Hobbies</label>
                                            <div class="col-lg-8">
                                                <input  type="text"  class="form-control" name="hobbies" id="hobbies" value="" />
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Awards</label>
                                            <div class="col-lg-8">
                                               <input  type="checkbox"name="avards"id="avards" value="1"  />
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Foundations</label>
                                            <div class="col-lg-8">
                                               <input  type="checkbox"name="foundations"id="foundations" value="1"  />
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Email</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" type="email"name="email"id="email" required  placeholder="Enter your EmailId" />
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Password</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" type="password"name="pass"id="pass" required  placeholder="Enter your Password" />
                                            </div>
                                        </div>
                                        <div id="trending">&nbsp;</div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">&nbsp;</label>
                                            <div class="col-lg-8"><input type="submit" name="addCelebrity" value="submit" class="btn btn-danger" ></input></div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
<!-- Javascripts-->
</body>
</html>