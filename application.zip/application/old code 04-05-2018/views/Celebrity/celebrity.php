<?php $this->load->view('sideMenu');
$this->load->view('scripts'); ?>

<div class="content-wrapper">
    <div class="page-title">
        <div>
            <h1> </h1>
        </div>
        <div>
            <ul class="breadcrumb">
                <li>Celebrity's</li>
<?php $dashboardUrl = DASHBOARD_URL; ?>
                <li><a href="<?php echo $dashboardUrl; ?>">Dashboard</a></li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-md-12">

            <h1 class="table_title">Celebrity DATA</h1>
            <div class="title_separator"></div>
            <div>
                <a class="btn btn-info color_btn" href="<?php echo ADD_CELEBRITY_URL; ?>">ADD</a>

            </div>
            <div class="main_table">
                <div class="table-responsive">
                    <br><br>
					 <?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
                                <?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
                    <table id="myTable" class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" width="100%" > 
                        <thead>
                            <tr class="title_head">
                                <th width="5%" class="text-center">S.No</th>
                                <th width="15%" class="text-center"> App Id </th>
                                <th width="15%" class="text-center"> Celebrity Name </th>
                                <th width="15%" class="text-center">Celedrity Image</th>
								<th width="15%" class="text-center">Celebrity Phone</th>
								<th width="15%" class="text-center">Celebrity Address</th>
								<th width="15%" class="text-center">Celebrity Hobbies</th>
								<th width="15%" class="text-center">Celebrity Languages</th>
								<!--th width="15%" class="text-center">Celebrity Awards</th>
								<th width="15%" class="text-center">Celebrity Foundations</th-->
								<th width="15%" class="text-center">Celebrity Email</th>
								<th width="15%" class="text-center">Celebrity Password</th>
                                <th width="15%" class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($celebrity) {
                                $i = 1;
                                foreach ($celebrity as $celeb) {
									$password="";
									if($celeb->c_password){ 
                                       $password = decrypt($celeb->c_password);
									}
                                    ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
										<td><?php echo $celeb->c_id;; ?></td>
										<td><a href="<?php echo CELEBRITY_PAGE_URL.$celeb->c_id;?>"><?php echo $celeb->c_name; ?></a></td>
                                        <td><img src="<?php echo CELEBRITY_IMAGE_PATH.$celeb->c_image?>" width="100" height="100"></td>
										<td><?php echo $celeb->c_phone; ?></td>
                                        <td><?php echo  $celeb->c_address; ?></td>
										<td><?php echo $celeb->c_hobbies; ?></td>
										<td><?php echo $celeb->c_language; ?></td>
										<?php if($celeb->c_is_awards_available){$avards = 'yes';}else{$avards = 'no';}?>
										<!--td><?php echo $avards; ?></td-->
										<?php if($celeb->c_is_foundations_available){$foundation = 'yes';}else{$foundation = 'no';}?>
										<!--td><?php echo $foundation; ?></td-->
										<td><?php echo $celeb->c_email; ?></td>
										<td><?php echo $password; ?></td>
                                        <td class="text-center"><a href="<?php echo EDIT_CELEBRITY_URL . '/' . $celeb->c_id; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                            &nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0)"><i class="fa fa-trash-o" aria-hidden="true" onclick="deleteCelebrity(<?php echo $celeb->c_id?>);"></i></a>
                                        </td>
                                    </tr>
									
                       <?php $i++;} } ?>
                      </tbody>
                    </table>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<script>
function deleteCelebrity(id){
	var ok = confirm("Are you sure to Delete?"); 
       if (ok) {
	          $.ajax({
                    type: "POST",
                    url:'<?php echo DELETE_CELEBRITY_URL ?>', 
				    data: {'id':id},
					dataType:'json',
                    success: function(response){
						 location.reload();   
                    },
				    error: function(xhr, statusText, err){
                              console.log("Error:" + xhr.status);  
				    }
						
                });
	   }
 				
  return false;
}
</script>