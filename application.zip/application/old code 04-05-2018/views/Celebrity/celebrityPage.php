<?php $Role_Id = $this->session->userdata('Role_Id');?>
      <!-- Side-Nav-->
    <?php $this->load->view('sideMenu');?>
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h2 style="color:blue;margin-left:400px"><?php echo $celebrityName->c_name;?></h2>
          </div>
          <div>
            <ul class="breadcrumb">
              <li>Celebriry Menus</li>
              <li><a href="<?php echo DASHBOARD_URL; ?>">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="clearfix"></div>
          <div class="col-md-12">
		    <div class="white-box">
			 <div class="row row-in">
				  <div class="col-lg-3 col-sm-6 row-in-br">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color1"><i class="fa fa-picture-o"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
							<h4> <a href="<?php echo IMAGE_URL.'/'.$celebrityName->c_id;?>">Galery </a></h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6 row-in-br  b-r-none">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color2"><i class="fa fa-play-circle-o"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo MOVIE_URL.'/'.$celebrityName->c_id;?>">  Movies </a></h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6 row-in-br">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color3"><i class="fa fa-clipboard"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo NEWS_URL.'/'.$celebrityName->c_id;?>">  News </a></h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><i class="fa fa-heart"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo WISHES_URL.'/'.$celebrityName->c_id;?>"> Wishes </a> </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><i class="fa fa-trophy"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo AWARDS_URL.'/'.$celebrityName->c_id;?>"> Awards </a> </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div> 
				  
				  <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><i class="fa fa-microphone"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo SPEECHES_URL.'/'.$celebrityName->c_id;?>"> Speeches </a> </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><i class="fa fa-industry"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo FOUNDATION_URL.'/'.$celebrityName->c_id;?>"> Foundations </a> </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div> 
				  <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><i class="fa fa-industry"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo SOCIAL_SERVICE_URL.'/'.$celebrityName->c_id;?>"> Social services </a> </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><i class="fa fa-industry"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo EVENTS_URL.'/'.$celebrityName->c_id;?>"> Events </a> </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><i class="fa fa-industry"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo VIDEOS_URL.'/'.$celebrityName->c_id;?>"> Videos </a> </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><i class="fa fa-industry"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo ADDS_URL.'/'.$celebrityName->c_id;?>"> Adds </a> </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				   <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><i class="fa fa-industry"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo TIMELINE_POST_URL.'/'.$celebrityName->c_id;?>"> Time Line </a> </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><i class="fa fa-industry"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo OPENION_POLLS_URL.'/'.$celebrityName->c_id;?>"> Openions </a> </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><i class="fa fa-industry"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo PROMOTION_BANNERS_URL.'/'.$celebrityName->c_id;?>"> Promotion Banners </a> </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><i class="fa fa-industry"></i></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"></h3></li>
							<li class="col-middle">
								<h4><a href="<?php echo TUTORIAL_URL.'/'.$celebrityName->c_id;?>"> Tutorial </a> </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				</div> 
              <br><br><br> <br><br><br><br><br><br><br><br><br><br><br><br>				
			</div>
		
          </div>
        </div>
      </div>
    </div>
    <!-- Javascripts-->
   <?php // $this->load->view('footer'); ?> 
  </body>
</html>