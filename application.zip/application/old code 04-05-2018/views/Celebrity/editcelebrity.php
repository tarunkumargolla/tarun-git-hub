<!DOCTYPE html>
<html>
    <style>
        .animated {
            -webkit-animation-duration: 10s;animation-duration: 10s;
            -webkit-animation-fill-mode: both;animation-fill-mode: both;
        }
        @-webkit-keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        @keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        .fadeOut {
            -webkit-animation-name: fadeOut;
            animation-name: fadeOut;
        }
    </style>
    <?php $this->load->view('sideMenu');
    $this->load->view('scripts'); ?>
    <div class="content-wrapper">
        <div class="page-title">
            <div>
                <h1>Celebrity</h1>
            </div>
            <div>
                <ul class="breadcrumb">
                    <li>Edit Celebrity</li>
                    <?php
                    $Role_Id = $this->session->userdata('Role_Id');
                    $dashboardUrl = DASHBOARD_URL;
                    ?>
                    <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="clearfix"></div>
            <div class="col-md-12">
                <div class="card">
                    <div class="row"><br>
                        <div class="col-lg-8 m-t-25">
                            <div class="well bs-component">
                                <?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
                                <?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
<?php $action = EDIT_CELEBRITY_URL; ?>
                                 <form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data" >
                                    <div id="Error"></div>
                                    <fieldset>
									<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> App Type</label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="editapptype" name="editapptype[]" multiple required>
												<option value="">Select App Type </option>
												<?php if($appTypes){
													foreach($appTypes as $apptype){
												 $celebarray = explode(',',$celebrity->c_app_type);?>
                                                  <option value="<?php echo $apptype->id;?>"<?php if(in_array($apptype->id ,$celebarray)){echo "selected";true;}?>><?php echo $apptype->type;?></option>
												<?php } }?>
												
												</select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Celebrity Name</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="editname"   name="editname" value="<?php if($celebrity->c_name){echo $celebrity->c_name;}else{echo "";}?>" type="text"  placeholder="News Title" required>
                                            </div>
                                        </div>
                                            <div class="form-group" id="image">
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="imagename">Image</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="editimage"  name="editimage" <?php if($celebrity->c_image){echo $celebrity->c_image;}else{echo "required";}?> type="file">
                                                </div>
                                            </div>
										     <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Phone</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" type="text"name="editnum"id="editnum" value="<?php if($celebrity->c_phone){echo $celebrity->c_phone;}else{echo "";}?>" maxlength="10" pattern="[6789][0-9]{9}" placeholder="Enter your mobile number [6789][0-9]{9}" />
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Address</label>
                                            <div class="col-lg-8">
                                                <textarea class="form-control" name="editaddress"id="editaddress" value=""  placeholder="Enter your Address" /><?php if($celebrity->c_address){echo $celebrity->c_address;}else{echo "";}?></textarea>
                                            </div>
                                        </div>
										<?php if($celebrity->c_gender){
											$genarray = explode(',',$celebrity->c_gender);
										?>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Gender</label>
                                            <div class="col-lg-8">
                                                <input  type="radio"name="editgender"id="editgender" value="Male"  <?php if(in_array('Male',$genarray)){echo "checked";}else{echo "selected";false;}?> />Male &nbsp;
												<input  type="radio"name="editgender"id="editgender" value="FeMale" <?php if(in_array('FeMale',$genarray)){echo "checked";}else{echo "selected";false;}?> />Female
                                            </div>
                                        </div>
										<?php } else {?>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Gender</label>
                                            <div class="col-lg-8">
                                                <input  type="radio"name="editgender"id="editgender" value="Male" required />Male &nbsp;
												<input  type="radio"name="editgender"id="editgender" value="FeMale" />Female
                                            </div>
                                        </div>
										<?php } ?>
										<?php if($celebrity->c_language){
											$langarray = explode(',',$celebrity->c_language);
										?>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail">Language</label>
                                            <div class="col-lg-8">
                                                <select  class="form-control select2" name="editlang[]"id="editlang" required multiple >
												<option value=""autofocus>select</option>
												<option value="Telugu" <?php if(in_array('Telugu',$langarray)){echo "selected";true;}else{echo "selected";false;}?> >Telugu</option>
												<option value="English" <?php if(in_array('English',$langarray)){echo "selected";true;}else{echo "selected";false;}?>>English</option>
												<option value="Hindi" <?php if(in_array('Hindi',$langarray)){echo "selected";true;}else{echo "selected";false;}?>>Hindi</option>
												<option value="Tamil" <?php if(in_array('Tamil',$langarray)){echo "selected";true;}else{echo "selected";false;}?>>Tamil</option>
											</select>
                                            </div>
                                        </div>
										<?php } else {?>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Language</label>
                                            <div class="col-lg-8">
                                                <select  class="form-control select2" name="editlang[]"id="editlang" required multiple >
												<option value=""autofocus>select</option>
												<option value="Telugu" >Telugu</option>
												<option value="English">English</option>
												<option value="Hindi" >Hindi</option>
												<option value="Tamil" >Tamil</option>
											</select>
                                            </div>
                                        </div>
										<?php } ?>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Hobbies</label>
                                            <div class="col-lg-8">
                                                <input  type="text" class="form-control" name="edithobbies"id="edithobbies" value="<?php if($celebrity->c_hobbies){echo $celebrity->c_hobbies;}else{echo "";}?>" required>
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Awards</label>
                                            <div class="col-lg-8">
                                               <input  type="checkbox"name="editavards"id="editavards" value="1"  <?php if($celebrity->c_is_awards_available==1){echo "checked";}?>/>
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Foundations</label>
                                            <div class="col-lg-8">
                                               <input  type="checkbox"name="editfoundations"id="editfoundations" value="1" <?php if($celebrity->c_is_foundations_available==1){echo "checked";}?> />
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Email</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" type="email"name="editemail"id="editemail" value="<?php if($celebrity->c_email){echo $celebrity->c_email;}else{echo "";}?>" placeholder="Enter your EmailId" required />
                                            </div>
                                        </div>
										<?php //if(empty($celebrity->c_password)){?>
										<!--div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Password </label>
                                            <div class="col-lg-8">
                                                <input class="form-control" type="password" name="editpassword" id="editpassword" value" placeholder="Enter your Password" required />
                                            </div>
                                        </div-->
										<?php //} ?>
										<input type="hidden" id="cel_id" name="cel_id" value="<?php echo $celebrity->c_id;?>">
                                        <div id="trending">&nbsp;</div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">&nbsp;</label>
                                            <div class="col-lg-8"><input type="submit" name="editCelebrity" value="submit" class="btn btn-danger" ></input></div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
</body>
</html>