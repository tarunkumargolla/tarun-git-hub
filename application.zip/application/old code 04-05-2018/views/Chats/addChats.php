<!DOCTYPE html>
<html>
  <?php $this->load->view('sideMenu');?>
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>Chat</h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li>Add Chat</li>
               <?php 
			  $Role_Id=$this->session->userdata('Role_Id');
			  $dashboardUrl=DASHBOARD_URL;
			  ?>
              <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="clearfix"></div>
          <div class="col-md-12">
            <div class="card">
              <div class="row"><br>
                <div class="col-lg-8 m-t-25">
                  <div class="well bs-component">
               <?php if($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php  echo $this->session->flashdata('Smessage');?></div><?php } ?>
                <?php  if($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage');?></div><?php } ?>
                    <?php if(@$details->ID){ 
						$action=ADD_CHAT_MEMBERS_URL.'/'.@$details->ID;
					}else{
						$action=ADD_CHAT_MEMBERS_URL;
					}?>
					
					<form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data">
                      <fieldset>
                         <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Name</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="name"   name="name" value="<?php if(@$details->name) echo @$details->name;?>" type="text"  placeholder="Name" required>
                          </div>
                        </div>
						
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Image</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="Image"  name="image" onchange='ImageCheck(this.id)'  value="<?php if(@$details->image) echo @$details->image;?>" type="file" required>
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">News</label>
                          <div class="col-lg-8">
						<select class="form-control" id="news" name="news"  <?php if($details){echo "disabled";} ?> required>
                        <option>Select News</option>
					    <?php if($news && count($news) > 0){
						 foreach($news as $new){ 
						 if($new->news_id == $details->newsID){ ?>
							 <option value="<?php echo $new->news_id ; ?>" selected ><?php echo $new->news_title ?> </option>
						<?php }
						 
						 ?>
                        <option value="<?php echo $new->news_id ; ?>"><?php echo $new->news_title ?> </option>
						<?php } }   ?>
                       </select>
					   </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Chart Types</label>
                          <div class="col-lg-8">
						<select class="form-control" id="chart" name="chart" <?php if($details){echo "disabled";} ?>  required>
                        <option>Select chart Types</option>
					    <?php if($chatTypes && count($chatTypes) > 0){
						 foreach($chatTypes as $chatTy){ 
						 if($chatTy->chat_type_ref_id == $details->chatTypeRefID){ ?>
							 <option value="<?php echo $chatTy->chat_type_ref_id ; ?>" selected ><?php echo $chatTy->type_ref ?> </option>
						<?php }
						 
						 ?>
                        <option value="<?php echo $chatTy->chat_type_ref_id ; ?>"><?php echo $chatTy->type_ref ?> </option>
						<?php } }   ?>
                       </select>
					   </div>
                        </div>
						 <input type="hidden" name="id" value="<?php if(@$details->ID) echo @$details->ID;?>">
                        <div class="form-group">
                          <label class="col-lg-2 control-label">&nbsp;</label>
                          <div class="col-lg-8"><input type="submit" name="addMember" value="submit" class="btn btn-danger" ></input></div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
                
              </div>
            </div>
			<div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Javascripts-->
    <script>
	 $(document).ready(function(){
   
    $("#addNewImage").click(function(){
        $("#image").append("<br><br><br><div class='col-lg-8' style='margin-left:130px'><input class='form-control' type='file' id='file' name='news_image[]'></div>");
    });
   });
	jQuery('#name').keyup(function () {
        var start = this.selectionStart,
        end = this.selectionEnd;		
        this.value = this.value.replace(/[^a-zA-Z0-9  \s]/g,'');
	    this.setSelectionRange(start, end); 
        });
		function ImageCheck(id){ 
		var files = $('#'+id).get(0).files; 
        for(var i=0; i<files.length;i++) {
        var file = files[i];
        var name = file.name;
        var size = file.size;
        var type = file.type; 
		if(file.type.match('image.*') ){
           }else{ 
				 $('#'+id).focus();
				 document.getElementById(id).value = null;
				 $('#'+id).after('<p class="animated fadeOut" style="color: red;">Select image files only</p>');
                  
			}
		
	     }
	}
	</script>
  </body>
</html>