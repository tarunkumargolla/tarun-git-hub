<!DOCTYPE html>
<html>
  <?php $this->load->view('sideMenu');?>
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>Chart Values</h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li>Add Values</li>
               <?php 
			  $Role_Id=$this->session->userdata('Role_Id');
			  $dashboardUrl=DASHBOARD_URL;
			  ?>
              <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="clearfix"></div>
          <div class="col-md-12">
            <div class="card">
              <div class="row"><br>
                <div class="col-lg-8 m-t-25">
                  <div class="well bs-component">
               <?php if($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php  echo $this->session->flashdata('Smessage');?></div><?php } ?>
                <?php  if($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage');?></div><?php } ?>
                    <form class="form-horizontal" method="post" action="<?php echo ADD_PIE_CHAT_VALUES_URL; ?>" enctype="multipart/form-data">
                      <fieldset>
					  <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">News</label>
                          <div class="col-lg-8">
						<select class="form-control" id="news" name="news" disabled required>
                        <option>Select News</option>
					    <?php if($news && count($news) > 0){
						 foreach($news as $new){ 
						 if($new->news_id == $details->newsID){ ?>
							 <option value="<?php echo $new->news_id ; ?>" selected ><?php echo $new->news_title ?> </option>
						<?php }
						 
						 ?>
                        <option value="<?php echo $new->news_id ; ?>"><?php echo $new->news_title ?> </option>
						<?php } }   ?>
                       </select>
					   </div>
                        </div> 
						
						<input type="hidden" name="chartTypeid" value="<?php echo  $details->chatTypeRefID; ?>">
						<input type="hidden" name="newsId" value="<?php echo  $details->newsID; ?>">
						<input type="hidden" name="memberId" value="<?php echo  $details->ID; ?>">
						<div id="Ma">
						<?php 
						$values=$details->values; 
						if($values && count($values)>0){ $i=1; 
						foreach($values as $val){
						?>
					  <div id="main" >
                         <!--<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Value <?php echo $i; ?></label>
                          <div class="col-lg-8">
                            <input class="form-control" id="value<?php echo $i; ?>" onkeyup="check(this.id)"  name="value[]" value="<?php if(@$val->value) echo @$val->value;?>" type="text"  placeholder="Value" required>
                          </div>
                        </div>-->
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Text <?php echo $i; ?></label>
                          <div class="col-lg-8">
                            <input class="form-control" id="text<?php echo $i; ?>"   name="text[]" value="<?php if(@$val->text) echo @$val->text;?>" type="text"  placeholder="Text" required>
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Percentage <?php echo $i; ?></label>
                          <div class="col-lg-8">
						<input type="text" class="form-control" onkeyup="check(this.id)" id="Percentage<?php echo $i; ?>" name="Percentage[]" placeholder="Percentage" value="<?php if(@$val->percentage) echo @$val->percentage;?>"  required>
                         </div>
						 <?php if(count($values) > 1){ ?>
						 <div onclick="deleteGraphValue(<?php echo $val->id; ?>,<?php echo $details->chatTypeRefID ?>)"> <img  src='<?php echo SITEURL; ?>/assets/images/close.jpg' width="20" height="20"></div>
						 <?php } ?>
                        </div> 
						
						</div>
						<?php $i++; } }else{ ?>
						<div id="main" >
                        <!-- <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Value</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="value1" onkeyup="check(this.id)"   name="value[]"  type="text"  placeholder="Value" required>
                          </div>
                        </div>-->
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Text</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="text1"   name="text[]"  type="text"  placeholder="Text" required>
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Percentage</label>
                          <div class="col-lg-8">
						<input type="text" class="form-control" id="Percentage1" name="Percentage[]" onkeyup="check(this.id)" placeholder="Percentage" value="<?php if(@$val->percentage) echo @$val->percentage;?>"  required>
                         </div>
                        </div> 
						</div>
						<?php } ?>
						</div>
						 <div>
							<button type="button" id="addMore"  class="text-center">Add More</button>
						</div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label">&nbsp;</label>
                          <div class="col-lg-8"><input type="submit" name="addVlaue" value="submit" class="btn btn-danger" ></input></div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
                
              </div>
            </div>
			<div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Javascripts-->
    <script> 
	$(document).ready(function(){ 
     $("#addMore").click(function(){  
	var len = $("div[id*='main']").length; 
	len=len+1;
	 $("#Ma").append(" <div id='main'><div id="+len+"><div class='form-group'><label class='col-lg-2 control-label' for='inputEmail'>Text "+ len+"</label><div class='col-lg-8' style='margin-left:130px' ><input class='form-control' type='text' id='text"+ len+"' name='text[]' placeholder='text' required></div></div> <div class='form-group'><label class='col-lg-2 control-label' for='inputEmail'>Percentage "+ len+" </label><div class='col-lg-8'><input type='text' class='form-control' onkeyup='check(this.id)' id='Percentage"+ len+"' name='Percentage[]' placeholder='Percentage'   required> </div><a href='javascript:void(0);' onclick='deleteVlueAndText("+len+")'><img style='margin-left:456px' src='<?php echo SITEURL; ?>/assets/images/close.jpg' width='20' height='20' ></a></div> </div></div>");
	 });
   });
    function deleteVlueAndText(len){
	   var id="value"+len;
	  $('#'+id).remove(); 
	  
	  var id1="text"+len;
	  $('#'+id1).remove();
	  
	  var id2=len;
	  $('#'+id2).remove();
	   
   }
	jQuery('#name').keyup(function () {
        var start = this.selectionStart,
        end = this.selectionEnd;		
        this.value = this.value.replace(/[^a-zA-Z0-9  \s]/g,'');
	    this.setSelectionRange(start, end); 
        });
	</script>
  </body>
</html>