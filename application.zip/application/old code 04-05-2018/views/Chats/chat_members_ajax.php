 <table id="myTable" class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" width="100%" > 
                  <thead>
                    <tr class="title_head">
                      <th width="5%" class="text-center">S.No</th>
                      <th width="15%" class="text-center">Name</th>
                      <th width="10%" class="text-center">Image</th>
                      <th width="10%" class="text-center">News Title</th>
                      <th width="10%" class="text-center">Chat TYpe</th>
                      <th width="15%" class="text-center">Add Values</th>
                      <th width="15%" class="text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
				    <?php $this->load->model('Chatmodel');?>

				  <?php if($chatMembers){
					  $i=1;$chatTy="-";
					  foreach($chatMembers as $chatMem){   
                      if($chatTypes){
						   foreach($chatTypes as $chtType){ 
							  if($chtType->chat_type_ref_id == $chatMem->chatTypeRefID){
								  $chatTy=$chtType->type_ref;
							  }
						   }
					  }
					  $newsTitle=$this->Chatmodel->getNewsTitle($chatMem->newsID);
					  ?>
				 <tr>
                       <td><?php echo $i; ?></td>
                       <td><?php  echo $chatMem->name ?></td>
                       <td><img src="<?php  echo CHAT_MEMBER_IMAGE_PATH.$chatMem->image ?>" height="50px" width="50px"></td>
                       <td><?php  echo @$newsTitle ?></td>
                       <td><?php  echo $chatTy ?></td>
					   <td class="text-center"><a href="<?php  echo ADD_CHAT_VALUES_URL.'/'.$chatMem->ID; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
                       <td class="text-center"><a href="<?php echo ADD_CHAT_MEMBERS_URL.'/'.$chatMem->ID; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
					 &nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0)"><i class="fa fa-trash-o" aria-hidden="true" onclick="deleteMember(<?php echo $chatMem->ID; ?>);"></i></a>
					 </td>
                    </tr>
					<?php $i++;  }  }else{
						echo '<p style="color:red">No results found for this search.</p>';die(); 
					} ?>
                   </tbody>
                </table>
             <div class="clearfix"></div>
			
         
	 
	 