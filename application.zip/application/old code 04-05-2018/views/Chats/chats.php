  <?php $this->load->view('sideMenu');$this->load->view('scripts');?>
 <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1> </h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li>Chats</li>
               <?php 
			  $Role_Id=$this->session->userdata('Role_Id');
			  $agentId=$this->session->userdata('agent_id');
			  if(empty($Role_Id) && $agentId){
				   $dashboardUrl=AGENT_DASHBOARD_URL;
			  }else{
				 $dashboardUrl=DASHBOARD_URL;
			  }
			  ?>
              <li><a href="<?php echo $dashboardUrl; ?>">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="clearfix"></div>
          <div class="col-md-12">
		   
			<h1 class="table_title">Chats DATA</h1>
			<div class="title_separator"></div>
			<div>
			<a class="btn btn-info color_btn" href="<?php echo ADD_CHAT_MEMBERS_URL; ?>">ADD</a>
			
			</div>
            <div class="main_table">
              <div class="table-responsive">
			  <div class="form-group">
                         <label  for="inputEmail" style="margin-top:20px;">Search By News :</label>
                        <select  id="news" name="news" class="form-control" style="width:25%;margin-top:-30px;margin-left:150px">
                        <option value="">Select News</option>
					    <?php if($news && count($news) > 0){
						 foreach($news as $new){ ?>
						<option id="newsId" value="<?php echo $new->news_id ; ?>"><?php echo $new->news_title ?> </option>
						<?php } }   ?>
                       </select>
				 </div>
				 <div id="error"></div>
               
		     <div id="table">
               <table id="myTable" class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" width="100%" > 
                  <thead>
                    <tr class="title_head">
                      <th width="5%" class="text-center">S.No</th>
                      <th width="15%" class="text-center">Name</th>
                      <th width="10%" class="text-center">Image</th>
                      <th width="10%" class="text-center">News Title</th>
                      <th width="10%" class="text-center">Chat TYpe</th>
                      <th width="15%" class="text-center">Add Values</th>
                      <th width="15%" class="text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
				   <?php $this->load->model('Chatmodel');?>

				  <?php if($chatMembers){
					  $i=1;$chatTy="-";
					  foreach($chatMembers as $chatMem){   

                       if($chatTypes){
						   foreach($chatTypes as $chtType){ 
							  if($chtType->chat_type_ref_id == $chatMem->chatTypeRefID){
								  $chatTy=$chtType->type_ref;
							  }
						   }
					  }
					 $newsTitle=$this->Chatmodel->getNewsTitle($chatMem->newsID);
					  ?>
				 <tr>
                       <td><?php echo $i; ?></td>
                       <td><?php  echo $chatMem->name ?></td>
                       <td><img src="<?php  echo CHAT_MEMBER_IMAGE_PATH.$chatMem->image ?>" height="50px" width="50px"></td>
                       <td><?php  echo @$newsTitle ?></td>
                       <td><?php  echo $chatTy ?></td>
					   <td class="text-center"><a href="<?php  echo ADD_CHAT_VALUES_URL.'/'.$chatMem->ID; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
                       <td class="text-center"><a href="<?php echo ADD_CHAT_MEMBERS_URL.'/'.$chatMem->ID; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
					 &nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0)"><i class="fa fa-trash-o" aria-hidden="true" onclick="deleteMember(<?php echo $chatMem->ID; ?>);"></i></a>
					 </td>
                    </tr>
					<?php $i++;  }  } ?>
                    
                  </tbody>
                </table>
              </div>
              </div>
            </div><br><br><br><br>
			<div class="clearfix"></div>
			
          </div>
        </div>
      </div>
	 
	  <script>
	   $(document).ready(function(){ 
		$("#news").change(function(){
		var id=this.value; 
		if(id){
		 $.ajax({
                    type: "post",
					 url:baseUrl+'/Chats/newsBySearch',  
				    data: {id:id},
                            success: function(response){ 
							 if(response == "1"){
								$('#error').html("No results found for this Search..");
							}else{
								$('#table').html(response);
							}
                    },
						error: function(xhr, statusText, err){
                             console.log("Error:" + xhr.status);  
						}
						
                });
 				
         return false; 
		 }
       });
	  
     });
	 </script>
	 