<!DOCTYPE html>
<html>
    <style>
        .animated {
            -webkit-animation-duration: 10s;animation-duration: 10s;
            -webkit-animation-fill-mode: both;animation-fill-mode: both;
        }
        @-webkit-keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        @keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        .fadeOut {
            -webkit-animation-name: fadeOut;
            animation-name: fadeOut;
        }
    </style>
    <?php $this->load->view('sideMenu');
          $this->load->view('scripts'); ?>
    <div class="content-wrapper">
        <div class="page-title">
            <div>
                <h1>Advertisements</h1>
            </div>
            <div>
                <ul class="breadcrumb">
                    <li>Add Advertisements </li>
                    <?php
                    $Role_Id = $this->session->userdata('Role_Id');
                    $dashboardUrl = DASHBOARD_URL;
                    ?>
                    <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="clearfix"></div>
            <div class="col-md-12">
                <div class="card">
                    <div class="row"><br>
                        <div class="col-lg-8 m-t-25">
                            <div class="well bs-component">
                                <?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
                                <?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
                                <?php $action = ADD_ADD_URL.'/'.$celebrityId; ?>
                                <form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data" >
                                    <div id="Error"></div>
                                    <fieldset>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Title</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="add_title"   name="add_title" value="" type="text"  placeholder=" Title" required>
                                            </div>
                                        </div>
										<div class="form-group" >
                                                <label class="col-lg-2 control-label"  for="inputEmail" > Select file Type </label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" id="type" name="add_type" onchange="show()">
													<option value="">Select Option </option>
													<option value="19"> Google Add with image</option>
													<option value="20"> Google Add with video </option>
													<option value="21"> Add with image</option>
													<option value="22"> Add with video </option>
													</select>
                                                </div>
                                            </div>
										<div class="form-group" id="thumb_image">
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="thumb">Thumb Image</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="add_thumb_image" name="add_thumb_image" value="" type="file">
                                                </div>
                                            </div>
										<div class="form-group" id="image">
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="imagename">Image</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="add_image" name="add_image" value="" type="file">
                                                </div>
                                            </div>
											<div class="form-group" id="video">
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="imagename">Video</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="add_video" name="add_video" value="" type="file">
                                                </div>
                                            </div>
                                        <div class="form-group" id="content">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Content </label>
                                            <div class="col-lg-8">
                                                <textarea placeholder=" content" class="form-control" id="add_content"  name="add_content" value="" ></textarea>
                                            </div>
                                        </div>
										<div class="form-group" id="IVFO ">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Is Visible For Once </label>
                                            <div class="col-lg-8">
                                                <input placeholder=" Is Visible For Once " class="form-control" id="add_visible_for_once"  name="add_visible_for_once" value="1" type="checkbox">
                                            </div>
                                        </div>
										 <div class="form-group" id="location ">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Location </label>
                                            <div class="col-lg-8">
                                                <input placeholder=" location" class="form-control" id="add_location"  name="add_location" value="" type="text" >
                                            </div>
                                        </div>
										<div class="form-group" id="coins ">
                                            <label class="col-lg-2 control-label" for="inputEmail"> No Of Coins</label>
                                            <div class="col-lg-8">
                                                <input placeholder=" coins" class="form-control" id="add_coins"  name="add_coins" onkeyup="checkInp()"pattern="[0-9.]+" maxlength="5" size="5" value=""  required>
                                            </div>
                                        </div>
                                        </div>
                                        <div id="append"></div>
                                        <div id="trending">&nbsp;</div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">&nbsp;</label>
                                            <div class="col-lg-8"><input type="submit" name="addADD" value="submit" class="btn btn-danger" ></input></div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
<script>
$('#thumb_image').hide();
$('#video').hide();
function show(){
	var type = $('#type').val();
	if(type == 21){
		$('#image').show();
		$('#thumb_image').hide();
		$('#video').hide();
	}
	else if(type == 22){
		$('#image').hide();
		$('#thumb_image').show();
		$('#video').show();
	}
	else{
		$('#image').hide();
		$('#thumb_image').hide();
		$('#video').hide();
	}
}
function checkInp()
{
    var x=$('#promotionBanners_order').val();
    var regex=/^[0-9]+$/;
    if (!x.match(regex))
    {  document.getElementById("promotionBanners_order").value = "";
        return false;
    }
}
</script>