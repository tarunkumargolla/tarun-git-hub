<?php $this->load->view('sideMenu');
$this->load->view('scripts'); ?>
<div class="content-wrapper">
    <div class="page-title">
        <div>
            <h1> </h1>
        </div>
        <div>
            <ul class="breadcrumb">
                <li>Advertisement</li>
<?php $dashboardUrl = DASHBOARD_URL; ?>
                <li><a href="<?php echo $dashboardUrl; ?>">Dashboard</a></li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-md-12">

            <h1 class="table_title">Advertisement </h1>
			
            <div class="title_separator"></div>
               <a class="btn btn-info color_btn" href="<?php echo ADD_ADD_URL.'/'.$celebrityId;?>">ADD</a>

            <div class="main_table">
                <div class="table-responsive">
                    <br><br>
					<?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
					<?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
                    <table id="myTable" class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" width="100%" > 
                        <thead>
                            <tr class="title_head">
                                <th width="5%" class="text-center">S.No</th>
                                <th width="15%" class="text-center">Title</th>
								<th width="15%" class="text-center">Image</th>
								<!--th width="15%" class="text-center">Content</th-->
								<th width="15%" class="text-center">Location</th>
								 <th width="15%" class="text-center">Actions</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
							if($adds){
							$i=1;
							foreach($adds as $add){?>
									
                                    <tr>
                                        <td class="text-center"><?php echo $i; ?></td>
										<td class="text-center"><?php echo $add->add_title; ?></td>
										<?php if($add->add_thumb_image){?>
										 <td ><img src="<?php echo FSITEURL.'/uploads/adds/'.$add->add_thumb_image; ?>" width="100" height="100"></td>
										<?php } elseif($add->add_image) {?>
										<td><img src="<?php echo FSITEURL.'/uploads/adds/'.$add->add_image; ?>" width="100" height="100"></td>
										<?php }else{ ?>
										<td class="text-center"><?php echo "-";?></td>
										<?php } ?>
										 <!--td><?php echo $add->add_content; ?></td-->
										 <td class="text-center"> <?php echo ($add->add_location)?$add->add_location:"-"; ?></td>
                                        <td class="text-center"><a href="<?php echo EDIT_ADD_URL .'/'.$add->add_celebrity_id. '/' . $add->add_id; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0)"><i class="fa fa-trash-o" aria-hidden="true"  onclick="deleteAdd(<?php echo $add->add_id;?>)"></i></a>
                                        </td>
                                    </tr>
																
									<?php $i++;
							} }?>

                        </tbody>
                    </table>
                </div>
            </div><br><br><br><br>
            <div class="clearfix"></div>

        </div>
    </div>
</div>
<script>
function deleteAdd(id){ 
	var ok = confirm("Are you sure to Delete?"); 
       if (ok) {
	          $.ajax({
                    type: "POST",
                    url:'<?php echo DELETE_ADD_URL ?>', 
				    data: {'id':id},
					//dataType:'json',
                    success: function(response){ 
						 location.reload(); 
						
                    },
				    error: function(xhr, statusText, err){
                              console.log("Error:" + xhr.status);  
				    }
						
                });
	   }
 				
  return false;
}
/* function deleteImage(id){
	var ok = confirm("Are you sure to Delete?"); 
       if (ok) {
	          $.ajax({
                    type: "POST",
                    url:'<?php echo DELETE_FOUNDATION_URL ?>', 
				    data: {'id':id},
					dataType:'json',
                    success: function(response){
						 location.reload(); 
						
                    },
				    error: function(xhr, statusText, err){
                              console.log("Error:" + xhr.status);  
				    }
						
                });
	   }
 				
  return false;
} */
</script>