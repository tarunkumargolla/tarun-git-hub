<!DOCTYPE html>
<html>
    <style>
        .animated {
            -webkit-animation-duration: 10s;animation-duration: 10s;
            -webkit-animation-fill-mode: both;animation-fill-mode: both;
        }
        @-webkit-keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        @keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        .fadeOut {
            -webkit-animation-name: fadeOut;
            animation-name: fadeOut;
        }
    </style>
    <?php $this->load->view('sideMenu');
    $this->load->view('scripts'); ?>
    <div class="content-wrapper">
        <div class="page-title">
            <div>
                <h1>Advertisements</h1>
            </div>
            <div>
                <ul class="breadcrumb">
                    <li>Advertisements</li>
                    <?php
                    $Role_Id = $this->session->userdata('Role_Id');
                    $dashboardUrl = DASHBOARD_URL;
                    ?>
                    <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="clearfix"></div>
            <div class="col-md-12">
                <div class="card">
                    <div class="row"><br>
                        <div class="col-lg-8 m-t-25">
                            <div class="well bs-component">
                                <?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
                                <?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
<?php $action = EDIT_ADD_URL.'/'.$celebrityId.'/'.$details->add_id; ?>
                                <form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data" >
                                    <div id="Error"></div>
                                    <fieldset>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail">  Title</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="edit_add_title"   name="edit_add_title" value="<?php if(@$details->add_title){echo $details->add_title;}else{echo "";}?>" type="text"  placeholder=" Title" required>
                                            </div>
                                        </div>
											<?php if(@$details->add_thumb_image){?>
										<div class="form-group" id="image">
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="thumb">Thumb Image</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="edit_add_thumb_image" name="edit_add_thumb_image" value="1" <?php if($details->add_thumb_image){echo $details->add_thumb_image;}else{echo "required";}?> type="file">
                                                </div>
                                            </div>
											<?php } 
											if($details->add_type == 21){ ?>
										   <div class="form-group" >
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="imagename"> Image</div></label>
                                                <div class="col-lg-8">
												    <img  src='<?php echo ADD_IMAGE_PATH.'/'.$details->add_image ?>' width="80" height="80"><img>
                                                    <!--img  src='<?php echo SITEURL; ?>/assets/images/close.jpg' width="20" height="20" style="margin:10px"-->
                                                    <input class="form-control" id="edit_add_image" name="edit_add_image" value=""<?php if(@$details->add_image){echo $details->add_image;}else {echo "required";}?> type="file">
                                                </div>
                                            </div>
											<?php }elseif($details->add_type == 22){ ?>
												<div class="form-group" >
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="imagename"> video</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="edit_add_video" name="edit_add_video" value=""<?php if(@$details->add_video){echo $details->add_video;}else {echo "required";}?> type="file">
                                                </div>
                                            </div>
											<?php } ?>
                                        <div class="form-group" id="content">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Content</label>
                                            <div class="col-lg-8">
                                                <textarea placeholder=" content" class="form-control" id="edit_add_content"  name="edit_add_content" value="" ><?php if(@$details->add_content){echo $details->add_content;}else{echo "";}?></textarea>
                                            </div>
                                        </div>
										<div class="form-group" id="IVFO ">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Is Visible For Once </label>
                                            <div class="col-lg-8">
                                                <input placeholder=" Is Visible For Once " class="form-control" id="edit_add_visible_for_once"  name="edit_add_visible_for_once" value="1" <?php if($details->add_visible_once_per_user == 1){echo "checked";}else{echo "";}?> type="checkbox">
                                            </div>
                                        </div>
										 <div class="form-group" id="location ">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Location </label>
                                            <div class="col-lg-8">
                                                <input placeholder=" location" class="form-control" id="edit_add_location"  name="edit_add_location" value="<?php if($details->add_location){echo $details->add_location;}else{echo "";}?>" type="text" >
                                            </div>
                                        </div>
										<div class="form-group" id="coins ">
                                            <label class="col-lg-2 control-label" for="inputEmail"> No Of Coins</label>
                                            <div class="col-lg-8">
                                                <input placeholder=" coins" class="form-control" id="edit_add_coins"  name="edit_add_coins" onkeyup="checkInp" value="<?php if($details->add_coins){echo $details->add_coins;}else{echo "";}?>"  required>
                                            </div>
                                        </div>
										<input type="hidden" id="edit_add_id" name="edit_add_id" value="<?php echo @$details->add_id;?>">
										<input type="hidden" id="type" name="type" value="<?php echo @$details->add_type;?>">
                                        </div>
                                        <div id="append"></div>
                                        <div id="trending">&nbsp;</div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">&nbsp;</label>
                                            <div class="col-lg-8"><input type="submit" name="editADD" value="submit" class="btn btn-danger" ></input></div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
<script>
function checkInp()
{
    var x=$('#promotionBanners_order').val();
    var regex=/^[0-9]+$/;
    if (!x.match(regex))
    {  document.getElementById("promotionBanners_order").value = "";
        return false;
    }
}
</script>