<!DOCTYPE html>
<html>
  
  <?php $this->load->view('sideMenu');?>
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>Profile</h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li>Home</li>
              <li><a href="<?php echo DASHBOARD_URL ?>">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="clearfix"></div>
          <div class="col-md-12">
            <div class="card">
              <div class="row"><br>
                <div class="col-lg-8 m-t-25">
                  <div class="well bs-component">
               <?php if($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php  echo $this->session->flashdata('Smessage');?></div><?php } ?>
                <?php  if($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage');?></div><?php } ?>
                    <form class="form-horizontal" method="post" action="<?php echo UPDATE_ADMIN_PROFILE_URL; ?>">
                      <fieldset>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Name</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="inputEmail" readonly name="name" value="<?php if($details->name) echo $details->name;?>" type="text" placeholder="Name">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Email</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="inputEmail"  name="emailAddress" value="<?php if($details->emailAddress) echo $details->emailAddress;?>" type="text" placeholder="Email">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Phone Number</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="inputEmail" readonly name="phoneNumber" value="<?php if($details->phoneNumber) echo $details->phoneNumber;?>" type="text" placeholder="Phone Number">
                          </div>
                        </div>
                       
                      <input type="hidden" name="id" value="<?php if($details->adminId) echo $details->adminId;?>">
                        <div class="form-group">
                          <label class="col-lg-2 control-label">&nbsp;</label>
                          <div class="col-lg-8"><input type="submit" name="Submit" value="submit" class="btn btn-danger" href="<?php echo UPDATE_ADMIN_PROFILE_URL ;?>"></input></div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
                
              </div><br><br><br>
            </div>
			<div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Javascripts-->
   
  </body>
</html>