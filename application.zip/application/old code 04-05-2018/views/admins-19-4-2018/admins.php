  <?php $this->load->view('sideMenu');$this->load->view('scripts');
  $Role_Id = $this->session->userdata('Role_Id');
  ?>
  
 <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1> </h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li>Admins</li>
              <li><a href="<?php echo DASHBOARD_URL; ?>">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="clearfix"></div>
          <div class="col-md-12">
		   
			<h1 class="table_title">ADMINS DATA</h1>
			<div class="title_separator"></div>
			<?php if($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php  echo $this->session->flashdata('Smessage');?></div><?php } ?>
            <?php  if($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage');?></div><?php } ?>
               <div class="tile_div" style="display: inline-block;" >
			   <?php if($Role_Id == 1){?>
   <a class="btn btn-info color_btn" href="<?php echo ADD_ADMINS_URL; ?>">ADD</a>
			   <?php }?>
    </form></a>
</div>    
			<div>
			
			 
			</div>
            <div class="main_table">
              <div class="table-responsive">
               <br><br>
               <table id="myTable" class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" width="100%" > 
                  <thead>
                    <tr class="title_head">
                      <th width="5%" class="text-center">S.No</th>
                      <th width="15%" class="text-center">Name</th>
                      <th width="15%" class="text-center">Phone Number</th>
                      <th width="15%" class="text-center">Email Address</th>
					   <th width="15%" class="text-center">Celebrity Name</th>
                      <th width="15%" class="text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
				  <?php if($admins){
					  $i=1;
					  foreach($admins as $admin){
                         foreach($celebritys as $celeb)	{
							 if($celeb->c_id == $admin->celebrityId){
							 $celebrity = $celeb->c_name;
							 }
						 }					  
					 ?>
				
                    <tr>
                      <td><?php echo $i; ?></td>
                      <td><?php  echo $admin->name ?></td>
                      <td><?php  echo $admin->phoneNumber ?></td>
                      <td><?php  echo $admin->emailAddress ?></td>
					  <td><?php  echo $celebrity ?></td>
                     <td class="text-center"><a href="<?php echo ADD_ADMINS_URL.'/'.$admin->adminId; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
					 &nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0)"><i class="fa fa-trash-o" aria-hidden="true" onclick="deleteUser(<?php echo $admin->adminId; ?>);"></i></a>
					 </td>
                    </tr>
					<?php $i++;  }  } ?>
                    
                  </tbody>
                </table>
              </div>
            </div>
			<div class="clearfix"></div>
		</div>
        </div>
      </div>