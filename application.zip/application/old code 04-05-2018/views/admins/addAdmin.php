<!DOCTYPE html>
<html>
  <?php $this->load->view('sideMenu');?>
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>Admin</h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li>Add Admin</li>
               <?php 
			  $Role_Id=$this->session->userdata('Role_Id');
			  $agentId=$this->session->userdata('agent_id');
			  if(empty($Role_Id) && $agentId){
				   $dashboardUrl=AGENT_DASHBOARD_URL;
			  }else{
				 $dashboardUrl=DASHBOARD_URL;
			  }
			  ?>
              <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="clearfix"></div>
          <div class="col-md-12">
            <div class="card">
              <div class="row"><br>
                <div class="col-lg-8 m-t-25">
                  <div class="well bs-component">
               <?php if($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php  echo $this->session->flashdata('Smessage');?></div><?php } ?>
                <?php  if($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage');?></div><?php } ?>
                    <?php if(@$details->adminId){ 
						$action=ADD_ADMINS_URL.'/'.@$details->adminId;
					}else{
						$action=ADD_ADMINS_URL;
					}
					?>
					
					<form class="form-horizontal" method="post" action="<?php echo $action; ?>">
                      <fieldset>
                         <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Name</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="name"   name="name" value="<?php if(@$details->name) echo @$details->name;?>" type="text"  placeholder="Name">
                          </div>
                        </div>
						
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Phone Number</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="phoneNumber" maxlength="10" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'');"  name="phoneNumber" value="<?php if(@$details->phoneNumber) echo @$details->phoneNumber;?>" type="text" placeholder="phone Number">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Email Address</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="emailAddress"  name="emailAddress" value="<?php if(@$details->emailAddress) echo @$details->emailAddress;?>" type="text" placeholder="Email Address">
                          </div>
                        </div>
						<?php if(empty(@$details->password)){?>
						 <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Password</label>
                          <div class="col-lg-8">
                            <input class="form-control" id="password"  name="password" value="<?php if(@$details->password) echo @$details->password;?>" type="password" placeholder="Password">
                        </div>
						</div>
						<?php } ?>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Celebrity</label>
                          <div class="col-lg-8">
                            <select class="form-control" id="celeb" name="celeb" <?php if($details){ echo 'readonly';}?> >
							<option value="">select Celebrity </option>
							<?php if($celebritys){
							foreach($celebritys as $celebrity){?>
								<option value="<?php echo $celebrity->c_id;?>"<?php if($celebrity->c_id == @$details->celebrityId){echo "selected";true;}?>><?php echo $celebrity->c_name;?></option>
							<?php }}?>
							
							</select>
                        </div>
						</div>
						
						 <input type="hidden" name="id" value="<?php if(@$details->bId) echo @$details->bId;?>">
                        <div class="form-group">
                          <label class="col-lg-2 control-label">&nbsp;</label>
                          <div class="col-lg-8"><input type="submit" name="addUser" value="submit" class="btn btn-danger" ></input></div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
                
              </div>
            </div>
			<div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Javascripts-->
   
  </body>
</html>