<?php $this->load->view('sideMenu');
$this->load->view('scripts'); ?>
<div class="content-wrapper">
    <div class="page-title">
        <div>
            <h1> </h1>
        </div>
        <div>
            <ul class="breadcrumb">
                <li>Awards</li>
<?php $dashboardUrl = DASHBOARD_URL; ?>
                <li><a href="<?php echo $dashboardUrl; ?>">Dashboard</a></li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-md-12">

            <h1 class="table_title">Awards </h1>
			
            <div class="title_separator"></div>
               <a class="btn btn-info color_btn" href="<?php echo ADD_AWARDS_URL.'/'.$celebrityId;?>">ADD</a>

            <div class="main_table">
                <div class="table-responsive">
                    <br><br>
					<?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
					<?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
                    <table id="myTable" class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" width="100%" > 
                        <thead>
                            <tr class="title_head">
                                <th width="5%" class="text-center">S.No</th>
                                <th width="15%" class="text-center">Awards</th>
								<th width="15%" class="text-center">Celebrity Name</th>
								<th width="15%" class="text-center">Content</th>
								 <th width="15%" class="text-center">Actions</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
							if($awards){
							$i=1;
							foreach($awards as $award){?>
									
                                    <tr>
                                        <td><?php echo $i; ?></td>
										<td><?php echo $award->a_title; ?></td>
										 <td><?php echo $cele_Name; ?></td>
										 <td><?php echo $award->a_content; ?></td>
                                        <td class="text-center"><a href="<?php echo EDIT_AWARDS_URL .'/'.$award->celebrityId. '/' . $award->a_id; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0)"><i class="fa fa-trash-o" aria-hidden="true"  onclick="deleteAwards(<?php echo $award->a_id;?>)"></i></a>
                                        </td>
                                    </tr>
																
									<?php $i++;
							} }?>

                        </tbody>
                    </table>
                </div>
            </div><br><br><br><br>
            <div class="clearfix"></div>

        </div>
    </div>
</div>
<script>
function deleteAwards(id){
	var ok = confirm("Are you sure to Delete?"); 
       if (ok) {
	          $.ajax({
                    type: "POST",
                    url:'<?php echo DELETE_AWARDS_URL ?>', 
				    data: {'id':id},
					//dataType:'json',
                    success: function(response){
						 location.reload(); 
						
                    },
				    error: function(xhr, statusText, err){
                              console.log("Error:" + xhr.status);  
				    }
						
                });
	   }
 				
  return false;
}
</script>