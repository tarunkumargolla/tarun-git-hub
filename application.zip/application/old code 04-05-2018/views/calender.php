  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
	  var date = $('#datepicker').datepicker({ dateFormat: 'd-m-yy',minDate: 0/* , multidate: true */}).val();
	  
   // $( "#datepicker" ).datepicker();
    $( "#datepicker1" ).datepicker({ dateFormat: 'd-m-yy',minDate: 0 }).val();
  } );
  </script>
    