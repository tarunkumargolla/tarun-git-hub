<?php $Role_Id = $this->session->userdata('Role_Id');?>
      <!-- Side-Nav-->
    <?php //$this->load->view('header');?>
    <?php $this->load->view('sideMenu');?>
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>ADMIN DATA</h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li>Home</li>
              <li><a href="<?php echo DASHBOARD_URL; ?>">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="clearfix"></div>
          <div class="col-md-12">
		    <div class="white-box">
			 <div class="row row-in">
				  <div class="col-lg-3 col-sm-6 row-in-br">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color1"><img src="<?php echo IMG_URL ?>/toplist_icon1.png" alt="User Image"></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"><?php echo $usersCount->users_count; ?></h3></li>
							<li class="col-middle">
							<?php if($Role_Id == 1){?>
								<h4>Users  </h4>
							<?php } else{?>
							<h4>Admins  </h4>
							<?php }?>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <!--div class="col-lg-3 col-sm-6 row-in-br  b-r-none">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color2"><img src="<?php echo IMG_URL ?>/toplist_icon1.png" alt="User Image"></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"><?php echo $categories->categories; ?></h3></li>
							<li class="col-middle">
								<h4>Categories </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6 row-in-br">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color3"><img src="<?php echo IMG_URL ?>/toplist_icon1.png" alt="User Image"></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"><?php echo $articles->articles; ?></h3></li>
							<li class="col-middle">
								<h4>Articles </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  <div class="col-lg-3 col-sm-6  b-0">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color4"><img src="<?php echo IMG_URL ?>/toplist_icon1.png" alt="User Image"></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"><?php echo $subscriptions->subscriptions; ?></h3></li>
							<li class="col-middle">
								<h4>Subscriptions </h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div-->
				  <div class="col-lg-3 col-sm-6 row-in-br  b-r-none">
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color2"><img src="<?php echo IMG_URL ?>/toplist_icon1.png" alt="User Image"></span>
							</li>
							<li class="col-last"><h3 class="counter text-right m-t-15"><?php echo $noOfapps->noOfApps; ?></h3></li>
							<li class="col-middle">
								<h4>No Of Apps</h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				  </div>
				  
				   <?php if($apptypes){foreach($apptypes as $apptype){?>
				  <div class="col-lg-3 col-sm-6 row-in-br">
				 
					<ul class="col-in">
							<li>
								<span class="circle circle-md bg_color3"><img src="<?php echo IMG_URL ?>/toplist_icon1.png" alt="User Image"></span>
							</li>
							<li class="col-middle">
								<h4><a href="<?php echo CELEBRITY_URL.'/'.$apptype->id;?>"><?php echo $apptype->type;?></a></h4>
								<div class="title_separator m-0"></div>
							</li>
					</ul>
				 
				  </div>
				   <?php }} ?>
				</div> 
              <br><br><br> <br><br><br><br><br><br><br><br><br><br><br><br>				
			</div>
		
          </div>
        </div>
      </div>
    </div>
    <!-- Javascripts-->
   <?php // $this->load->view('footer'); ?> 
  </body>
</html>