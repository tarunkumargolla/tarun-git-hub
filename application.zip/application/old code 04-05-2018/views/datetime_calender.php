 <script src="<?php echo ASITEURL ?>/assets/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
  <link href="<?php echo ASITEURL ?>/assets/bootstrap-datetimepicker/css/bootstrap-datetimepicker.css" rel="stylesheet" type="text/css">
 <script type="text/javascript">
 $(function() {
            $("#date").click(function() {
                $('#datepicker').datetimepicker().datetimepicker( "show" )
            });
			$("#date1").click(function() {
                $('#datepicker1').datetimepicker().datetimepicker( "show" )
 				$('#datepicker1').datetimepicker().datetimepicker("fixed")
          });
			$("#date2").click(function() {
                $('#datepicker2').datetimepicker().datetimepicker( "show" )
            });
			$("#date3").click(function() {
                $('#datepicker3').datetimepicker().datetimepicker( "show" )
            });
        });
            $(function () {
				var nowDate = new Date();
var today = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 0, 0, 0, 0);
                $('#datepicker').datetimepicker({ 
		    format: "dd-mm-yyyy  hh:ii:ss ",
			autoclose: true,
			todayBtn: true,
			pickerPosition: "bottom-right",
			startDate: today,
            }).val();
				$('#datepicker1').datetimepicker({ 
		    format: "dd-mm-yyyy  hh:ii:ss",
			autoclose: true,
			todayBtn: true,
			pickerPosition: "bottom-right",
			startDate: today
            }).val(); 
			$('#datepicker2').datetimepicker({ 
		    format: "dd-mm-yyyy  hh:ii:ss",
			autoclose: true,
			todayBtn: true,
			pickerPosition: "bottom-right",
			startDate: today
            }).val(); 
			$('#datepicker3').datetimepicker({ 
		    format: "dd-mm-yyyy  hh:ii:ss",
			autoclose: true,
			todayBtn: true,
			pickerPosition: "bottom-right",
			startDate: today
            }).val(); 
            });
        </script>