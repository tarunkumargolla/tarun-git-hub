<!DOCTYPE html>
<html>
<?php $this->load->view('datetime_calender'); ?>
    <style>
        .animated {
            -webkit-animation-duration: 10s;animation-duration: 10s;
            -webkit-animation-fill-mode: both;animation-fill-mode: both;
        }
        @-webkit-keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        @keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        .fadeOut {
            -webkit-animation-name: fadeOut;
            animation-name: fadeOut;
        }
    </style>
    <?php $this->load->view('sideMenu');
    $this->load->view('scripts'); ?>
    <div class="content-wrapper">
        <div class="page-title">
            <div>
                <h1>Events</h1>
            </div>
            <div>
                <ul class="breadcrumb">
                    <li>Edit Events</li>
                    <?php
                    $Role_Id = $this->session->userdata('Role_Id');
                    $dashboardUrl = DASHBOARD_URL;
                    ?>
                    <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="clearfix"></div>
            <div class="col-md-12">
                <div class="card">
                    <div class="row"><br>
                        <div class="col-lg-8 m-t-25">
                            <div class="well bs-component">
                                <?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
                                <?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
<?php $action = EDIT_EVENT_URL.'/'.$celebrityId; ?>
                                <form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data" >
                                    <div id="Error"></div>
                                    <fieldset>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Events Title</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="edit_event_title"   name="edit_event_title" value="<?php if(@$details->e_title){echo $details->e_title;}else{echo "";}?>" type="text"  placeholder="Events Title" required>
                                            </div>
                                        </div>
										<div class="form-group" >
                                                <label class="col-lg-2 control-label"  for="inputEmail" >Event Image</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="edit_event_image" name="edit_event_image" value="" <?php if($details->e_image){echo $details->e_image;}else{echo "required";}?> type="file">
                                                </div>
                                            </div>
                                        <div class="form-group" id="content">
                                            <label class="col-lg-2 control-label" for="inputEmail">Events Description</label>
                                            <div class="col-lg-8">
                                                <textarea placeholder="Events content" class="form-control" id="edit_event_content"  name="edit_event_content" value=""  required><?php if(@$details->e_content){echo $details->e_content;}else{echo "";}?></textarea>
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail">Event Place</label>
                                            <div class="col-lg-8">
                                                <textarea placeholder="Events Place" class="form-control" id="edit_event_place"  name="edit_event_place" value=""  required><?php if(@$details->e_place){echo $details->e_place;}else{echo "";}?></textarea>
                                            </div>
                                        </div>
										<div class="form-group" id="date">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Event Start Date </label>
                                            <div class="col-lg-8" >
                                                <input class="form-control" id="datepicker" class="date-control"  name="edit_event_start_date" value="<?php if(@$details->e_start_date){echo $details->e_start_date;}else{echo "";}?>" type="text"  placeholder="Event Start Date" required>
                                            </div>
                                        </div>
										<div class="form-group" id="date1">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Event End Date </label>
                                            <div class="col-lg-8" >
                                                <input class="form-control" id="datepicker1" class="date-control"  name="edit_event_end_date" value="<?php if(@$details->e_end_date){echo $details->e_end_date;}else{echo "";}?>" type="text"  placeholder="Event End Date" required>
                                            </div>
                                        </div>
										<input type="hidden" id="edit_foundation_id" name="edit_foundation_id" value="<?php echo @$details->e_id;?>">
                                        </div>
                                        <div id="append"></div>
                                        <div id="trending">&nbsp;</div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">&nbsp;</label>
                                            <div class="col-lg-8"><input type="submit" name="editEvent" value="submit" class="btn btn-danger" ></input></div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
