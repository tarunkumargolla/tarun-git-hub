<?php  
 $connect = mysqli_connect("localhost", "root", "", "flicknews"); 
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM users";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                         <th>Name</th>  
                         <th>Email</th>  
                         <th>phoneNumber</th>  
                    </tr>
  ';
  while($row = mysqli_fetch_assoc($result))
  { 
   $output .= '
    <tr>  
                         <td>'.$row["name"].'</td>  
                         <td>'.$row["emailAddress"].'</td>  
                         <td>'.$row["phoneNumber"].'</td>  
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xlsx');
  header('Content-Disposition: attachment; filename=download.xlsx');
  echo $output;
 }
}
?>