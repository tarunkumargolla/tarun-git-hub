 <script>
$(document).ready(function(){
    $('#myTable').dataTable();
});
</script>
<!--<script src="<?php echo JS_URL ?>/jquery-2.1.4.min.js"></script>-->
<script src="<?php echo JS_URL ?>/bootstrap.min.js"></script>
<script src="<?php echo JS_URL ?>/plugins/pace.min.js"></script>
<script src="<?php echo JS_URL ?>/main.js"></script>
<script src="<?php echo ASITEURL; ?>/assets/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
