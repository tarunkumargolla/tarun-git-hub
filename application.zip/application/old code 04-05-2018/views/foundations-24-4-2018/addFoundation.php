<!DOCTYPE html>
<html>
    <style>
        .animated {
            -webkit-animation-duration: 10s;animation-duration: 10s;
            -webkit-animation-fill-mode: both;animation-fill-mode: both;
        }
        @-webkit-keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        @keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        .fadeOut {
            -webkit-animation-name: fadeOut;
            animation-name: fadeOut;
        }
    </style>
    <?php $this->load->view('sideMenu');
          $this->load->view('scripts'); ?>
    <div class="content-wrapper">
        <div class="page-title">
            <div>
                <h1>Foundations</h1>
            </div>
            <div>
                <ul class="breadcrumb">
                    <li>Add Foundations News</li>
                    <?php
                    $Role_Id = $this->session->userdata('Role_Id');
                    $dashboardUrl = DASHBOARD_URL;
                    ?>
                    <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="clearfix"></div>
            <div class="col-md-12">
                <div class="card">
                    <div class="row"><br>
                        <div class="col-lg-8 m-t-25">
                            <div class="well bs-component">
                                <?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
                                <?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
                                <?php $action = ADD_FOUNDATION_URL.'/'.$celebrityId; ?>
                                <form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data" >
                                    <div id="Error"></div>
                                    <fieldset>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Foundations Title</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="foundations_title"   name="foundations_title" value="" type="text"  placeholder="Foundations Title" required>
                                            </div>
                                        </div>
										<div class="form-group" >
                                                <label class="col-lg-2 control-label"  for="inputEmail" > Select file Type </label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" id="type" name="type" onchange="show()">
													<option value="">Select Option </option>
													<option value="14"> Foundation with image</option>
													<option value="17"> Foundation with video </option>
													</select>
                                                </div>
                                            </div>
										<div class="form-group" id="image">
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="thumb">Thumb Image</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="thumb_image" name="thumb_image" value="" type="file">
                                                </div>
                                            </div>
										<div class="form-group" id="video">
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="imagename">Foundations Image/video</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="foundation_image_video" name="foundation_image_video" value="" type="file"   required>
                                                </div>
                                            </div>
                                        <div class="form-group" id="content">
                                            <label class="col-lg-2 control-label" for="inputEmail">Foundations Content</label>
                                            <div class="col-lg-8">
                                                <textarea placeholder="Foundations content" class="form-control" id="foundations_content"  name="foundations_content" value=""  required></textarea>
                                            </div>
                                        </div>
                                        </div>
                                        <div id="append"></div>
                                        <div id="trending">&nbsp;</div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">&nbsp;</label>
                                            <div class="col-lg-8"><input type="submit" name="addFoundation" value="submit" class="btn btn-danger" ></input></div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
<script>
$('#image').hide();
function show(){
	var type = $('#type').val();
	if(type == 14){
		$('#video').show();
		$('#image').hide();
	}
	else if(type == 17){
		$('#video').show();
		$('#image').show();
	}
	else{
		$('#image').hide();
	}
}
</script>