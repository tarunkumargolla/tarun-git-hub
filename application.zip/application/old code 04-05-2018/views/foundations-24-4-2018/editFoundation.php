<!DOCTYPE html>
<html>
    <style>
        .animated {
            -webkit-animation-duration: 10s;animation-duration: 10s;
            -webkit-animation-fill-mode: both;animation-fill-mode: both;
        }
        @-webkit-keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        @keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        .fadeOut {
            -webkit-animation-name: fadeOut;
            animation-name: fadeOut;
        }
    </style>
    <?php $this->load->view('sideMenu');
    $this->load->view('scripts'); ?>
    <div class="content-wrapper">
        <div class="page-title">
            <div>
                <h1>Foundation News</h1>
            </div>
            <div>
                <ul class="breadcrumb">
                    <li>Foundation News</li>
                    <?php
                    $Role_Id = $this->session->userdata('Role_Id');
                    $dashboardUrl = DASHBOARD_URL;
                    ?>
                    <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="clearfix"></div>
            <div class="col-md-12">
                <div class="card">
                    <div class="row"><br>
                        <div class="col-lg-8 m-t-25">
                            <div class="well bs-component">
                                <?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
                                <?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
<?php $action = EDIT_FOUNDATION_URL.'/'.$celebrityId; ?>
                                <form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data" >
                                    <div id="Error"></div>
                                    <fieldset>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Foundations Title</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="edit_foundation_title"   name="edit_foundation_title" value="<?php if(@$details->f_title){echo $details->f_title;}else{echo "";}?>" type="text"  placeholder="Wishes Title" required>
                                            </div>
                                        </div>
											<?php if(@$details->f_thumb_image){?>
										<div class="form-group" id="image">
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="thumb">Thumb Image</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="edit_thumb_image" name="edit_thumb_image" value="" <?php if($details->f_thumb_image){echo $details->f_thumb_image;}else{echo "required";}?> type="file">
                                                </div>
                                            </div>
											<?php } 
											if($details->f_article_type == 14){ ?>
										   <div class="form-group" >
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="imagename">Foundations Image</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="edit_foundation_image_video" name="edit_foundation_image_video" value=""<?php if(@$details->f_image){echo $details->f_image;}else {echo "required";}?> type="file">
                                                </div>
                                            </div>
											<?php }else{ ?>
												<div class="form-group" >
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="imagename">Foundations video</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="edit_foundation_image_video" name="edit_foundation_image_video" value=""<?php if(@$details->f_video){echo $details->f_video;}else {echo "required";}?> type="file">
                                                </div>
                                            </div>
											<?php } ?>
                                        <div class="form-group" id="content">
                                            <label class="col-lg-2 control-label" for="inputEmail">Foundations Content</label>
                                            <div class="col-lg-8">
                                                <textarea placeholder="Wishes content" class="form-control" id="edit_foundation_content"  name="edit_foundation_content" value=""  required><?php if(@$details->f_content){echo $details->f_content;}else{echo "";}?></textarea>
                                            </div>
                                        </div>
										<input type="hidden" id="edit_foundation_id" name="edit_foundation_id" value="<?php echo @$details->f_id;?>">
										<input type="hidden" id="type" name="type" value="<?php echo @$details->f_article_type;?>">
                                        </div>
                                        <div id="append"></div>
                                        <div id="trending">&nbsp;</div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">&nbsp;</label>
                                            <div class="col-lg-8"><input type="submit" name="editFoundation" value="submit" class="btn btn-danger" ></input></div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
