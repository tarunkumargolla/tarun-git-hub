<!DOCTYPE html>
<html>
    <style>
        .animated {
            -webkit-animation-duration: 10s;animation-duration: 10s;
            -webkit-animation-fill-mode: both;animation-fill-mode: both;
        }
        @-webkit-keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        @keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        .fadeOut {
            -webkit-animation-name: fadeOut;
            animation-name: fadeOut;
        }
    </style>
    <?php $this->load->view('sideMenu');
    $this->load->view('scripts'); ?>
    <div class="content-wrapper">
        <div class="page-title">
            <div>
                <h1>Foundations</h1>
            </div>
            <div>
                <ul class="breadcrumb">
                    <li>Add Foundations News</li>
                    <?php
                    $Role_Id = $this->session->userdata('Role_Id');
                    $dashboardUrl = DASHBOARD_URL;
                    ?>
                    <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="clearfix"></div>
            <div class="col-md-12">
                <div class="card">
                    <div class="row"><br>
                        <div class="col-lg-8 m-t-25">
                            <div class="well bs-component">
                                <?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
                                <?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
                                <?php $action = ADD_FOUNDATION_URL.'/'.$celebrityId; ?>
                                <form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data" >
                                    <div id="Error"></div>
                                    <fieldset>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Foundations Title</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="foundation_title"   name="foundation_title" value="" type="text"  placeholder="Foundation Title" required>
                                            </div>
                                        </div>
										<div class="form-group" >
                                                <label class="col-lg-2 control-label"  for="inputEmail" > Select file Type </label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" id="type" name="type" onchange="show()"required>
													<option value="">Select Option </option>
													<option value="14"> Foundation with image </option>
													<option value="17"> Foundation with video </option>
													</select>
                                                </div>
                                            </div>
										<div class="form-group" id="thumbimage">
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="thumb">Thumb Image</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="thumb_image" name="thumb_image" onchange='checkFile(this.id)' value="" type="file">
                                                </div>
                                            </div>
											<div class="form-group" id="video">
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="imagename">Foundations video</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="foundation_video" name="foundation_video" onchange='checkFile(this.id)' value="" type="text" >
                                                </div>
                                            </div>
                                        <div class="form-group" id="content">
                                            <label class="col-lg-2 control-label" for="inputEmail">Foundations Content</label>
                                            <div class="col-lg-8">
                                                <textarea placeholder="Foundation content" class="form-control" id="foundation_content"  name="foundation_content" value=""  required></textarea>
                                            </div>
                                        </div>
										<div class="form-group" id="image">
                                                <label class="col-lg-2 control-label"  for="inputEmail" ><div id="imagename">Foundations Image</div></label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" id="foundation_image" name="foundation_image[]" onchange='checkFile(this.id)' value="" type="file" >
                                                </div>
                                            </div>
											<div id="append"></div>
                                        <div class="form-group" id="more">
                                            <button type="button" id="addNewImage"  class="text-center">More Images</button>
                                        </div>
                                        </div>
                                        <div id="append"></div>
                                        <div id="trending">&nbsp;</div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">&nbsp;</label>
                                            <div class="col-lg-8"><input type="submit" name="addFoundation" value="submit" class="btn btn-danger" ></input></div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
<script>
$('#thumbimage').hide();
$('#video').hide();
function show(){
	var type = $('#type').val();
	if(type == 14){
		$('#video').hide();
		$('#thumbimage').hide();
		$('#image').show();
		$('#more').show();
	}
	else if(type == 17){
		$('#video').show();
		$('#image').hide();
		$('#thumbimage').show();
		$('#more').hide();
	}
	else{
		$('#thumbimage').hide();
		$('#video').hide();
	}
}
    $(document).ready(function () {
        $("#addNewImage").click(function () {
            var len = $("div[id*='image']").length;
            len = len + 1;
            $("#image").append("<div class='form-group' id='file" + len + "'><label class='col-lg-2 control-label'  for='inputEmail' >Foundation Image</label><div class='col-lg-8'id='image'><input class='form-control'  name='foundation_image[]' id='file" + len + "' onchange='checkFile(this.id)' type='file' required><a href='javascript:void(0);' id=" + len + "   onclick='deleteRow(" + len + ")'>close</a></div></div>");
        });
    });
    function deleteRow(len) {
        var id = "file" + len;
        $('#' + id).remove();
        var id1 = len;
        $('#' + id1).remove();
    }
function checkFile(id) {
        var files = $('#' + id).get(0).files;
        for (var i = 0; i < files.length; i++) {
            var article = $("#type").val();
            var file = files[i];
            var name = file.name;
            var size = file.size;
            var type = file.type;
          
                if (file.type.match('image')) {

                } else {
                    document.getElementById(id).value = null;
                    $('#' + id).focus();
                    $('#' + id).after('<p class="animated fadeOut" style="color: red;">Select image files only</p>');

                }
        }
    }
</script>