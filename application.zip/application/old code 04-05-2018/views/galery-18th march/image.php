<?php $this->load->view('sideMenu');
$this->load->view('scripts'); ?>
<div class="content-wrapper">
    <div class="page-title">
        <div>
            <h1> </h1>
        </div>
        <div>
            <ul class="breadcrumb">
                <li>Image</li>
<?php $dashboardUrl = DASHBOARD_URL; ?>
                <li><a href="<?php echo $dashboardUrl; ?>">Dashboard</a></li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-md-12">

            <h1 class="table_title">Image DATA</h1>
            <div class="title_separator"></div>
			<ol>
                            <?php
                            if($titles) {
                                foreach ($titles as $title) {
                                        
                                    ?>
							<div><i><li><a href="<?php echo IMAGE_DATA_URL.'/'.$title->news_title.'/'.$celebrityId;?>"><?php echo $title->news_title;?></a></li><i></div><?php }}?>
							</ol>
            </div>
			 <?php
                            if($videotitles) {?>
			<h1 class="table_title">Video DATA</h1>
            <div class="title_separator"></div>
            
            <div class="main_table">
                <div class="table-responsive">
                    <br><br>
					<ol>
                              <?php
                                foreach ($videotitles as $videotitle) {
                                          
                                    ?>
							<div><li><i><a href="<?php echo VIDEO_DATA_URL.'/'.$videotitle->news_title.'/'.$celebrityId.'/'.$videotitle->news_id;?>"><?php echo $videotitle->news_title;?></a></i></li></div><?php }}?>
							</ol>
    </div>
</div>
			</div>