<?php $this->load->view('sideMenu');
$this->load->view('scripts'); ?>
<div class="content-wrapper">
    <div class="page-title">
        <div>
            <h1> </h1>
        </div>
        <div>
            <ul class="breadcrumb">
                <li>Image</li>
<?php $dashboardUrl = DASHBOARD_URL; ?>
                <li><a href="<?php echo $dashboardUrl; ?>">Dashboard</a></li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-md-12">

            <h1 class="table_title">Image DATA</h1>
			<?php if(empty($newsId)){?>
			<div><a href="<?php echo IMAGE_URL.'/'.$celebrityId;?>">Back To Galery</a></div>
			<?php }else{?>
			<div><a href="<?php echo NEWS_URL.'/'.$celebrityId;?>">Back To News</a></div>
			<?php }?>
            <div class="title_separator"></div>
            
            <div class="main_table">
                <div class="table-responsive">
                    <br><br>
					<?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
					<?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
                    <table id="myTable" class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" width="100%" > 
                        <thead>
                            <tr class="title_head">
                                <th width="5%" class="text-center">S.No</th>
                                <th width="15%" class="text-center">Images</th>
								 <th width="15%" class="text-center">Actions</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
							$dirname = '../uploads/news/'.$title.'/';
							$i = 1;
		                             foreach(glob($dirname."{*.jpg,*.png,*.gif}",GLOB_BRACE) as $imagename){
                                         $image = str_ireplace(".."," ",$imagename);
										 
                                    ?>
									
                                    <tr>
                                        <td><?php echo $i; ?></td>
										<?php if(empty($newsId)){?>
										 <td><img src="<?php echo FRONT_FOLDER.$image; ?>" width="100" height="100"></td>
										<?php }else{?>
										 <td><img src="<?php echo FRONT_FOLDER.$image; ?>" width="100" height="100"></td>
										<?php }?>
                                        <td class="text-center"><a href="javascript:void(0)"><i class="fa fa-trash-o" aria-hidden="true"  onclick="deleteImage('<?php echo $imagename;?>',<?php echo $newsId;?>,<?php echo $celebrityId;?>)"></i></a>
                                        </td>
                                    </tr>
									
        <?php $i++;
    }
							 ?>

                        </tbody>
                    </table>
                </div>
            </div><br><br><br><br>
            <div class="clearfix"></div>

        </div>
    </div>
</div>
<script>
function deleteImage(image,id,celebrityId){
	var ok = confirm("Are you sure to Delete?"); 
       if (ok) {
	          $.ajax({
                    type: "POST",
                    url:'<?php echo DELETE_FOLDER_IMAGE_URL ?>', 
				    data: {'path':image,'newsId':id,'celebrityId':celebrityId},
					dataType:'json',
                    success: function(response){
						 location.reload(); 
						
                    },
				    error: function(xhr, statusText, err){
                              console.log("Error:" + xhr.status);  
				    }
						
                });
	   }
 				
  return false;
}
</script>