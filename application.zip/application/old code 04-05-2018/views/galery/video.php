<?php $this->load->view('sideMenu');
$this->load->view('scripts'); ?>
<div class="content-wrapper">
    <div class="page-title">
        <div>
            <h1> </h1>
        </div>
        <div>
            <ul class="breadcrumb">
                <li>Video</li>
<?php $dashboardUrl = DASHBOARD_URL; ?>
                <li><a href="<?php echo $dashboardUrl; ?>">Dashboard</a></li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-md-12">

            <h1 class="table_title">Video DATA</h1>
            <div class="title_separator"></div>
            
            <div class="main_table">
                <div class="table-responsive">
                    <br><br>
					<ol>
                              <?php
                            if($titles) {
                                foreach ($titles as $title) {
                                          
                                    ?>
							<div><li><i><a href="<?php echo VIDEO_DATA_URL.'/'.$title->news_title;?>"><?php echo $title->news_title;?></a></i></li></div><?php }}?>
							</ol>
    </div>
</div>
