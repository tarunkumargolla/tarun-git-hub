<?php $this->load->view('sideMenu');
$this->load->view('scripts'); ?>
<div class="content-wrapper">
    <div class="page-title">
        <div>
            <h1> </h1>
        </div>
        <div>
            <ul class="breadcrumb">
                <li>Video</li>
<?php $dashboardUrl = DASHBOARD_URL; ?>
                <li><a href="<?php echo $dashboardUrl; ?>">Dashboard</a></li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-md-12">

            <h1 class="table_title">Video DATA</h1>
			<div><a href="<?php echo IMAGE_URL.'/'.$celebrityId;?>">Back To Galery</a></div>
            <div class="title_separator"></div>
            
            <div class="main_table">
                <div class="table-responsive">
                    <br><br>
					<?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
					<?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
                    <table id="myTable" class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" width="100%" > 
                        <thead>
                            <tr class="title_head">
                                <th width="5%" class="text-center">S.No</th>
                                <th width="15%" class="text-center">Videos</th>
								 <th width="15%" class="text-center">Actions</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
							if($videoDetails){
							$i=1;
							foreach($videoDetails as $Details){
                                           
                                    ?>
                                    <tr>
                                        <td><?php echo $i;?></td>
										<?php if($Details->nvVideoUrl){?>
                                       <td><a href="https://www.youtube.com/watch?v<?php echo $Details->nvVideoUrl;?>"><img src="<?php echo FSITEURL.'/uploads/videos/'.$Details->nvVideoThumbnail;?>"width="100" height="100"></td>
										<?php } else{?>
										<td><video width="100" height="100" controls><source src="<?php echo FSITEURL.'/uploads/videos/'.$Details->nvVideo;?>"></video></td>
										<?php } ?>
                                        <td class="text-center"><a href="javascript:void(0)"><i class="fa fa-trash-o" aria-hidden="true"  onclick="deleteImage(<?php echo $Details->nvVideoID;?>,<?php echo $Details->nvNewsID;?>,<?php echo $newsDetails->news_article_type;?>)"></i></a>
                                        </td>
                                    </tr>
										<?php $i++;
						   }}?>

                        </tbody>
                    </table>
                </div>
            </div><br><br><br><br>
            <div class="clearfix"></div>

        </div>
    </div>
</div>
<script>
function deleteVideo(id){
	var ok = confirm("Are you sure to Delete?"); 
       if (ok) {
	          $.ajax({
                    type: "POST",
                    url:'<?php echo DELETE_FOLDER_VIDEO_URL ?>', 
				    data: {'id':id},
					dataType:'json',
                    success: function(response){
						 location.reload();   
                    },
				    error: function(xhr, statusText, err){
                              console.log("Error:" + xhr.status);  
				    }
						
                });
	   }
 				
  return false;
}
</script>