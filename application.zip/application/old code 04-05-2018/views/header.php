<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSS-->
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">   
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <link rel="stylesheet"  href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script> 
    <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>/main.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="<?php echo ASITEURL ?>/assets/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
       <link href="<?php echo ASITEURL ?>/assets/bootstrap-datetimepicker/css/bootstrap-datetimepicker.css" rel="stylesheet" type="text/css">   <title>Celebstars</title>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries-->
    <!--if lt IE 9
    script(src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js')
    script(src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js')
    -->
  </head>
  <style>
         .animated {
           -webkit-animation-duration: 10s;animation-duration: 10s;
           -webkit-animation-fill-mode: both;animation-fill-mode: both;
         }
         @-webkit-keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
         }
         
         @keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
         }
         
         .fadeOut {
            -webkit-animation-name: fadeOut;
            animation-name: fadeOut;
         }
      </style>
  <body class="sidebar-mini fixed">
    <div class="wrapper">
      <!-- Navbar-->
	  	<?php 
	$Role_Id=$this->session->userdata('Role_Id');
	
   if($Role_Id == 1){
   $dashboardUrl=DASHBOARD_URL;}
   else{$dashboardUrl=CELEBRITY_ADMIN_DASHBOARD_URL;}
   if($Role_Id == 1){
   $logoutUrl=LOGOUT_URL;}
   else{
	 $logoutUrl=ADMIN_LOGOUT_URL;  
   }
		if($Role_Id == 1){
		$profileUrl=PROFILE_URL;}
		else{
			$profileUrl=ADMIN_PROFILE_URL;
		}
		if($Role_Id == 1){
		$changePwdUrl=CHANGEPASSWORD_URL;;}
		else{
			$changePwdUrl=ADMIN_CHANGEPASSWORD_URL;
		}
		
	
	if($this->session->userdata('User_Name')){
		$name=$this->session->userdata('User_Name');
	} else{
		$name="superadmin";
	}

	?>
	  <script>
           var baseUrl= "<?php echo SITEURL ?>";
		</script>
      <header class="main-header hidden-print"><a class="logo" href="<?php echo  $dashboardUrl; ?>">Celebstars</a>
        <nav class="navbar navbar-static-top">
          <!-- Sidebar toggle button--><a class="sidebar-toggle" href="#" data-toggle="offcanvas"></a>
          <!-- Navbar Right Menu-->
          <div class="navbar-custom-menu">
            <div class="top-nav dropdown">
              <!-- User Menu-->
            <a class="dropdown-toggle" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="color:#333;"><div class="pull-left image"><img class="img-circle mt-5" width="40" src="<?php echo IMG_URL ?>/default_profile_img.png" alt="User Image"></div>
            <div class="pull-left info">
              <span style="line-height: 50px;margin-left: 10px;"><?php echo @$name; ?></span> <i class="fa fa-sort-desc" aria-hidden="true"></i>
            </div></a>
                <ul class="dropdown-menu settings-menu">
                  <li><a href="<?php echo $changePwdUrl ?>"><i class="fa fa-cog fa-lg"></i> Chnage Password</a></li>
                  <li><a href="<?php echo $profileUrl ?>"><i class="fa fa-user fa-lg"></i> Profile</a></li>
                  <li><a href="<?php echo $logoutUrl; ?>"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
                </ul>
            </div>
          </div>
        </nav>
      </header>