<!DOCTYPE html>
<html>
 <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>/main.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Celebstarts</title>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries-->
    <!--if lt IE 9
    script(src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js')
    script(src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js')
    -->
  </head>
    <?php @$agent=$this->uri->segment(1);?>
  <body>
    <section class="material-half-bg" style="background:#f9f9f9;">
    </section>
	
    <section class="login-content">
      <div class="logo">
        <!--<img src="<?php echo IMG_URL ?>/login_logo.png" alt="" title="" width="130">-->
      </div>
	   <?php if($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php  echo $this->session->flashdata('Smessage');?></div><?php } ?>
        <?php  if($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage');?></div><?php } ?>
      <div class="login-box">
        <form class="login-form" action=""  method="post" >
          <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>SIGN IN</h3>
		  <?php if($agent){ ?>
          <div class="form-group">
            <label class="control-label">USERNAME or PHONE</label>
		   <?php $cookie_user_name = $this->input->cookie('superadmin_name'); ?>
            <input class="form-control" type="text" name="Email_OR_phone" value="<?php if(!empty($cookie_user_name)){
				  echo $this->input->cookie('superadmin_name',true);
				 }
			  ?>" placeholder="Email" autofocus>
          </div>
          <div class="form-group">
            <label class="control-label">PASSWORD</label>
             <?php  $cookie_password = $this->input->cookie('superadmin_password'); ?>
            <input class="form-control" type="password" name="password" placeholder="Password" value="<?php if(!empty($cookie_password)){
				  echo $this->input->cookie('superadmin_password',true);
				 }
			  ?>" />
          </div>
          <div class="form-group">
            <div class="utility">
              <div class="animated-checkbox">
                <label class="semibold-text">
                  <input type="checkbox" id="inlineCheckbox3" name="remember" value="1" onclick="$(this).attr('value', this.checked ? 1 : 0)" <?php if($this->input->cookie('superadmin_remember')==1) echo 'checked'; ?> 
                    value="<?php echo $this->input->cookie('superadmin_remember')?>"><span class="label-text">Stay Signed in</span>
                </label>
              </div>
			
              <!--<p class="small mb-0"><a data-toggle="flip">Forgot Password ?</a></p>-->
			 
            </div>
          </div>
		  <?php } else{ ?>
			  <div class="form-group">
            <label class="control-label">USERNAME or PHONE</label>
		   <?php $cookie_user_name = $this->input->cookie('admin_Name'); ?>
            <input class="form-control" type="text" name="Email_OR_phone" value="<?php if(!empty($cookie_user_name)){
				  echo $this->input->cookie('admin_Name',true);
				 }
			  ?>" placeholder="Email" autofocus>
          </div>
          <div class="form-group">
            <label class="control-label">PASSWORD</label>
             <?php  $cookie_password = $this->input->cookie('admin_password'); ?>
            <input class="form-control" type="password" name="password" placeholder="Password" value="<?php if(!empty($cookie_password)){
				  echo $this->input->cookie('admin_password',true);
				 }
			  ?>" />
          </div>
          <div class="form-group">
            <div class="utility">
              <div class="animated-checkbox">
                <label class="semibold-text">
                  <input type="checkbox" id="inlineCheckbox3" name="remember" value="1" onclick="$(this).attr('value', this.checked ? 1 : 0)" <?php if($this->input->cookie('admin_remember')==1) echo 'checked'; ?> 
                    value="<?php echo $this->input->cookie('admin_remember')?>"><span class="label-text">Stay Signed in</span>
                </label>
              </div>
              <!--<p class="small mb-0"><a data-toggle="flip">Forgot Password ?</a></p>-->
            </div>
          </div>
			  
		 <?php  }?>
          <div class="form-group btn-container">
            <button type="submit" class="btn btn-danger btn-block">SIGN IN</button>
          </div>
        </form>
        <form class="forget-form" method="post" action="<?php echo FORGOT_PASSWORD_URL;?>">
          <h3 class="login-head"><i class="fa fa-lg fa-fw fa-lock"></i>Forgot Password ?</h3>
          <div class="form-group">
            <label class="control-label">EMAIL</label>
            <input class="form-control" type="text" name="emailId" placeholder="Email">
          </div>
          <div class="form-group btn-container">
            <button class="btn btn-primary btn-block" type="submit" value="submit">RESET<i class="fa fa-unlock fa-lg"></i></button>
          </div>
          <div class="form-group mt-20">
            <p class="semibold-text mb-0"><a data-toggle="flip"><i class="fa fa-angle-left fa-fw"></i> Back to Login</a></p>
          </div>
        </form>
      </div>
    </section>
  </body>
 <script src="<?php echo JS_URL ?>/jquery-2.1.4.min.js"></script>
 <script src="<?php echo JS_URL ?>/bootstrap.min.js"></script>
<script src="<?php echo JS_URL ?>/plugins/pace.min.js"></script>
<script src="<?php echo JS_URL ?>/main.js"></script>
</html>