<!DOCTYPE html>
<html>
<?php $this->load->view('calender'); ?>
    <style>
        .animated {
            -webkit-animation-duration: 10s;animation-duration: 10s;
            -webkit-animation-fill-mode: both;animation-fill-mode: both;
        }
        @-webkit-keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        @keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        .fadeOut {
            -webkit-animation-name: fadeOut;
            animation-name: fadeOut;
        }
    </style>
    <?php $this->load->view('sideMenu');
    $this->load->view('scripts'); ?>
    <div class="content-wrapper">
        <div class="page-title">
            <div>
                <h1>Movie Trailer</h1>
            </div>
            <div>
                <ul class="breadcrumb">
                    <li>Add Movie Trailer</li>
                    <?php
                    $Role_Id = $this->session->userdata('Role_Id');
                    $dashboardUrl = DASHBOARD_URL;
                    ?>
                    <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="clearfix"></div>
            <div class="col-md-12">
                <div class="card">
                    <div class="row"><br>
                        <div class="col-lg-8 m-t-25">
                            <div class="well bs-component">
                                <?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
                                <?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
<?php $action = ADD_TRAILER_URL.'/'.$id; ?>
                                <form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data" >
                                    <div id="Error"></div>
                                    <fieldset>
									 <div class="form-group" id="thumb">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Thumb Image</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="thumb_image"   name="thumb_image[]" value="" type="file"  placeholder="Movie Title" required>
                                            </div>
                                        </div>
                                        <div class="form-group" id="title">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Title</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="trailer_title"   name="trailer_title[]" value="" type="text"  placeholder="trailer title" required>
                                            </div>
                                        </div>
										<div class="form-group" id="trailer">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Trailer </label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="movie_trailer"   name="movie_trailer[]" value="" type="text"  placeholder="movie_trailer" required><br>
                                            </div>
                                        </div>
										
										<div>
                                            <button type="button" id="addNewTrailer"  class="text-center">More Trailer</button>
                                        </div>
                                        <div id="trending">&nbsp;</div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">&nbsp;</label>
                                            <div class="col-lg-8"><input type="submit" name="addTrailer" value="Proceed" class="btn btn-danger" ></input></div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- Javascripts-->
<script>

    $(document).ready(function () {
		 $("#addNewTrailer").click(function () {
            var len = $("div[id*='trailer']").length;
			if(len == 5){
			$('#addNewTrailer').hide();
		}
            len = len + 1;
            $("#trailer").append("<div class='form-group' id='text" + len + "'><div class='form-group' id='thumb'><label class='col-lg-2 control-label'  for='inputEmail' >Thumb Image</label><div class='col-lg-8'id='title'><input class='form-control'  name='thumb_image[]' id='text" + len + "' onchange='checkFile(this.id)' type='file' required></div></div><div class='form-group' id='title'><label class='col-lg-2 control-label' for='inputEmail' >Title</label><div class='col-lg-8'id='title'><input class='form-control' name='trailer_title[]' id='text" + len + "' onchange='checkFile(this.id)' type='text' placeholder='Trailer Title' required></div></div><div class='form-group' id='trailer'><label class='col-lg-2 control-label'  for='inputEmail' >Trailer</label><div class='col-lg-8'id='title'><input class='form-control'  name='movie_trailer[]' id='text" + len + "' onchange='checkFile(this.id)' type='text' placeholder='Trailer' required><a href='javascript:void(0);'    onclick='deleteRow(" + len + ")'>close</a></div></div></div>");
        });
    });
    function deleteRow(len) {
        var id = "file" + len;
        $('#' + id).remove();
        var id1 = len;
        $('#' + id1).remove();
		 var id = "text" + len;
        $('#' + id).remove();
        var id2 = len;
        $('#' + id2).remove();
		
    }

</script>
</body>
</html>