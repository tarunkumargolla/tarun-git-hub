<!DOCTYPE html>
<html>
<?php $this->load->view('calender'); ?>
    <style>
        .animated {
            -webkit-animation-duration: 10s;animation-duration: 10s;
            -webkit-animation-fill-mode: both;animation-fill-mode: both;
        }
        @-webkit-keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        @keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        .fadeOut {
            -webkit-animation-name: fadeOut;
            animation-name: fadeOut;
        }
    </style>
    <?php $this->load->view('sideMenu');
    $this->load->view('scripts'); ?>
    <div class="content-wrapper">
        <div class="page-title">
            <div>
                <h1>Movies</h1>
            </div>
            <div>
                <ul class="breadcrumb">
                    <li>Edit Movie</li>
                    <?php
                    $Role_Id = $this->session->userdata('Role_Id');
                    $dashboardUrl = DASHBOARD_URL;
                    ?>
                    <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="clearfix"></div>
            <div class="col-md-12">
                <div class="card">
                    <div class="row"><br>
                        <div class="col-lg-8 m-t-25">
                            <div class="well bs-component">
                                <?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
                                <?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
<?php $action = EDIT_MOVIE_URL.'/'.$details->movie_id.'/'.$celebritys->c_id; ?>
                                   
                                <form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data" >
                                    <div id="Error"></div>
                                    <fieldset>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Movie Title</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="editmovie_title"   name="editmovie_title" value="<?php if($details && $details->movie_title){echo $details->movie_title;}else {echo "";}?>" type="text"  placeholder="News Title" required>
                                            </div>
                                        </div>
										<!-- START -->
										 <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Thumb Image</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="edit_thumb_image"   name="edit_thumb_image" value="" type="file" <?php if($details && $details->movie_thumbnail){echo $details->movie_thumbnail;}else {echo "required";}?> placeholder="News Title" >
                                            </div>
                                        </div>
										<!-- END -->
										     <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> About Movie</label>
                                            <div class="col-lg-8">
                                                <textarea class="form-control" id="editabout_movie"   name="editabout_movie" value="" type="text"  placeholder="About Movie" required><?php if($details->about_movie){echo $details->about_movie;}else {echo "";}?></textarea>
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Directed by</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="editmovie_dir"   name="editmovie_dir" value="<?php if($details->movie_director){echo $details->movie_director;}else {echo "";}?>" type="text"  placeholder="Movie Directer" required>
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Staring</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="editmovie_stars"   name="editmovie_stars" value="<?php if($details->movie_stars){echo $details->movie_stars;}else {echo "";}?>" type="text"  placeholder="Movie Stars" required>
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail">Genre</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="editmovie_genre"   name="editmovie_genre" value="<?php if($details->movie_genre){echo $details->movie_genre;}else {echo "";}?>" type="text"  placeholder="Movie Genre" required>
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Release Date </label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="datepicker"  class="date-control" name="editmovie_rel_date" value="<?php if($details->release_date){echo $details->release_date;}else {echo "";}?>" type="text"  placeholder="Release Date" required>
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Movie  </label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="editmovie_link"   name="editmovie_link" value="<?php if($details->movie_link){echo $details->movie_link;}else {echo "";}?>" type="text"  placeholder="Movie Link" required>
                                            </div>
                                        </div>
										<input type="hidden" id="movie_id" name="editmovie_id" value="<?php echo $details->movie_id;?>">
                                        <div id="trending">&nbsp;</div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">&nbsp;</label>
                                            <div class="col-lg-8"><input type="submit" name="editMovies" value="submit" class="btn btn-danger" ></input></div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- Javascripts-->
<script>

    $(document).ready(function () {
		$("#addNewSong").click(function () {
            var len = $("div[id*='song']").length;
            len = len + 1;
            $("#song").append("<div class='col-lg-8' id='song'   style='margin-left:130px;margin-top:10px;'><input class='form-control' type='text' id='text" + len + "'  name='editsongs_link[]' placeholder='Songs_link'required><a href='javascript:void(0);' id=" + len + "   onclick='deleteRow(" + len + ")'>close</a></div>");
        });
    });
    function deleteRow(len) {
        var id = "file" + len;
        $('#' + id).remove();
        var id1 = len;
        $('#' + id1).remove();
		var id = "text" + len;
        $('#' + id).remove();
        var id2 = len;
        $('#' + id2).remove();
    }

</script>
</body>
</html>