<!DOCTYPE html>
<html>
<?php $this->load->view('calender'); ?>
    <style>
        .animated {
            -webkit-animation-duration: 10s;animation-duration: 10s;
            -webkit-animation-fill-mode: both;animation-fill-mode: both;
        }
        @-webkit-keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        @keyframes fadeOut {
            0% {opacity: 1;}
            100% {opacity: 0;}
        }

        .fadeOut {
            -webkit-animation-name: fadeOut;
            animation-name: fadeOut;
        }
    </style>
    <?php $this->load->view('sideMenu');
    $this->load->view('scripts'); ?>
    <div class="content-wrapper">
        <div class="page-title">
            <div>
                <h1>Movie Trailer</h1>
            </div>
            <div>
                <ul class="breadcrumb">
                    <li>Edit Movie Trailer</li>
                    <?php
                    $Role_Id = $this->session->userdata('Role_Id');
                    $dashboardUrl = DASHBOARD_URL;
                    ?>
                    <li><a href="<?php echo $dashboardUrl ?>">Dashboard</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="clearfix"></div>
            <div class="col-md-12">
                <div class="card">
                    <div class="row"><br>
                        <div class="col-lg-8 m-t-25">
                            <div class="well bs-component">
                                <?php if ($this->session->flashdata('Smessage')) { ?> <div class='alert alert-success'> <?php echo $this->session->flashdata('Smessage'); ?></div><?php } ?>
                                <?php if ($this->session->flashdata('Fmessage')) { ?> <div class='alert alert-danger'> <?php echo $this->session->flashdata('Fmessage'); ?></div><?php } ?>
                                <?php $action = EDIT_TRAILER_URL.'/'.$id; ?>
                                <form class="form-horizontal" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data" >
                                    <div id="Error"></div>
                                    <fieldset>
									<?php if($Details){$i=1;
										foreach($Details as $details){?>
									
									 <div class="form-group" id="thumb">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Thumb Image</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="edit_thumb_image"   name="edit_thumb_image[]" value="" <?php if($details->mv_t_thumbnail){echo $details->mv_t_thumbnail;}else{echo "required";}?> type="file"   >
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Title </label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="edit_trailer_title"   name="edit_trailer_title[]" value="<?php if($details->mv_t_title){echo $details->mv_t_title;}else{echo "";}?>" type="text"  placeholder="edit_trailer_title" required><a onclick="deleteTrailer(<?php echo $details->mv_t_id; ?>)"><img  src='<?php echo ASSETS_URL; ?>/images/close.jpg' width="20" height="20" style="margin:10px"></a>
                                            </div>
                                        </div>
										<div class="form-group" id="trailer">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Trailer </label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="edit_movie_trailer"   name="edit_movie_trailer[]" value="<?php if($details->mv_trailer){echo $details->mv_trailer;}else{echo "";}?>" type="text"  placeholder="edit_movie_trailer" required><br>
                                            </div>
                                        </div>
										<input type="hidden" id="trailer_id" name="trailer_id[]" value="<?php if($details->mv_t_id){echo $details->mv_t_id;}else{echo " ";}?>">
									<?php $i++;}?>
									<div id="trending">&nbsp;</div>
									<div>
                                            <button type="button" id="addNewTrailer"  class="text-center">More Trailer</button>
                                        </div>
									<?php } else{?>
									<div class="form-group" id="thumb">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Thumb Image</label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="edit_thumb_image"   name="edit_thumb_image[]" value="" type="file"   >
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Title </label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="edit_trailer_title"   name="edit_trailer_title[]" value="" type="text"  placeholder="edit_trailer_title" required>
                                            </div>
                                        </div>
										<div class="form-group" id="trailer">
                                            <label class="col-lg-2 control-label" for="inputEmail"> Trailer </label>
                                            <div class="col-lg-8">
                                                <input class="form-control" id="edit_movie_trailer"   name="edit_movie_trailer[]" value="" type="text"  placeholder="edit_movie_trailer" required><br>
                                            </div>
                                        </div>
										<div id="trending">&nbsp;</div>
									<div>
                                            <button type="button" id="addNewTrailer"  class="text-center">More Trailer</button>
                                        </div>
										<?php } ?>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">&nbsp;</label>
                                            <div class="col-lg-8"><input type="submit" name="editTrailer" value="Proceed" class="btn btn-danger" ></input></div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- Javascripts-->
<script>

    $(document).ready(function () { 
		 $("#addNewTrailer").click(function () {
            var len = $("div[id*='trailer']").length;
            len = len + 1;
            $("#trending").append("<div class='form-group' id='file" + len + "'><div class='form-group' id='thumb'><label class='col-lg-2 control-label'  for='inputEmail' >Thumb Image</label><div class='col-lg-8'id='title'><input class='form-control'  name='edit_thumb_image[]' id='file" + len + "' onchange='checkFile(this.id)' type='file' required></div></div><div class='form-group' id='title'><label class='col-lg-2 control-label' for='inputEmail' >Trailer Title</label><div class='col-lg-8'id='title'><input class='form-control' name='edit_trailer_title[]' id='file" + len + "' onchange='checkFile(this.id)' type='text' placeholder='Trailer Title' required></div></div><div class='form-group' id='trailer'><label class='col-lg-2 control-label'  for='inputEmail' >Trailer</label><div class='col-lg-8'id='title'><input class='form-control'  name='edit_movie_trailer[]' id='file" + len + "' onchange='checkFile(this.id)' type='text' placeholder='Trailer' required><a href='javascript:void(0);'    onclick='deleteRow(" + len + ")'>close</a></div></div></div>");
        });
    });
    function deleteRow(len) {
        var id = "file" + len;
        $('#' + id).remove();
        var id1 = len;
        $('#' + id1).remove();
    } 
	function deleteTrailerRow(len) {
        var id = "trailer" + len;
        $('#' + id).remove();
        
    }
function deleteTrailer(id){alert(id);
	var ok = confirm("Are you sure to Delete?"); 
       if (ok) {
	          $.ajax({
                    type: "POST",
                    url:'<?php echo DELETE_TRAILER_URL ?>', 
				    data: {'id':id},
					//dataType:'json',
                    success: function(response){alert(response);
						 location.reload();  
                    },
				    error: function(xhr, statusText, err){
                              console.log("Error:" + xhr.status);  
				    }
						
                });
	   }
 				
  return false;
}
</script>
</body>
</html>