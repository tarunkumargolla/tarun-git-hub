<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
<?php $this->load->view('sideMenu');
$this->load->view('scripts'); ?>
<div class="content-wrapper">
    <div class="page-title">
        <div>
            <h1> </h1>
        </div>
        <div>
            <ul class="breadcrumb">
                <li>Movies</li>
<?php $dashboardUrl = DASHBOARD_URL; ?>
                <li><a href="<?php echo $dashboardUrl; ?>">Dashboard</a></li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-md-12">

            <h1 class="table_title">Movies Details</h1>
            <div class="title_separator"></div>
            <div>
            </div>
            <div class="main_table">
                <div class="table-responsive">
                    <br><br>
					<div class="topnav">
					  <a class="active" href="<?php echo ABOUT_MOVIE_URL.'/'.$id;?>">About Movie</a>
					  <a href="<?php echo MOVIE_IMAGES_LIST_URL.'/'.$id;?>">Images</a>
					  <a href="<?php echo MOVIE_SONGS_URL.'/'.$id;?>">Songs</a>
					  <a href="<?php echo MOVIE_TRAILER_URL.'/'.$id;?>">Trailer</a>
					   <a href="<?php echo FULL_MOVIE_URL.'/'.$id;?>">Movie</a>
					</div>
                </div>
			<br><br><br><br>
            <div class="clearfix"></div>
        </div>
    </div>
</div>