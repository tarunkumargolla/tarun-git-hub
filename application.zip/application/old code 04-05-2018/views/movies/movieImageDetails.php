<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
<?php $this->load->view('sideMenu');
$this->load->view('scripts'); 
$mvi_id = $this->uri->segment(3);
?>
<div class="content-wrapper">
    <div class="page-title">
        <div>
            <h1> </h1>
        </div>
        <div>
            <ul class="breadcrumb">
                <li>Movies</li>
<?php $dashboardUrl = DASHBOARD_URL; ?>
                <li><a href="<?php echo $dashboardUrl; ?>">Dashboard</a></li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-md-12">

            <h1 class="table_title">Movies Image Details</h1>
            <div class="title_separator"></div>
			<div>
                <a class="btn btn-info color_btn" href="<?php echo ADD_GALLERY_IMAGES_URL.$mvi_id; ?>">ADD</a>

            </div>
            <div>
            </div>
           
    <ol>
	
   <?php if($mvi_titles){
   foreach($mvi_titles as $mImgTitle){
	   ?>
       <li><a href="<?php echo MOVIE_IMAGE_DATA_URL.'/'.$mImgTitle->mvi_img_id;?>"><?php  echo $mImgTitle->mvi_title; ?></a></li>
	   <div><a href="<?php echo EDIT_GALLERY_IMAGES_URL . $mImgTitle->mvi_img_id; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
	   <a href="javascript:void(0)"><i class="fa fa-trash-o" aria-hidden="true"  onclick="deleteGalery('<?php  echo $mImgTitle->mvi_title; ?>',<?php echo $mImgTitle->mvi_img_id;?>)"></i></a></div>
   <?php  }} ?>
    </ol>
			<br><br><br><br>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<script>
function deleteGalery(title,id){
	var ok = confirm("Are you sure to Delete?"); 
       if (ok) {
	          $.ajax({
                    type: "POST",
                    url:'<?php echo DELETE_GALLERY_IMAGES_URL ?>', 
				    data: {'title':title,'id':id},
					//dataType:'json',
                    success: function(response){
						 location.reload(); 
						
                    },
				    error: function(xhr, statusText, err){
                              console.log("Error:" + xhr.status);  
				    }
						
                });
	   }
 				
  return false;
}
</script>